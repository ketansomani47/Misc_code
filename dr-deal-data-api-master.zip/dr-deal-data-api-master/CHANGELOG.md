# Changelog

## [1.22.9](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/compare/v1.22.8...v1.22.9) (2024-11-26)


### CI configuration

* **US1514978:** fix copyPaste for k6 script ([#1199](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1199)) ([6d06efa](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/6d06efa194890a5cb4e7153fe0b5556094908be4))
* **US1514978:** Fix variables naming for k6 script ([#1201](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1201)) ([c0c7c34](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/c0c7c34c6cbf0a186720b03fa12c3ef3a65f3377))

## [1.22.8](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/compare/v1.22.7...v1.22.8) (2024-11-25)


### Automated tests

* **TA3094173:** Fix lead test with v2 support ([#1197](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1197)) ([d88aa64](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/d88aa64c6c8c3feb9a94fc5a6bf0c19b136f53c9))

## [1.22.7](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/compare/v1.22.6...v1.22.7) (2024-11-22)


### CI configuration

* **TA3092631:** Adding test part of release-please ([#1195](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1195)) ([003e6ca](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/003e6cac4904a0fcc17619a933ece3882c5b2eb0))


### Automated tests

* **US1514978:** Fix for k6 action ([#1194](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1194)) ([09bbe1b](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/09bbe1b4e6480d9697df7f6791ebb0b4e4737955))
* **US1514978:** Git action for pa test ([#1191](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1191)) ([9be47d6](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/9be47d6dc9303830a44acba103b5510375d2410c))
* **US1514978:** Removing git token to k6 ([#1193](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1193)) ([28f4aba](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/28f4abad7e272ceecd291b13f958d97a7f583985))

## [1.22.6](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/compare/v1.22.5...v1.22.6) (2024-11-15)


### CI configuration

* **US1505966:** Making unit tests, pre-commit and pr-limit required for all PRs ([#1189](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1189)) ([bc8a615](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/bc8a615a8985296b759e7479fed3bbca6e73103f))


### Bug Fixes

* **TA3085015:** [PYNEERS] Updated eventID validation from ULID to UUID ([#1187](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1187)) ([27c5314](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/27c53142d8581763511233c4b39c071aab12a70b))
* **US1516375:** Turn on HighThroughPut for SQS ([#1190](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1190)) ([9304bf1](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/9304bf146234ca4c5092180e4614d6c0d87adcdc))

## [1.22.5](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/compare/v1.22.4...v1.22.5) (2024-11-13)


### CI configuration

* **US1505966:** Auto deploy to dev on merge of release please PR ([#1185](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1185)) ([0bdef4e](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/0bdef4e4435a6ee5bc6f6337beaa7c8bd3c8cb38))

## [1.22.4](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/compare/v1.22.3...v1.22.4) (2024-11-07)


### CI configuration

* **US1505966:** Clean up Jenkins and unwanted files ([#1181](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1181)) ([ea24022](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/ea240224a419e5985be4247c025f36f6cbadd58e))


### Routine Maintenance

* **US0000000:** [Update] Python requirements ([#1182](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1182)) ([93fdadb](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/93fdadb6ccbbcdc7b92d524709a256b14d335a38))

## [1.22.3](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/compare/v1.22.2...v1.22.3) (2024-10-29)


### Bug Fixes

* **US1468443:** Move region from param to options in serverless ([#1177](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1177)) ([5ef3cd1](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/5ef3cd1d9c8543c081af4a27e5e0c6fd70e72bce))

## [1.22.2](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/compare/v1.22.1...v1.22.2) (2024-10-29)


### CI configuration

* fix publish artifactory folder name ([#1175](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1175)) ([a67f059](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/a67f0599df98121e797fce76c638adc016677123))

## [1.22.1](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/compare/v1.22.0...v1.22.1) (2024-10-29)


### CI configuration

* Revert back common functional test to unblock pipeline ([#1174](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1174)) ([8c100be](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/8c100bede52eee841a8f595bfe68e2222b83f197))
* **US1468443:** Creating workflows to deploy from GitActions ([#1171](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1171)) ([4c2d78e](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/4c2d78e008ce32daa416571afc80be1bdebcebb9))

## [1.22.0](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/compare/v1.21.0...v1.22.0) (2024-10-24)


### CI configuration

* **US1468945:** Update security_orchestrator.yml ([#1169](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1169)) ([8760bba](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/8760bbac67682a1553cdf258f38e697d690b1435))


### Features

* **US1470561:** Add Fuel Type to CA Schema ([#1165](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1165)) ([dede256](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/dede256d4a4a07fd7987b2d16c0e4d70f6c98619))


### Bug Fixes

* **US1489806:** Adding logic to processes for nested fields ([#1163](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1163)) ([45868cc](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/45868ccc36d86ca95ac1b4b56ab10876ca100c87))

## [1.21.0](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/compare/v1.20.1...v1.21.0) (2024-10-17)


### Features

* **US1489806:** Only return what we have in schema and drop additional fields from DB ([#1159](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1159)) ([4da4035](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/4da40358eb65ceab946cff6543c9e642f26b8826))


### Bug Fixes

* **US1489506:** [PYNEERS] Updated payments URL ([#1161](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1161)) ([c862bed](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/c862beda94cc8f81d40688d382aa37879b3ddda3))

## [1.20.1](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/compare/v1.20.0...v1.20.1) (2024-10-11)


### Documentations

* **US1468375:** Updated Runbook link and template ([#1155](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1155)) ([a3e75bb](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/a3e75bbf81cbff28dc42fde2caae8e91e7b82aed))

## [1.20.0](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/compare/v1.19.0...v1.20.0) (2024-10-08)


### Features

* **US1470916:** fld decision with creditAppId ([#1153](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1153)) ([fb4ef99](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/fb4ef99081a734bcacac518bec7f821e4ccf1906))

## [1.19.0](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/compare/v1.18.0...v1.19.0) (2024-10-04)


### Features

* **US1396640:** Accepting and passing baggage headers to downstream ([#1147](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1147)) ([b8b69c7](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/b8b69c7a3b190737e5dc97f3d571b49a51f1735c))


### Bug Fixes

* **US1396640:** Moving baggage logic from message attributes to payload ([#1149](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1149)) ([5af7515](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/5af7515390029aeec4edda5d84d1dbad92d4cf28))

## [1.18.0](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/compare/v1.17.1...v1.18.0) (2024-09-30)


### Routine Maintenance

* Upgrade dependencies to fix security issues ([#1130](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1130)) ([437d702](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/437d70290f0b083a3c8cc5c610b834d94b8444a1))
* **US0000000:** [Update] Python requirements ([#1137](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1137)) ([3b23d77](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/3b23d77d2fc50f686d996640248e7a586c74e60f))


### Features

* **US1472896:** CPI - Adding poetry enhancements for Librefresh ([#1141](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1141)) ([33b76fd](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/33b76fd7279c0cc5b8adff4273b084b60189f482))


### Bug Fixes

* **US1397504:** [PYNEERS] Added condition for correlationId header check ([#1140](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1140)) ([73660ec](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/73660ec2b5ffa205fd1df40d120ad127f5e24fdf))

## [1.17.1](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/compare/v1.17.0...v1.17.1) (2024-09-11)


### Routine Maintenance

* **E35975:** Bump to latest gitops version ([#1118](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1118)) ([212d7f3](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/212d7f34ae18ca844c23da3583d4e559247cd923))


### Bug Fixes

* **US1452613:** Reducing size of IAM policy which hits the limit ([#1127](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1127)) ([64cd81a](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/64cd81acdd1916306846c4be4c0ddb773a150c01))

## [1.17.0](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/compare/v1.16.0...v1.17.0) (2024-09-10)


### Features

* remove CREDIT_APP_POST for DTC target platform ([#1119](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1119)) ([e7b40e2](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/e7b40e2c779918d8faa6d9751a9462c5f8277f62))


### Bug Fixes

* **US1452613:** updating S3 policy as per PR -1108 ([#1126](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1126)) ([9240199](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/9240199714d64f8846deecfd8105aa4fbdbf92fa))

## [1.16.0](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/compare/v1.15.1...v1.16.0) (2024-09-05)


### Features

* **US1443634:** kms role migration changes ([#1107](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1107)) ([d7ef9d5](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/d7ef9d5f611a3f7bed1dbf2c116098ccc20ea8ad))

## [1.15.1](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/compare/v1.15.0...v1.15.1) (2024-09-04)


### Bug Fixes

* Security fixes on NPM packages ([#1115](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1115)) ([3e52fbe](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/3e52fbe80798019449810d3a9067c3374c31ca88))
* **TA2960156:** [PYNEERS]update dr-utils package in deal-data ([#1116](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1116)) ([09b733e](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/09b733ef97f4310226c3dd04d1c4c488751732a5))

## [1.15.0](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/compare/v1.14.0...v1.15.0) (2024-08-30)


### Features

* **US1397505:** [PYNEERS]Adding Payment Detail APIG in healthcheck ([#1112](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1112)) ([0ac11ee](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/0ac11ee80c3df48bf672f67b2357c5944ce1422e))


### Bug Fixes

* **US1397505:** [PYNEERS] Added logs in payment details and enabled operation on west region s3 bucket ([#1108](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1108)) ([94c8887](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/94c88872ea8fe9adbf3a3474c458aa22be8db4de))

## [1.14.0](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/compare/v1.13.0...v1.14.0) (2024-08-28)


### Features

* **US0000000:** [Update] Python requirements ([#1105](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1105)) ([c6c8f1b](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/c6c8f1b4c28446033da533f6ef93722dc65d8da7))
* **US1396115:** Update deployment process to use artifact from release please ([#1106](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1106)) ([2d4e56d](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/2d4e56d74bab44d11ca58b46971a0635025f9ea7))
* **US1397505:** add get endpoint to retrieve payments decision ([#1099](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1099)) ([313464f](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/313464f6ebebb7dfdd48c2dea19ccb90832f29c9))


### Bug Fixes

* Artifactory fixes and remove git checkout on version commit ([#1109](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1109)) ([9af5332](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/9af53320a670403301460ac6f53de1fba831e8b4))

## [1.13.0](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/compare/v1.12.0...v1.13.0) (2024-08-15)


### Features

* **US1423394:** Multiple Deals for Single DJ - Deal Data ([#1089](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1089)) ([e2ec548](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/e2ec5483598e1daf63a02248ea8879e64a9ff221))


### Bug Fixes

* **TA2924902:** PA Deal Data pipeline test issue ([#1095](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1095)) ([14012f7](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/14012f79d9a1c2606bb951df87857efe2ab6e052))
* **US1302712:** R1J Contract - Feature Closure ([#1094](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1094)) ([78a189f](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/78a189f94d6c00681938faa4bdfc2722c418e55a))

## [1.12.0](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/compare/v1.11.0...v1.12.0) (2024-08-06)


### CI configuration

* [LAMBDA] Updating LibRefresh version ([#1065](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1065)) ([15c86de](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/15c86dec816ecb40e9006a2d80ef5c2c2a2b2f8f))


### Features

* [LAMBDA] Updating reqs file with latest dr-utils ([#1067](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1067)) ([47a82af](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/47a82afea6739de400f2d9382de10d0e888bfce6))
* typo fix for new payment detail endpoint ([#1087](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1087)) ([f3ee23e](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/f3ee23ea050c511f2ae7f863e6fdb6daa313aca9))
* **US0000000:** [Update] Python requirements ([#1066](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1066)) ([195d302](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/195d30221c139b24c1244ff6909dc3942927cc04))
* **US1394227:** Remove Docs Toggle ([#1068](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1068)) ([b831f80](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/b831f80f073db6eccb9b84205780cf2dce8eb384))
* **US1394711:** Update Newrelic with new secret in param ([#1081](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1081)) ([1e2ba69](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/1e2ba69faf8619e945c8d9248aa3fc80783c1e2a))
* **US1395817:** [LAMBDA] R1J - Implementation - Deal Data API to redirect traffic from RT1 to R1J for migration process ([#1054](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1054)) ([8d04db1](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/8d04db1e28d6612dfb6d755f632d7fec7a842f9a))
* **US1399128:** Passing dealXgDealId and dealXgDealVersion from deal-data ([#1074](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1074)) ([211a193](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/211a193da934f8f8a64474a97cf7d2e6dead687d))
* **US1408865:** Allow for dealRefIdFD & dealRefIdInt to be updated via key data PATCH ([#1064](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1064)) ([0536ecc](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/0536ecc173a9bfd24dfb8a36e9e6c8fc6a79d27c))
* **US1410282:** Add new field in deal_data.financeSummary: estimatedAmountFinanced ([#1072](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1072)) ([27628b8](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/27628b825efd9b5ded06de71a9b3d1550d139d77))
* **US1424857:** Added post endpoint in deal data to save UPQ to S3 bucket ([#1083](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1083)) ([b6f61a3](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/b6f61a30dd2540812c53f0c0d2f4409c1315f68d))


### Bug Fixes

* NPM security fix ([#1076](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1076)) ([f74eb8a](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/f74eb8a637fd186d83c58d07c39fe3fd8d19f47e))
* **TA2893138:** updating Orchestrator with veracode results ([#1079](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1079)) ([4261cb3](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/4261cb383f0a3eac2df8bfa23118467c7e5a5ba8))
* **US1391059:** [WallStreet] Fix logic to remove empty nodes for UCA ([#1056](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1056)) ([9d01864](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/9d01864cf579377a3bf15bde5a88f4947fe9a123))
* **US1422318:** Add default params for LibRefresh scheduler ([#1077](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1077)) ([6f9f8e2](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/6f9f8e2430a4d4a3797475c6e37b81b574427866))
* **US1428616:** Upgraded and fix security vulnerabilities ([#1086](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1086)) ([dc782e3](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/dc782e39250cb4aecb62e4d53a730852d0f234d6))

## [1.11.0](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/compare/v1.10.0...v1.11.0) (2024-07-02)


### Routine Maintenance

* **US1406338:** Update LibRefresh version ([03344b0](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/03344b039e5d898bb0253ae70442e83989e96bc9))


### Features

* **US0000000:** [Update] Python requirements ([#1051](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1051)) ([ce7ebed](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/ce7ebed5c6cc7f86da58b267ed16c2212cfbd564))
* **US1406338:** LAMBDA - Create reusable actions to auto-update the requirements ([#1048](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1048)) ([1f366d7](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/1f366d79c5102fccb1a6dc6bdd064084733bfcc1))
* **US1406338:** LAMBDA - Fixing version number ([#1050](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1050)) ([0e455ae](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/0e455aedb1343331e222ca027ae4b4fe8d71ccc9))

## [1.10.0](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/compare/v1.9.0...v1.10.0) (2024-06-25)


### Features

* Create new Cancel V2 API ([#1041](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1041)) ([ac2fd02](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/ac2fd0238a5c8af8bb9b2a48f86340b599d8d2c9))

## [1.9.0](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/compare/v1.8.0...v1.9.0) (2024-06-21)


### CI configuration

* Create Publish artifact action ([#1038](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1038)) ([5fc9b98](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/5fc9b98e8fc396e3d9dff143c252a6d41fa80bcc))


### Features

* Create new Verify V2 API ([#1039](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1039)) ([bd22a4b](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/bd22a4b41ad9d09e9cb0f294d41c9524936bd7bd))

## [1.8.0](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/compare/v1.7.0...v1.8.0) (2024-06-06)


### CI configuration

* Skip PR check on release PRs + adding 'do-not-close' tag to release please PR + updating release please to 'googleapis' ([#1021](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1021)) ([3270f5d](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/3270f5dd6e78325c5a324eff98960a499a0dabbe))


### Routine Maintenance

* Security dependabot fix for Werkzeug ([#1010](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1010)) ([fc3fb40](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/fc3fb406f311c31ffcd0c2f63c49e0a64a5457a1))
* Skip PR check on release PRs ([#1013](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1013)) ([00384f3](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/00384f386d06af5cdcb35874294ab5e2aab3d330))
* **TA2809306:** Add pr-linter ([#1024](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1024)) ([237ce45](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/237ce455f08025b4a8cebcafe28844681380e7d1))


### Features

* [WallStreet] Remove empty nodes from get credit-app response ([#1019](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1019)) ([85b2bfa](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/85b2bfa89d13abbd0ed44e5a651a2939bbb404c1))
* CREDIT_APP_PATCH support for DealXG Bridge US1382452 [Pyneers] ([#1025](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1025)) ([aab33e0](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/aab33e00a8fe1c01773994b73c0a42a0eca9aadc))
* Updating get lender id api deal component key name to target platform specific ([#1015](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1015)) ([5a8fa2f](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/5a8fa2f03a588e4a6a7e32007ca64e48cdfcf842))
* US1309047 Adding DealXG queue to routing configuration [pyneers] ([#1008](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1008)) ([33db354](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/33db354a55bf7cd86f2bc4d7a39e57f82648df70))
* US1369104 Added CommonOrgId in key-data for DTC platform ([#1030](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1030)) ([aadd4c5](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/aadd4c5801d111d6470a3bedc44ecf2902073feb))
* US1372588: Add DealXG Queue and DLQ to DealData Terraform Roles [pyneers] ([#1020](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1020)) ([bbfd3ea](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/bbfd3ea15f7557c136cd74659b0b84a0cadf8a41))
* US1372589: Update DR_UTILS package in requirement files in Deal Data API ([#1026](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1026)) ([0656107](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/0656107cc745691546e1447e78ed38828ac0ef50))


### Bug Fixes

* Adding endpointType as REGIONAL as default value is EDGE ([#1017](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1017)) ([45bc1d9](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/45bc1d9a55907d8186bde4fbe615f47e1eec8421))
* error log to info log ([#1011](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1011)) ([93fd13d](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/93fd13d4d1c4dc0b2b5a726889c052f6d530e63b))

## [1.7.0](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/compare/v1.6.0...v1.7.0) (2024-05-08)


### Features

* [WallStreet] Add new Credit-App GET endpoint ([#1000](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1000)) ([906b9ba](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/906b9bac0cebab08741e12b24ae33d423c52182a))

## [1.6.0](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/compare/v1.5.0...v1.6.0) (2024-05-07)


### Features

* Enhance Deal Data API to not save DealXGDealID and DealXGDealVersion on Create Contract v2 API Call ([#1001](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1001)) ([00370d3](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/00370d3dbf1fd40d2cd90f10f3afa076b8e6516d))
* Updating deal component key name to target platform specific for get events api ([#1002](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1002)) ([029fa65](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/029fa651c381d485f5fc0de4258223b5e5d68005))


### Bug Fixes

* changelog host ([#1004](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/1004)) ([9e2a5fb](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/9e2a5fb82b695618db978dcf2a55e39da63d84cd))

## [1.5.0](https://github.com/DT-SFI/dr-deal-data-api/compare/v1.4.0...v1.5.0) (2024-04-26)


### Documentations

* US1244068 update PRR template ([#993](https://github.com/DT-SFI/dr-deal-data-api/issues/993)) ([8f7af08](https://github.com/DT-SFI/dr-deal-data-api/commit/8f7af080d229705034fd43e2b8e3edfde4c621c1))


### Features

* Session post patch update ([#985](https://github.com/DT-SFI/dr-deal-data-api/issues/985)) ([cc07976](https://github.com/DT-SFI/dr-deal-data-api/commit/cc079763fa6a65030ac9925602641d4fea983b5c))
* Updating deal component key name to target platform from body to patch ([#995](https://github.com/DT-SFI/dr-deal-data-api/issues/995)) ([7009f6f](https://github.com/DT-SFI/dr-deal-data-api/commit/7009f6f613518403f49f03c4ad449088488ddaf0))
* Updating deal component key name to target platform specific ([#990](https://github.com/DT-SFI/dr-deal-data-api/issues/990)) ([ec427ab](https://github.com/DT-SFI/dr-deal-data-api/commit/ec427ab351dd92851873fb96987a582c5bd7d8f6))


### Bug Fixes

* [BRAVO] adding release please v4 ([#994](https://github.com/DT-SFI/dr-deal-data-api/issues/994)) ([c9c06eb](https://github.com/DT-SFI/dr-deal-data-api/commit/c9c06ebb96802179ba4297654b2a4754e2a58ad7))

## [1.4.0](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/compare/v1.3.1...v1.4.0) (2024-04-15)


### Features

* create update session logic ([#978](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/978)) ([8ed7cbf](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/8ed7cbf7ba79d03b9377ea25f2a3648d0dd45d1d))
* Enabling CaaS V2 for targetPlatform R1J ([#984](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/984)) ([bb36efa](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/bb36efa588426634412061f297a19b9e191c50ab))


### Bug Fixes

* Updating docker image and compose file to remove args and use secrets for security ([#980](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/980)) ([d7f780b](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/d7f780b5dfbd157f28d5f6217ca0df52509770b4))
* Upgrade idna version for security ([#979](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/979)) ([f819604](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/f81960473f75735e6f33cf76de095d5fa29d6cb4))

## [1.3.1](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/compare/v1.3.0...v1.3.1) (2024-04-10)


### Bug Fixes

* Upgrade node tar version for security ([#975](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/975)) ([4af4140](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/4af4140a440f6869ac391ed47207f5cd7abbae71))

## [1.3.0](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/compare/v1.2.0...v1.3.0) (2024-04-08)


### Features

* US1305769: implement post and to save multiple document records ([#969](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/969)) ([98b48e6](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/98b48e60774949666f0e54c43258032b336922d3))


### Bug Fixes

* Upgrade version for security dependabot ([#973](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/973)) ([923e232](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/923e232cf755a5ed2c9f96988222527c1b551a33))

## 1.2.0 (2024-03-15)


### Routine Maintenance

* release 1.2.0 ([#964](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/964)) ([90279a1](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/90279a1a35bf0666cccfe34d816b49e07b3593f1))


### Features

* [BRAVO] Adding release please. ([#962](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/962)) ([da38ff9](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/da38ff98bd01f6d33b9e357ea3832d52ff95381c))
* Adding dealXg ref ids in key-data GET and POST calls ([#892](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/892)) ([3cc2bdf](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/3cc2bdfca1b3073f0c9c8bfee330738488d900cb))
* Adding logic for includeInactiveRefs filter in header ([#950](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/950)) ([6309adf](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/6309adf62f996f6e7f083da9740e502733926a6b))
* Adding mapping for sourcePartnerDealerId in key-data records ([#941](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/941)) ([7f7a149](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/7f7a149e84865e0ad8685632f25404de1f7f0cfa))
* Adding new endpoint for Key-data V2 PATCH ([#948](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/948)) ([4dd2b0e](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/4dd2b0e28a1631855dde4642062d700af4c0d0de))
* adding new field for BCA ideal ([#903](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/903)) ([eb521f3](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/eb521f37248e2ad5f0626249580c6062e5dbab9a))
* Adding new fields in GET schema ([#890](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/890)) ([897bff6](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/897bff6a76add2334d8e4cc9084b283667444990))
* Adding new mapping file for key-data to save new records parallel to DTC.DEAL ([#940](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/940)) ([bf3f0b7](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/bf3f0b7fac7c6099a8c01e60e177e2196ea33fc4))
* Adding new v2 GET Key Data API ([#949](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/949)) ([1e9310c](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/1e9310c3cde19adfe086666cd0523cb051d87411))
* Adding rateVariance to Honda events ([#874](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/874)) ([f685f37](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/f685f377bc0abf9bf824ae07cc87f52111556cc8))
* Create new endpoint for Contract Cancel V1 ([#953](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/953)) ([ef2e5fb](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/ef2e5fbc87cda7010b17f642b1729b688da9fb76))
* Creating new endpoint for Contract Create V2 ([#883](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/883)) ([0e99a5b](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/0e99a5bd94e9fff2135bbd92484adf12faaf3c52))
* deprecating deal status API ([#911](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/911)) ([60506da](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/60506da6d1f4b202e38bf96b3d1cdd6cf79ab01a))
* Enabling detailed cloudwatch metrics+ adding 'noname' tag ([#822](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/822)) ([b6bd379](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/b6bd3796d586abe2302a608c19900784de69315f))
* New endpoint for update contract ([#876](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/876)) ([a8da9a5](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/a8da9a5bb6bd17cfa30f85601d24d0d9c2454a68))
* remove all `create_deal_record` instances in stormchasers func tests ([#921](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/921)) ([5a92110](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/5a92110104a47d66369b18c1d12eda2fe980508b))
* Remove API Key for deal-data ([#897](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/897)) ([6b5f84d](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/6b5f84d839ddd362ba40103e58fc0fabeea21759))
* Remove sourcePartnerDealerId for R1J ([#952](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/952)) ([56ddd09](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/56ddd095440ace69bf29c09db42655fbf7009919))
* removing monitor usage as we removed API key ([#908](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/908)) ([38d53b3](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/38d53b3a2f07e49fe0aaaa3fabd728a29eda6b8e))
* Upgrade PR requirement files for security ([#906](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/906)) ([dbb07ea](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/dbb07ea4ed90f900f65232a2fd21f141be8a2626))
* Upgrade Terraform, Node version and serverless plugins ([#904](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/904)) ([45bf29c](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/45bf29cda242b45db1cdcd60e5fea87e44cc1c49))
* Upgrade tj-action version for security vulnerability ([#905](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/905)) ([0e42573](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/0e42573e86190301e668a894e09f585e3d10070e))
* upgrading deal-data to Python 3.11/ Node 18.x version ([#932](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/932)) ([4a6954f](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/4a6954fc79f651ea32d8ded2adb72d548af4ca66))
* US1267059 - Migrate deployment jobs to GitHub Actions - dr-deal-data-api (Lambda)  ([#946](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/946)) ([047c475](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/047c4759f6e8baf463f7aa435e40808ecb9b9aca))


### Bug Fixes

* Add schema for V2 ([#884](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/884)) ([d012279](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/d012279e7e807b2712c029b1380d9090eff38642))
* Adding 2nd layer of protection for master ([#958](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/958)) ([4077b9e](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/4077b9ec661cab250e5a915bf5672db8d83dc425))
* adding check for Items ([#929](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/929)) ([3bf2ad0](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/3bf2ad07f13c03b2d1e1453630cd8057e3dc5eb6))
* adding routing for SIGN V2 ([#913](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/913)) ([784c69e](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/784c69e19eef3bd6d6a3a235bfa4da84162dcf60))
* deal record should not be dropped if creditAppId is not found ([#954](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/954)) ([4d208e0](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/4d208e012a477c09c8ce33a857085d1b7b59d230))
* Forward Contract Update to unifi bridge ([#880](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/880)) ([a0959b3](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/a0959b3df22626ea76cf78cb2f9fcdf2e25ff91d))
* functional tests for cancel contract api ([#959](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/959)) ([66822ae](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/66822ae50bec434a58b32f443ca84767f491e9dc))
* increasing health check lambda timeout from 5 to 10 secs ([#912](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/912)) ([f5f1afc](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/f5f1afce0c8a4e8d2219067879222b8b36bc5fa8))
* Increasing timeout to 20 sec to make dynamoDB failures gracefully ([#923](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/923)) ([165204f](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/165204ff9d20b16c30ddd1060051438ed9dba00f))
* IndexError-list index out of range while getting records from db using filter expression ([#867](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/867)) ([94a6f34](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/94a6f34b97f79a5401cf97ca0ea0f0cd01968b71))
* Passing correlationId in body to remove 5min limitation by FIFO SQS ([#885](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/885)) ([26ee6c3](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/26ee6c322f3a0f0c5a3f95afde87adec4aa49145))
* QA functional test for contract status ([#872](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/872)) ([dd612f1](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/dd612f17e946bc82c286e8b42a42d372950a713a))
* Reducing complexity and unnecessary data retrieve from DB ([#955](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/955)) ([f2c47eb](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/f2c47eb88b05ce8dcaef96ffa1de4fb6d769abc8))
* Remove unused arguments to SQS ([#875](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/875)) ([6de04f9](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/6de04f91403ec1ec220d50c8ee4caf76d0b062a4))
* removing deal data status from HC ([#914](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/914)) ([eabc793](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/eabc793a5a5ae97932aedce03e4f20c4805dd831))
* Removing independent timeouts and use global from serverless for key data and lender id GET ([#924](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/924)) ([83a585c](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/83a585ce95374e62a304987fd3c2579b9da83a25))
* Replacing Strip with replace as strip drops the characters from whole string ([#893](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/893)) ([2d22e75](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/2d22e75c8cef69ed79e5db40cec05826060b5ea9))
* Security improvements to use secrets instead random package ([#915](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/915)) ([064a6fc](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/064a6fc284641834e1f7026668a6c783205bc662))
* separating update and get deal events func tests ([#957](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/957)) ([f3d8cdd](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/f3d8cdd4958304e525b04490e6fd3cb91c930c04))
* Stabilizing GET lead and Key Data GET functional tests ([#943](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/943)) ([a1f46dd](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/a1f46ddda71d06012d5c7e01003804b3c496f272))
* stalebranch cleanup ([#960](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/960)) ([f1a8dc5](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/f1a8dc5bcdc67d9bd71d2ade56701413ff6e3fa0))
* temp fix until we add logic to check for updated timestamp ([#917](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/917)) ([54eb5ab](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/54eb5abbf188bccead9cafe0adbb918f6a4e25a5))
* tests: cleanup functional tests ([#961](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/961)) ([3d271d0](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/3d271d042a8b30e3a482eba8f83c5fa21eb920c2))
* type object 'SchemaType' has no attribute 'CONTRACT_DEAL_STATUS_POST' ([#865](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/issues/865)) ([95758ec](https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/commit/95758ecad443e773796e6f04a55b0e57809608dc))
