# -*- coding: utf-8 -*-
import json
from http import HTTPStatus

import dr_utils
from common.lambda_base import ProducerLambda
from common.settings import CORRELATION_ID_HEADER_KEY, Env, PayloadType as pt
from common.validators import ExistingDealValidator
from utils import common


class ContractProducerLambdaV2(ProducerLambda):
    def __init__(self, **kwargs):

        super().__init__(**kwargs)
        self.deal_ref_id = None

    @ProducerLambda.catch_exceptions
    @ProducerLambda.is_handler
    def existing_deal_handler(self, event: dict, context: dict):

        """
        Handles the new Contract app Post for a Deal and a specific lender.

        Endpoint: /deals/{dealRefId}/contract

        This asynchronous API submits a message to DealDataQueue, then returns
        Accepted to the client with HTTP status ACCEPTED (202).

        :param dict event: An API Gateway event object
        :param dict context: AWS Lambda Context Object
        :return: JSON with status code and body
        """

        self.deal_ref_id = self.path_params.get("dealRefId")
        lender_id = self.request_headers.get("lenderId")
        deal_xg_deal_id = self.request_headers.get("dealXgDealId")
        deal_xg_deal_version = self.request_headers.get("dealXgDealVersion")

        self.log.bind(
            dealRefId=self.deal_ref_id,
            lenderId=lender_id,
            dealXgDealId=deal_xg_deal_id,
            dealXgDealVersion=deal_xg_deal_version,
        )
        self.log.info("Contract creation request received for a deal")

        validator = ExistingDealValidator(
            sqs_event=event, deal_ref_id=self.deal_ref_id, validate_deal_exist=True
        )
        data = validator.validate_body()

        data["lenderId"] = lender_id
        data["dealXgDealId"] = deal_xg_deal_id
        data["dealXgDealVersion"] = deal_xg_deal_version
        data["baggage"] = self.baggage
        data = common.drop_ref_ids_from_payload(data)

        self.log.bind(requestPayload=data)

        # As FIFO queue maintain the history of processed messageGroupId, body to not to process duplicate messages
        # for 5 min, to remove the limitation we are adding correlation Id to the body to make the request unique
        # and process by SQS instead of dropping
        data[CORRELATION_ID_HEADER_KEY] = self.correlation_id

        dr_utils.send_payload_to_queue(
            queue=Env.DEAL_DATA_QUEUE,
            payload=data,
            region=Env.AWS_REGION,
            msg_group_id=self.deal_ref_id,
            payloadType=self.payload_type,
            correlationId=self.correlation_id,
            dealRefId=self.deal_ref_id,
        )

        self.log.info(f"Contract creation request sent to queue: {Env.DEAL_DATA_QUEUE}")

        return {
            "statusCode": HTTPStatus.ACCEPTED,
            "body": json.dumps({"message": "Accepted"}),
            "headers": self.response_headers,
        }

    @ProducerLambda.catch_exceptions
    @ProducerLambda.is_handler
    def verify_contract_handler(self, event: dict, context: dict):

        """
        Verify previously created Contract for an existing Deal and a specific lender.

        Endpoint: /v2/deals/{dealRefId}/contract/verify

        This asynchronous API submits a message to DealDataQueue, then returns HTTP status ACCEPTED (202)
        to the client.

        :param dict event: An API Gateway event object
        :param dict context: AWS Lambda Context Object
        :return: JSON with status code
        """
        empty_path_parameters = []
        self.deal_ref_id = self.path_params.get("dealRefId")
        self.lender_id = self.request_headers.get("lenderId")
        if not self.deal_ref_id:
            empty_path_parameters.append("dealRefId")

        # TODO Remove this when all error messages will be in same format
        event["new_error_message"] = True

        self.log.bind(
            dealRefId=self.deal_ref_id,
            lenderId=self.lender_id,
        )
        self.log.info("Contract app verification request received for a deal")
        validator = ExistingDealValidator(
            event,
            self.deal_ref_id,
            new_error_message=True,
            path_parameters=empty_path_parameters,
            validate_deal_exist=True,
        )

        data = validator.validate_body()
        data["lenderId"] = self.lender_id
        data["baggage"] = self.baggage
        data = common.drop_ref_ids_from_payload(data)

        self.log.bind(requestPayload=data)

        # As FIFO queue maintain the history of processed messageGroupId, body to not to process duplicate messages
        # for 5 min, to remove the limitation we are adding correlation Id to the body to make the request unique
        # and process by SQS instead of dropping
        data[CORRELATION_ID_HEADER_KEY] = self.correlation_id

        dr_utils.send_payload_to_queue(
            queue=Env.DEAL_DATA_QUEUE,
            payload=data,
            region=Env.AWS_REGION,
            msg_group_id=self.deal_ref_id,
            payloadType=self.payload_type,
            correlationId=self.correlation_id,
            dealRefId=self.deal_ref_id,
        )

        self.log.info(
            f"Contract app verification request sent to queue: {Env.DEAL_DATA_QUEUE}"
        )
        return {
            "statusCode": HTTPStatus.ACCEPTED,
            "body": json.dumps({"message": "Accepted"}),
            "headers": self.response_headers,
        }

    @ProducerLambda.catch_exceptions
    @ProducerLambda.is_handler
    def standalone_sign_con_handler(self, event: dict, context: dict):

        """
        Contract Signing for an existing Deal

        Endpoint: /v2/deals/{dealRefId}/contract/sign

        This asynchronous API submits a message to DealDataQueue, then returns HTTP status ACCEPTED (202)
        to the client.

        :param dict event: An API Gateway event object
        :param dict context: AWS Lambda Context Object
        :return: JSON with status code
        """
        empty_path_parameters = []
        self.deal_ref_id = self.path_params.get("dealRefId")
        if not self.deal_ref_id:
            empty_path_parameters.append("dealRefId")

        # TODO Remove this when all error messages will be in same format
        event["new_error_message"] = True

        self.log.bind(
            dealRefId=self.deal_ref_id,
        )
        self.log.info("Standalone contract signing request received for a deal")
        validator = ExistingDealValidator(
            event,
            self.deal_ref_id,
            new_error_message=True,
            path_parameters=empty_path_parameters,
            validate_deal_exist=True,
        )

        data = validator.validate_body()
        data["baggage"] = self.baggage
        data = common.drop_ref_ids_from_payload(data)

        self.log.bind(requestPayload=data)

        # As FIFO queue maintain the history of processed messageGroupId, body to not to process duplicate messages
        # for 5 min, to remove the limitation we are adding correlation Id to the body to make the request unique
        # and process by SQS instead of dropping
        data[CORRELATION_ID_HEADER_KEY] = self.correlation_id

        dr_utils.send_payload_to_queue(
            queue=Env.DEAL_DATA_QUEUE,
            payload=data,
            region=Env.AWS_REGION,
            msg_group_id=self.deal_ref_id,
            payloadType=self.payload_type,
            correlationId=self.correlation_id,
            dealRefId=self.deal_ref_id,
        )

        self.log.info(
            f"Standalone contract signing request sent to queue: {Env.DEAL_DATA_QUEUE}"
        )
        return {
            "statusCode": HTTPStatus.ACCEPTED,
            "body": json.dumps({"message": "Accepted"}),
            "headers": self.response_headers,
        }

    @ProducerLambda.catch_exceptions
    @ProducerLambda.is_handler
    def contract_cancel_handler(self, event: dict, context: dict):

        """
        Contract cancel  for an existing Deal

        Endpoint: /v2/deals/{dealRefId}/contract/cancel

        This asynchronous API submits a message to DealDataQueue, then returns HTTP status ACCEPTED (202)
        to the client.

        :param dict event: An API Gateway event object
        :param dict context: AWS Lambda Context Object
        :return: JSON with status code
        """
        empty_path_parameters = []
        self.deal_ref_id = self.path_params.get("dealRefId")
        if not self.deal_ref_id:
            empty_path_parameters.append("dealRefId")

        # TODO Remove this when all error messages will be in same format
        event["new_error_message"] = True

        self.log.bind(
            dealRefId=self.deal_ref_id,
        )
        self.log.info("Contract cancel request received for a deal")
        validator = ExistingDealValidator(
            event,
            self.deal_ref_id,
            new_error_message=True,
            path_parameters=empty_path_parameters,
            validate_deal_exist=True,
        )

        data = validator.validate_body()
        data["baggage"] = self.baggage
        data = common.drop_ref_ids_from_payload(data)
        self.log.bind(requestPayload=data)

        # As FIFO queue maintain the history of processed messageGroupId, body to not to process duplicate messages
        # for 5 min, to remove the limitation we are adding correlation Id to the body to make the request unique
        # and process by SQS instead of dropping
        data[CORRELATION_ID_HEADER_KEY] = self.correlation_id

        dr_utils.send_payload_to_queue(
            queue=Env.DEAL_DATA_QUEUE,
            payload=data,
            region=Env.AWS_REGION,
            msg_group_id=self.deal_ref_id,
            payloadType=self.payload_type,
            correlationId=self.correlation_id,
            dealRefId=self.deal_ref_id,
        )

        self.log.info(f"Contract cancel sent to queue: {Env.DEAL_DATA_QUEUE}")
        return {
            "statusCode": HTTPStatus.ACCEPTED,
            "body": json.dumps({"message": "Accepted"}),
            "headers": self.response_headers,
        }


create_contract = ContractProducerLambdaV2().get_handler(
    handler_func="existing_deal_handler", payload_type=pt.CONTRACT_POST_V2
)

verify_contract = ContractProducerLambdaV2().get_handler(
    handler_func="verify_contract_handler", payload_type=pt.VERIFY_CONTRACT_POST_V2
)

standalone_sign_contract = ContractProducerLambdaV2().get_handler(
    handler_func="standalone_sign_con_handler", payload_type=pt.SIGN_CONTRACT_POST_V2
)

cancel_contract = ContractProducerLambdaV2().get_handler(
    handler_func="contract_cancel_handler", payload_type=pt.CONTRACT_CANCEL_POST_V2
)
