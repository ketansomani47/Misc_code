# -*- coding: utf-8 -*-
import copy
import json
from datetime import datetime
from decimal import Decimal
from functools import reduce
from http import HTTPStatus

import ulid
from boto3.dynamodb.conditions import And, Attr, Key
from botocore.exceptions import ClientError
from common import settings
from common.lambda_base import GetLambda, ProducerLambda
from common.settings import (
    DOCS_CUSTOMER_TYPES,
    GET_DOCS_FILTER_PARAMS,
    DealComponent,
    Env,
    ErrorMsgs,
    InfoMsgs,
    WarningMsgs,
)
from common.validators import ExistingDealValidator
from utils import common
from utils.common import DealDataParameters
from utils.db_helper import DynamoDbHelper
from utils.exceptions import BadRequestError


class DocsLambda(GetLambda, ProducerLambda):
    def __init__(self, operation=None, **kwargs):
        super().__init__(operation=operation, **kwargs)

    @GetLambda.catch_exceptions
    @GetLambda.is_handler
    def get_documents(self, event, context):
        """
        This method will query on dealRefId and filter only 'DTC.DOCS' resources
        :param dict event: An API Gateway event object
        :param dict context: AWS Lambda Context Object
        :return: JSON with status code and body
        """
        deal_ref_id = self.path_params.get("dealRefId")
        self.log.bind(
            operationId="get_documents",
            dealRefId=deal_ref_id,
            queryStringParameters=self.query_string_params,
        )

        event["new_error_message"] = True
        path_params = ["dealRefId"] if not deal_ref_id else []

        validator = ExistingDealValidator(
            event, deal_ref_id, new_error_message=True, path_parameters=path_params
        )

        validator.validate_api_version(self.request_api_version)

        self.validate_query_string_params(validator)

        db = DynamoDbHelper(
            region=Env.AWS_REGION, table_name=DealDataParameters().db_name
        )
        key_expression = Key("dealRefId").eq(deal_ref_id)
        filter_expression = (
            Attr("dealComponent").begins_with(DealComponent.DTC_DOCS)
            | Attr("dealComponent").begins_with(DealComponent.IDL_DOCS)
            | Attr("dealComponent").begins_with(DealComponent.R1J_DOCS)
        )
        if self.query_string_params:
            filter_expression = filter_expression & self.create_filter_expression(
                self.query_string_params
            )

        db_records = db.query_items(
            key_expression=key_expression,
            filter_expression=filter_expression,
            index="dealRefId-index",
        )

        self.log.info(InfoMsgs.received_data_from_db.format(operation=self.operation))

        if not db_records:
            return {
                "statusCode": HTTPStatus.NOT_FOUND,
                "body": json.dumps(
                    self.no_resources_found_response(deal_ref_id),
                    cls=common.decimal_decoder(),
                ),
                "headers": self.response_headers,
            }

        return {
            "statusCode": HTTPStatus.OK,
            "body": json.dumps(db_records, cls=common.decimal_set_decoder()),
            "headers": self.response_headers,
        }

    @GetLambda.catch_exceptions
    @GetLambda.is_handler
    def get_single_document(self, event, context):
        """
        This method will query on dealRefId and documentId.
        :param dict event: An API Gateway event object
        :param dict context: AWS Lambda Context Object
        :return: JSON with status code and body
        """
        deal_ref_id = self.path_params.get("dealRefId")
        document_id = self.path_params.get("documentId")
        deal_component = document_id

        self.log.bind(
            dealRefId=deal_ref_id,
            documentId=document_id,
            operationId="get_single_document",
            queryStringParameters=self.query_string_params,
            dealComponent=deal_component,
        )

        event["new_error_message"] = True
        path_params = [
            path
            for path in ["dealRefId", "documentId"]
            if not self.path_params.get(path)
        ]

        validator = ExistingDealValidator(
            event, deal_ref_id, new_error_message=True, path_parameters=path_params
        )
        validator.validate_api_version(self.request_api_version)

        db = DynamoDbHelper(
            region=Env.AWS_REGION, table_name=DealDataParameters().db_name
        )
        key_expression = Key("dealRefId").eq(deal_ref_id) & Key("dealComponent").eq(
            deal_component
        )

        db_records = db.query_items(key_expression=key_expression)

        self.log.info(InfoMsgs.received_data_from_db.format(operation=self.operation))

        if not db_records:
            return {
                "statusCode": HTTPStatus.NOT_FOUND,
                "body": json.dumps(
                    self.no_resources_found_response(
                        deal_ref_id, field="documentId", value=document_id
                    ),
                    cls=common.decimal_decoder(),
                ),
                "headers": self.response_headers,
            }

        return {
            "statusCode": HTTPStatus.OK,
            "body": json.dumps(db_records, cls=common.decimal_set_decoder()),
            "headers": self.response_headers,
        }

    @GetLambda.catch_exceptions
    @GetLambda.is_handler
    def get_session(self, event, context):
        """
        This method will query on dealRefId and sessionId.
        :param dict event: An API Gateway event object
        :param dict context: AWS Lambda Context Object
        :return: JSON with status code and body
        """
        deal_ref_id = self.path_params.get("dealRefId")
        session_id = self.path_params.get("sessionId")
        deal_component = session_id

        self.log.bind(
            dealRefId=deal_ref_id,
            sessionId=session_id,
            queryStringParameters=self.query_string_params,
            operationId="get_session",
            dealComponent=deal_component,
        )

        event["new_error_message"] = True
        path_params = [
            path
            for path in ["dealRefId", "sessionId"]
            if not self.path_params.get(path)
        ]

        validator = ExistingDealValidator(
            event, deal_ref_id, new_error_message=True, path_parameters=path_params
        )
        validator.validate_api_version(self.request_api_version)

        db = DynamoDbHelper(
            region=Env.AWS_REGION, table_name=DealDataParameters().db_name
        )
        key_expression = Key("dealRefId").eq(deal_ref_id) & Key("dealComponent").eq(
            deal_component
        )

        db_records = db.query_items(key_expression=key_expression)

        self.log.info(InfoMsgs.received_data_from_db.format(operation=self.operation))

        if not db_records:
            return {
                "statusCode": HTTPStatus.NOT_FOUND,
                "body": json.dumps(
                    self.no_resources_found_response(
                        deal_ref_id, field="sessionId", value=session_id
                    ),
                    cls=common.decimal_decoder(),
                ),
                "headers": self.response_headers,
            }

        return {
            "statusCode": HTTPStatus.OK,
            "body": json.dumps(db_records, cls=common.decimal_set_decoder()),
            "headers": self.response_headers,
        }

    @ProducerLambda.catch_exceptions
    @ProducerLambda.is_handler
    def post_document(self, event, context):
        """
        This method will post document on dealRefId with dealComponent:
        'DTC.DOCS.{documentId}' (and 'DTC.DOCS.UPLOADS.{sessionId} if 'pageCount' provided)

        Always creates a document regardless of session

        :param dict event: An API Gateway event object
        :param dict context: AWS Lambda Context Object
        :return: JSON with status code and body
        """
        deal_ref_id = self.path_params.get("dealRefId")
        page_count = self.request_headers.get("pageCount")
        dd_parameters = DealDataParameters()

        self.log.bind(
            dealRefId=deal_ref_id,
            operationId="post_document",
        )

        event["new_error_message"] = True
        path_params = ["dealRefId"] if not deal_ref_id else []

        validator = ExistingDealValidator(
            event, deal_ref_id, new_error_message=True, path_parameters=path_params
        )

        validator.validate_body()
        validator.validate_api_version(self.request_api_version)

        body = json.loads(event.get("body") or "{}", parse_float=Decimal)

        self.log.info(InfoMsgs.body_received.format(body=body))

        if not self.validate_docs_body(validator, body, page_count):
            return {
                "statusCode": HTTPStatus.BAD_REQUEST,
                "body": json.dumps(
                    validator.missing_property_errors,
                    cls=common.decimal_decoder(),
                ),
                "headers": self.response_headers,
            }

        document_id = self.create_document_id(body)
        upload_status = body.get("uploadStatus")
        target_platform = self.get_target_platform(body)

        return_body = {"dealRefId": deal_ref_id, "documentId": document_id}
        deal_component = f"{target_platform}.DOCS.{document_id}"
        return_body.update({"dealComponent": deal_component})

        self.log.bind(dealComponent=deal_component)
        current_time = datetime.isoformat(datetime.utcnow())
        body.update(
            {
                "dealRefId": deal_ref_id,
                "dealComponent": deal_component,
                "uploadStatus": upload_status,
                "createdTimestamp": current_time,
                "updatedTimestamp": current_time,
                "ttl": validator.stored_ttl or common.SingleTTL().general_ttl(),
            }
        )

        db = DynamoDbHelper(region=Env.AWS_REGION, table_name=dd_parameters.db_name)

        save_error = self.save_document(db, validator, body, page_count)
        if save_error:
            self.log.error(ErrorMsgs.error_document_post, **save_error)
            return save_error

        # Indicates that we need to create a session.
        if page_count:
            # sessions are short lived (12 hours) so this logic will instead
            # always work off the proper target platform passed in as argument
            # All session logic will rely on a single record
            converted_page_count = self.validate_page_count(validator, page_count)
            if not converted_page_count:
                return {
                    "statusCode": HTTPStatus.BAD_REQUEST,
                    "body": json.dumps(
                        validator.data_property_errors,
                        cls=common.decimal_decoder(),
                    ),
                    "headers": self.response_headers,
                }
            body.pop("uploadStatus")
            session_id = self.post_session_flow(
                page_count=converted_page_count,
                body=body,
                db=db,
                deal_ref_id=deal_ref_id,
                current_time=current_time,
                target_platform=target_platform,
            )
            return_body.update({"sessionId": session_id})
            self.log.info(InfoMsgs.post_session)
        return {
            "statusCode": HTTPStatus.CREATED,
            "body": json.dumps(return_body, cls=common.decimal_decoder()),
            "headers": self.response_headers,
        }

    @ProducerLambda.catch_exceptions
    @ProducerLambda.is_handler
    def delete_document(self, event, context):
        """
        This method will delete document with dealRefId on DTC.DOCS.{documentId}
        :param dict event: An API Gateway event object
        :param dict context: AWS Lambda Context Object
        :return: JSON with status code and body
        """
        deal_ref_id = self.path_params.get("dealRefId")
        document_id = self.path_params.get("documentId")
        dd_parameters = DealDataParameters()

        # Document ID will actually be the full deal component, making it a true PK-like ID
        deal_component = document_id

        self.log.bind(
            dealRefId=deal_ref_id,
            documentId=document_id,
            dealComponent=deal_component,
            operationId="delete_document",
        )

        event["new_error_message"] = True
        path_params = [
            path
            for path in ["dealRefId", "documentId"]
            if not self.path_params.get(path)
        ]
        validator = ExistingDealValidator(
            event, deal_ref_id, new_error_message=True, path_parameters=path_params
        )

        validator.validate_api_version(self.request_api_version)

        self.log.info(
            InfoMsgs.delete_document.format(
                dealRefId=deal_ref_id, documentId=document_id
            )
        )

        db = DynamoDbHelper(region=Env.AWS_REGION, table_name=dd_parameters.db_name)
        try:
            self.delete_document_record(db, deal_ref_id, deal_component)
        except ClientError as error:
            if error.response["Error"]["Code"] == "ConditionalCheckFailedException":
                return {
                    "statusCode": HTTPStatus.BAD_REQUEST,
                    "body": json.dumps(
                        self.no_resources_found_response(
                            deal_ref_id, field="documentId", value=document_id
                        ),
                    ),
                    "headers": self.response_headers,
                }
            raise error

        self.log.info(InfoMsgs.delete_document_successful)

        return {
            "statusCode": HTTPStatus.NO_CONTENT,
            "headers": self.response_headers,
        }

    @ProducerLambda.catch_exceptions
    @ProducerLambda.is_handler
    def patch_document(self, event, context):
        """
        This method will patch the document on dealRefId with DTC.DOCS.{documentId}:
        :param dict event: An API Gateway event object
        :param dict context: AWS Lambda Context Object
        :return: JSON with status code and body
        """
        deal_ref_id = self.path_params.get("dealRefId")
        document_id = self.path_params.get("documentId")
        deal_component = document_id

        self.log.bind(
            dealRefId=deal_ref_id,
            documentId=document_id,
            dealComponent=deal_component,
            operationId="patch_document",
        )

        event["new_error_message"] = True
        path_params = [
            path
            for path in ["dealRefId", "documentId"]
            if not self.path_params.get(path)
        ]
        validator = ExistingDealValidator(
            event, deal_ref_id, new_error_message=True, path_parameters=path_params
        )

        validator.validate_body()
        validator.validate_api_version(self.request_api_version)

        body = json.loads(event.get("body") or "{}", parse_float=Decimal)
        self.log.info(InfoMsgs.body_received.format(body=body))

        current_time = datetime.isoformat(datetime.utcnow())

        body.update(
            {
                "ttl": validator.stored_ttl or common.SingleTTL().general_ttl(),
                "updatedTimestamp": current_time,
                "dealComponent": deal_component,
                "dealRefId": deal_ref_id,
            }
        )

        self.log.info(InfoMsgs.body_to_be_sent.format(body=body))

        db = DynamoDbHelper(
            region=Env.AWS_REGION, table_name=DealDataParameters().db_name
        )

        try:
            db.update_item(
                partition_key="dealRefId",
                sort_key="dealComponent",
                update_record=body,
                condition_expression=Attr("dealComponent").exists()
                & Attr("dealRefId").exists(),
            )
        except ClientError as error:
            if error.response["Error"]["Code"] == "ConditionalCheckFailedException":
                return_error = self.no_resources_found_response(
                    deal_ref_id, field="documentId", value=document_id
                )
                return {
                    "statusCode": HTTPStatus.BAD_REQUEST,
                    "body": json.dumps(return_error),
                    "headers": self.response_headers,
                }
            raise Exception(error)

        self.log.info(InfoMsgs.patch_event_on_db)

        return {
            "statusCode": HTTPStatus.NO_CONTENT,
            "body": None,
            "headers": self.response_headers,
        }

    @ProducerLambda.catch_exceptions
    @ProducerLambda.is_handler
    def patch_session(self, event, context):
        """
        This method will patch the session on dealRefId with 'DTC.DOCS.UPLOADS.{sessionId}:
        :param dict event: An API Gateway event object
        :param dict context: AWS Lambda Context Object
        :return: JSON with status code and body
        """
        deal_ref_id = self.path_params.get("dealRefId")
        session_id = self.path_params.get("sessionId")
        deal_component = session_id

        self.log.bind(
            dealRefId=deal_ref_id,
            dealComponent=deal_component,
            operationId="patch_session",
        )

        event["new_error_message"] = True
        path_params = [
            path
            for path in ["dealRefId", "sessionId"]
            if not self.path_params.get(path)
        ]

        validator = ExistingDealValidator(
            event, deal_ref_id, new_error_message=True, path_parameters=path_params
        )

        validator.validate_body()
        validator.validate_api_version(self.request_api_version)
        body = json.loads(event.get("body") or "{}", parse_float=Decimal)
        self.log.info(InfoMsgs.body_received.format(body=body))

        current_time = datetime.isoformat(datetime.utcnow())
        body.update(
            {
                "ttl": validator.stored_ttl or common.SingleTTL().general_ttl(),
                "updatedTimestamp": current_time,
                "dealComponent": deal_component,
                "dealRefId": deal_ref_id,
            }
        )

        self.log.info(InfoMsgs.body_to_be_sent.format(body=body))

        db = DynamoDbHelper(
            region=Env.AWS_REGION, table_name=DealDataParameters().db_name
        )

        try:
            db.update_item(
                partition_key="dealRefId",
                sort_key="dealComponent",
                update_record=body,
                condition_expression=Attr("dealComponent").exists()
                & Attr("dealRefId").exists(),
            )
        except ClientError as error:
            if error.response["Error"]["Code"] == "ConditionalCheckFailedException":
                return_error = self.no_resources_found_response(
                    deal_ref_id, field="sessionId", value=session_id
                )
                return {
                    "statusCode": HTTPStatus.BAD_REQUEST,
                    "body": json.dumps(return_error),
                    "headers": self.response_headers,
                }
            raise Exception(error)

        self.log.info(InfoMsgs.patch_event_on_db)

        return {
            "statusCode": HTTPStatus.NO_CONTENT,
            "body": None,
            "headers": self.response_headers,
        }

    @ProducerLambda.catch_exceptions
    @ProducerLambda.is_handler
    def patch_session_page(self, event, context):
        """
        This method will patch the session on dealRefId with 'DTC.DOCS.UPLOADS.{sessionId}:
        :param dict event: An API Gateway event object
        :param dict context: AWS Lambda Context Object
        :return: JSON with status code and body
        """
        deal_ref_id = self.path_params.get("dealRefId")
        session_id = self.path_params.get("sessionId")
        page_id = self.path_params.get("pageId")

        self.log.bind(
            dealRefId=deal_ref_id,
            pageId=page_id,
            operationId="patch_session_page",
        )
        self.log.info(InfoMsgs.patch_session_page_deprecated)

        event["new_error_message"] = True
        path_params = [
            path
            for path in ["dealRefId", "sessionId", "pageId"]
            if not self.path_params.get(path)
        ]

        validator = ExistingDealValidator(
            event, deal_ref_id, new_error_message=True, path_parameters=path_params
        )

        validator.validate_body()
        validator.validate_api_version(self.request_api_version)

        body = json.loads(event.get("body") or "{}", parse_float=Decimal)

        self.log.info(InfoMsgs.body_received.format(body=body))
        deal_component = session_id

        ttl = validator.stored_ttl or common.SingleTTL().general_ttl()

        db = DynamoDbHelper(
            region=Env.AWS_REGION, table_name=DealDataParameters().db_name
        )
        session_record = db.query_db_pk_sk(deal_ref_id, deal_component)
        if not session_record:
            return_error = self.no_resources_found_response(
                deal_ref_id, field="sessionId", value=session_id
            )
            return {
                "statusCode": HTTPStatus.BAD_REQUEST,
                "body": json.dumps(return_error),
                "headers": self.response_headers,
            }

        status = body.get("status")
        location = body.get("location")

        params = self.generate_expression_params(deal_component, status, location, ttl)

        db.table.update_item(**params)
        return {
            "statusCode": HTTPStatus.NO_CONTENT,
            "body": None,
            "headers": self.response_headers,
        }

    def get_target_platform(self, body):
        tps = body.get("targetPlatforms")
        if tps:
            # structure is {id: target_playform} and should always be length 1 in docs
            # as it will be working off a single platform
            return tps[0]["id"]
        self.log.warning(WarningMsgs.post_docs_missing_target_platform, body=body)
        return "DTC"

    def create_document_id(self, body):
        document_type = body.get("documentType").upper()
        customer_role = body.get("customerRole")

        app_type_key = DOCS_CUSTOMER_TYPES.get(customer_role)
        return f"{app_type_key}.{document_type}"

    def validate_query_string_params(self, validator):
        """
        :param validator: validator class instance
        raises error if any of the filter key doesn't exist in allowed list
        """
        try:
            if self.query_string_params:
                assert all(
                    key in GET_DOCS_FILTER_PARAMS for key in self.query_string_params
                ), validator.generate_error_message(
                    "queryParameters",
                    ErrorMsgs.error_unsupported_events_filter.format(
                        filters=GET_DOCS_FILTER_PARAMS
                    ),
                    "invalid_query_params",
                )
        except AssertionError:
            validator.generate_invalid_query_param_errors_message()
            raise BadRequestError(validator.validation_errors)

    def create_filter_expression(self, query_params):
        filter_expression = (
            reduce(
                And,
                (
                    [
                        Attr(k).eq(v) if k not in ["tags"] else Attr(k).contains(v)
                        for k, v in query_params.items()
                    ]
                ),
            )
            if query_params
            else None
        )
        return filter_expression

    def no_resources_found_response(self, deal_ref_id, field=None, value=None):
        if not field:
            field = "dealRefId"
            message = f"No resources found for given dealRefId {deal_ref_id}."
        else:
            message = f"No resources found for given dealRefId: {deal_ref_id} and {field}: {value}."
        return [
            {
                "code": "deal.noResourcesFound",
                "properties": [
                    {
                        "property": field,
                        "message": message,
                    }
                ],
            }
        ]

    def validate_docs_body(self, validator, body, page_count):
        data_validate = {}
        data_validate["documentType"] = body.get("documentType")
        data_validate["customerRole"] = body.get("customerRole")
        if not page_count:
            data_validate["uploadStatus"] = body.get("uploadStatus")

        if not all(data_validate.values()):
            validator.generate_error_message(
                "body",
                ErrorMsgs.missing_body_fields_docs.format(
                    fields=list(data_validate.keys())
                ),
                indicator="missing_data",
            )
            return False

        if data_validate["customerRole"] not in DOCS_CUSTOMER_TYPES:
            validator.generate_error_message(
                "body",
                ErrorMsgs.invalid_customer_type.format(
                    values=list(DOCS_CUSTOMER_TYPES.keys())
                ),
                indicator="missing_data",
            )
            return False

        return True

    def validate_page_count(self, validator, page_count):
        try:
            converted_page_count = int(page_count)
            return converted_page_count
        except Exception:
            validator.generate_error_message(
                "headers",
                ErrorMsgs.invalid_page_count,
                indicator="invalid_data",
            )
        return False

    def post_session_flow(
        self,
        page_count,
        body,
        db,
        deal_ref_id,
        current_time,
        target_platform,
    ):
        mutation_free_body = copy.deepcopy(body)
        session_id = ulid.new().str
        mutation_free_body.update(
            {
                "dealRefId": deal_ref_id,
                "dealComponent": f"{target_platform}.DOCS.UPLOADS.{session_id}",
                "createdTimestamp": current_time,
                "updatedTimestamp": current_time,
                "pages": {
                    str(page): {"status": "Initialized"}
                    for page in range(1, page_count + 1)
                },
                "ttl": common.SingleTTL().document_session_ttl(),
            }
        )
        db.update_item(
            partition_key="dealRefId",
            sort_key="dealComponent",
            update_record=mutation_free_body,
            condition_expression=Attr("dealComponent").not_exists(),
        )
        return session_id

    def generate_expression_params(self, deal_component, status, location, ttl):
        params = {
            "Key": {
                "dealComponent": deal_component,
                "dealRefId": self.path_params["dealRefId"],
            },
            "UpdateExpression": "SET #pages.#num.#sts = :v, #ttl = :ttl, updatedTimestamp = :timestamp",
            "ExpressionAttributeNames": {
                "#pages": "pages",
                "#num": self.path_params["pageId"],
                "#sts": "status",
                "#ttl": "ttl",
            },
            "ExpressionAttributeValues": {
                ":v": status,
                ":ttl": ttl,
                ":timestamp": datetime.isoformat(datetime.utcnow()),
            },
        }

        if status and location:
            params["UpdateExpression"] = params["UpdateExpression"].replace(".#sts", "")
            params["ExpressionAttributeNames"].pop("#sts")
            params["ExpressionAttributeValues"].update(
                {":v": {"status": status, "location": location}}
            )
        return params

    def save_document(self, db, validator, body, page_count):
        error_body = {}
        unmutated = copy.deepcopy(body)
        try:
            db.update_item(
                partition_key="dealRefId",
                sort_key="dealComponent",
                update_record=unmutated,
                condition_expression=Attr("dealComponent").not_exists(),
            )
        except ClientError as error:
            # Only throw an error if pageCount is not given.
            # This prevents a dealRefId from having multiple document (but still allows multiple sessions).
            if not page_count:
                if error.response["Error"]["Code"] == "ConditionalCheckFailedException":
                    validator.generate_error_message(
                        "dealComponent",
                        ErrorMsgs.duplicate_document_record,
                        indicator="invalid_data",
                    )
                    validator.generate_data_property_errors_message()
                    error = validator.validation_errors
                    return_error = eval(str(error))
                    error_body = {
                        "statusCode": HTTPStatus.BAD_REQUEST,
                        "body": json.dumps(return_error),
                        "headers": self.response_headers,
                    }
                    return error_body
                raise Exception(error)
        return error_body

    def delete_document_record(self, db, deal_ref, deal_component):
        db.table.delete_item(
            Key={
                "dealRefId": deal_ref,
                "dealComponent": deal_component,
            },
            ConditionExpression=(
                Attr("dealRefId").exists() & Attr("dealComponent").exists()
            ),
        )


def docs_handlers(event, content):
    if (
        event.get("headers", {}).get(settings.HEALTHCHECK_HEADER_FIELD)
        == settings.HEALTHCHECK_HEADER_VALUE
    ):
        return {"statusCode": HTTPStatus.OK, "body": json.dumps("Operational")}

    operation = event.get("requestContext").get("operationName")
    docs_lambda = DocsLambda(operation=operation)

    routes = {
        "get_documents": docs_lambda.get_handler(handler_func="get_documents"),
        "get_single_document": docs_lambda.get_handler(
            handler_func="get_single_document"
        ),
        "get_session": docs_lambda.get_handler(handler_func="get_session"),
        "post_document": docs_lambda.get_handler(handler_func="post_document"),
        "patch_document": docs_lambda.get_handler(handler_func="patch_document"),
        "patch_session": docs_lambda.get_handler(handler_func="patch_session"),
        "patch_session_page": docs_lambda.get_handler(
            handler_func="patch_session_page"
        ),
        "delete_document": docs_lambda.get_handler(handler_func="delete_document"),
    }

    handler_function = routes.get(operation)

    return handler_function(event, content)
