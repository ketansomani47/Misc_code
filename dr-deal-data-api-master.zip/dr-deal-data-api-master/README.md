# Deal Data API

This is an internal api that facilitates digital transactions related to the Deal Financing process

For more information please refer to wiki pages https://ghe.coxautoinc.com/DT-SFI/dr-deal-data-api/wiki
