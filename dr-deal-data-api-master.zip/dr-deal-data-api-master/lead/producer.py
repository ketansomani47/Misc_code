# -*- coding: utf-8 -*-
import json
from decimal import Decimal
from http import HTTPStatus

import dr_utils
import ulid
from common.deal_consumer import DealConsumerLambda, generate_records
from common.lambda_base import ProducerLambda
from common.settings import (
    DEAL_REF_ID_HEADER_KEY,
    Env,
    ErrorMsgs,
    PayloadType as pt,
    SchemaType,
)
from common.validators import ExistingDealValidator
from utils import common, db_helper, exceptions, schema as schema_module
from utils.common import (
    DealDataParameters,
    convert_empty_strings_to_none,
    remove_root_none_nodes,
)


class LeadProducerLambda(ProducerLambda):
    def __init__(self, **kwargs):

        super().__init__(**kwargs)
        self.deal_ref_id = None
        self.lead_ref_id = None

    @ProducerLambda.catch_exceptions
    @ProducerLambda.is_handler
    def new_deal_handler(self, event: dict, context: dict):
        """
        Handles the Lead Post for new Deal endpoint. Creates a new Lead and a new Deal simultaneously.

        Endpoint: /deals/leads

        This asynchronous API generates new dealRefId and leadRefId submits a message to DealDataQueue, then returns
        these IDs to the client with HTTP status CREATED (201).

        :param dict event: An API Gateway event object
        :param dict context: AWS Lambda Context Object
        :return: JSON with status code and body
        """

        new_deal_ulid = False
        new_lead_ulid = False

        deal_ref_id_header = self.request_headers.get(DEAL_REF_ID_HEADER_KEY)

        if deal_ref_id_header and deal_ref_id_header.strip():
            self.deal_ref_id = deal_ref_id_header
        else:
            self.deal_ref_id = ulid.new().str
            new_deal_ulid = True

        if deal_ref_id_header and deal_ref_id_header.strip():
            self.lead_ref_id = deal_ref_id_header
        else:
            self.lead_ref_id = ulid.new().str
            new_lead_ulid = True

        common.verify_ulid(self.deal_ref_id) if not new_deal_ulid else None
        common.verify_ulid(self.lead_ref_id) if not new_lead_ulid else None

        self.log.bind(dealRefId=self.deal_ref_id, leadRefId=self.lead_ref_id)
        self.log.info("Lead creation request received for new deal")

        validator = ExistingDealValidator(event, self.deal_ref_id)
        if not new_deal_ulid and validator.deal_exists():
            raise exceptions.BadRequestError(
                ErrorMsgs.deal_ref_id_already_exists.format(
                    deal_ref_id=self.deal_ref_id
                )
            )

        data = validator.validate_body()
        validator.validate_id_uniqueness(
            self.payload_type, reference_id=self.lead_ref_id
        )
        data["leadRefId"] = self.lead_ref_id
        data["baggage"] = self.baggage

        # add key_data dict to data with keys extracted from headers
        data.update(self.key_data)
        data = common.verify_and_add_source_partner_dealer_id(data)

        # Save a minimal version of the deal to speed up availability for credit app patch
        deal_stub = {"leadRefId": self.lead_ref_id}
        records = self.prepare_records_for_db(deal_stub)
        records = json.loads(
            json.dumps(records, cls=dr_utils.DecimalEncoder), parse_float=Decimal
        )
        self.persist(records)
        self.log.info("Partial application persisted to database")
        self.log.bind(requestPayload=data)

        dr_utils.send_payload_to_queue(
            queue=Env.DEAL_DATA_QUEUE,
            payload=data,
            region=Env.AWS_REGION,
            msg_group_id=self.deal_ref_id,
            payloadType=self.payload_type,
            correlationId=self.correlation_id,
            dealRefId=self.deal_ref_id,
            leadRefId=self.lead_ref_id,
        )

        self.log.info(f"Lead sent to queue: {Env.DEAL_DATA_QUEUE}")

        return_body = {"dealRefId": self.deal_ref_id, "leadRefId": self.lead_ref_id}

        return {
            "statusCode": HTTPStatus.CREATED,
            "body": json.dumps(return_body),
            "headers": self.response_headers,
        }

    @ProducerLambda.catch_exceptions
    @ProducerLambda.is_handler
    def existing_deal_handler(self, event: dict, context: dict):
        """
        Handles the Lead Post for existing Deal endpoint. Creates a new Lead under an existing Deal.

        Endpoint: /deals/{dealRefId}/leads/

        This asynchronous API generates new leadRefId submits a message to DealDataQueue, then returns these IDs to
        the client with HTTP status CREATED (201).

        :param dict event: An API Gateway event object
        :param dict context: AWS Lambda Context Object
        :return: JSON with status code and body
        """

        deal_ref_id_header = self.request_headers.get(DEAL_REF_ID_HEADER_KEY)
        self.deal_ref_id = common.get_path_parameter(event, "dealRefId")
        self.lead_ref_id = (
            deal_ref_id_header
            if deal_ref_id_header and deal_ref_id_header.strip()
            else ulid.new().str
        )
        common.verify_ulid(self.lead_ref_id)

        self.log.bind(dealRefId=self.deal_ref_id, leadRefId=self.lead_ref_id)
        self.log.info("Lead creation request received for exiting deal")

        validator = ExistingDealValidator(event, self.deal_ref_id)
        validator.validate_body()
        validator.validate_api_version(self.request_api_version)
        validator.validate_id_uniqueness(
            self.payload_type, reference_id=self.lead_ref_id
        )

        data = validator.data
        data["leadRefId"] = self.lead_ref_id
        data["baggage"] = self.baggage

        # add key_data dict to data with keys extracted from headers
        data.update(self.key_data)
        data = common.drop_ref_ids_from_payload(data)

        self.log.bind(requestPayload=data)

        dr_utils.send_payload_to_queue(
            queue=Env.DEAL_DATA_QUEUE,
            payload=data,
            region=Env.AWS_REGION,
            msg_group_id=self.deal_ref_id,
            payloadType=self.payload_type,
            correlationId=self.correlation_id,
            dealRefId=self.deal_ref_id,
            leadRefId=self.lead_ref_id,
            dealTTL=validator.stored_ttl,
        )

        self.log.info(
            f"Lead creation request for existing deal sent to queue: {Env.DEAL_DATA_QUEUE}"
        )

        return_body = {"dealRefId": self.deal_ref_id, "leadRefId": self.lead_ref_id}

        return {
            "statusCode": HTTPStatus.CREATED,
            "body": json.dumps(return_body),
            "headers": self.response_headers,
        }

    @ProducerLambda.catch_exceptions
    @ProducerLambda.is_handler
    def update_handler(self, event: dict, context: dict):
        """
        Handles the Lead Update endpoint. Updates an existing Lead under an existing Deal.
        Endpoint: /deals/{dealRefId}/leads/{leadRefId}/

        This asynchronous API submits a message to DealDataQueue, then returns this ID to the client with
        HTTP status NO_CONTENT (204).

        :param dict event: An API Gateway event object
        :param dict context: AWS Lambda Context Object
        :return: JSON with status code and body
        """

        self.deal_ref_id = common.get_path_parameter(event, "dealRefId")
        self.lead_ref_id = common.get_path_parameter(event, "leadRefId")

        self.log.bind(dealRefId=self.deal_ref_id, leadRefId=self.lead_ref_id)
        self.log.info("Lead update request received")

        validator = ExistingDealValidator(event, self.deal_ref_id)
        validator.validate_body()
        validator.validate_api_version(self.request_api_version)
        validator.validate_id_uniqueness(
            self.payload_type, resource_id=self.lead_ref_id
        )

        data = validator.data
        data["leadRefId"] = self.lead_ref_id
        data["baggage"] = self.baggage

        # add key_data dict to data with keys extracted from headers
        data.update(self.key_data)
        data = common.drop_ref_ids_from_payload(data)

        self.log.bind(requestPayload=data)

        dr_utils.send_payload_to_queue(
            queue=Env.DEAL_DATA_QUEUE,
            payload=data,
            region=Env.AWS_REGION,
            msg_group_id=self.deal_ref_id,
            payloadType=self.payload_type,
            correlationId=self.correlation_id,
            dealRefId=self.deal_ref_id,
            leadRefId=self.lead_ref_id,
            dealTTL=validator.stored_ttl,
        )

        self.log.info(f"Lead update request sent to queue: {Env.DEAL_DATA_QUEUE}")

        return {
            "statusCode": HTTPStatus.NO_CONTENT,
            "body": "Lead was updated",
            "headers": self.response_headers,
        }

    def prepare_records_for_db(self, deal_data: dict) -> list:
        # TODO: 2023-06-09 Amaury: This is a duplication of store_to_database, added temporarily because the latter is
        #  too tightly-coupled to DealConsumerLambda and separating it at this time would affect sprint commitments.

        deal_data = DealConsumerLambda.transform_lender_list_payload(deal_data)
        deal_data = remove_root_none_nodes(deal_data)

        schema_type = SchemaType.get_schema_name(self.payload_type)
        schema = schema_module.get_schema(
            self.request_api_version, schema_type, deal_data
        )

        # pre process data for schema validation
        deal_app = db_helper.pre_process_data_for_post(schema, deal_data)

        # convert empty string to None because dynamodb doesn't accept empty strings
        deal_app = convert_empty_strings_to_none(deal_app)

        # List to persist the dynamodb records in batch mode
        records = []

        records.extend(generate_records(deal_app))

        return records

    def persist(self, records):
        db_helper.persist_deal_records(
            records, self.deal_ref_id, DealDataParameters().db_name
        )


def lead_handlers(event, content):
    handler_function = None
    if event.get("requestContext").get("operationName") == "lead_new_deal":
        handler_function = LeadProducerLambda().get_handler(
            handler_func="new_deal_handler", payload_type=pt.LEAD_POST
        )(event, content)

    if event.get("requestContext").get("operationName") == "lead_existing_deal":
        handler_function = LeadProducerLambda().get_handler(
            handler_func="existing_deal_handler", payload_type=pt.LEAD_PATCH
        )(event, content)

    if event.get("requestContext").get("operationName") == "lead_update":
        handler_function = LeadProducerLambda().get_handler(
            handler_func="update_handler", payload_type=pt.LEAD_UPDATE
        )(event, content)
    return handler_function
