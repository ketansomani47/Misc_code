# -*- coding: utf-8 -*-
import argparse
import logging

import boto3


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger()


def get_function_name(deploy_env):
    """
    The function returns the name of the health check lambda function.
        :param deploy_env: one of the standard environments for deal data api
        :return: returns the name of the health check lambda function.
    """
    return f"dr-deal-data-api-{deploy_env}-deal_data_healthcheck"


def update_lambda_environment_variable(deploy_env: str, region: str, value: str):
    """
    The function updates the DEPLOY_STATUS environment variable.
    :param deploy_env:
    :param region:
    :param value:
    :return:
    """
    client = boto3.client("lambda", region_name=region)
    function_name = get_function_name(deploy_env)
    config = client.get_function_configuration(FunctionName=function_name)
    env_variables = config["Environment"]
    env_variables["Variables"]["DEPLOY_STATUS"] = value
    client.update_function_configuration(
        FunctionName=function_name, Environment=env_variables
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Get healthy stack region")
    parser.add_argument("--action", action="store")
    parser.add_argument("--deploy-env", action="store")
    parser.add_argument("--region", action="store")
    parser.add_argument("--env-value", action="store")

    args = parser.parse_args()

    if args.action == "update_variable":
        update_lambda_environment_variable(
            deploy_env=args.deploy_env, region=args.region, value=args.env_value
        )
