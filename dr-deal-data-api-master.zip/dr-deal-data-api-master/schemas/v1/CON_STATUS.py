# -*- coding: utf-8 -*-

schema = {
    "sourcePartnerId": "str",
    "targetPlatforms": [{"id": "str", "partyId": "str"}],
    "contractStatusCode": "str",
}
