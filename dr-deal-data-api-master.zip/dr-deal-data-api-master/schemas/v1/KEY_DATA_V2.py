# -*- coding: utf-8 -*-
from common.settings import TargetPlatformIds
from schemas.v1.KEY_DATA import DB_FIELD_MAPPING


# Backward compatability mapping
DB_FIELD_MAPPING_V2 = {
    **DB_FIELD_MAPPING,
    TargetPlatformIds.DTC: {
        "dealJacketId": "dealJacketId",
        "dealId": "dealIdFI",
        "dealerId": "dealerId",
        "dealerCode": "dealerCode",
        "documentMasterIndexId": "documentMasterIndexIdFI",
        "commonOrgId": "commonOrgId",
    },
}
EXCLUDED_KEY_DATA_FIELDS_FROM_DEAL_RECORDS = ["dealXgDealId", "dealXgDealVersion"]

KEY_DATA_SCHEMA = {
    TargetPlatformIds.DTA: {
        "creditAppId": "str",
        "financeMethod": "str",
        "proxyPartnerId": "str",
        "dealXgDealId": "str",
        "dealXgDealVersion": "str",
        "dealRefIdFD": "str",
        "dealRefIdFDInt": "Number",
    },
    TargetPlatformIds.DTC: {
        "creditAppId": "str",
        "dealJacketId": "str",
        "dealId": "str",
        "dealerId": "str",
        "dealerCode": "str",
        "documentMasterIndexId": "str",
        "commonOrgId": "str",
    },
    TargetPlatformIds.IDL: {
        "creditAppId": "str",
        "dealJacketId": "str",
        "dealId": "str",
        "dealerCode": "str",
        "documentMasterIndexId": "str",
    },
    TargetPlatformIds.R1J: {
        "creditAppId": "str",
        "creditAppIdR1": "str",
        "conversationId": "str",
        "dealJacketId": "str",
    },
}

CONDITIONAL_VALIDATIONS = {
    TargetPlatformIds.DTA: {
        "financeMethod": "creditAppId",
        "creditAppId": "financeMethod",
    },
    TargetPlatformIds.DTC: {"dealId": "creditAppId", "creditAppId": "dealId"},
    TargetPlatformIds.IDL: {"dealId": "creditAppId", "creditAppId": "dealId"},
    TargetPlatformIds.R1J: {
        "conversationId": "creditAppId",
        "creditAppId": "conversationId",
        "creditAppIdR1": "conversationId",
    },
}

SUPPORTED_QUERY_STRINGS = {
    TargetPlatformIds.DTA: [
        "dealRefId",
        "creditAppId",
        "appRefIdFD",
        "dealRefIdFD",
        "appRefIdFDInt",
        "dealRefIdFDInt",
    ],
    TargetPlatformIds.DTC: ["dealJacketId"],
    TargetPlatformIds.IDL: ["dealJacketId"],
    TargetPlatformIds.R1J: ["conversationId", "dealJacketId"],
}

TARGET_PLATFORM_STANDARD_REF_V2 = {
    "DTA": "creditAppId",
    "DTC": "dealId",
    "IDL": "dealId",
    "R1J": "conversationId",
}


schema = {}
