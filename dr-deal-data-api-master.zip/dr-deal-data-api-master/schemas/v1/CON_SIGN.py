# -*- coding: utf-8 -*-

schema = {
    "sourcePartnerId": "str",
    "targetPlatforms": [{"id": "str", "partyId": "str"}],
    "applicant": {
        "emailAddress": "str",
        "firstName": "str",
        "lastName": "str",
        "phone": "str",
    },
    "coApplicant": {
        "emailAddress": "str",
        "firstName": "str",
        "lastName": "str",
        "phone": "str",
    },
    "dealer": {
        "emailAddress": "str",
        "firstName": "str",
        "lastName": "str",
        "phone": "str",
        "dealerName": "str",
    },
    "guarantorPrimary": {
        "emailAddress": "str",
        "firstName": "str",
        "lastName": "str",
        "phone": "str",
    },
    "guarantorAdditional": {
        "emailAddress": "str",
        "firstName": "str",
        "lastName": "str",
        "phone": "str",
    },
}
