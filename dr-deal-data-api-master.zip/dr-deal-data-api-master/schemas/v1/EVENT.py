# -*- coding: utf-8 -*-

schema = {
    "eventVersion": "Number",
    "eventId": "str",
    "eventTime": "str",
    "eventName": "str",
    "eventDetailHref": "str",
    "eventSource": "str",
    "eventType": "str",
    "eventIdentityId": "str",
    "eventEntityId": "str",
    "eventTransactionId": "str",
    "payloadSchemaHref": "str",
    "eventKeyData": {},
    "payload": {},
}
