# -*- coding: utf-8 -*-
from common.settings import TargetPlatformIds


def generate_key_data_schema():
    """
    Generates GET flatted schema
    :return:
    """
    flat_schema = {}
    for target_platform, mapping in DB_FIELD_MAPPING.items():
        flat_schema.update(mapping)
    return flat_schema


DB_FIELD_MAPPING = {
    TargetPlatformIds.DTA: {
        "dealRefId": "dealRefId",
        "creditAppId": "creditAppId",
        "leadRefId": "leadRefId",
        "contractRefId": "contractRefId",
        "appRefIdFD": "appRefIdFD",
        "dealRefIdFD": "dealRefIdFD",
        "appRefIdFDInt": "appRefIdFDInt",
        "dealRefIdFDInt": "dealRefIdFDInt",
        "partnerCode": "partnerCode",
        "sourcePartnerId": "sourcePartnerId",
        "sourcePartnerDealerId": "sourcePartnerDealerId",
        "proxyPartnerId": "proxyPartnerId",
        "financeMethod": "financeMethod",
        "dealXgDealId": "dealXgDealId",
        "dealXgDealVersion": "dealXgDealVersion",
    },
    TargetPlatformIds.DTC: {
        "dealJacketId": "dealJacketId",
        "dealRefIdFI": "dealRefIdFI",
        "dealIdFI": "dealIdFI",
        "dealerId": "dealerId",
        "dealerCode": "dealerCode",
        "documentMasterIndexIdFI": "documentMasterIndexIdFI",
        "commonOrgId": "commonOrgId",
    },
    TargetPlatformIds.IDL: {
        "dealJacketId": "dealJacketIdIDL",
        "dealId": "dealIdIDL",
        "dealerCode": "dealerCodeIDL",
        "documentMasterIndexId": "documentMasterIndexIdIDL",
    },
    TargetPlatformIds.R1J: {
        "dealJacketId": "dealJacketIdR1",
        "conversationId": "conversationIdR1",
        "creditAppIdR1": "creditAppIdR1",
    },
}

SUPPORTED_QUERY_STRINGS = [
    "dealRefId",
    "creditAppId",
    "contractRefId",
    "leadRefId",
    "appRefIdFD",
    "dealRefIdFD",
    "appRefIdFDInt",
    "dealRefIdFDInt",
    "dealJacketId",
    "dealRefIdFI",
    "conversationId",
    "creditAppIdR1",
]


TARGET_PLATFORM_RECORD = {
    "DTA": {
        "creditAppId": "creditAppId",
        "leadRefId": "leadRefId",
        "contractRefId": "contractRefId",
        "dealRefIdFD": "dealRefIdFD",
        "dealRefIdFDInt": "dealRefIdFDInt",
        "partnerCode": "partnerCode",
        "sourcePartnerId": "sourcePartnerId",
        "proxyPartnerId": "proxyPartnerId",
        "financeMethod": "financeMethod",
        "dealXgDealId": "dealXgDealId",
        "dealXgDealVersion": "dealXgDealVersion",
    },
    "DTC": {
        "dealJacketId": "dealJacketId",
        "dealerId": "dealerId",
        "dealerCode": "dealerCode",
        "documentMasterIndexIdFI": "documentMasterIndexId",
        "commonOrgId": "commonOrgId",
    },
    "IDL": {
        "dealJacketIdIDL": "dealJacketId",
        "dealerCodeIDL": "dealerCode",
        "documentMasterIndexIdIDL": "documentMasterIndexId",
    },
    "R1J": {"dealJacketIdR1": "dealJacketId"},
}


TARGET_PLATFORM_STANDARD_REF_RECORD = {
    "DTA": {
        "appRefIdFDInt": "appRefIdFDInt",
        "appRefIdFD": "appRefIdFD",
        "creditAppId": "creditAppId",
    },
    "DTC": {"dealIdFI": "dealId", "creditAppId": "creditAppId"},  # DTA creditAppId
    "IDL": {"dealIdIDL": "dealId", "creditAppId": "creditAppId"},  # DTA creditAppId
    "R1J": {
        "conversationIdR1": "conversationId",
        "creditAppIdR1": "creditAppIdR1",
        "creditAppId": "creditAppId",  # DTA creditAppId
    },
}


TARGET_PLATFORM_STANDARD_REF = {
    "DTA": "creditAppId",
    "DTC": "dealIdFI",
    "IDL": "dealIdIDL",
    "R1J": "conversationIdR1",
}


schema = generate_key_data_schema()
