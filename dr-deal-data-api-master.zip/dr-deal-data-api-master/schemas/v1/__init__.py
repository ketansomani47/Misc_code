# -*- coding: utf-8 -*-
from schemas.v1 import (  # noqa
    CA,
    CA_GET,
    CB,
    CON,
    CON_SIGN,
    CON_STATUS,
    DEAL_GET,
    EVENT,
    KEY_DATA,
    KEY_DATA_V2,
    LEAD,
)
