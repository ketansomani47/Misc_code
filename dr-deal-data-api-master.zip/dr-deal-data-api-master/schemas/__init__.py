# -*- coding: utf-8 -*-
from schemas import v1  # noqa
