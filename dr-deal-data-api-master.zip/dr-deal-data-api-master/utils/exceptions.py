# -*- coding: utf-8 -*-


class RoutingError(Exception):
    """Raised when given data failed to route to target platform's queue"""


class SnapshotSaveError(Exception):
    """Raised when given data failed to save in s3 bucket as snapshot"""


class BadRequestError(Exception):
    """Raised when given request is bad request"""


class NoRecordsFoundError(Exception):
    """Raised when a database query that was expected to find at least one record finds none"""


class DynamoDBException(Exception):
    """Raised when a error/ exception other than client error occurs for any operation to dynamoDB"""


class DealStatusException(Exception):
    """Raised when an exception occurs to update deal status to dynamoDB"""


class S3SaveError(Exception):
    """Raised when given data failed to save in s3 bucket"""
