# -*- coding: utf-8 -*-
import copy
import json
from datetime import datetime

import boto3
from boto3.dynamodb import conditions
from boto3.dynamodb.conditions import Attr, Key
from botocore.config import Config
from common import settings as common_settings
from common.settings import PROTECTED_KEY_NAME, Env
from dynamodb_json import json_util
from utils import EventsEnum, logger
from utils.exceptions import DynamoDBException


class DynamoDbHelper:
    def __init__(self, region, table_name):
        self.table_name = table_name
        self.region = region

        config = Config(
            connect_timeout=5,
            read_timeout=5,
            retries={"max_attempts": 3, "mode": "standard"},
        )

        db = boto3.resource("dynamodb", region_name=region, config=config)
        self.table = db.Table(table_name)

    def query_items(
        self,
        key_expression=None,
        key_expr_dict=None,
        index=None,
        filter_expression=None,
    ):
        """
        Will fetch all records of particular key condition expression
        If filter_key_value is provided function itself creates key_expression with basic & condition in between
        multiple filter keys
        For complex filter_expression, provide filter_expression instead of filter_key_value
        :param key_expr_dict: (dict) Should be dict format:
                                { "filter key": {
                                                "operation": "eq",
                                                "value": "filter value",
                                                }}
        :param key_expression: (boto3 condition object) Filter expression to fetch records from dynamo
        :param index: Name of an index to query.
        :return: List of records
        """
        if not key_expression:
            for counter, (key, value) in enumerate(key_expr_dict.items()):
                exp = eval(
                    f"conditions.Key('{key}').{value.get('operation')}('{value.get('value')}')"
                )
                key_expression = key_expression & exp if counter > 0 else exp

        if index:
            records = (
                self.table.query(
                    KeyConditionExpression=key_expression,
                    IndexName=index,
                    FilterExpression=filter_expression,
                )
                if filter_expression
                else self.table.query(
                    KeyConditionExpression=key_expression, IndexName=index
                )
            )
        else:
            records = (
                self.table.query(
                    KeyConditionExpression=key_expression,
                    FilterExpression=filter_expression,
                )
                if filter_expression
                else self.table.query(KeyConditionExpression=key_expression)
            )

        return records.get("Items", [])

    def query_pk_filter(self, key_expr: Key, filter_expr: Attr):
        """

        :param key_expr: dealRefId from path parameters
        :param filter_expr: List of 3-tuples representing (attribute_key, operation, attribute_value)
        :return: records list
        """

        return self.table.query(
            KeyConditionExpression=key_expr, FilterExpression=filter_expr
        ).get("Items")

    def query_with_selected_attributes(self, key_expr: Key, attributes: str):
        """
        query data from table with projected attributes
        :param key_expr: dealRefId from path parameters
        :param attributes: projection attributes
        :return: records list
        """

        return self.table.query(
            KeyConditionExpression=key_expr, ProjectionExpression=attributes
        ).get("Items")

    def scan_items(
        self,
        filter_expression=None,
        filter_expr_dict=None,
        get_first_found_records=True,
    ):
        """
        Will fetch all records of particular filter condition
        If filter_key_value is provided function itself creates filter_expression with basic & condition in between
        multiple filter keys
        For complex filter_expression, provide filter_expression instead of filter_key_value
        :param filter_expr_dict: (dict) Should be dict format:
                                { "filter key": {
                                                "operation": "eq",
                                                "value": "filter value",
                                                }}
        :param filter_expression: (boto3 condition object) Filter expression to fetch records from dynamo
        :param get_first_found_records: flag to send first found record instead of waiting to scan entire table
        :return: List of records
        """
        if not filter_expression:
            for counter, (key, value) in enumerate(filter_expr_dict.items()):
                exp = eval(
                    f"conditions.Attr('{key}').{value.get('operation')}('{value.get('value')}')"
                )
                filter_expression = filter_expression & exp if counter > 0 else exp

        filter_kwargs = {"FilterExpression": filter_expression}
        done = False
        items = []
        while not done:
            response = self.table.scan(**filter_kwargs)
            items.extend(response.get("Items", []))
            if get_first_found_records and items:
                done = True
            if response.get("LastEvaluatedKey", {}) == {}:
                done = True
            filter_kwargs["ExclusiveStartKey"] = response.get("LastEvaluatedKey")
        return items

    def update_item(
        self, partition_key, update_record, sort_key=None, condition_expression=None
    ):
        """
        Update item with record if given partition key and value are present in table.

        - To update composite primary key table, both partition key and sort key are required, if failed to provide
          ClientError is raised
        - To update simple primary key table, only partition key is required

        :param partition_key: (string) partition key of table
        :param update_record: (dict) record required fields that need to be updated, partition, sort key and value
        :param sort_key: (string) sort key must be provided for table which contain composite primary key
        :param condition_expression: (boto3 condition object) conditional expression at which record need to be updated,
                If not provided function creates following conditional expression
                - If simple primary key table condition with partition key and value
                - If composite primary key table condition with partition key and sort key values
        :return: None
        """
        update_expression_list = []
        expression_attribute_names = {}
        expression_attribute_values = {}

        partition_value = update_record.pop(partition_key)
        key_info = {partition_key: partition_value}
        if sort_key:
            sort_key_val = update_record.pop(sort_key)
            key_info.update({sort_key: sort_key_val})

        if not condition_expression:
            condition_expression = conditions.Attr(partition_key).eq(
                str(partition_value)
            )
            if sort_key:
                condition_expression = condition_expression & conditions.Attr(
                    sort_key
                ).eq(str(sort_key_val))

        for key, val in update_record.items():
            update_expression_list.append(f"#{key} = :{key}")
            expression_attribute_names[f"#{key}"] = str(key)
            expression_attribute_values[f":{key}"] = val

        self.table.update_item(
            Key=key_info,
            ConditionExpression=condition_expression,
            UpdateExpression=f"SET {' , '.join(update_expression_list)}",
            ExpressionAttributeNames=expression_attribute_names,
            ExpressionAttributeValues=expression_attribute_values,
        )

    def query_db_pk_sk(
        self,
        deal_ref_id: str,
        deal_component: str = None,
        deal_component_op: str = "eq",
    ):
        """
        Query DynamoDB by PartitionKey and SortKey
        :param deal_ref_id: dealRefId from path parameters
        :param deal_component: sort key for the db to form key expression
        :param deal_component_op: boto3 key expression attribute operation ('eq', 'begins_with')
        :return: version number from db
        """

        key_expression = Key("dealRefId").eq(deal_ref_id)
        if deal_component:
            component_expr = getattr(Key("dealComponent"), deal_component_op)(
                deal_component
            )
            key_expression = key_expression & component_expr

        return self.query_items(key_expression=key_expression)


def persist_deal_records(records: list, pk: str, table_name: str):
    """
    Update each record with dealRefId, createdTimestamp and updatedTimestamp and insert data into dynamodb.
    :param records: list of records that need to be persisted
    :param string pk: Partition key
    :param table_name: dynamo db table name
    :return: None
    """

    current_time = datetime.isoformat(datetime.utcnow())

    try:
        dynamodb = boto3.resource("dynamodb", region_name=Env.AWS_REGION)
        table = dynamodb.Table(table_name)

        with table.batch_writer() as batch:
            for record in records:
                record.update(
                    {
                        "dealRefId": pk,
                        "createdTimestamp": current_time,
                        "updatedTimestamp": current_time,
                    }
                )
                batch.put_item(record)
    except Exception as e:
        logger.exception(
            f"Exception: Application failed to perform STORE operation with error: {e}",
            aws_event=EventsEnum.app_processing_failed,
        )
        raise DynamoDBException(str(e))


def update_deal_records(
    update_expressions: dict,
    attr_names: dict,
    attr_values: dict,
    deal_ref_id: str,
    db_name: str,
):
    """
    This method goes through each record and generate transact update item list as per boto3 syntax
    :param update_expressions: An expression that defines one or more attributes to be updated, the action to be
        performed on them, and new values for them
    :param attr_names: One or more substitution tokens for attribute names in an expression
    :param attr_values: One or more values that can be substituted in an expression.
    :param deal_ref_id: deal_ref_id, ulid corresponding to a deal
    :param db_name: DynamoDB name
    :return: record expression list with multiple update query expressions
    """
    # TODO: tech-debt data-access methods should be defined in their own mixin classes to keep code modular.
    records = []
    for key, value in update_expressions.items():
        records.append(
            {
                "Update": {
                    "Key": {
                        "dealRefId": {"S": deal_ref_id},
                        "dealComponent": {"S": key},
                    },
                    "UpdateExpression": f"SET {value}",
                    "TableName": db_name,
                    "ConditionExpression": "attribute_exists(dealRefId)",
                    "ExpressionAttributeNames": attr_names[key],
                    "ExpressionAttributeValues": attr_values[key],
                }
            }
        )
    try:
        dynamodb_client = boto3.client("dynamodb", region_name=Env.AWS_REGION)
        dynamodb_client.transact_write_items(TransactItems=records)
    except Exception as e:
        logger.exception(
            f"Exception: Application failed to perform UPDATE operation with error: {e}",
            aws_event=EventsEnum.app_update_processing_failed,
        )
        raise DynamoDBException(str(e))


def generate_dynamodb_json_structure(key, val):
    """
    To update in dynamodb, it requires a certain format for attribute value dict object. For that object we need to
    change python data types to dynamodb data types so that db can understand and update a specific type. For example ->
        ExpressionAttributeValues": {
          "string" : {
             "B": blob,
             "BOOL": boolean,
             "BS": [ blob ],
             "L": [
                "AttributeValue"
             ],
             "M": {
                "string" : "AttributeValue"
             },
             "N": "string",
             "NS": [ "string" ],
             "NULL": boolean,
             "S": "string",
             "SS": [ "string" ]
          }
       }
       {"firstName": "test"}
            -> will change to ->
                {"firstName": {"S":"test"}}
    :param key: key node at root level or nested dict object inside root node
    :param val: val for key, either simple data or nested dict
    :return: structured dict object for key value pair
    """
    # TODO: tech-debt data-access methods should be defined in their own mixin classes to keep code modular.
    return json.loads((json_util.dumps({f":{key}": val})))


def add_updated_timestamp(
    update_expressions: dict, attr_names: dict, attr_values: dict
):
    """
    Adds an updated timestamp to update expressions
    :param update_expressions: An expression that defines one or more attributes to be updated, the action to be
        performed on them, and new values for them
    :param attr_names: One or more substitution tokens for attribute names in an expression
    :param attr_values: One or more values that can be substituted in an expression.
    :return: update_expressions, attr_names, attr_values dict objects
    """
    current_time = datetime.isoformat(datetime.utcnow())
    for k, v in update_expressions.items():
        update_expressions[k] = f"{v} , #updatedTimestamp = :updatedTimestamp"
        attr_names[k].update({"#updatedTimestamp": "updatedTimestamp"})
        attr_values[k].update({":updatedTimestamp": {"S": current_time}})

    return update_expressions, attr_names, attr_values


def update_protected_information(
    update_expressions: dict,
    attr_names: dict,
    attr_values: dict,
    protected_info: dict,
    deal_ref_id: str,
    db_name: str,
):
    """
    This method is responsible for updating protected information in updated expression.
    Problem:
        Protected information encrypted and stored into dynamodb, which is string of garbage for a user looking at it.

    Solution:
        For each protected node inside data, if for corresponding node protected information exists in database then,
        - First do a GET and check if data exist, -> True
        - Then decrypt the data so as to get a dict object - > {"protected": {"ssn": "12345"}}
        - Update the dict object with new protected dict against a customer ->
                applicant: {"protected": {"ssn": "12345", "dob": "01/01/1994"}}
        - Encrypt the newly formed protected node and replace inside customer node ->
                applicant: {"protected": "encrypted"}
        - Update expression parameters for update_expressions, attr_names, attr_values

        - If data doesn't exist, then current node can be the new protected information, we encrypt and use it.

    :param update_expressions: An expression that defines one or more attributes to be updated, the action to be
        performed on them, and new values for them
    :param attr_names: One or more substitution tokens for attribute names in an expression
    :param attr_values: One or more values that can be substituted in an expression.
    :param protected_info: Protected dict extracted earlier from generate_update_expression_parameters
    :param deal_ref_id: pk for the deal table
    :param db_name: DynamoDB name
    :return: update_expressions, attr_names, attr_values dict objects
    """
    db = DynamoDbHelper(region=Env.AWS_REGION, table_name=db_name)
    for k, v in protected_info.items():
        dtc_component = f"{k}.{PROTECTED_KEY_NAME.upper()}"
        key_expression = Key("dealRefId").eq(deal_ref_id) & Key("dealComponent").eq(
            dtc_component
        )
        # retrieve protected data for a specific deal component
        protected_retrieved_info = db.query_items(key_expression=key_expression)
        if protected_retrieved_info:
            protected_retrieved = protected_retrieved_info[0].get(PROTECTED_KEY_NAME)
        else:
            logger.warning(
                f"Exception: Application failed to retrieve protected_retrieved information: {protected_retrieved_info}"
            )
            raise DynamoDBException(
                "Error retrieving  protected information from dynamoDB"
            )

        if protected_retrieved:
            protected_retrieved.update(v)
        else:
            protected_retrieved = v

        update_expressions[dtc_component] = (
            f"{update_expressions[dtc_component]}, #{PROTECTED_KEY_NAME} = :{PROTECTED_KEY_NAME}"
            if update_expressions.get(dtc_component)
            else f"#{PROTECTED_KEY_NAME} = :{PROTECTED_KEY_NAME}"
        )

        attr_values.setdefault(dtc_component, {}).update(
            generate_dynamodb_json_structure(PROTECTED_KEY_NAME, protected_retrieved)
        )
        attr_names.setdefault(dtc_component, {}).update(
            {f"#{PROTECTED_KEY_NAME}": f"{PROTECTED_KEY_NAME}"}
        )

    return update_expressions, attr_names, attr_values


def pre_process_data_for_post(schema: dict, data: dict, json_level=0):
    """
    To correctly update an attribute within a map in dynaomodb, we need to correctly define the blueprint/path for that
    map in dynamodb at the time of post. This method compares schema with data provided and initialize empty dict or list objects
    if they are not present in actual payload provided.
    :param schema: Schema corresponding to API. https://swaggerhub.np.aws.dealertrack.com/apis/COX-DRS/deals/1.0.0d
    :param data: payload provided for post
    :param json_level: this is the count for nested dict object within json
    :return: updated payload with schema objects if not present
    """
    for k, v in schema.items():

        if k == PROTECTED_KEY_NAME:
            continue
        elif isinstance(v, dict):
            if not data.get(k):
                data[k] = {}
            pre_process_data_for_post(schema[k], data[k], json_level + 1)
            if json_level == 1:
                extract_nested(data, k)

        elif isinstance(v, list):
            if not data.get(k):
                data[k] = []
    return data


def extract_nested(data, parent):
    """
    This method is responsible to extract nested dict object from 2 level deep to 1 level and remove from nested object.
    example:
        applicant: {
            "currentEmployment": {
                "employerAddress": "some value"
            }
        }
        changes to ->

        applicant: {
            "currentEmployment": {},
            "currentEmployment_employerAddress": "some value"
        }

    :param data: data for a key in recursion, extracted from event handler
    :param parent: key which has nested dict object
    :return: refactored data where nested keys are added to root level of current data
    """
    root = copy.deepcopy(data[parent])
    for k, v in root.items():

        if isinstance(v, dict):
            data.update({f"{parent}{common_settings.NESTED_KEY_IDENTIFIER}{k}": v})
            data[parent].pop(k)
