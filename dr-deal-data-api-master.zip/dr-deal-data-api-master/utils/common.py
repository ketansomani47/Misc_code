# -*- coding: utf-8 -*-
import json
import re
import sys
import time
from copy import deepcopy
from decimal import Decimal
from http import HTTPStatus
from uuid import uuid4 as uuid, UUID as UUID_CLS

import boto3
import requests
import ulid
from common.settings import (
    CORRELATION_ID_HEADER_KEY,
    KEY_DATA_MAPPING,
    Env,
    ErrorMsgs,
    RetentionPeriod,
    S3Config,
)
from utils import exceptions, logger


VERSION_PATTERN = re.compile(r"\d\.?\d?\d?\.?\d?\d?")


class SingleTTL:
    """
    A singleton holding a timestamp. The timestamp value will remain the same from the moment the class is first
    instantiated.
    """

    class __OnlyOne:
        def __init__(self):
            self.ttl = int(time.time())

        def __str__(self):
            return f"{repr(self)} {self.ttl}"

    instance = None

    def __init__(self):
        if not SingleTTL.instance:
            SingleTTL.instance = SingleTTL.__OnlyOne()

    def __getattr__(self, name):
        return getattr(self.instance, name)

    def general_ttl(self):
        return self.ttl + RetentionPeriod.general

    def document_session_ttl(self):
        return self.ttl + RetentionPeriod.document_session


def add_ttl(record: dict, offset: int = RetentionPeriod.general):
    """
    Adds an item with key "ttl" and to the given record dictionary. The value of ttl is a timestamp in UNIX epoch format
    representing a time in the future as defined by the given offset.
    :param record: Any given dictionary
    :param offset: An integer value representing the time in seconds to add to the current time.
    :return: A new dictionary containing all items form the original record, plus the additional "ttl" item.
    """
    ttl_dict = {"ttl": SingleTTL().ttl + offset}
    return {**record, **ttl_dict}


def convert_empty_strings_to_none(record: dict):
    """
    Convert all empty string values in `record` to None
    :param record: (dict) records that need to be updated
    :return: (dict) updated record
    """
    for key, val in record.items():
        if isinstance(val, dict):
            record[key] = convert_empty_strings_to_none(val)
        elif isinstance(val, list):
            updated_list = []
            for rec in val:
                if isinstance(rec, dict):
                    updated_list.append(convert_empty_strings_to_none(rec))
                elif rec == "":
                    updated_list.append(None)
                else:
                    updated_list.append(rec)
            record[key] = updated_list
        elif record[key] == "":
            record[key] = None
    return record


def remove_root_none_nodes(body):
    """
    Remove any None value key from body
    :param body: dict payload object
    :return: dict payload object without none keys
    """
    data = {k: v for k, v in body.items() if v or isinstance(v, bool)}
    return data


def get_response_header(correlation_id: str, region: str, version: str):
    return {
        CORRELATION_ID_HEADER_KEY: correlation_id,
        "x-aws-region": region,
        "x-api-version": version,
        "Cache-Control": "public, max-age=3600, s-maxage=3600",
        "Content-Security-Policy": "default-src 'none'",
        "X-Frame-Options": "deny",
        "X-Content-Type-Options": "nosniff",
    }


def validate_api_version(stored_api_version: str, request_api_version: str):
    """
    Compare versions and raise an exception if there is a mismatch.
    :param stored_api_version: version extracted from path
    :param request_api_version: version stored in db for the same deal
    :return: raise exceptions.BadRequestError if versions don't match
    """

    stored_api_version = stored_api_version[:1]

    if str(stored_api_version) != f"{request_api_version}":
        raise exceptions.BadRequestError(
            f"API version mismatch: The deal was created with version {stored_api_version} but access from API version "
            f"{request_api_version} was attempted."
        )


def get_common_attributes(event: dict, region: str, current_api_version: str):
    """
    This method extracts common attributes from event and return values or default
    :param event: An API Gateway event object
    :param region: AWS region value
    :param current_api_version: API version from environment
    :return: body, corr_id, response_header, request_api_version
    """
    body = event.get("body", "{}")
    headers = event.get("headers") or {}
    lowercase_headers = {key.lower(): value for key, value in headers.items()}
    corr_id = lowercase_headers.get(CORRELATION_ID_HEADER_KEY.lower()) or str(uuid())
    response_header = get_response_header(corr_id, region, current_api_version)
    request_api_version = event.get("path")[2:3]

    return body, corr_id, response_header, request_api_version, headers


# TODO tech-debt remove this method when all handlers are class based
def extract_key_data(request_headers):
    """
    Extract common key data if present in headers and store them in db with pre-defined names
    :param request_headers: headers dict extracted from aws event
    :return: set key_data with dict of records
    """
    key_data_mapping = KEY_DATA_MAPPING.keys()
    return {
        KEY_DATA_MAPPING[key]: value
        for key, value in request_headers.items()
        if key in key_data_mapping
    }


def get_bad_request_message(key_should_exist: bool):
    """
    Return error message based on "key_should_exist" bool value
    :param key_should_exist:
    :return:
    """
    # TODO: tech-debt These messages are too generic. Make them more specific. Use ErrorMsgs class.
    return {
        True: "You have tired to post to an endpoint for which the resource doesn't exists.",
        False: "You have tired to post to an endpoint for which the resource already exists.",
    }.get(key_should_exist)


def decimal_decoder():
    class DecimalDecoder(json.JSONEncoder):
        def default(self, obj):
            if isinstance(obj, Decimal):
                if abs(obj % 1) > 0:
                    return float(obj)
                elif obj < sys.maxsize:
                    return int(obj)
            return super(DecimalDecoder, self).default(obj)

    return DecimalDecoder


def decimal_set_decoder():
    class DecimalDecoder(json.JSONEncoder):
        def default(self, obj):
            if isinstance(obj, set):
                return list(obj)
            if isinstance(obj, Decimal):
                if abs(obj % 1) > 0:
                    return float(obj)
                elif obj < sys.maxsize:
                    return int(obj)
            return super(DecimalDecoder, self).default(obj)

    return DecimalDecoder


def get_path_parameter(event: dict, parameter: str):
    """
    Fetch required parameter from pathParameters field in event
    :param event: An API Gateway event object
    :param parameter: parameter name that need to fetched
    :return: parameter value
    """
    return (event.get("pathParameters") or {}).get(parameter)


def get_query_string_parameter(event: dict, parameter: str):
    """
    Fetch required parameter from queryStringParameters field in event
    :param event: An API Gateway event object
    :param parameter: parameter name that need to fetched
    :return: parameter value
    """
    return (event.get("queryStringParameters") or {}).get(parameter)


def change_dict_naming(data, convert_function):
    """
    Convert a nested dictionary from one convention to another.
    :param data: a JSON-serializable object to be converted.
    :param convert_function: function that takes the string in one convention and returns it in the other one.
    :return: Dictionary with the new keys.
    """
    if isinstance(data, dict):
        new_dict = {}
        for k, v in data.items():
            new_v = change_dict_naming(v, convert_function)
            new_dict[convert_function(k)] = new_v
        return new_dict

    elif isinstance(data, list):
        new_list = []
        for x in data:
            new_list.append(change_dict_naming(x, convert_function))
        return new_list

    return data


def scrub_dictionary(dict_obj):
    """
    Returns a copy of the given dict_obj with the key "x-api-key" removed.
    :param dict_obj: A dictionary object
    :return: A copy of the given dict_obj with the key "x-api-key" removed.
    """
    keys_to_scrub = ["x-api-key"]
    if dict_obj:
        return {k: v for k, v in dict_obj.items() if k not in keys_to_scrub}
    return dict_obj


class DTEvent:
    """
    Represents a DT Event payload.
    """

    # TODO: tech-deb Move this class to a separate module.
    def __init__(self, event: dict):
        """
        Takes an DT Event dictionary and initializes instance attributes with the most commonly used items, setting
        sensible defaults where appropriate.
        :param event: Deserialized DT Event object
        """
        if isinstance(event, str):
            event = json.loads(event)

        self.event_body = event
        self.corr_id = event.get("eventId") or str(uuid())
        self.transaction_id = event.get("eventTransactionId")
        self.key_data = event.get("eventKeyData") or {}
        self.payload = event.get("payload")


def verify_ulid(ulid_str, ref_id=None, validator=None):
    """
    verifies given string is an ulid or not, if not raise BadRequestError
    :param ulid_str: ulid in string
    :param ref_id: reference ID associated with the given ulid
    :param validator: instance of validator class
    :return: None or Exception
    """
    try:
        ulid.api.from_str(ulid_str)
    except Exception as error:
        if validator and validator.new_error_message:
            validator.generate_error_message(
                ref_id or "invalidUlid",
                ErrorMsgs.invalid_ulid.format(error=error),
                indicator="invalid_data",
            )
            validator.generate_data_property_errors_message()
            raise exceptions.BadRequestError(validator.validation_errors)
        else:
            raise exceptions.BadRequestError(ErrorMsgs.invalid_ulid.format(error=error))


def verify_uuid(
    uuid_str,
    version=4,
    ref_id=None,
    validator=None,
):
    """
    verifies given string is a UUID or not, if not raise BadRequestError
    :param uuid_str: UUID in string
    :param version: UUID version
    :param ref_id: reference ID associated with the given UUID
    :param validator: instance of validator class
    :return: None or Exception
    """
    try:
        UUID_CLS(uuid_str, version=version)
    except Exception as error:
        if validator and validator.new_error_message:
            validator.generate_error_message(
                ref_id or "invalid_UUID",
                ErrorMsgs.invalid_uuid.format(error=error),
                indicator="invalid_data",
            )
            validator.generate_data_property_errors_message()
            raise exceptions.BadRequestError(validator.validation_errors)
        else:
            raise exceptions.BadRequestError(ErrorMsgs.invalid_uuid.format(error=error))


class DealDataParameters:
    def __init__(self):
        self._db_name = ""

    @staticmethod
    def get_parameter(query_param):  # pragma: no cover
        try:
            url = f"http://localhost:2773/systemsmanager/parameters/get?{query_param}"
            headers = {"X-Aws-Parameters-Secrets-Token": Env.AWS_SESSION_TOKEN}
            resp = requests.get(url=url, headers=headers)
            if resp.status_code != HTTPStatus.OK:
                raise Exception(
                    f"Error while fetching secret for url: {url}, "
                    f"response: {resp.text}, status code: {resp.status_code}"
                )

            parameter = resp.json()["Parameter"]
            if not parameter:
                raise Exception(
                    f"Secret not found for url: {url}, response: {resp.json()}"
                )

            return parameter["Value"]
        except Exception as error:
            raise exceptions.DynamoDBException(
                f"Error during getting deal data parameter {query_param}"
            ) from error

    def get_db_name(self):
        """
        Function to call the get_parameters function to get the secret
        :return: dynamoDB table name
        """
        return self.get_parameter(f"name=%2F{Env.DEPLOY_ENV}%2Fdeal-data%2Fdb_name")

    @property
    def db_name(self):
        """
        DB name stored in parameter store as /<env>/deal-data/db_name
        :return: dynamoDB table name
        """
        return self._db_name if self._db_name else self.get_db_name()


def remove_empty_nodes(data, record=None):
    """
    Function remove empty json objects from the given data
    :param data: data from where empty json objects should be removed
    :param record: temp object for traversing
    :return: data without empty json objects
    """
    record = record if record else deepcopy(data)
    for key, value in data.items():
        if isinstance(value, dict) and not value:
            record.pop(key)
        elif isinstance(value, dict):
            record[key] = remove_empty_nodes(data[key], record[key])
    return record


def drop_ref_ids_from_payload(data):
    """
    Function to drop the refIds which should not be updated in dynamoDB from the payload and headers received
    :param data: Payload received which need to be forwarded to SQS
    :return: json payload without ref ids
    """
    drop_ref_ids = ["dealRefIdFD"]
    for ref_id in drop_ref_ids:
        if ref_id in data:
            data.pop(ref_id)
            logger.warning(
                "Dropped the refId from the request data", droppedRefId=ref_id
            )
    return data


def verify_and_add_source_partner_dealer_id(data):
    """
    Verify if the payload contains sourcePartnerDealerId, if not add the field with value as partyId of
    first targetPlatform.

    This is a temporary workaround to solve single targetPlatform workflow like IDL which doesn't have
    sourcePartnerDealerId in the requestPayload.

    Future, sourcePartnerDealerId will be deprecated and targetPlatform specific key-data will be implemented.
    :param data: Payload received which need to be forwarded to SQS
    :return: json payload with sourcePartnerDealerId
    """
    if not data.get("sourcePartnerDealerId") and data.get("targetPlatforms"):
        data["sourcePartnerDealerId"] = data["targetPlatforms"][0].get("partyId")

    return data


def generate_s3_file_tags(tag_dict: dict):
    """
    This method creates s3 object tags
    :param tag_dict: dict object
    :return: string of key value pair in querystring format
    """
    tags = []
    if len(tag_dict) > 10:
        err_msg = "Can't have more than 10 tags for one S3 object"
        raise Exception(err_msg)

    for key, value in tag_dict.items():
        tags.append(f"&{key}={value}") if tags else tags.append(f"{key}={value}")

    return "".join(tags)


def generate_s3_key(s3_key, **kwargs):
    """
    This method generates s3 object key
    :return: s3 object key
    """
    try:
        return s3_key.format(**kwargs).upper()
    except KeyError as error:
        raise Exception(
            f"Can't construct s3 key. Provide correct keys. Missing key: {error}"
        )


def store_to_s3(data: dict, s3_key: str, s3_tags: str = None, file_type: str = None):
    """
    This method creates s3 object with {s3_key}.json as name, s3_tags as tags to be stored with json object.
    :param data: data to be stored in s3
    :param s3_key: s3 object key
    :param s3_tags: s3 object tags
    :param file_type: s3 file type, example - txt, json, xml etc.
    :return:
    """
    try:
        s3_client = boto3.client("s3", region_name=Env.AWS_REGION)

        if file_type:
            s3_key = f"{s3_key}.{file_type}"

        s3_client.put_object(
            Body=json.dumps(data, cls=decimal_decoder()),
            Bucket=Env.DEAL_BUCKET,
            Key=s3_key,
            Tagging=s3_tags,
            ContentType=S3Config.CONTENT_TYPE,
        )
    except Exception as error:
        raise exceptions.S3SaveError(ErrorMsgs.s3_save_error_msg.format(error=error))
