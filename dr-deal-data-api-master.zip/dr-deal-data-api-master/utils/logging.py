# -*- coding: utf-8 -*-
import os

import dr_utils


class Env:
    """Environment variables. Wrapped in a class to simplify testing."""

    AWS_REGION = os.environ.get("REGION")
    EVENT_SOURCE = os.environ.get("EVENT_SOURCE")


class EventsEnum:
    app_processing_failed = "AppProcessingFailed"
    app_update_processing_failed = "AppUpdateProcessingFailed"
    ca_existing_deal_processing_failed = "CreditAppExistingDealProcessingFailed"
    ca_existing_deal_parsing_failed = "CreditAppExistingDealParsingFailed"
    app_encryption_failed = "AppEncryptionFailed"
    app_decryption_failed = "AppDecryptionFailed"
    app_stored_dlq = "AppStoredInDLQ"
    app_parsing_failed = "AppParsingFailed"
    app_update_parsing_failed = "AppUpdateParsingFailed"
    app_persisting_failed = "AppPersistingFailed"
    app_failed_status_received = "AppFailedStatusReceived"
    app_routing_failed = "AppRoutingFailed"
    deal_status_update_failed = "DealStatusUpdateFailed"
    lead_processing_failed = "LeadProcessingFailed"
    lead_update_processing_failed = "LeadUpdateProcessingFailed"
    lead_update_parsing_failed = "LeadUpdateParsingFailed"
    lead_existing_deal_processing_failed = "LeadExistingDealProcessingFailed"
    lead_existing_deal_parsing_failed = "LeadExistingDealParsingFailed"
    lead_parsing_failed = "LeadParsingFailed"
    credit_bureau_pull_parsing_failed = "CreditBureauPullParsingFailed"
    credit_bureau_pull_processing_failed = "CreditBureauPullProcessingFailed"
    credit_bureau_response_parsing_failed = "CreditBureauResponseParsingFailed"
    credit_bureau_response_processing_failed = "CreditBureauResponseProcessingFailed"
    deal_get_bad_request = "DealGetBadRequest"
    deal_get_failed = "DealGetFailed"
    deal_get_decryption_failed = "DealGetDecryptionFailed"
    event_processing_failed = "EventProcessingFailed"
    event_parsing_failed = "EventParsingFailed"
    fd_timeout_error = "FinanceDriverTimeoutError"
    events_timeout_error = "EventsFrameworkTimeoutError"
    snapshot_parsing_failed = "SnapshotParsingFailed"
    snapshot_create_failed = "SnapshotCreateFailed"
    decision_get_failed = "LenderDecisionGetFailed"
    key_data_stream_failed = "KeyDataStreamFailed"


logger = dr_utils.get_logger(
    event_source=Env.EVENT_SOURCE,
    region=Env.AWS_REGION,
    keys_to_mask=[
        "lastName",
        "driversLicenseNumber",
        "driversLicenseState",
        "reportedCreditScore",
        "dateOfBirth",
        "ssn",
        "line1",
        "line2",
        "postalCode",
        "email",
        "workPhone",
        "otherPhone",
        "phone",
        "bankAccountNumber",
        "bankName",
        "businessTaxId",
        "identificationNumber",
        "taxIdentifier",
    ],
)
