# -*- coding: utf-8 -*-
import json
import re

import schemas
from utils.common import VERSION_PATTERN


def extract_schema(version, schema_type):
    """
    Extract the schema dict from schemas dir
    :param version: version of the schema dir
    :param schema_type: schema type needed to match with payload
    :return:
    """
    return getattr(getattr(schemas, version), schema_type).schema


def get_schema(version: str, schema_type: str, payload: dict = None):
    """
    Extract schema for a specific api version
    :param version: version number for the api
    :param schema_type: schema type needed to match with payload
    :param payload: original payload provided in request
    :return: response schema as dict
    """
    if VERSION_PATTERN.match(version):
        version = f"v{version[:1]}"
    elif re.compile(r"v\d\.?\d?\d?\.?\d?\d?").match(version):
        version = version[:2]

    schema = extract_schema(version, schema_type)
    schema = (
        {
            k: schema[k]
            for k, v in payload.items()
            if isinstance(schema.get(k), (list, dict))
        }
        if payload
        else schema
    )
    schema = json.loads(json.dumps(schema))
    return schema


def get_key_original_case(schema: dict, db_node_name: str):
    """
    Gets actual sub object name in schema
    :param schema: response schema
    :param db_node_name: node name in db which is stored as deal component
    :return: schema sub object name or None
    """
    for key in schema:
        if key.upper() == db_node_name:
            return key


def generate_schema_components(schema: dict, data: dict):
    """
    Generates a dictionary schema with every key present in both schema and data, with a dictionary or list value in
    data. The resulting dictionary consists of the selected keys UPPER-CASED and the same selected key in its original
    form as its value.

    >>> schema
    {"foo": {"orange": "str"}}

    >>> data
    {"foo":
        {
            "snake": "python"
        },
     "bar": "fight"
    }

    >>>  generate_schema_components(schema, data)
    {"FOO": "foo"}

    :param schema: A schema defined as a dictionary
    :param data: Payload data (credit app, lead, etc.)
    :return: Dictionary representing the common keys.
    """
    schema_components = {}

    for k, v in schema.items():
        if k in data and isinstance(v, (list, dict)):
            schema_components.update({k.upper(): k})

    return schema_components
