# -*- coding: utf-8 -*-
import json
from http import HTTPStatus

import boto3
from common.deal_consumer import ConsumerLambda
from common.settings import (
    CONTENT_TYPE,
    S3_OBJECT_KEY_TEMPLATE,
    SNAPSHOT_RESERVED_TAGS,
    Env,
    ErrorMsgs,
    InfoMsgs,
    SnapshotAction,
)
from utils import exceptions, logging


class SnapShotConsumerLambda(ConsumerLambda):
    def __init__(self):
        super().__init__()
        self.s3_client = boto3.client("s3", region_name=Env.AWS_REGION)

    @ConsumerLambda.is_handler
    def handle(self, event: dict, context: dict):
        """
        Handles messages from SNAPSHOT_QUEUE.

        :param event: An SQS event object
        :param context: AWS Lambda Context Object
        :return: JSON with status code
        """
        self.log.info(
            InfoMsgs.processing_message_from_queue.format(queue=Env.SNAPSHOT_QUEUE)
        )

        try:
            if self.msg_attrs.action == SnapshotAction.SNAPSHOT_CREATE:
                self.log.info(
                    InfoMsgs.processing_persistence.format(resource="Snapshot")
                )
                self.create()

            return {"statusCode": HTTPStatus.CREATED}
        except json.JSONDecodeError as error:
            message = ErrorMsgs.invalid_json_payload
            self.process_exception(
                error, logging.EventsEnum.snapshot_parsing_failed, message=message
            )
        except exceptions.SnapshotSaveError as error:
            message = ErrorMsgs.failed_write_operation.format(
                resource="Snapshot",
                action=self.msg_attrs.action,
                queue=Env.SNAPSHOT_DLQ,
            )
            self.process_exception(
                error, logging.EventsEnum.snapshot_create_failed, message=message
            )

        except Exception as error:
            # The queue is configured with a DeadLetterQueue and no retries, so exceptions raised
            # here will cause the message to be sent directly to the SnapshotDLQ.
            self.process_exception(error, logging.EventsEnum.snapshot_create_failed)

    def create(self):
        """
        This method creates s3 key, tags for the object and store s3 object into the s3 bucket
        :return: None
        """
        snapshot_key = self.generate_s3_key()
        snapshot_tags = self.generate_snapshot_file_tags()

        self.store_snapshot(snapshot_key, snapshot_tags)
        self.log.info("Snapshot stored successfully", snapshotKey=snapshot_key)

    def generate_s3_key(self):
        """
        This method generates s3 object key for snapshot
        :return: s3 object key
        """
        return S3_OBJECT_KEY_TEMPLATE.format(
            dealerId=self.msg_attrs.dealer_id,
            dealRefId=self.msg_attrs.deal_ref_id,
            feature=self.msg_attrs.feature,
            context_id=self.msg_attrs.context_id,
            content_type=self.msg_attrs.content_type,
        )

    def generate_snapshot_file_tags(self):
        """
        This method extract s3 object tags for snapshot from msg_attrs and appends extra key value if eventKeyData exists
        :return: string of key value pair in querystring format
        """
        tags = []

        snapshot_tags = json.loads(self.msg_attrs.tags or "{}")

        for key in SNAPSHOT_RESERVED_TAGS:
            if getattr(self.msg_attrs, key):
                snapshot_tags.update({f"__{key}__": getattr(self.msg_attrs, key)})

        for key, value in snapshot_tags.items():
            tags.append(f"&{key}={value}") if tags else tags.append(f"{key}={value}")

        return "".join(tags)

    def store_snapshot(self, snapshot_key: str, snapshot_tags: str):
        """
        This method creates s3 object with {snapshot_key}.json as name, snapshot_tags as tags and extracts body from
        sqs_msg to be stored within json object
        :param snapshot_key: s3 object key for snapshot
        :param snapshot_tags: s3 object tags for snapshot
        :return: None or raises SnapshotSaveError for any exception
        """
        try:
            content_type = CONTENT_TYPE.format(file_type=self.msg_attrs.content_type)

            self.s3_client.put_object(
                Body=self.sqs_msg.get("body"),
                Bucket=Env.SNAPSHOT_BUCKET,
                Key=snapshot_key,
                Tagging=snapshot_tags,
                ContentType=content_type,
            )
        except Exception as error:
            raise exceptions.SnapshotSaveError(str(error)) from error

    def process_exception(self, error, event, message=None):
        """
        process incoming exception, logs the exception based on event and raises an error, which causes the message to be sent to Snapshot DLQ
        :param error: exception object
        :param event: event based on exception type
        :param message: custom error message to replace default message
        :return: raises an error
        """
        default_msg = ErrorMsgs.sending_msg_dlq.format(
            payload_type="snapshot", queue=Env.SNAPSHOT_DLQ, error=error
        )

        message = message or default_msg
        self.log.exception(
            message, exc_info=error, payload=self.sqs_msg.get("body"), aws_event=event
        )
        raise error


handler = SnapShotConsumerLambda.get_handler()
