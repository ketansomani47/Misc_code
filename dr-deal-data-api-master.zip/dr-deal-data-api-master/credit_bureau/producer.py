# -*- coding: utf-8 -*-
import json
from http import HTTPStatus

import dr_utils
import ulid
from common import settings as se
from common.mixins import process_exception
from common.settings import Env, ErrorMsgs, PayloadType as pt
from common.validators import BodyValidator, ExistingDealValidator
from utils import EventsEnum, common, exceptions, logger
from utils.common import DTEvent, extract_key_data, get_path_parameter


def cb_new_deal(event, context):
    """
    Handles the Credit Bureau Pull Post for new Deal endpoint. Creates a new Credit Bureau Pull and a new Deal
    simultaneously.

    Endpoint: /deals/credit-bureaus

    This asynchronous API generates new dealRefId and retrieves creditBureauRefId from HTTP headers, then submits a
    message to DealDataQueue. dealRefId and creditBureauRefId are returned to the client with HTTP status CREATED (201).

    :param dict event: An API Gateway event object
    :param dict context: AWS Lambda Context Object
    :return: JSON with status code and body
    """

    (
        body,
        corr_id,
        response_header,
        request_version,
        headers,
    ) = common.get_common_attributes(event, Env.AWS_REGION, Env.VERSION)

    if headers.get(se.HEALTHCHECK_HEADER_FIELD) == se.HEALTHCHECK_HEADER_VALUE:
        return {"statusCode": HTTPStatus.CREATED, "body": json.dumps("Operational")}

    deal_ref_id = ulid.new().str
    cb_pull_id = headers.get(se.CB_PULL_HEADER_KEY)
    payload_type = pt.CREDIT_BUREAU_PULL

    log = logger.new(
        functionArn=context.invoked_function_arn,
        correlationId=corr_id,
        dealRefId=deal_ref_id,
        cbPullId=cb_pull_id,
        payloadType=payload_type,
        requestHeaders=headers,
    )

    log.info("Credit Bureau creation request received for new deal")

    try:
        if cb_pull_id is None:
            raise exceptions.BadRequestError(
                f"No {se.CB_PULL_HEADER_KEY} header provided"
            )

        validator = BodyValidator(event, deal_ref_id)
        data = validator.validate_body()

        # add key_data dict to data which keys extracted from headers
        data.update(extract_key_data(headers))

        log = log.bind(requestPayload=body)

        dr_utils.send_payload_to_queue(
            queue=Env.DEAL_DATA_QUEUE,
            payload=data,
            region=Env.AWS_REGION,
            msg_group_id=deal_ref_id,
            payloadType=payload_type,
            correlationId=corr_id,
            dealRefId=deal_ref_id,
            cbPullId=cb_pull_id,
        )

        log.info(f"Credit Bureau creation request sent to queue: {Env.DEAL_DATA_QUEUE}")

        return_body = {"dealRefId": deal_ref_id, "creditBureauRefId": cb_pull_id}

        return {
            "statusCode": HTTPStatus.CREATED,
            "body": json.dumps(return_body),
            "headers": response_header,
        }
    except exceptions.BadRequestError as error:
        message = f"Error processing application for credit bureau. {error}"
        log.error(
            message,
            requestPayload=body,
            _event=EventsEnum.credit_bureau_pull_processing_failed,
        )
        return_body = {"message": str(error)}
        return {
            "statusCode": HTTPStatus.BAD_REQUEST,
            "body": json.dumps(return_body),
            "headers": response_header,
        }
    except json.JSONDecodeError as error:
        message = "Invalid JSON payload"
        log.exception(
            message,
            requestPayload=body,
            _event=EventsEnum.credit_bureau_pull_parsing_failed,
        )
        return process_exception(
            error=error,
            event=event,
            headers=response_header,
            status_code=HTTPStatus.BAD_REQUEST,
            queue_name=Env.DEAL_DATA_DLQ,
            region=Env.AWS_REGION,
            correlation_id=corr_id,
            cb_pull_id=cb_pull_id,
            msg_group_id=deal_ref_id,
        )

    except Exception as error:
        message = ErrorMsgs.sending_msg_dlq.format(
            payload_type=payload_type, queue=Env.DEAL_DATA_DLQ, error=error
        )
        log.exception(
            message,
            requestPayload=body,
            _event=EventsEnum.credit_bureau_pull_processing_failed,
        )
        return process_exception(
            error=error,
            event=event,
            headers=response_header,
            queue_name=Env.DEAL_DATA_DLQ,
            region=Env.AWS_REGION,
            correlation_id=corr_id,
            cb_pull_id=cb_pull_id,
            msg_group_id=deal_ref_id,
        )


def cb_existing_deal(event, context):
    """
    This function handles a credit bureau pull request with a dealRefId path parameter.
    The referenced deal is updated with the given data.
    :param dict event: An API Gateway event object
    :param dict context: AWS Lambda Context Object
    :return: JSON with status code and body
    """

    (
        body,
        corr_id,
        response_header,
        request_version,
        headers,
    ) = common.get_common_attributes(event, Env.AWS_REGION, Env.VERSION)

    if headers.get(se.HEALTHCHECK_HEADER_FIELD) == se.HEALTHCHECK_HEADER_VALUE:
        return {"statusCode": HTTPStatus.CREATED, "body": json.dumps("Operational")}

    headers = event.get("headers") or {}
    cb_pull_id = headers.get(se.CB_PULL_HEADER_KEY)
    deal_ref_id = get_path_parameter(event, "dealRefId")
    payload_type = pt.CREDIT_BUREAU_PULL_DEAL_UPDATE

    log = logger.new(
        functionArn=context.invoked_function_arn,
        correlationId=corr_id,
        dealRefId=deal_ref_id,
        cbPullId=cb_pull_id,
        payloadType=payload_type,
        requestHeaders=headers,
    )

    try:
        if cb_pull_id is None:
            raise exceptions.BadRequestError(
                f"No {se.CB_PULL_HEADER_KEY} header provided"
            )

        validator = ExistingDealValidator(event, deal_ref_id)
        validator.validate_body()
        validator.validate_api_version(request_version)

        data = validator.validate_id_uniqueness(
            payload_type=payload_type, reference_id=cb_pull_id
        )

        data["cbPullId"] = cb_pull_id

        # add key_data dict to data which keys extracted from headers
        data.update(extract_key_data(headers))

        log = log.bind(dealRefId=deal_ref_id, cbPullId=cb_pull_id, payload=data)

        log.info("Credit Bureau creation request received for existing deal")

        dr_utils.send_payload_to_queue(
            queue=Env.DEAL_DATA_QUEUE,
            payload=data,
            region=Env.AWS_REGION,
            msg_group_id=deal_ref_id,
            payloadType=payload_type,
            correlationId=corr_id,
            cbPullId=cb_pull_id,
            dealTTL=validator.stored_ttl,
            dealRefId=deal_ref_id,
        )
        log.info(
            f"Credit Bureau creation request for existing deal sent to queue: {Env.DEAL_DATA_QUEUE}"
        )
        return_body = {"dealRefId": deal_ref_id, "creditBureauRefId": cb_pull_id}

        return {
            "statusCode": HTTPStatus.CREATED,
            "body": json.dumps(return_body),
            "headers": response_header,
        }

    except json.JSONDecodeError as error:
        message = "Invalid JSON payload"
        log.exception(
            message,
            requestPayload=body,
            _event=EventsEnum.credit_bureau_pull_parsing_failed,
        )

        return process_exception(
            error=error,
            event=event,
            status_code=HTTPStatus.BAD_REQUEST,
            headers=response_header,
            queue_name=Env.DEAL_DATA_DLQ,
            region=Env.AWS_REGION,
            correlation_id=corr_id,
            cb_pull_id=cb_pull_id,
            msg_group_id=deal_ref_id,
        )
    except exceptions.BadRequestError as error:
        message = f"Error processing Credit Bureau pull with dealRefId. {error}"
        log.warning(
            message,
            requestPayload=body,
            _event=EventsEnum.credit_bureau_pull_processing_failed,
        )
        return_body = {"message": str(error)}
        return {
            "statusCode": HTTPStatus.BAD_REQUEST,
            "body": json.dumps(return_body),
            "headers": response_header,
        }

    except Exception as error:
        message = ErrorMsgs.sending_msg_dlq.format(
            payload_type=payload_type, queue=Env.DEAL_DATA_DLQ, error=error
        )
        log.exception(
            message,
            requestPayload=body,
            _event=EventsEnum.credit_bureau_pull_processing_failed,
        )
        return process_exception(
            error=error,
            event=event,
            headers=response_header,
            queue_name=Env.DEAL_DATA_DLQ,
            region=Env.AWS_REGION,
            correlation_id=corr_id,
            cb_pull_id=cb_pull_id,
            msg_group_id=deal_ref_id,
        )


def cb_response(event, context):
    """
    Handles the Credit Bureau Response Post endpoint. Creates a new Credit Bureau Response.

    Endpoint: /deals/credit-bureau-response

    This asynchronous API retrieves creditBureauRefId from event payload, then submits a message to DealDataQueue.
    dealRefId and creditBureauRefId are returned to the client with HTTP status CREATED (201).

    :param dict event: An API Gateway event object
    :param dict context: AWS Lambda Context Object
    :return: JSON with status code and body
    """
    # TODO: tech-debt Abstract handling of the Event payload so it's reusable and decoupled from credit bureau response
    body = event.get("body", "{}")
    request_version = event.get("path")[2:3]
    headers = event.get("headers") or {}
    response_header = None

    # The current design has a flaw, if no deal_ref_id is present or invalid JSON is provided we won't be able to
    # extract deal_ref_id which will not send messages to the DLQ as all DLQs are fifo now. FIFO queues require a
    # message group id, if not present they won't take the payload
    deal_ref_id = ulid.new().str

    payload_type = pt.CREDIT_BUREAU_RESPONSE

    log = logger.new(
        functionArn=context.invoked_function_arn,
        payloadType=payload_type,
        requestHeaders=headers,
    )

    log.info("CB Response received")

    try:
        if headers.get(se.HEALTHCHECK_HEADER_FIELD) == se.HEALTHCHECK_HEADER_VALUE:
            return {"statusCode": HTTPStatus.CREATED, "body": json.dumps("Operational")}

        event_obj = DTEvent(body)
        deal_ref_id = event_obj.key_data.get("dealRefId")
        # Ensure cb_pull_id is treated as a string
        cb_pull_id = (
            str(event_obj.transaction_id)
            if event_obj.transaction_id
            else event_obj.transaction_id
        )
        corr_id = event_obj.corr_id

        log = log.bind(
            correlationId=corr_id,
            dealRefId=deal_ref_id,
            cbPullId=cb_pull_id,
            requestPayload=event_obj.event_body,
        )

        response_header = common.get_response_header(
            corr_id, Env.AWS_REGION, Env.VERSION
        )
        if not event_obj.event_body:
            raise exceptions.BadRequestError(ErrorMsgs.missing_body_aws_event)

        if not cb_pull_id:
            raise exceptions.BadRequestError(ErrorMsgs.missing_transaction_id)

        validator = ExistingDealValidator(event, deal_ref_id)
        validator.validate_body()
        validator.validate_api_version(request_version)
        event_body = validator.validate_id_uniqueness(
            payload_type=payload_type, reference_id=cb_pull_id
        )

        cb_resp_body = event_body.get("payload")

        if not cb_resp_body:
            raise exceptions.BadRequestError(ErrorMsgs.missing_event_payload)

        cb_resp_body["dealRefId"] = deal_ref_id
        cb_resp_body["cbPullId"] = cb_pull_id

        dr_utils.send_payload_to_queue(
            queue=Env.DEAL_DATA_QUEUE,
            payload=cb_resp_body,
            region=Env.AWS_REGION,
            msg_group_id=deal_ref_id,
            payloadType=pt.CREDIT_BUREAU_RESPONSE,
            correlationId=corr_id,
            cbPullId=cb_pull_id,
            dealTTL=validator.stored_ttl,
            dealRefId=deal_ref_id,
        )

        log.info(f"CB response sent to queue: {Env.DEAL_DATA_QUEUE}")
        return_body = {"dealRefId": deal_ref_id, "creditBureauRefId": cb_pull_id}

        return {
            "statusCode": HTTPStatus.CREATED,
            "body": json.dumps(return_body),
            "headers": response_header,
        }
    except exceptions.BadRequestError as error:
        message = f"Error processing application for credit bureau response. {error}"
        log.error(
            message,
            requestPayload=body,
            _event=EventsEnum.credit_bureau_response_processing_failed,
        )
        return_body = {"message": str(error)}
        return {"statusCode": HTTPStatus.BAD_REQUEST, "body": json.dumps(return_body)}
    except json.JSONDecodeError as error:
        message = "Invalid JSON payload"
        log.exception(
            message,
            requestPayload=body,
            _event=EventsEnum.credit_bureau_response_parsing_failed,
        )
        return process_exception(
            error=error,
            event=event,
            headers=response_header,
            status_code=HTTPStatus.BAD_REQUEST,
            queue_name=Env.DEAL_DATA_DLQ,
            region=Env.AWS_REGION,
            msg_group_id=deal_ref_id,
        )

    except Exception as error:
        message = ErrorMsgs.sending_msg_dlq.format(
            payload_type=payload_type, queue=Env.DEAL_DATA_DLQ, error=error
        )
        log.exception(
            message,
            requestPayload=body,
            _event=EventsEnum.credit_bureau_response_processing_failed,
        )
        return process_exception(
            error=error,
            event=event,
            headers=response_header,
            queue_name=Env.DEAL_DATA_DLQ,
            region=Env.AWS_REGION,
            msg_group_id=deal_ref_id,
        )
