# -*- coding: utf-8 -*-
import copy
import json
import operator

from boto3.dynamodb.conditions import Attr, Key
from common.settings import (
    DEAL_COMPONENT_SEPARATOR,
    DealComponent,
    Env,
    ErrorMsgs,
    PayloadType,
)
from utils import exceptions
from utils.common import DealDataParameters, get_bad_request_message
from utils.db_helper import DynamoDbHelper
from utils.exceptions import NoRecordsFoundError


class BaseValidator:
    def __init__(
        self, aws_event, deal_ref_id, new_error_message=False, path_parameters=None
    ):
        self._db_records = None
        self.event = aws_event
        self.region = Env.AWS_REGION
        self.table_name = DealDataParameters().db_name
        self.deal_ref_id = deal_ref_id
        self.db_helper = DynamoDbHelper(self.region, self.table_name)
        self.new_error_message = new_error_message
        self.path_parameters = path_parameters or []
        self.data_property_errors = []
        self.query_param_errors = []
        self.missing_property_errors = []
        self.validation_errors = []
        self.validate_path_parameters()

    def validate_path_parameters(self):
        """
        This method validates path parameters/deal_ref_id whether they exist in request
        :return: None or raise exception if parameters doesn't exist
        """
        if self.path_parameters and self.new_error_message:
            for path_parameter in self.path_parameters:
                self.generate_error_message(
                    path_parameter,
                    ErrorMsgs.path_params_new_format.format(
                        path_parameter_Id=path_parameter
                    ),
                    indicator="missing_data",
                )
            self.generate_missing_property_errors_message()
            raise exceptions.BadRequestError(self.validation_errors)
        if not self.deal_ref_id and not self.new_error_message:
            raise exceptions.BadRequestError(ErrorMsgs.deal_ref_id_not_provided)

    def _cache_db_records(self):
        if self._db_records is None:
            self.populate_db_records()

    def get_filter_expression(self):
        return (
            Attr("apiVersion").exists()  # For DTC.VERSION record
            | Attr("creditAppId").exists()  # For DTC.DEAL record
            | Attr("leadRefId").exists()  # For DTC.DEAL record
            | Attr("dealRecord").exists()  # For DTC.DEAL record
            | Attr("provider").exists()  # For CB.* records
        )

    def populate_db_records(self):
        key_expr = Key("dealRefId").eq(self.deal_ref_id)
        filter_expr = self.get_filter_expression()

        self._db_records = self.db_helper.query_pk_filter(key_expr, filter_expr)
        if not self._db_records:
            if self.new_error_message:
                self.generate_error_message(
                    "dealRefId",
                    ErrorMsgs.invalid_deal_ref_id.format(deal_ref_id=self.deal_ref_id),
                    indicator="invalid_data",
                )
                self.generate_data_property_errors_message()
                raise exceptions.BadRequestError(self.validation_errors)
            else:
                raise exceptions.BadRequestError(
                    ErrorMsgs.missing_deal_from_db.format(deal_ref_id=self.deal_ref_id)
                )

    def get_records_by_deal_component(self, filter, op: operator):
        records = []
        for record in self._db_records:
            val = record.get("dealComponent")
            if op(val, filter):
                records.append(record)
        return copy.deepcopy(records)

    def generate_error_message(self, node, error, indicator=None):
        """
        Generate error message and updates the list based on the error type
        :param node: Name of the node
        :param error: error message
        :param indicator: error type
        :return: None
        """
        properties = {"property": node, "message": error}
        if indicator == "missing_data":
            self.missing_property_errors.append(properties)

        if indicator == "invalid_data":
            self.data_property_errors.append(properties)

        if indicator == "invalid_query_params":
            self.query_param_errors.append(properties)

    def generate_data_property_errors_message(self):
        """
        Generate data property error message from the errors list
        :return: None
        """
        if self.data_property_errors:
            self.validation_errors.append(
                {"code": "deal.invalidRefId", "properties": self.data_property_errors}
            )

    def generate_missing_property_errors_message(self):
        """
        Generate missing property error message from the errors list
        :return: None
        """
        if self.missing_property_errors:
            self.validation_errors.append(
                {
                    "code": "deal.missingRequiredProperty",
                    "properties": self.missing_property_errors,
                }
            )

    def generate_invalid_query_param_errors_message(self):
        """
        Generate invalid query param error message from the errors list
        :return: None
        """
        if self.query_param_errors:
            self.validation_errors.append(
                {
                    "code": "deal.invalidQueryParameter",
                    "properties": self.query_param_errors,
                }
            )


class BodyValidator(BaseValidator):
    def __init__(
        self, aws_event, deal_ref_id, new_error_message=False, path_parameters=None
    ):
        super().__init__(
            aws_event, deal_ref_id, new_error_message, path_parameters or []
        )
        self._data = None

    @property
    def data(self):
        return copy.deepcopy(self._data)

    def validate_body(self, add_deal_ref_id_to_payload=True):
        if self._data is None:
            data = json.loads(self.event.get("body") or "{}")
            if not data:
                if self.new_error_message:
                    self.generate_error_message(
                        "eventBody",
                        ErrorMsgs.missing_body_aws_event,
                        indicator="missing_data",
                    )
                    self.generate_missing_property_errors_message()
                    raise exceptions.BadRequestError(self.validation_errors)
                else:
                    raise exceptions.BadRequestError(ErrorMsgs.missing_body_aws_event)
            elif not isinstance(data, dict):
                raise exceptions.BadRequestError(ErrorMsgs.invalid_json_payload)
            self._data = data
            if add_deal_ref_id_to_payload:
                self._data.update({"dealRefId": self.deal_ref_id})

        return self.data


class ExistingDealValidator(BodyValidator):
    def __init__(
        self,
        sqs_event,
        deal_ref_id,
        new_error_message=False,
        path_parameters=None,
        validate_deal_exist=False,
    ):
        super().__init__(
            sqs_event, deal_ref_id, new_error_message, path_parameters or []
        )
        self._stored_ttl = None
        self._stored_api_version = None

        if validate_deal_exist:
            self._cache_db_records()

    @property
    def db_records(self):
        self._cache_db_records()
        return self._db_records

    @property
    def stored_ttl(self):
        self._cache_attrs()
        return self._stored_ttl

    @property
    def stored_api_version(self):
        self._cache_attrs()
        return self._stored_api_version

    def _cache_attrs(self):
        self._cache_db_records()
        if self._stored_ttl is None or self._stored_api_version is None:
            version_records = self.get_records_by_deal_component(
                DealComponent.DTC_VERSION, operator.eq
            )
            if not version_records:
                raise NoRecordsFoundError(f"dealComponent: {DealComponent.DTC_VERSION}")
            self._stored_ttl = version_records[0].get("ttl")
            self._stored_api_version = version_records[0].get("apiVersion", "0")[:1]

    def validate_api_version(self, request_api_version: str):
        """
        Compare versions and raise an exception if there is a mismatch.
        :param request_api_version: version stored in db for the same deal
        :return: raise exceptions.BadRequestError if versions don't match
        """
        if (self.stored_api_version and request_api_version) and (
            str(self.stored_api_version) != f"{request_api_version}"
        ):
            raise exceptions.BadRequestError(
                ErrorMsgs.api_version_mismatch.format(
                    stored_api_version=self.stored_api_version,
                    request_api_version=request_api_version,
                )
            )

    def validate_reference_ids(self, reference_ids: dict, should_exist: bool = True):
        """
        This method validates reference ids whether they are attached to deal in DTC record
        :param reference_ids: dict with reference id name and value
        :param should_exist: bool value to verify if the ref ids exist or not, default is true
        :return: None or raise exception if ids are not associated with deal
        """
        dtc_records = self.get_records_by_deal_component(
            DealComponent.DTC_DEAL, operator.eq
        )
        for key, value in reference_ids.items():
            if should_exist and dtc_records[0].get(key) != value:
                if not self.new_error_message:
                    raise exceptions.BadRequestError(
                        ErrorMsgs.reference_id_mismatch.format(
                            reference_id_type=key,
                            reference_id=value,
                            deal_ref_id=self.deal_ref_id,
                        )
                    )
                else:
                    self.generate_error_message(
                        key,
                        ErrorMsgs.reference_id_mismatch_new_format.format(
                            reference_id_type=key,
                            reference_id=value,
                            deal_ref_id=self.deal_ref_id,
                        ),
                        indicator="invalid_data",
                    )
            elif not should_exist and dtc_records[0].get(key):
                if not self.new_error_message:
                    raise exceptions.BadRequestError(
                        ErrorMsgs.reference_id_exist.format(
                            reference_id_type=key,
                            deal_ref_id=self.deal_ref_id,
                        )
                    )
                else:
                    self.generate_error_message(
                        key,
                        ErrorMsgs.reference_id_exist.format(
                            reference_id_type=key,
                            deal_ref_id=self.deal_ref_id,
                        ),
                        indicator="invalid_data",
                    )
        if self.new_error_message:
            self.generate_data_property_errors_message()
            if self.validation_errors:
                raise exceptions.BadRequestError(self.validation_errors)

    def validate_id_uniqueness(
        self, payload_type: str, reference_id: str = None, resource_id: str = None
    ):
        """
        This method validates data, deal_ref_id and version of api corresponding to value in dynamodb
        :param payload_type: payload type based on event of the api
        :param reference_id: any key that needs to be check for this transaction in deal component, usually last key
        :param resource_id: This is either creditAppId, leadRefId, or cbPullId
        :return: data/ payload extracted from event and deal_ref_id
        """

        should_id_exist = PayloadType.should_id_exist_for_post(payload_type)
        if PayloadType.get_payload_component_id(payload_type):

            # retrieve dtc deal from dynamodb and compare with api endpoint if Leads/CA id already exists for post
            self.check_id_for_post(
                payload_type=payload_type,
                deal_component=DealComponent.DTC_DEAL,
                key_should_exist=should_id_exist,
                resource_id=resource_id,
            )

        elif PayloadType.reference_record_id_validation(payload_type):
            dtc_component = DealComponent.get_component_name(payload_type)

            # retrieve dtc_component from dynamodb and compare with api endpoint if CbPullId id already exists for post
            self.check_id_for_post(
                payload_type=payload_type,
                deal_component=dtc_component,
                key_should_exist=should_id_exist,
                reference_id=reference_id,
            )

        return self.data

    def check_id_for_post(
        self,
        payload_type: str,
        deal_component: str,
        key_should_exist: bool,
        reference_id: str = None,
        resource_id: str = None,
    ):
        """
        Retrieve deal component from dynamoDB and compare with api endpoint if Leads/CA/ CB id already exists for post,
        it raises BadRequestError based on key indicator, if key exists or not
        :param payload_type: payload type based on event of the api
        :param deal_component: sort key for the db to form key expression
        :param key_should_exist: bool to represent should key already exist in db for comparison in this operation
        :param reference_id: any key that needs to be checked for this transaction in deal component, usually last key
        :param resource_id: This is either creditAppId, leadRefId, or cbPullId
        :return: raise error if version doesn't match with stored value in dynamoDB
        """
        data = self.db_helper.query_db_pk_sk(
            deal_ref_id=self.deal_ref_id,
            deal_component=deal_component,
            deal_component_op="begins_with" if reference_id else "eq",
        )

        raise_exception = False
        existing_resource_id = (
            data[0].get(PayloadType.get_payload_component_id(payload_type))
            if data
            else None
        )

        if not data and reference_id and key_should_exist:
            raise_exception = True

        elif data and reference_id and not key_should_exist:
            deal_components = [
                value.get("dealComponent").split(f"{DEAL_COMPONENT_SEPARATOR}")[-1]
                for value in data
                if value.get("dealComponent")
            ]
            raise_exception = True if str(reference_id) in deal_components else False

        elif data and reference_id and key_should_exist:
            deal_components = [
                value.get("dealComponent").split(f"{DEAL_COMPONENT_SEPARATOR}")[-1]
                for value in data
                if value.get("dealComponent")
            ]
            raise_exception = True if str(reference_id) not in deal_components else None

        elif data and existing_resource_id:
            if resource_id is None:
                raise_exception = True if not key_should_exist else False
            elif existing_resource_id != resource_id:
                raise exceptions.BadRequestError(
                    ErrorMsgs.resource_id_mismatch.format(
                        resource_id=resource_id, deal_ref_id=self.deal_ref_id
                    )
                )

        elif data and not data[0].get(
            PayloadType.get_payload_component_id(payload_type)
        ):
            raise_exception = True if key_should_exist else False

        if raise_exception:
            raise exceptions.BadRequestError(get_bad_request_message(key_should_exist))

    @staticmethod
    def validate_header(headers, header_list, validator=None):
        """
        Compare header and raise an exception if there is a mismatch.
        :param headers: The super set of headers.
        :param header_list: The list of headers to compare
        :param validator: validator class instance
        :return: raise exceptions.BadRequestError if headers
        """

        missing_headers = [header for header in header_list if not headers.get(header)]
        if missing_headers:
            if validator and validator.new_error_message:
                for header in missing_headers:
                    validator.generate_error_message(
                        header,
                        ErrorMsgs.missing_headers.format(header=header),
                        indicator="missing_data",
                    )
                validator.generate_missing_property_errors_message()
                raise exceptions.BadRequestError(validator.validation_errors)
            else:
                raise exceptions.BadRequestError(
                    ErrorMsgs.missing_headers.format(header=",".join(missing_headers))
                )

    def deal_exists(self):
        """
        Query database for a deal_ref_id and return True if any records are found, otherwise return False.
        """
        try:
            return bool(self.db_records)
        except exceptions.BadRequestError:
            return False
