# -*- coding: utf-8 -*-
import json
from http import HTTPStatus

import dr_utils


class LambdaMixin:
    def generate_error_response_body(self, error_msg):
        return {"message": str(error_msg)}

    def generate_success_response_body(self, deal_ref_id, description):
        return {
            "description": description,
            "dealRefId": deal_ref_id,
        }

    def process_exception(
        self,
        error: Exception,
        event: dict,
        queue_name: str,
        region: str,
        headers: dict = None,
        correlation_id: str = None,
        status_code: HTTPStatus = None,
        cb_pull_id: str = None,
        message_override: str = None,
        msg_group_id: str = None,
    ):
        status_code = status_code or HTTPStatus.INTERNAL_SERVER_ERROR

        if msg_group_id:
            dr_utils.send_payload_to_queue(
                queue=queue_name,
                payload=event,
                region=region,
                correlation_id=correlation_id,
                cb_pull_id=cb_pull_id,
                msg_group_id=msg_group_id,
            )
        else:
            dr_utils.send_payload_to_queue(
                queue=queue_name,
                payload=event,
                region=region,
                correlation_id=correlation_id,
                cb_pull_id=cb_pull_id,
            )

        msg = message_override or error
        return_body = generate_error_response_body(msg)

        return {
            "statusCode": status_code,
            "body": json.dumps(return_body),
            "headers": headers,
        }


# TODO: This is here to maintain compatibility with function-based handlers that can't inherit the mixin, until those
#       handlers are converted to class-based.
def process_exception(*args, **kwargs):
    return LambdaMixin().process_exception(*args, **kwargs)


def generate_error_response_body(*args, **kwargs):
    return LambdaMixin().generate_error_response_body(*args, **kwargs)
