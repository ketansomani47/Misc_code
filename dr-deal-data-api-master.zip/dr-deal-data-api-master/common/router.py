# -*- coding: utf-8 -*-
import json

import dr_utils
from common.settings import Env, PayloadType as pt
from utils import logger
from utils.exceptions import RoutingError


def get_target_platform_details(target_platform: str):
    """
    Mapping for target platform which contains queue name and service name
    :return: dict containing service and queue name
    """
    return {
        "RT1": {
            "forward_payloads": [
                pt.CREDIT_APP_POST,
                pt.CREDIT_APP_PATCH,
            ],
            "queue_name": Env.ROUTE_ONE_QUEUE,
            "service_name": Env.ROUTE_ONE_SERVICE_NAME,
        },
        "R1J": {
            "forward_payloads": [
                pt.CREDIT_APP_POST,
                pt.CREDIT_APP_PATCH,
                pt.CONTRACT_POST_V2,
            ],
            "queue_name": Env.ROUTE_ONE_JSON_QUEUE,
            "service_name": Env.ROUTE_ONE_SERVICE_NAME,
        },
        "IDL": {
            "forward_payloads": [
                pt.CREDIT_APP_POST,
                pt.CREDIT_APP_PATCH,
                pt.SIGN_CONTRACT_POST,
                pt.SIGN_CONTRACT_POST_V2,
                pt.CONTRACT_POST_V2,
                pt.CONTRACT_CANCEL_POST_V2,
                pt.DEAL_UPDATE,
                pt.VERIFY_CONTRACT_POST_V2,
            ],
            "queue_name": Env.HONDA_QUEUE,
            "service_name": Env.HONDA_SERVICE_NAME,
        },
        "DTC": {
            "forward_payloads": [
                pt.CREDIT_APP_LENDER_POST,
                pt.CONTRACT_POST,
                pt.CONTRACT_UPDATE,
                pt.VERIFY_CONTRACT_POST,
                pt.VERIFY_CONTRACT_POST_V2,
                pt.SIGN_CONTRACT_POST,
                pt.SIGN_CONTRACT_POST_V2,
                pt.CONTRACT_DEAL_STATUS_POST,
                pt.CONTRACT_CANCEL_POST,
                pt.CONTRACT_CANCEL_POST_V2,
                pt.CONTRACT_POST_V2,
                pt.CREDIT_APP_PUT,
            ],
            "queue_name": Env.UNIFI_BRIDGE_QUEUE,
            "service_name": Env.UNIFI_BRIDGE_SERVICE_NAME,
        },
        "DXG": {
            "forward_payloads": [
                pt.CREDIT_APP_POST,
                pt.CREDIT_APP_PATCH,
            ],
            "queue_name": Env.DEALXG_BRIDGE_QUEUE,
            "service_name": Env.DEALXG_BRIDGE_SERVICE_NAME,
        },
    }.get(target_platform.upper(), {})


def get_queue_name(target_platforms: list, payload_type: str):
    """
    As we have limitation to only support one target platform, we are returning queue name once it is found in mapping
    and dropping all other target platforms
    :param target_platforms: list of target platforms in the form of dicts
                            [{"id": "RT1", "partyId": "123987"}]
    :param payload_type: type of payload to route to downstream
    :return: queue name and target route
    """
    routing_list = []
    for target_platform in target_platforms:
        target_platform_id = target_platform.get("id", "")
        target_platform_details = get_target_platform_details(target_platform_id)
        if payload_type in target_platform_details.get("forward_payloads", []):
            routing_list.append(
                {**target_platform_details, "target_platform_id": target_platform_id}
            )
        else:
            logger.warning(
                "Routing is not configured for given payloadType and targetPlatformId",
                targetPlatformId=target_platform_id,
            )
    return routing_list


def route(body: str, correlation_id: str, payload_type: str, deal_ref_id: str):
    """
    Extracts id from targetPlatforms and find suitable queue against the id to send the payload.
    example id: RT1, will have RouteOneQueue
    :param body: body that need to be sent to downstream
    :param correlation_id: correlation id created at the start of request
    :param payload_type: payload type of the body
    :param deal_ref_id: deal data ref id
    :return: raise exception when required otherwise returns nothing
    """
    resp = None
    queue_name = None
    try:
        data = json.loads(body)
        routing_list = get_queue_name(
            target_platforms=data.get("targetPlatforms") or [],
            payload_type=payload_type,
        )

        # Credit applications which contain target platform DTC(only) will be forwarded to DealXG.
        if "DTC" in [
            target_platform.get("id", "")
            for target_platform in data.get("targetPlatforms") or []
        ]:
            routing_list.extend(
                get_queue_name(
                    target_platforms=[{"id": "DXG"}], payload_type=payload_type
                )
            )

        if not routing_list:
            raise dr_utils.exceptions.NoQueueFound(
                f"No queue found for given targetPlatforms: {data.get('targetPlatforms')}"
            )

        for target_platform_detail in routing_list:
            queue_name = target_platform_detail["queue_name"]
            region = dr_utils.get_region(
                service_name=target_platform_detail["service_name"],
                env=Env.DEPLOY_ENV,
                stage=Env.STAGE,
                version=Env.VERSION,
                default_region=Env.AWS_REGION,
                log=logger,
            )
            if "_SIMBRIDGE" not in correlation_id:
                resp = dr_utils.send_payload_to_queue(
                    queue=target_platform_detail["queue_name"],
                    payload=data,
                    region=region,
                    correlation_id=correlation_id,
                    deal_ref_id=deal_ref_id,
                    payload_type=payload_type,
                )
                logger.info(
                    "Application sent to target platform queue",
                    requestPayload=data,
                    targetPlatformId=target_platform_detail["target_platform_id"],
                )
            else:
                logger.info(
                    "Application not sent to target platform queue and simulating sqs response",
                    requestPayload=data,
                    targetPlatformId=target_platform_detail["target_platform_id"],
                )
        return resp
    except dr_utils.exceptions.NoQueueFound as error:
        raise error
    except Exception as error:
        logger.exception(f"Routing failed to send payload to {queue_name}")
        raise RoutingError(str(error)) from error
