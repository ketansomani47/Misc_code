# -*- coding: utf-8 -*-
import copy
import json
from http import HTTPStatus
from numbers import Number

import utils.schema
from boto3.dynamodb.conditions import Key
from common import settings as se
from common.settings import (
    CREDIT_BUREAU_COMPONENT,
    CREDIT_BUREAU_REPORT_KEY,
    DEAL_COMPONENT_SEPARATOR,
    NESTED_KEY_IDENTIFIER,
    PROTECTED_KEY_NAME,
    DealComponent as dc,
    Env,
    ErrorMsgs,
    InfoMsgs,
    SchemaType as st,
)
from common.validators import ExistingDealValidator
from utils import EventsEnum, common, logger
from utils.common import DealDataParameters
from utils.db_helper import DynamoDbHelper
from utils.exceptions import BadRequestError


def deal_get(event, context):
    """
    Validates if dealRefId is present and fetches information for that dealRefId
    :param dict event: An API Gateway event object
    :param dict context: AWS Lambda Context Object
    :return: JSON with status code and body
    """
    (
        body,
        corr_id,
        response_header,
        request_version,
        headers,
    ) = common.get_common_attributes(event, Env.AWS_REGION, Env.VERSION)

    if headers.get(se.HEALTHCHECK_HEADER_FIELD) == se.HEALTHCHECK_HEADER_VALUE:
        return {"statusCode": HTTPStatus.CREATED, "body": json.dumps("Operational")}

    deal_ref_id = common.get_path_parameter(event, "dealRefId")

    log = logger.new(
        functionArn=context.invoked_function_arn,
        correlationId=corr_id,
        dealRefId=deal_ref_id,
        requestHeaders=headers,
    )
    try:

        validator = ExistingDealValidator(event, deal_ref_id)
        validator.validate_api_version(request_version)

        key_expression = Key("dealRefId").eq(deal_ref_id)
        db = DynamoDbHelper(
            region=Env.AWS_REGION, table_name=DealDataParameters().db_name
        )
        db_records = db.query_items(key_expression=key_expression)

        log.info(InfoMsgs.received_data_from_db.format(operation="GET FULL DEAL"))

        include_protected = bool(
            common.get_query_string_parameter(event, "protected") in ("True", "true")
        )
        schema = utils.schema.get_schema(request_version, st.DEAL_GET)

        data = process_data_for_response_schema(db_records, schema, include_protected)
        log.info(
            InfoMsgs.payload_transformed_for_version.format(version=request_version)
        )

        # Transform lenders to original property
        lender_list_data = transform_back_lender_list_payload(
            db_records=db_records, payload=data
        )
        log.info(InfoMsgs.lenders_transformed_back)

        return {
            "statusCode": HTTPStatus.OK,
            "body": json.dumps(lender_list_data, cls=common.decimal_decoder()),
            "headers": response_header,
        }

    except BadRequestError as error:
        message = (
            f"{ErrorMsgs.error_processing_get.format(operation='FULL DEAL')} {error}"
        )
        log.warning(message, exc_info=error, aws_event=EventsEnum.deal_get_failed)
        return_body = {"dealRefId": deal_ref_id, "message": str(error)}
        return {
            "statusCode": HTTPStatus.BAD_REQUEST,
            "body": json.dumps(return_body),
            "headers": response_header,
        }
    except Exception as error:
        message = ErrorMsgs.error_processing_get.format(operation="FULL DEAL")
        log.exception(message, exc_info=error, aws_event=EventsEnum.deal_get_failed)
        return_body = {"dealRefId": deal_ref_id, "message": str(error)}
        return {
            "statusCode": HTTPStatus.INTERNAL_SERVER_ERROR,
            "body": json.dumps(return_body),
            "headers": response_header,
        }


def process_data_for_response_schema(
    db_records: list, schema: dict, include_protected: bool
):
    """
    Transforms a list of records queried from dynamodb and transform it to swagger schema response type.
    -   All protected information will be decrypted and extracted inside parent object. example all protected info from
        DTC.APPLICANT.PROTECTED into applicant key.
    -   All list objects are extracted to root level objects, example {'dealComponent': 'DTC.TRADEINS', 'tradeIns': []}
        to {'tradeIns': []}
    -   All keys with Credit Bureau Records are combined if report record exists for both CB Pull and CB Response
    otherwise display individual records.
    - https://swaggerhub.np.aws.dealertrack.com/apis/COX-DRS/deals/1.0.0d#/

    :param db_records: list of records queried from dynamodb
    :param schema: schema for a specific api version
    :param include_protected: Include protected data in output
    :return: swagger complied re-structured response
    """

    data = {}
    credit_bureau_records = {}
    records = copy.deepcopy(db_records)
    for record in records:
        deal_component = str(record.pop("dealComponent")).split(
            DEAL_COMPONENT_SEPARATOR
        )
        sub_object_name = utils.schema.get_key_original_case(schema, deal_component[1])

        if "DEAL" in deal_component:
            data.update(process_sub_node(schema, record, {}))
        elif PROTECTED_KEY_NAME.upper() in deal_component and include_protected:
            object_data = process_protected(data.get(sub_object_name) or {}, record)
            data.setdefault(sub_object_name, {}).update(object_data)
        elif sub_object_name in record:
            data[sub_object_name] = record.get(sub_object_name)
        elif deal_component[0] == dc.CREDIT_BUREAU_PREFIX:
            credit_bureau_records = process_credit_bureau_reports(
                deal_component, record, credit_bureau_records, schema
            )
        elif (
            sub_object_name in schema
            and PROTECTED_KEY_NAME.upper() not in deal_component
        ):
            sub_node_schema = schema.get(sub_object_name) or {}
            data[sub_object_name] = process_sub_node(sub_node_schema, record, {})

    if credit_bureau_records:
        data = add_cb_reports_to_data(data, credit_bureau_records)

    return data


def process_sub_node(
    schema: dict,
    db_record: dict,
    data: dict,
    current_node: str = None,
    previous_node: str = None,
):
    """
    Process each sub node and transforms into schema structure
    :param schema: schema of particular sub object
    :param db_record: dynamo db record of particular sub object
    :param data: record that used in recursion to transform db record to schema structure
    :param current_node: field name in current recursion loop
    :param previous_node: field name of previous recursion loop which helps to create if not present
    :return: sub object dict which got transform to schema structure
    """
    for key, val in db_record.items():
        if isinstance(val, dict):
            split_key = key.split(NESTED_KEY_IDENTIFIER)
            if (
                len(split_key) > 1
                and split_key[0] in schema
                and split_key[1] in schema[split_key[0]]
            ):
                data.setdefault(split_key[0], {}).update({split_key[1]: val})
            elif key in schema:
                process_sub_node(schema[key], db_record[key], data, key, current_node)
        elif (val or isinstance(val, Number)) and key in schema:
            if previous_node:
                data.setdefault(previous_node, {}).setdefault(current_node, {})[
                    key
                ] = val
            elif current_node:
                data.setdefault(current_node, {})[key] = val
            else:
                data[key] = val
    return data


def process_protected(sub_object: dict, db_record: dict):
    """
    Decrypts protected data and update sub object with all pii data
    :param sub_object: fields of sub object (applicant, coApplicant etc)
    :param db_record: protected record that need to be decrypted
    :return: sub object node with pii data if present
    """
    if db_record.get(PROTECTED_KEY_NAME):
        protected_decrypted = db_record[PROTECTED_KEY_NAME]
        sub_object.update(protected_decrypted)
        logger.info("Decrypted protected information")
    return sub_object


def process_credit_bureau_reports(
    deal_component_parts, data, credit_bureau_records, schema
):
    """
    This method checks for CB Record for it's request type. It makes a nested dict object from these records where
    keys are defined by CUSTOMER_TYPE ->  {CB_PULL_ID.PROVIDER.TYPE: [REPORTS]}

    If for same CUSTOMER_TYPE, CB_PULL_ID.PROVIDER.TYPE, RESPONSE exists then we simply update REPORTS else we add
    a new REPORT if either CB_PULL_ID.PROVIDER.TYPE is different or it belongs to a different CUSTOMER_TYPE.
    :param list deal_component_parts: name of deal component
    :param dict data: record object queried from database and transformed to swagger response
    :param dict credit_bureau_records: previous dict of CUSTOMER_TYPE ->  {CB_PULL_ID.PROVIDER.TYPE: [REPORTS]} to be updated
    :param dict schema: schema based on deal object https://swaggerhub.np.aws.dealertrack.com/apis/COX-DRS/deals/1.0.0d#/
    :return: dict of CUSTOMER_TYPE ->  {CB_PULL_ID.PROVIDER.TYPE: [REPORTS]}
    """
    cb_pull_id = deal_component_parts[-1]
    customer_type = deal_component_parts[-2]
    sub_object_name = utils.schema.get_key_original_case(schema, customer_type)
    report_schema = schema[sub_object_name].get(CREDIT_BUREAU_REPORT_KEY)[0]
    value = {key: value for key, value in data.items() if key in report_schema.keys()}

    cb_record_key = f"{cb_pull_id}.{data.get('provider')}.{data.get('type')}".upper()
    credit_bureau_records.setdefault(customer_type, {}).setdefault(
        cb_record_key, {}
    ).update(value)

    return credit_bureau_records


def add_cb_reports_to_data(data, credit_bureau_records):
    """
    This method will extract REPORT data from CUSTOMER_TYPE -> {CB_PULL_ID.PROVIDER.TYPE: [REPORTS]} based on
    CUSTOMER_TYPE and make a REPORTS record in data for that particular CUSTOMER.

    :param data: record list queried from database and transformed to swagger response
    :param credit_bureau_records: dict object with CUSTOMER_TYPE -> {CB_PULL_ID.PROVIDER.TYPE: [REPORTS]}
    :return: data with updated records for Credit Bureau Reports
    """
    for customer_type in CREDIT_BUREAU_COMPONENT:
        customer_reports = credit_bureau_records.get(customer_type.upper()) or {}
        if customer_reports:
            data.setdefault(customer_type, {}).setdefault(
                CREDIT_BUREAU_REPORT_KEY, []
            ).extend(list(customer_reports.values()))

    return data


def transform_back_lender_list_payload(db_records: list, payload: dict):
    """
    Transform back to original schema list of lenders from DynamoDB to
    lenderList property.
    DynamoDb ei.
        {
            'lenderList.BOA': {'lenderId': 'BOA', 'lenderName': 'Bank of America'},
            'lenderList.CMB': {'lenderId': 'CMB', 'lenderName': 'Chase Bank'}
        }
    :return {
        "lenderList": [
            {"lenderId": "CMB", "lenderName": "Chase Bank"},
            {"lenderId": "BOA", "lenderName": "Bank of America"}
        ]
    }
    """
    lender_list = []
    data = copy.deepcopy(payload)
    for record in db_records:
        deal_component = str(record.pop("dealComponent")).split(
            DEAL_COMPONENT_SEPARATOR
        )
        if "LENDERLIST" in deal_component and "lenderId" in record:
            lender_list.append(
                {
                    "lenderId": record.get("lenderId", ""),
                    "lenderName": record.get("lenderName", ""),
                }
            )
            data["lenderList"] = lender_list

    return data


def process_trade_ins_list(data: dict, trade_in_schema: dict):
    """
    Transforms the trade_ins list to remove extra fields
    """
    trade_ins = data.get("tradeIns", [])
    for index, trade_in_data in enumerate(trade_ins):
        data["tradeIns"][index] = process_sub_node(trade_in_schema, trade_in_data, {})


def remove_empty_data_nodes(data):
    """
    Removes empty nodes from response data
    """
    if isinstance(data, dict):
        cleaned_dict = {
            k: remove_empty_data_nodes(v) for k, v in data.items() if v is not None
        }
        # Filter out any remaining empty dictionaries
        return {k: v for k, v in cleaned_dict.items() if v not in [{}, []]}
    elif isinstance(data, list):
        cleaned_list = [
            remove_empty_data_nodes(item) for item in data if item is not None
        ]
        # Filter out any remaining empty lists
        return [item for item in cleaned_list if item not in [{}, []]]
    else:
        return data
