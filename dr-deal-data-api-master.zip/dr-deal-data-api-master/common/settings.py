# -*- coding: utf-8 -*-
import os


HEALTHCHECK_HEADER_FIELD = "healthcheck"
HEALTHCHECK_HEADER_VALUE = "true"
LENDER_DECISION_OPERATION = "Latest Lender Decision"
TARGET_PLATFORM_FIELD = "targetPlatformId"
DEAL_COMPONENT_ID_MAPPING = {"applicant": "applicantId", "coApplicant": "coApplicantId"}
CREDIT_BUREAU_COMPONENT = ["applicant", "coApplicant"]
COMPONENTS_NOT_AS_SEPARATE_RECORDS = ["targetPlatforms"]
COMPONENTS_NOT_INCLUDED_IN_RECORDS = ["VERSION"]
CORRELATION_ID_HEADER_KEY = "X-CoxAuto-Correlation-Id"
DEAL_REF_ID_HEADER_KEY = "X-Deal-Reference-Id"
CREDIT_APP_ID_HEADER_KEY = "X-Credit-Application-Reference-Id"
CB_PULL_HEADER_KEY = "Credit-Bureau-Reference-Id"
DEAL_XG_ID_HEADER_KEY = "dealXgDealId"
DEAL_XG_VERSION_HEADER_KEY = "dealXgDealVersion"
CB_RESPONSE_KEY_FD = "eventTransactionId"
PROTECTED_KEY_NAME = "protected"
CREDIT_BUREAU_REPORT_KEY = "reports"
RETRY_DELAY_TIME = {1: 5, 2: 10, 3: 15, 4: 15, 5: 15}
MAX_RETRY_ATTEMPTS = 5
NESTED_KEY_IDENTIFIER = "_"
DEAL_COMPONENT_SEPARATOR = "."
API_CONNECT_SCOPE = "internet-app-write"
CD_SOURCE_PARTNER = "Source-Partner"
SIMULATOR_GET = "https://simulation-qa.drsvcnp.aws.dealertrack.com/v1"
SIMULATOR_POST = "https://simulation-qa.drsvcnp.aws.dealertrack.com/v1/virtualfd"
SIMULATOR_TOKEN_ENDPOINT = (
    "https://simulation-qa.drsvcnp.aws.dealertrack.com/oauth2/token"
)
SNAPSHOT_RESERVED_TAGS = ["expiration_date", "api_version"]
S3_OBJECT_KEY_TEMPLATE = (
    "{dealerId}/{dealRefId}/DATA/{feature}/{context_id}.{content_type}"
)
S3_DLQ_OBJECT_KEY_TEMPLATE = "{dlqName}/{dealRefId}/{timestamp}.{content_type}"
CONTENT_TYPE = "application/{file_type}"
PII_DATA_KEYS = [
    "ssn",
    "dateOfBirth",
    "driversLicenseNumber",
    "driversLicenseState",
    "bankAccountNumber",
    "businessTaxId",
    "identificationNumber",
    "taxIdentifier",
    "bankName",
]

# These are the mappings that we use to store keys provided in headers by the client
KEY_DATA_MAPPING = {
    "X-Lead-Reference-Number": "dealRefIdFD",
    "X-Application-Reference-Number": "appRefIdFD",
    "X-Lead-Reference-Number-Internal": "dealRefIdFDInt",
    "X-Application-Reference-Number-Internal": "appRefIdFDInt",
    "X-Deal-Jacket-ID": "dealJacketId",
    "X-Dealer-Code": "dealerCode",
    "X-Deal-Reference-Number-UniFI": "dealRefIdFI",
}
KEY_DATA_INDEX = "key-data"

GET_EVENTS_FILTER_PARAMS = ["eventName", "eventSource", "eventType", "targetPlatformId"]
GET_DOCS_FILTER_PARAMS = [
    "uploadStatus",
    "documentType",
    "customerRole",
    "tags",
    "extensionFields",
    "targetPlatform",
]

DOCS_REQUIRED_BODY_FIELDS = ["documentType", "customerRole", "uploadStatus"]
DOCS_CUSTOMER_TYPES = {
    "Applicant": "APP",
    "Coapplicant": "COAPP",
    "Generic": "GEN",
    "Guarantor": "GUARANTOR",
}


class RetentionPeriod:
    """
    Each variable represents a time in seconds to be used as the retention period for DynamoDB data records.
    """

    general = (24 * 60 * 60) * 60  # 60 days
    credit_bureau = (24 * 60 * 60) * 30  # 30 days
    document_session = (60 * 60) * 12  # 12 hours


class SnapshotAction:
    SNAPSHOT_CREATE = "CREATE"
    SNAPSHOT_UPDATE = "UPDATE"


class PayloadType:
    CONTRACT_CANCEL_POST = "CONTRACT_CANCEL_POST"
    CONTRACT_CANCEL_POST_V2 = "CONTRACT_CANCEL_POST_V2"
    CONTRACT_DEAL_STATUS_POST = "CONTRACT_DEAL_STATUS_POST"
    CONTRACT_POST = "CONTRACT_POST"
    CONTRACT_POST_V2 = "CONTRACT_POST_V2"
    CONTRACT_UPDATE = "CONTRACT_UPDATE"
    CREDIT_APP_LENDER_POST = "CREDIT_APP_LENDER_POST"
    CREDIT_APP_PATCH = "CREDIT_APP_PATCH"
    CREDIT_APP_POST = "CREDIT_APP_POST"
    CREDIT_APP_UPDATE = "CREDIT_APP_UPDATE"
    CREDIT_APP_PUT = "CREDIT_APP_PUT"
    CREDIT_BUREAU_PULL = "CREDIT_BUREAU_PULL"
    CREDIT_BUREAU_PULL_DEAL_UPDATE = "CREDIT_BUREAU_PULL_DEAL_UPDATE"
    CREDIT_BUREAU_RESPONSE = "CREDIT_BUREAU_RESPONSE"
    DEAL_UPDATE = "DEAL_UPDATE"
    KEY_DATA_POST = "KEY_DATA_POST"
    KEY_DATA_STREAM = "KEY_DATA_STREAM"
    KEY_DATA_UPDATE = "KEY_DATA_UPDATE"
    KEY_DATA_UPDATE_V2 = "KEY_DATA_UPDATE_V2"
    LEAD_PATCH = "LEAD_PATCH"
    LEAD_POST = "LEAD_POST"
    LEAD_UPDATE = "LEAD_UPDATE"
    SIGN_CONTRACT_POST = "SIGN_CONTRACT_POST"
    SIGN_CONTRACT_POST_V2 = "SIGN_CONTRACT_POST_V2"
    VERIFY_CONTRACT_POST = "VERIFY_CONTRACT_POST"
    VERIFY_CONTRACT_POST_V2 = "VERIFY_CONTRACT_POST_V2"

    @staticmethod
    def get_payload_component_id(payload_type: str):
        return {
            PayloadType.LEAD_POST: "leadRefId",
            PayloadType.LEAD_UPDATE: "leadRefId",
            PayloadType.LEAD_PATCH: "leadRefId",
            PayloadType.CREDIT_APP_POST: "creditAppId",
            PayloadType.CREDIT_APP_PATCH: "creditAppId",
            PayloadType.CREDIT_APP_UPDATE: "creditAppId",
            PayloadType.DEAL_UPDATE: "creditAppId",
            PayloadType.CREDIT_APP_LENDER_POST: "creditAppId",
            PayloadType.CREDIT_APP_PUT: "creditAppId",
            PayloadType.CONTRACT_POST: "contractRefId",
            PayloadType.CONTRACT_UPDATE: "contractRefId",
            PayloadType.VERIFY_CONTRACT_POST: "contractRefId",
            PayloadType.SIGN_CONTRACT_POST: "contractRefId",
            PayloadType.SIGN_CONTRACT_POST_V2: "contractRefId",
            PayloadType.CONTRACT_DEAL_STATUS_POST: "contractRefId",
            PayloadType.CONTRACT_CANCEL_POST: "contractRefId",
        }.get(payload_type)

    @staticmethod
    def should_id_exist_for_post(payload_type: str):
        """
        This method checks for validation against some id, whether it should be present in db or not
        :param payload_type: payload type indicates the nature of request (CA, CB, LEAD)
        :return: bool based on payload type
        """
        return {
            PayloadType.LEAD_POST: False,
            PayloadType.CREDIT_APP_POST: False,
            PayloadType.CREDIT_APP_LENDER_POST: True,
            PayloadType.CREDIT_BUREAU_RESPONSE: True,
            PayloadType.CREDIT_BUREAU_PULL_DEAL_UPDATE: False,
            PayloadType.LEAD_PATCH: False,
            PayloadType.CREDIT_APP_PATCH: False,
            PayloadType.LEAD_UPDATE: True,
            PayloadType.CREDIT_APP_UPDATE: True,
            PayloadType.DEAL_UPDATE: True,
            PayloadType.CONTRACT_POST: False,
            PayloadType.CREDIT_APP_PUT: True,
        }.get(payload_type)

    @staticmethod
    def reference_record_id_validation(payload_type: str):
        """
        This method returns the id to look for each payload type for validation
        :param payload_type: payload type indicates the nature of request (CA, CB, LEAD)
        :return: id for a given payload type
        """
        return {
            PayloadType.CREDIT_BUREAU_PULL_DEAL_UPDATE: "cb_pull_id",
            PayloadType.CREDIT_BUREAU_RESPONSE: "cb_pull_id",
        }.get(payload_type)


class SchemaType:
    """
    This class maps payload types defined above in PayloadType with schema file names defined in directory schemas for a
    specific version
    """

    CONTRACT_CANCEL_POST = "CON_STATUS"
    CONTRACT_CANCEL_POST_V2 = "CON_STATUS"
    CONTRACT_DEAL_STATUS_POST = "CON_STATUS"
    CONTRACT_POST = "CON"
    CONTRACT_POST_V2 = "CON"
    CONTRACT_UPDATE = "CON"
    CREDIT_APP_LENDER_POST = "CA"
    CREDIT_APP_PATCH = "CA"
    CREDIT_APP_POST = "CA"
    CREDIT_APP_UPDATE = "CA"
    CREDIT_BUREAU_PULL = "CA"
    CREDIT_BUREAU_PULL_DEAL_UPDATE = "CA"
    CREDIT_BUREAU_RESPONSE = "CB"
    DEAL_GET = "DEAL_GET"
    DEAL_UPDATE = "CA"
    EVENT = "EVENT"
    KEY_DATA_GET = "KEY_DATA"
    KEY_DATA_POST = "KEY_DATA"
    KEY_DATA_UPDATE = "KEY_DATA"
    KEY_DATA_UPDATE_V2 = "KEY_DATA_V2"
    LEAD_PATCH = "LEAD"
    LEAD_POST = "LEAD"
    LEAD_UPDATE = "LEAD"
    SIGN_CONTRACT_POST = "CON_SIGN"
    SIGN_CONTRACT_POST_V2 = "CON_SIGN"
    VERIFY_CONTRACT_POST = "CON"
    VERIFY_CONTRACT_POST_V2 = "CON"
    CA_GET = "CA_GET"
    CREDIT_APP_PUT = "CA"

    @staticmethod
    def get_schema_name(payload_type: str):
        """
        Returns schema file name for a given payload type
        :param payload_type: payload type indicates the nature of request (CA, CB, LEAD)
        :return: attribute
        """
        return getattr(SchemaType, payload_type)


class DealComponent:
    DTC_DEAL = "DTC.DEAL"
    DTC_VERSION = "DTC.VERSION"
    DTC_EVENTS = "DTC.EVENTS"
    DTC_DOCS = "DTC.DOCS"
    IDL_DOCS = "IDL.DOCS"
    R1J_DOCS = "R1J.DOCS"
    DTC_DOCS_UPLOAD = "DTC.DOCS.UPLOADS"
    PROTECTED = "DTC.{deal_component}.{protected_key_name}"

    CB_PULL_COMPONENT = "CB.PULL.{provider}.{report_type}.{cust_type}.{cb_pull_id}"
    CB_RESPONSE_COMPONENT = "CB.RESP.{provider}.{report_type}.{cust_type}.{cb_pull_id}"
    CREDIT_BUREAU_PREFIX = "CB"

    # all ids define below are used to perform query operation for validation with begins_with inside deal_component
    CREDIT_BUREAU_PULL = "CB"
    CREDIT_BUREAU_PULL_DEAL_UPDATE = "CB"
    CREDIT_BUREAU_RESPONSE = "CB"

    @staticmethod
    def get_component_name(payload_type: str):
        """
        Returns schema file name for a given payload type
        :param payload_type: payload type indicates the nature of request (CA, CB, LEAD)
        :return: attribute value for a specific payload type
        """
        return getattr(DealComponent, payload_type)

    def get_credit_bureau_component(self, payload_type: str):
        return {
            PayloadType.CREDIT_BUREAU_PULL: self.CB_PULL_COMPONENT,
            PayloadType.CREDIT_BUREAU_PULL_DEAL_UPDATE: self.CB_PULL_COMPONENT,
            PayloadType.CREDIT_BUREAU_RESPONSE: self.CB_RESPONSE_COMPONENT,
        }.get(payload_type)


class WarningMsgs:
    post_docs_missing_target_platform = (
        "Missing target platform in document create body"
    )


class ErrorMsgs:
    error_processing_request_fmt = "Error processing {payload_type} request. {error}"
    error_processing_request = "Error processing request"
    missing_deal_from_db = "No deal found for {deal_ref_id}"
    deal_ref_id_not_provided = "dealRefId not provided"
    missing_body_aws_event = "No record or body found in AWS event payload"
    missing_transaction_id = "No eventTransactionId found in event"
    missing_event_payload = "No payload found in event"
    missing_query_string_parameters = "No query string parameters provided"
    missing_headers = "Missing header(s): '{header}' is needed to process request"
    missing_multiple_headers = (
        "The following headers are required to process the request: {headers}"
    )
    missing_body_fields_docs = (
        "The following body fields are required to process the request: {fields}"
    )
    invalid_customer_type = "customerRole field must be one of the following: {values}"
    invalid_page_count = "pageCount is a required header and must be of type int"
    missing_keydata_for_s3_key = "{property} is missing in eventKeyData"
    missing_lender_id = "lenderId is missing in provided decision"
    invalid_json_payload = "Invalid JSON payload"
    api_version_mismatch = (
        "API version mismatch: The deal was created with version {stored_api_version} but "
        "access was attempted from API version {request_api_version}"
    )
    resource_id_mismatch = "The resource_id: {resource_id} does not match our records for dealRefId: {deal_ref_id}"
    reference_id_mismatch = (
        "Provided {reference_id_type}: {reference_id} does not match our records for "
        "dealRefId: {deal_ref_id}"
    )
    reference_id_exist = (
        "'{reference_id_type}' already exists for resource dealRefId={deal_ref_id}"
    )
    deal_ref_id_missing = "Missing dealRefId"
    invalid_deal_ref_id = "Invalid dealRefId {deal_ref_id}"
    deal_ref_id_already_exists = "Provided dealRefId {deal_ref_id} already exists"
    invalid_credit_app_id = "Invalid creditAppId {credit_app_id}"
    invalid_ulid = "Invalid ulid provided. Error {error}"
    invalid_uuid = "Invalid uuid provided. Error {error}"
    invalid_event_id = (
        "Provided eventId {event_id} is not associated to dealRefId {deal_ref_id}"
    )
    reference_id_mismatch_new_format = (
        "Provided {reference_id_type} {reference_id} is not associated to "
        "dealRefId {deal_ref_id}"
    )
    path_params_new_format = (
        "{path_parameter_Id} is missing in provided path parameters"
    )
    failed_write_operation = "Error processing {resource} for operation {action}. Sending message to DLQ {queue}."
    sending_msg_dlq = "Error processing {payload_type}. Sending message to DLQ {queue}. Error: {error}"
    retry_failed_apps = (
        "Failed to process deal data for {payload_type}, retry count: = {retry_count}"
    )
    status_update_failed_retry = "Deal not found in db when attempting to update status. Retrying in {delay} minutes."
    error_processing_get = "Error processing application for get {operation}."
    unsupported_key_data_post_fields = (
        "Given fields '{field}' is not supported for "
        "targetPlatformId {target_platform_id}"
    )
    key_data_conditional_validation_fields = (
        "'{dependent_field}' and '{field}' are mutually conditional, "
        "if one is provided the other becomes mandatory"
    )
    key_data_conditional_validation_fields_2 = (
        "'{dependent_field}' is required if '{field}' is provided"
    )
    error_unsupported_key_data = "Given query param, {field} is not supported."
    unsupported_key_data_query_field = (
        "Given query param, {field} is not supported for "
        "targetPlatformId {target_platform_id}"
    )
    error_unsupported_target_platform_key_data = (
        "Given target platform, {field} is not supported."
    )
    error_empty_query_string_value = "Query string value cannot be empty"
    error_unsupported_events_filter = (
        "Given filter parameters aren't supported. Supported filters: {filters}"
    )
    error_multiple_key_data_query_param = (
        "Only one query param along with a targetPlatformId is allowed"
    )
    error_duplicate_resource = (
        "You have tired to post to an endpoint for which the resource doesn't exists."
    )
    error_document_post = "Error encountered saving document record"
    api_usage_threshold_limit = "API Usage limit exceeded {percentage} of usage."
    empty_path_parameter = "Provided path parameter is invalid/empty {path_parameter}"
    duplicate_event_record = "Event record already posted"
    duplicate_document_record = "Document record already posted"
    delete_document_record_not_exists = (
        "Delete document from dynamo failed as the document targeted does not exist"
    )
    s3_save_error_msg = "Error saving data to s3. Error: {error}"
    payment_detail_not_found = "No payment details found on S3"
    fld_with_credit_app_not_found = (
        "No full lender decision found for given creditAppId on s3"
    )


class InfoMsgs:
    received_event_from_db_stream = "Received data from dynamoDb stream event"
    processing_message_from_queue = "Processing message from queue {queue}"
    processing_persistence = "Processing persistence for {resource} operation"
    received_get_request = "Received GET request"
    received_data_from_db = "Received data from dynamoDb for {operation} operation"
    patch_event_on_db = "Patched event on dynamoDB"
    payload_transformed_for_version = (
        "Deal data transformed against the schema for version: v{version}"
    )
    lenders_transformed_back = "lenderList transformed for original property"
    processing_lender_decision = "Processing lender decision {operation}"
    stored_payment_detail = "Payment details stored to S3 with {file_name}"
    retrieved_payment_detail = "Retrieved latest payment details from s3"
    retrieved_fld_with_credit_app_id = (
        "Retrieved latest full lender decision for given creditAppId from s3"
    )
    payload_removed_from_es = "Successfully removed data from ES "
    payload_added_to_es = "Added/ Modified data to ES"
    post_lender_decision = "Lender decision has been posted to DB"
    post_event = "Event has been posted to DB"
    post_document = "Document has been posted to DB"
    post_session = "Session has been posted to DB"
    patch_session_page_deprecated = "Deprecated patch session called"
    body_to_be_sent = "Body to be sent to DB: {body}"
    body_received = "Initial body received: {body}"
    delete_document = "Document with dealRefId {dealRefId} and documentId {documentId} ready for deletion"
    delete_document_no_tp_record = (
        "Target platform record was not deleted because it did not exist. "
        "Records created before target platform logic existed."
    )
    delete_document_successful = "Document deleted"


class Env:
    """Environment variables. Wrapped in a class to simplify testing."""

    URL = os.environ.get("URL")
    KEY = os.environ.get("KEY")
    VERSION = os.environ.get("VERSION")
    STAGE = os.environ.get("STAGE")
    DEPLOY_ENV = os.environ.get("DEPLOY_ENV")
    AWS_REGION = os.environ.get("REGION")
    DEPLOY_STATUS = os.environ.get("DEPLOY_STATUS")
    DEAL_DATA_QUEUE = os.environ.get("DEAL_DATA_QUEUE")
    DEAL_DATA_DLQ = os.environ.get("DEAL_DATA_DLQ")
    EVENT_QUEUE = os.environ.get("EVENT_QUEUE")
    EVENT_ROUTE_QUEUE = os.environ.get("EVENT_ROUTE_QUEUE")
    ROUTE_ONE_QUEUE = os.environ.get("ROUTE_ONE_QUEUE")
    ROUTE_ONE_JSON_QUEUE = os.environ.get("ROUTE_ONE_JSON_QUEUE")
    ROUTE_ONE_JSON_DLQ = os.environ.get("ROUTE_ONE_JSON_DLQ")
    HONDA_QUEUE = os.environ.get("HONDA_QUEUE")
    KMS_REGULATED_KEY_ALIAS_NAME = os.environ.get("KMS_REGULATED_KEY_ALIAS_NAME")
    SERVICE_NAME = os.environ.get("SERVICE_NAME")
    ROUTE_ONE_SERVICE_NAME = os.environ.get("ROUTE_ONE_SERVICE_NAME")
    HONDA_SERVICE_NAME = os.environ.get("HONDA_SERVICE_NAME")
    SNAPSHOT_QUEUE = os.environ.get("SNAPSHOT_QUEUE")
    SNAPSHOT_DLQ = os.environ.get("SNAPSHOT_DLQ")
    SNAPSHOT_BUCKET = os.environ.get("SNAPSHOT_BUCKET")
    DEAL_BUCKET = os.environ.get("DEAL_BUCKET")
    REPROCESSING_GARAGE = os.environ.get("REPROCESSING_GARAGE")
    UNIFI_BRIDGE_QUEUE = os.environ.get("UNIFI_BRIDGE_QUEUE")
    UNIFI_BRIDGE_DLQ = os.environ.get("UNIFI_BRIDGE_DLQ")
    UNIFI_BRIDGE_SERVICE_NAME = os.environ.get("UNIFI_BRIDGE_SERVICE_NAME")
    EVENTS_ENDPOINT = os.environ.get("EVENTS_ENDPOINT")
    SETTINGS_ENDPOINT = os.environ.get("SETTINGS_ENDPOINT")
    SETTINGS_API_KEY = os.environ.get("SETTINGS_API_KEY")
    AWS_SESSION_TOKEN = os.environ.get("AWS_SESSION_TOKEN")
    API_NAME = os.environ.get("API_NAME")
    CHECK_LEAD_REFERENCE_ID = os.environ.get("CHECK_LEAD_REFERENCE_ID")
    DEALXG_BRIDGE_QUEUE = os.environ.get("DEALXG_BRIDGE_QUEUE")
    DEALXG_BRIDGE_SERVICE_NAME = os.environ.get("DEALXG_BRIDGE_SERVICE_NAME")


class TargetPlatformIds:

    DTA = "DTA"
    DTC = "DTC"
    IDL = "IDL"
    R1J = "R1J"
    RT1 = "RT1"


class KeyDataFetchMethod:
    DYNAMO_DB = "dynamoDb"


class S3Config:
    """
    S3 key structures
    """

    CONTENT_TYPE = "application/json"
    S3_PAYMENT_DETAILS_KEY = (
        "{partnerId}/{partnerDealerId}/{dealRefId}/"
        "{creditAppId}/PAYMENTDETAILS/{lenderId}/{eventId}"
    )
    S3_FLD_WITH_CREDIT_APP_KEY = "{partnerId}/{partnerDealerId}/{dealRefId}/CA/{creditAppId}/{lenderId}/{eventId}"
