# -*- coding: utf-8 -*-
import json
from functools import wraps
from http import HTTPStatus
from uuid import uuid4 as uuid

from common import settings
from common.mixins import LambdaMixin
from common.settings import (
    CORRELATION_ID_HEADER_KEY,
    KEY_DATA_MAPPING,
    Env,
    ErrorMsgs,
)
from utils import EventsEnum, common, exceptions, logger


class LambdaBase:
    def __init__(self, **kwargs):
        self.api_version = Env.VERSION
        self.log = logger.new()
        self.correlation_id = None
        self.request_headers = None
        self.lowercase_headers = None
        self.request_api_version = None
        self.body = None

    @classmethod
    def get_handler(cls, handler_func: str = None, **kwargs):
        """
        Returns a handler function which will call the underlying handler method named in handler_func with the event
        and context parameters.

        :param handler_func: Name of the method wo call in the underlying lambda handler class.
        :param kwargs: Any keyword arguments to pass to the initializer of the underlying lambda handler class.
        :return: A reference to the wrapped handler function.
        """
        handler_func = handler_func or "handle"

        def handler(event, context):
            # The class instantiation below `cls(**kwargs)` ensures a new instance is created for each lambda run.
            return getattr(cls(**kwargs), handler_func)(event, context)

        return handler

    def handle(self, event, context):
        raise NotImplementedError

    @staticmethod
    def is_handler(func):
        """
        Default handler decorator. Performs the bare minimum pre-initialization
        :param func: Function to decorate
        :return: Return value of decorated function
        """

        @wraps(func)
        def wrapper(self, event, context):
            self.init_logger(context)
            return func(self, event, context)

        return wrapper

    def init_logger(self, context, **kwargs):
        """
        Initialize logger by binding default keys such as aws_resources, in addition to any keys passed in as keyword
        arguments.
        :param context: A LambdaContext instance passed to the lambda function.
        :param kwargs: Any key-value pair that should be bound to the logger.
        :return: A logger instance
        """
        fields_to_bind = {
            "functionArn": context.invoked_function_arn,
            "requestHeaders": common.scrub_dictionary(self.request_headers),
            "stage": Env.STAGE,
            "env": Env.DEPLOY_ENV,
            "version": Env.VERSION,
            **kwargs,
        }
        fields_to_bind.update(
            {"correlationId": self.correlation_id}
        ) if self.correlation_id else None

        self.log = self.log.bind(**fields_to_bind)
        return self.log

    @property
    def response_headers(self):
        """
        Generates standard HTTP response headers.
        """
        return {
            CORRELATION_ID_HEADER_KEY: self.correlation_id,
            "x-aws-region": Env.AWS_REGION,
            "x-api-version": self.api_version,
            "Cache-Control": "public, max-age=3600, s-maxage=3600",
            "Content-Security-Policy": "default-src 'none'",
            "X-Frame-Options": "deny",
            "X-Content-Type-Options": "nosniff",
        }


class ProducerLambda(LambdaBase, LambdaMixin):
    """
    Base class for queue producer lambda handlers.
    """

    def __init__(self, payload_type=None, **kwargs):
        super().__init__(**kwargs)
        self.request_api_version = None
        self.key_data = None
        self.payload_type = payload_type
        self.path_params = None
        self.baggage = None

    @staticmethod
    def is_handler(func):
        """
        Producer handler decorator. Performs queue producer-specific pre-initialization.
        :param func: Function to decorate
        :return: Return value of decorated function
        """

        @wraps(func)
        def wrapper(self, event, context):
            self.set_common_attributes(event)
            self.init_logger(context)
            self.extract_key_data()

            if (
                self.request_headers.get(settings.HEALTHCHECK_HEADER_FIELD)
                == settings.HEALTHCHECK_HEADER_VALUE
            ):
                return {
                    "statusCode": HTTPStatus.CREATED,
                    "body": json.dumps("Operational"),
                }
            return func(self, event, context)

        return wrapper

    def handle(self, event, context):
        super().handle(event, context)

    def init_logger(self, context, **kwargs):
        """
        Initialize logger by binding keys used by all producer handlers. Calls init_logger in the parent
        class to simply add the keys and combine them with any keys added by the parent.

        :param context: A LambdaContext instance passed to the lambda function.
        :param kwargs: Any key-value pair that should be bound to the logger.
        :return: A logger instance
        """
        self.log = super().init_logger(context=context, payloadType=self.payload_type)

        return self.log

    # TODO: tech-debt move this to base class for API gateway events and make another base class for SQS event
    def set_common_attributes(self, event: dict):
        """
        Extract generic common attributes from an API Gateway event object and set corresponding instance variables
        :param event: An API Gateway event object
        :return: None
        """
        self.body = event.get("body", "{}")
        self.request_headers = event.get("headers") or {}
        self.lowercase_headers = {
            key.lower(): value for key, value in self.request_headers.items()
        }
        self.correlation_id = self.lowercase_headers.get(
            CORRELATION_ID_HEADER_KEY.lower()
        ) or str(uuid())
        self.baggage = self.lowercase_headers.get("baggage")
        self.request_api_version = event.get("path")[2:3] if event.get("path") else None
        self.path_params = event.get("pathParameters") or {}

    def extract_key_data(self):
        """
        Extract common key data if present in headers and store them in db with pre-defined names
        :return: set key_data with dict of records
        """
        key_data_mapping = KEY_DATA_MAPPING.keys()
        self.key_data = {
            KEY_DATA_MAPPING[key]: value
            for key, value in self.request_headers.items()
            if key in key_data_mapping and KEY_DATA_MAPPING[key]
        }

    @staticmethod
    def catch_exceptions(func):
        """
        Decorator for queue producer handlers. Catches all expected and unexpected exceptions, performs necessary
        logging and sends messages to DealDataDLQ when needed.
        """

        @wraps(func)
        def wrapper(self, event, context):

            try:
                return func(self, event, context)

            except json.JSONDecodeError as error:
                self.log.exception(
                    ErrorMsgs.invalid_json_payload,
                    _event=EventsEnum.app_parsing_failed,
                    requestPayload=self.body,
                    statusCode=HTTPStatus.BAD_REQUEST,
                )

                return_body = self.generate_error_response_body(error)
                return {
                    "statusCode": HTTPStatus.BAD_REQUEST,
                    "body": json.dumps(return_body),
                    "headers": self.response_headers,
                }

            except exceptions.BadRequestError as error:
                self.log.warning(
                    ErrorMsgs.error_processing_request,
                    _event=EventsEnum.app_processing_failed,
                    errorMessage=str(error),
                    statusCode=HTTPStatus.BAD_REQUEST,
                )

                if event.get("new_error_message"):
                    return_body = eval(str(error))
                else:
                    return_body = self.generate_error_response_body(error)
                return {
                    "statusCode": HTTPStatus.BAD_REQUEST,
                    "body": json.dumps(return_body),
                    "headers": self.response_headers,
                }

            except Exception as error:
                self.log.exception(
                    ErrorMsgs.error_processing_request,
                    _event=EventsEnum.app_processing_failed,
                    requestPayload=self.body,
                    statusCode=HTTPStatus.INTERNAL_SERVER_ERROR,
                )

                return_body = self.generate_error_response_body(error)
                return {
                    "statusCode": HTTPStatus.INTERNAL_SERVER_ERROR,
                    "body": json.dumps(return_body),
                    "headers": self.response_headers,
                }

        return wrapper


class GetLambda(LambdaBase, LambdaMixin):
    """
    Base class for get lambda handlers.
    """

    def __init__(self, operation=None, **kwargs):
        super().__init__(**kwargs)
        self.query_string_params = None
        self.request_api_version = None
        self.path_params = None
        self.operation = operation

    @staticmethod
    def is_handler(func):
        """
        Get handler decorator. Performs get lambda pre-initialization.
        :param func: Function to decorate
        :return: Return value of decorated function
        """

        @wraps(func)
        def wrapper(self, event, context):
            self.set_common_attributes(event)
            self.init_logger(context)

            if (
                self.request_headers.get(settings.HEALTHCHECK_HEADER_FIELD)
                == settings.HEALTHCHECK_HEADER_VALUE
            ):
                return {
                    "statusCode": HTTPStatus.CREATED,
                    "body": json.dumps("Operational"),
                }
            return func(self, event, context)

        return wrapper

    # TODO: tech-debt move this to base class for API gateway events and make another base class for SQS event
    def set_common_attributes(self, event: dict):
        """
        Extract generic common attributes from an API Gateway event object and set corresponding instance variables
        :param event: An API Gateway event object
        :return: None
        """
        self.body = event.get("body", "{}")
        self.request_headers = event.get("headers") or {}
        self.lowercase_headers = {
            key.lower(): value for key, value in self.request_headers.items()
        }
        self.correlation_id = self.lowercase_headers.get(
            CORRELATION_ID_HEADER_KEY.lower()
        ) or str(uuid())
        self.request_api_version = event.get("path")[2:3]
        self.query_string_params = event.get("queryStringParameters") or {}
        self.path_params = event.get("pathParameters") or {}

    @staticmethod
    def catch_exceptions(func):
        """
        Decorator for get lambda handlers. Catches all expected and unexpected exceptions, performs necessary
        logging return error and status code.
        """

        @wraps(func)
        def wrapper(self, event, context):

            try:

                return func(self, event, context)

            except exceptions.BadRequestError as error:
                self.log.warning(str(error), _event=EventsEnum.deal_get_bad_request)
                if event.get("new_error_message"):
                    return_body = eval(str(error))
                else:
                    return_body = self.generate_error_response_body(error)
                return {
                    "statusCode": HTTPStatus.BAD_REQUEST,
                    "body": json.dumps(return_body),
                    "headers": self.response_headers,
                }

            except Exception as error:
                self.log.exception(str(error), _event=EventsEnum.deal_get_failed)
                return_body = self.generate_error_response_body(error)
                return {
                    "statusCode": HTTPStatus.INTERNAL_SERVER_ERROR,
                    "body": json.dumps(return_body),
                    "headers": self.response_headers,
                }

        return wrapper
