# -*- coding: utf-8 -*-
import copy
import functools
import json
import numbers
import re
import time
from datetime import datetime
from decimal import Decimal
from http import HTTPStatus
from uuid import uuid4 as uuid

import boto3
import dr_utils
import ulid
import utils.schema
from botocore.exceptions import ClientError
from common import settings as common_settings
from common.lambda_base import LambdaBase
from common.mixins import LambdaMixin
from common.router import route
from common.settings import (
    CORRELATION_ID_HEADER_KEY,
    MAX_RETRY_ATTEMPTS,
    PROTECTED_KEY_NAME,
    RETRY_DELAY_TIME,
    DealComponent as dc,
    Env,
    ErrorMsgs,
    PayloadType as pt,
    SchemaType as st,
)
from key_data.mapper import transform_key_data_records
from schemas.v1.KEY_DATA_V2 import EXCLUDED_KEY_DATA_FIELDS_FROM_DEAL_RECORDS
from stringcase import camelcase
from utils import EventsEnum, common as common_utils, db_helper, logger
from utils.common import (
    DealDataParameters,
    SingleTTL,
    add_ttl,
    convert_empty_strings_to_none,
    remove_root_none_nodes,
)
from utils.db_helper import pre_process_data_for_post
from utils.exceptions import DynamoDBException, RoutingError
from utils.schema import generate_schema_components


class ConsumerLambda(LambdaBase, LambdaMixin):
    # TODO: tech-debt Move this class to a separate module
    def __init__(self):
        super().__init__()
        self.sqs_msg = None
        self.msg_attrs = None
        self.deal_ref_id = None
        self.correlation_id = None
        self.payload_type = None
        self.cb_pull_id = None
        self.deal_ttl = None

    @staticmethod
    def extract_msg_attrs(event: dict):
        """
        Takes all Message Attributes from an SQS event with a single message and creates an object based on those
        attributes. The object is returned to the caller.

        :param event: An AWS SQS event dictionary
        :return: A custom object with SQS message attributes as the object attributes.
        """

        class MessageAttributes:
            def __init__(self, **kwargs):
                for name, val in kwargs.items():
                    setattr(self, name, val)

            def __getattr__(self, name):
                return None

        message = next(iter(event.get("Records")), {}) or {}
        msg_attrs = message.get("messageAttributes", {})
        msg_attrs = {k: v.get("stringValue") for k, v in msg_attrs.items()}

        return MessageAttributes(**msg_attrs)

    @staticmethod
    def is_handler(func):
        """
        Overrides the default event handler with an implementation specific for SQS events.

        :param func: Function to wrap
        :return: The return value of func()
        """

        @functools.wraps(func)
        def wrapper(self, event, context):
            self.sqs_msg = next(iter(event.get("Records")), {}) or {}
            self.msg_attrs = ConsumerLambda.extract_msg_attrs(event)

            if not self.msg_attrs.correlationId:
                self.msg_attrs.correlationId = str(uuid())

            try:
                self.msg_attrs.dealTTL = int(self.msg_attrs.dealTTL)
            except (ValueError, TypeError):
                self.msg_attrs.dealTTL = SingleTTL().general_ttl()

            self.set_common_attributes()

            self.init_logger(
                context,
                **common_utils.change_dict_naming(self.msg_attrs.__dict__, camelcase),
            )
            return func(self, event, context)

        return wrapper

    def set_common_attributes(self):
        """
        Extract generic common attributes for consumer Lambda from an API Gateway event object and set corresponding
        instance variables
        :return: None
        """
        self.body = self.sqs_msg.get("body")
        self.deal_ref_id = self.msg_attrs.dealRefId
        self.correlation_id = self.msg_attrs.correlationId
        self.payload_type = self.msg_attrs.payloadType
        self.cb_pull_id = self.msg_attrs.cbPullId
        self.deal_ttl = self.msg_attrs.dealTTL

    @staticmethod
    def catch_exceptions(func):
        """
        Decorator for consumer error handling. Catches all expected and unexpected exceptions, performs necessary
        logging, perform retry logic for necessary errors and sends messages to DealDataDLQ when all retries are
        exhausted.

        :param func: Function to wrap
        :return: The return value of func()
        """

        @functools.wraps(func)
        def wrapper(self, event, context):
            try:
                return func(self, event, context)
            except dr_utils.exceptions.NoQueueFound as error:
                self.log.warning(str(error))
                return {
                    "statusCode": HTTPStatus.BAD_REQUEST,
                    "body": json.dumps({"error": str(error)}),
                }
            except RoutingError as error:
                message = f"Error routing data for payload type {self.payload_type}"
                return self.retry_or_fail(
                    error=str(error),
                    event=event,
                    context=context,
                    error_type=EventsEnum.app_routing_failed,
                    body=self.body,
                    message=message,
                    no_retry=True,
                )
            except json.JSONDecodeError as error:
                message = f"Error decoding JSON application for payload type {self.payload_type}"
                return self.retry_or_fail(
                    error=error,
                    event=event,
                    context=context,
                    error_type=EventsEnum.app_parsing_failed,
                    body=self.body,
                    message=message,
                )
            except DynamoDBException as error:
                message = f"Error processing a transaction to dynamoDB for payload type {self.payload_type}"
                return self.retry_or_fail(
                    error=error,
                    event=event,
                    context=context,
                    error_type=EventsEnum.app_parsing_failed,
                    status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
                    body=self.body,
                    message=message,
                )

            except Exception as error:
                # We don't update the status of the deal if it fails to be persisted.
                # The method is configured with a DeadLetterQueue and no retries, so exceptions raised
                # here will cause the message to be sent directly to the DLQ.
                message = f"Error performing operation on deal data for payload type {self.payload_type}"
                return self.retry_or_fail(
                    error=error,
                    event=event,
                    context=context,
                    error_type=EventsEnum.app_persisting_failed,
                    body=self.body,
                    status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
                    message=message,
                    no_retry=True,
                )

        return wrapper


class DealConsumerLambda(ConsumerLambda, LambdaMixin):
    def __init__(self):
        super().__init__()
        #  TODO: tech-debt We should reuse DynamoDB instances, move this to a class-level attribute.
        self.dynamodb = boto3.resource("dynamodb", region_name=Env.AWS_REGION)
        self.deal_ref_id = None
        self.correlation_id = None
        self.payload_type = None
        self.body = None
        self.retry_count = 0
        self.db_name = DealDataParameters().db_name

    def drop_empty_key_data_fields(self, data):
        schema_type = st.get_schema_name("KEY_DATA_POST")
        key_data_schema = utils.schema.get_schema(self.api_version, schema_type)
        for key_data_field in key_data_schema:
            if key_data_field in data and not data[key_data_field]:
                data.pop(key_data_field)
        return data

    @ConsumerLambda.catch_exceptions
    @ConsumerLambda.is_handler
    def handle(self, event: dict, context: dict):
        """
        Handles messages from DealDataQueue. Persists or updates the given deal data in dynamoDb and route data to SQS
        based on payload type.

        :param event: An SQS event object
        :param context: AWS Lambda Context Object
        :return: JSON with status code and body
        """
        self.retry_count = event.get("retry_count", self.retry_count)
        self.log.info(f"Processing message from queue {Env.DEAL_DATA_QUEUE}")

        if not self.deal_ref_id:
            raise Exception("dealRefId is None or not present.")

        route_body = copy.deepcopy(self.body)

        self.body = (
            json.loads(self.body, parse_float=Decimal) if self.body else self.body
        )

        if not self.body:
            raise Exception(ErrorMsgs.missing_body_aws_event)

        # Removing correlationId from body as to some APIs adds it remove the limitation of sending multiple requests
        # within 5min
        self.body.pop(CORRELATION_ID_HEADER_KEY, "")

        # TODO: Remove this once status queue is removed.
        # Creating new object here as dealRefId is fetched from body at the time of deal status.
        process_body = copy.deepcopy(self.body)
        baggage = process_body.pop("baggage", "")
        self.log.bind(baggage=baggage)

        if self.payload_type in (
            pt.CREDIT_APP_POST,
            pt.LEAD_POST,
            pt.CREDIT_BUREAU_PULL,
            pt.CREDIT_BUREAU_RESPONSE,
            pt.KEY_DATA_POST,
        ):
            self.log.info("Processing persistence for POST operation")

            # logic to store credit apps, leads, or credit bureau into database and return response

            self.store_to_database(process_body, self.payload_type)

        elif self.payload_type in [pt.CREDIT_BUREAU_PULL_DEAL_UPDATE]:
            self.log.info(
                "Processing persistence for Credit Bureau POST with dealRefId"
            )
            self.credit_bureau_deal_update(process_body)

            self.log.info(
                "Credit bureau POST with dealRefId information persisted to database"
            )

        elif self.payload_type in (
            pt.LEAD_PATCH,
            pt.LEAD_UPDATE,
            pt.CREDIT_APP_PATCH,
            pt.CREDIT_APP_UPDATE,
            pt.DEAL_UPDATE,
            pt.CREDIT_APP_LENDER_POST,
            pt.KEY_DATA_UPDATE,
            pt.KEY_DATA_UPDATE_V2,
            pt.CONTRACT_POST,
            pt.CONTRACT_UPDATE,
            pt.VERIFY_CONTRACT_POST,
            pt.VERIFY_CONTRACT_POST_V2,
            pt.SIGN_CONTRACT_POST,
            pt.CONTRACT_CANCEL_POST,
            pt.CONTRACT_CANCEL_POST_V2,
            pt.CONTRACT_DEAL_STATUS_POST,
            pt.CONTRACT_POST_V2,
            pt.SIGN_CONTRACT_POST_V2,
            pt.CREDIT_APP_PUT,
        ):
            self.log.info(
                "Processing persistence of CA/LEAD for PATCH/UPDATE/PUT and CON/VERIFY_CON/SIGN_CON/DEAL_STATUS_CON for POST operation"
            )

            # logic to store new or update current credit apps, leads or contract into database and return response
            self.deal_records_update(process_body)

        if self.payload_type in (
            pt.CREDIT_APP_POST,
            pt.CREDIT_APP_PATCH,
            pt.CREDIT_APP_LENDER_POST,
            pt.DEAL_UPDATE,
            pt.CONTRACT_POST,
            pt.CONTRACT_UPDATE,
            pt.VERIFY_CONTRACT_POST,
            pt.VERIFY_CONTRACT_POST_V2,
            pt.SIGN_CONTRACT_POST,
            pt.CONTRACT_CANCEL_POST,
            pt.CONTRACT_CANCEL_POST_V2,
            pt.CONTRACT_DEAL_STATUS_POST,
            pt.CONTRACT_POST_V2,
            pt.SIGN_CONTRACT_POST_V2,
            pt.CREDIT_APP_PUT,
        ):
            # Transform lenderList from unchanged deal_data and re-insert to deal_data
            prep_list = self.prepare_deal_data_for_routing(self.body)
            # route application to appropriate queue
            for item in prep_list or [route_body]:
                route(
                    body=item,
                    correlation_id=self.correlation_id,
                    payload_type=self.payload_type,
                    deal_ref_id=self.deal_ref_id,
                )

        return {
            "statusCode": HTTPStatus.CREATED,
            "body": "Queue message processed successfully",
        }

    def prepare_deal_data_for_routing(self, payload: dict) -> list:
        """
        Generate a credit_app per lender from the original lenderList in deal_data payload.
        """
        payloads_list = []
        if self.payload_type == pt.CREDIT_APP_LENDER_POST:
            tmp_payload = copy.deepcopy(payload)
            lender_list = tmp_payload.pop("lenderList")

            for lender in lender_list:
                payloads_list.append(
                    json.dumps(
                        {**tmp_payload, "lenderList": [lender]},
                        cls=dr_utils.DecimalEncoder,
                    )
                )

        return payloads_list

    @staticmethod
    def transform_lender_list_payload(payload: dict):
        """
        Transform lenderList data by extracting and transforming each item's key in
         the dictionary with lenderId as part of the key; this data will be saved to
         DynamoDb; ej.
            {
                'lenderList.BOA': {'lenderId': 'BOA', 'lenderName': 'Bank of America'},
                'lenderList.CMB': {'lenderId': 'CMB', 'lenderName': 'Chase Bank'},
                'lenderList.DTL': {'lenderId': 'DTL', 'lenderName': 'DTL'}
            }
        """
        if not payload.get("lenderList"):
            return payload

        lender_list = payload.pop("lenderList")
        for lender in lender_list:
            payload[f"lenderList.{lender.get('lenderId')}"] = lender
        return payload

    def put_dynamodb_records(self, data: dict, schema: dict):
        """
        Tries to put records in dynamodb if doesn't already exist and will pop that element from dict
        payload on a successful write. Used only to for Lead and CreditApp records.

        :param data: data extracted from event handler
        :param schema: schema based on deal object https://swaggerhub.np.aws.dealertrack.com/apis/COX-DRS/deals/1.0.0d#/
        :return: data object with popped out successful keys and failed_items dict for any exceptions other
        than ConditionalCheckFailedException
        """

        table = self.dynamodb.Table(self.db_name)
        failed_items = {}

        schema_components = generate_schema_components(schema, data)

        deal_put_data = copy.deepcopy(data)

        deal_put_data = pre_process_data_for_post(schema, deal_put_data)

        records = generate_records(deal_put_data)

        current_time = datetime.isoformat(datetime.utcnow())

        for record in records:
            deal_component = record.get("dealComponent")
            deal_component_parts = []
            if "REF_IDS" in deal_component:
                key_name = deal_component
            else:
                deal_component_parts = str(deal_component).split(".")
                key_name = schema_components.get(deal_component_parts[1])

            record.update(
                {
                    "dealRefId": self.deal_ref_id,
                    "createdTimestamp": current_time,
                    "updatedTimestamp": current_time,
                    # Any new Lead or CreditApp records use the existing TTL from the Deal
                    "ttl": self.deal_ttl,
                }
            )

            try:
                table.put_item(
                    Item=record,
                    ConditionExpression="attribute_not_exists(dealRefId) AND attribute_not_exists(dealComponent)",
                )
            except ClientError as e:
                if e.response["Error"]["Code"] != "ConditionalCheckFailedException":
                    logger.exception(
                        f"Application failed to perform PUT operation with error: {e}",
                        aws_event=EventsEnum.app_update_processing_failed,
                    )

                    if PROTECTED_KEY_NAME.upper() in deal_component_parts:
                        failed_items.update(
                            {
                                key_name: {
                                    PROTECTED_KEY_NAME: data.get(key_name)[
                                        PROTECTED_KEY_NAME
                                    ]
                                }
                            }
                        )
                    else:
                        failed_items.update({key_name: data.get(key_name)})
            except Exception as e:
                logger.exception(
                    f"Exception: Application failed to perform PUT operation with error: {e}",
                    aws_event=EventsEnum.app_update_processing_failed,
                )
                raise DynamoDBException(str(e))
            else:
                if PROTECTED_KEY_NAME.upper() in deal_component_parts:
                    data.get(key_name, {}).pop(PROTECTED_KEY_NAME, None)
                    schema.get(key_name, {}).pop(PROTECTED_KEY_NAME, None)
                else:
                    data.pop(key_name, None)
                    schema.pop(key_name, None)

        return data, failed_items

    def deal_records_update(self, body_dict: dict):
        """
        Method to update deal information, including protected information for a customer
        :param body_dict: data extracted from event handler
        :return: JSON with description and dealRefId
        """
        # Remove ref ids that need not be stored in Key Data as part of deal records update and will be stored
        # as part of respective bridges via Key Data patch call.
        if self.payload_type in [
            pt.CONTRACT_POST_V2,
            pt.CREDIT_APP_PATCH,
        ]:
            for key in EXCLUDED_KEY_DATA_FIELDS_FROM_DEAL_RECORDS:
                body_dict.pop(key, None)

        body_dict = self.transform_lender_list_payload(body_dict)
        if self.payload_type not in [pt.KEY_DATA_UPDATE_V2]:
            body_dict = transform_key_data_records(body_dict, self.payload_type)

        # Remove dealRefId because we can't update the partition key
        body_dict.pop("dealRefId", None)

        # Drop key data fields with empty value
        new_body_dict = self.drop_empty_key_data_fields(body_dict)

        schema_type = st.get_schema_name(self.payload_type)
        schema = utils.schema.get_schema(self.api_version, schema_type, new_body_dict)

        # convert empty string to None because dynamodb doesn't accept empty strings
        new_body_dict = convert_empty_strings_to_none(new_body_dict)

        # delete nodes based on if root level {k: None}
        new_body_dict, failed_items = delete_dynamodb_records(
            new_body_dict, self.deal_ref_id, schema, self.db_name
        )
        self.log.info("Deleted root level None objects from database")

        # put nodes based on if root level {k: {some value}} and doesn't already exist in dynamoDB
        new_body_dict, failed_items = self.put_dynamodb_records(new_body_dict, schema)
        self.log.info("Added new objects in database")

        # pre process the body for list values for root nodes and skip targetPlatforms
        new_body_dict = pre_process_data_for_update(schema, new_body_dict)

        new_body_dict = common_utils.remove_empty_nodes(new_body_dict)
        self.log.info("Removed empty json objects from body")

        # generate dynamodb update item query parameters
        (
            update_expressions,
            attr_names,
            attr_values,
            protected_info,
        ) = generate_update_expression_parameters(new_body_dict)
        # check if there are any protected nodes, get the existing nodes, decrypt and update with updated nodes
        if protected_info:
            (
                update_expressions,
                attr_names,
                attr_values,
            ) = db_helper.update_protected_information(
                update_expressions,
                attr_names,
                attr_values,
                protected_info,
                self.deal_ref_id,
                self.db_name,
            )
        self.log.info("Generated update expressions for UPDATE")
        # add updated timestamp for update_expressions
        update_expressions, attr_names, attr_values = db_helper.add_updated_timestamp(
            update_expressions, attr_names, attr_values
        )

        # generate records from update item query parameters and update them in DB
        db_helper.update_deal_records(
            update_expressions, attr_names, attr_values, self.deal_ref_id, self.db_name
        )
        self.log.info("Updated fields in database")

        if failed_items:
            self.log.info(
                "Application didn't update to database completely",
                failed_items=failed_items,
            )
            dr_utils.send_payload_to_queue(
                queue=Env.DEAL_DATA_DLQ,
                payload=failed_items,
                region=Env.AWS_REGION,
                correlation_id=self.correlation_id,
                deal_ref_id=self.deal_ref_id,
                msg_group_id=self.deal_ref_id,
            )

        self.log.info("Application updated in database")

    def credit_bureau_deal_update(self, data: dict):
        """
        This function separates the reports from applicant or coapplicant, send the app/coapp to the
        update function and send the reports to the cb post function so that proper information can be
        updated/stored in the database.

        :param data: The deserialized payload for the request
        :return: None
        """
        # TODO: tech-debt Context-specific methods should be defined in their own mixin classes to keep code modular.
        # Pop out the reports
        data, reports_nodes = pop_reports(data)
        reports_nodes["dealRefId"] = self.deal_ref_id
        # Persist payload without reports in db via update function
        self.deal_records_update(data)
        # Persist credit_bureau_component in db
        records = self.credit_bureau_records(reports_nodes)
        db_helper.persist_deal_records(records, self.deal_ref_id, self.db_name)

    def credit_bureau_records(self, reports_nodes: dict):
        """
        This function takes in the payload and credit bureau id (given in header) and extracts the
        record information from the payload and creates deal components, so that credit bureau
        information can properly be stored in the database.

        :param reports_nodes: The payload needed to extract applicant, coApplicant
        credit bureau information
        :return: records: An array which contains dealComponent and CB info for applicant/coApplicant
        """
        # TODO: tech-debt Context-specific methods should be defined in their own mixin classes to keep code modular.
        records = []
        for item in common_settings.CREDIT_BUREAU_COMPONENT:
            if (
                item in reports_nodes
                and common_settings.CREDIT_BUREAU_REPORT_KEY in reports_nodes.get(item)
            ):
                app_reports = reports_nodes.get(item)
                for report in app_reports.pop("reports", []):
                    credit_bureau_component = dc().get_credit_bureau_component(
                        self.payload_type
                    )
                    report["dealComponent"] = credit_bureau_component.format(
                        provider=report.get("provider"),
                        report_type=report.get("type"),
                        cust_type=item,
                        cb_pull_id=self.cb_pull_id,
                    ).upper()
                    report["creditBureauRefId"] = self.cb_pull_id
                    report = add_ttl(
                        report, common_settings.RetentionPeriod.credit_bureau
                    )
                    records.append(report)

                    if report.get("ttl") > self.deal_ttl:
                        report["ttl"] = self.deal_ttl

        return records

    def store_to_database(self, deal_data: dict, payload_type: str = None):
        """
        Stores deal data components(CA, CB, Lead) into dynamoDb
        :param unencrypted_body: data extracted from event handler
        :return: JSON with description and dealRefId
        """

        # Remove ref ids that need not be stored in Key Data as part of deal records post and will be stored
        # as part of respective bridges via Key Data patch call.
        if self.payload_type in [pt.CREDIT_APP_POST]:
            for key in EXCLUDED_KEY_DATA_FIELDS_FROM_DEAL_RECORDS:
                deal_data.pop(key, None)

        deal_data = self.transform_lender_list_payload(deal_data)
        deal_data = transform_key_data_records(deal_data, self.payload_type)
        deal_data = remove_root_none_nodes(deal_data)

        # TODO: tech-debt This 2-step process can be rolled into one
        schema_type = st.get_schema_name(self.payload_type)
        schema = utils.schema.get_schema(self.api_version, schema_type, deal_data)

        # pre process data for schema validation
        deal_app = pre_process_data_for_post(schema, deal_data)
        self.log.info("Pre-processed data for schema validation")

        # convert empty string to None because dynamodb doesn't accept empty strings
        deal_app = convert_empty_strings_to_none(deal_app)

        # List to persist the dynamodb records in batch mode
        records = []

        # If payload type is CREDIT BUREAU PULL, add CB deal components
        if payload_type == pt.CREDIT_BUREAU_PULL:
            records.extend(self.credit_bureau_records(deal_app))

        # If payload type is CREDIT BUREAU RESPONSE, add CB response payload and return without saving anything else
        elif payload_type == pt.CREDIT_BUREAU_RESPONSE:
            records.extend(self.credit_bureau_records(deal_app))

            # Persist records into dynamodb deals table in batch mode
            db_helper.persist_deal_records(records, self.deal_ref_id, self.db_name)
            self.log.info("Credit bureau response persisted to database")

            return {
                "description": "CB Response stored successfully.",
                "dealRefId": self.deal_ref_id,
            }

        records.extend(generate_records(deal_app))

        # Persist records into dynamodb deals table in batch mode
        db_helper.persist_deal_records(records, self.deal_ref_id, self.db_name)
        self.log.info("Application persisted to database")

        return {
            "description": "Item stored successfully.",
            "dealRefId": self.deal_ref_id,
        }

    def retry_or_fail(
        self,
        error,
        event,
        context,
        error_type,
        body,
        message,
        status_code=HTTPStatus.BAD_REQUEST,
        no_retry=False,
    ):
        """
        This method will either put the original event to the context or into the DLQ based on retry count. If the given
        retry count is more than maximum allowed attempts, it will put the message into the DLQ.
        :param error: string value of the error object
        :param event: original event body sent by SQS
        :param body: deal data payload present in the event payload
        :param context: original context object sent by SQS
        :param error_type: ENUM value of the error type based on error
        :param message: string value suggesting what kind of error happened
        :param no_retry: bool value to dictate whether to retry or not
        :return: either puts the message to DLQ or returns the original handler
        """
        if self.retry_count >= MAX_RETRY_ATTEMPTS or no_retry:
            error_message = ErrorMsgs.sending_msg_dlq.format(
                payload_type=self.payload_type,
                queue=Env.DEAL_DATA_DLQ,
                error=error,
            )
            logger.exception(
                message,
                requestPayload=body,
                _event=error_type,
                retryCount=self.retry_count,
                errorMessage=error_message,
            )

            raise Exception(str(error))
        else:
            message = ErrorMsgs.retry_failed_apps.format(
                payload_type=self.payload_type, retry_count=self.retry_count
            )
            logger.warning(
                message,
                requestPayload=body,
                _event=error_type,
                retryCount=self.retry_count,
            )
            # Since we are using same lambda instance to handle retry logic, we are keeping sleep to provide a delay to
            # clear any db errors, connection errors or any other hiccups that might help to retry failed apps
            event["retry_count"] = self.retry_count + 1
            sleep_time = RETRY_DELAY_TIME.get(event["retry_count"])
            time.sleep(sleep_time)

            return DealConsumerLambda().handle(event, context)


handler = DealConsumerLambda.get_handler()  # input values for args and/or kwargs


def pop_reports(body: dict):
    """
    This function pops reports from the body payload and creates a separate dict for
    reports and returns it along with the body (which no longer contains reports)
    :param body: They payload sent to the credit bureau endpoint
    :return: body: The same payload without reports for applicant or coapplicant
    :return: credit_bureau_component: The reports dict popped from payload
    """

    reports = {}
    # applicant, coApplicant, or both
    for item in (i for i in common_settings.CREDIT_BUREAU_COMPONENT if i in body):
        reports[item] = {}
        reports[item]["reports"] = body[item].pop("reports")

    return body, reports


def delete_dynamodb_records(data: dict, deal_ref_id: str, schema: dict, db_name: str):
    """
    Tries to delete records in dynamodb if payload root level key is none, if it already exists in dynamodb.
    Will pop that element from dict payload on a successful delete.
    :param data: data extracted from event handler
    :param deal_ref_id:  pk for the deal table
    :param schema: schema based on deal object https://swaggerhub.np.aws.dealertrack.com/apis/COX-DRS/deals/1.0.0d#/
    :param db_name: DynamoDB Name
    :return: data object with popped out successful delete keys and failed_items dict for any exceptions other
    than ConditionalCheckFailedException
    """
    dynamodb = boto3.resource("dynamodb", region_name=Env.AWS_REGION)
    table = dynamodb.Table(db_name)
    failed_items = {}
    keys = get_keys_to_delete(schema, data)

    for key in keys:
        try:
            deal_component = f"DTC.{key.upper()}"
            table.delete_item(
                Key={"dealRefId": deal_ref_id, "dealComponent": deal_component}
            )
        except ClientError as e:
            if (
                e.response.get("Error", {}).get("Code")
                != "ConditionalCheckFailedException"
            ):
                logger.exception(
                    f"Application failed to perform DELETE operation for root level None keys with error: {e}",
                    aws_event=EventsEnum.app_update_processing_failed,
                )

                if key.endswith(f".{PROTECTED_KEY_NAME}"):
                    node_key = key.split(".")[0]  # "applicant", "coApplicant", etc
                    node_value = data.get(node_key) or {}
                    protected_value = node_value.get(PROTECTED_KEY_NAME)

                    item = {node_key: {PROTECTED_KEY_NAME: protected_value}}
                    failed_items.update(item)
                else:
                    failed_items.update({key: data[key]})
        except Exception as e:
            logger.exception(
                f"Exception: Application failed to perform DELETE operation for root level None keys with error: {e}",
                aws_event=EventsEnum.app_update_processing_failed,
            )
            raise DynamoDBException(str(e))
        else:
            data.get(key.split(".")[0], {}).pop(
                PROTECTED_KEY_NAME, None
            ) if PROTECTED_KEY_NAME in key else data.pop(key, None)
            schema.get(key.split(".")[0], {}).pop(
                PROTECTED_KEY_NAME, None
            ) if PROTECTED_KEY_NAME in key else schema.pop(key, None)

    return data, failed_items


def get_keys_to_delete(schema: dict, data: dict):
    """
    Generates list with keys from data which are defined as list or dictionary in the given schema AND
    have a falsy value in data. For nodes that contain a subitem with key "protected" in the schema,
    an additional key is added to the list representing the expected deal component format "<key_name>.protected"
    so that any protected records in the database also get deleted when the main record becomes a candidate for
    deletion.

    :param schema: schema object corresponding to the data provided
    :param data: deserialized payload
    :return: list of keys to be deleted eg, ['applicant', 'applicant.protected']
    """
    keys = [
        str(key)
        for key in data.keys()
        if isinstance(schema.get(key), (list, dict)) and not data.get(key)
    ]
    protected_keys = [
        f"{key}.{PROTECTED_KEY_NAME}"
        for key, value in data.items()
        if isinstance(schema.get(key), dict)
        and PROTECTED_KEY_NAME in schema.get(key)
        and (not value or not value.get(PROTECTED_KEY_NAME, True))
    ]
    keys.extend(protected_keys)

    return keys


def pre_process_data_for_update(schema: dict, body: dict):
    """
    Pre process update payload put root level list objects into a dict with key as root key name
    example:
    {
        applicant : {},
        extraData: [{"data": "value"}]
    }
    changes to
    {
        applicant : {},
        extraData: {"extraData": [{"data": "value"}]}
    }
    :param schema: schema based on deal object
    :param body: data extracted from event handler
    :return: updated data with pre processing
    """
    for k, v in body.items():
        if (
            isinstance(v, list)
            and str(k) not in common_settings.COMPONENTS_NOT_AS_SEPARATE_RECORDS
        ):
            body[k] = {k: v}

    body = pre_process_data_for_post(schema, body)
    return body


def generate_update_expression_parameters(data: dict):
    """
    Traverses each key inside dict object as go to N level deep to construct boto3 expression parameters
    example:-
        update_expression: SET info.#rating = :r, info.#plot=:p, info.#actors=:a
        attr_names: {dtc_component}: { "#rating": "rating", "#plot": "plot",  "#actors": "actors"}
        attr_values: {dtc_component}: {":p": "value1", ":a": "value2", ":r": "value3"}
        protected: protected fields if any inside each customer/ dtc_component
    :param data: data extracted from event handler
    :return: update_expression, attr_names, attr_values, protected dict objects
    """
    attr_names, attr_values, update_expression, protected = {}, {}, {}, {}

    # generate update expression for deal update
    def generate_expression_parameters(
        data: dict, parent: str = None, root: str = None
    ):
        """
        Logic for traversal based on parent and root node, similar to a binary tree. Each node keeps a track of parent
        node, or root node (self or nested dict key). In case of no root and no parent, dtc_component becomes "DTC.DEAL"

        For all protected nodes inside k(dict element), it skips and adds to a protected dict. Update expression for
        protected nodes are created differently because they are stored as a separate row in dynanomodb.
        Example:
        {
            applicant: {
                "firstName": "Arhant",
                "protected": {
                    "ssn": "12345"
                }
            }
        }
        will be stored as:
        {
            "DTC.APPLICANT": {"firstName": "Arhant"},
            "DTC.APPLICANT.PROTECTED": "protected": {"ssn": "12345"}
        }
        :param data: data extracted from event handler after pre processing
        :param parent: parent node for any key in loop
        :param root: root node could be node itself or nodes after 2 level nested structure
        :return:
        """
        if root and "REF_IDS" in root:
            dtc_component = root
        elif root:
            dtc_component = "DTC.{}".format(str(root).upper())
        else:
            dtc_component = "DTC.DEAL"
        attr_names[dtc_component] = attr_names.get(dtc_component) or {}
        attr_values[dtc_component] = attr_values.get(dtc_component) or {}

        for k, v in data.items():
            if k == PROTECTED_KEY_NAME:
                protected[dtc_component] = v
                continue

            elif isinstance(v, dict) and str(k) != PROTECTED_KEY_NAME and v:

                if root and parent:
                    generate_expression_parameters(v, f"{parent}.{k}", root)
                elif root:
                    generate_expression_parameters(v, k, root)
                else:
                    generate_expression_parameters(v, None, k)

            else:
                key = f"{str(parent).replace('.', '_')}_{k}"
                if root and parent:

                    update_expression[dtc_component] = (
                        f"{update_expression[dtc_component]}, {parent}.#{k} = :{key}"
                        if update_expression.get(dtc_component)
                        else f"{parent}.#{k} = :{key}"
                    )

                    attr_values.setdefault(dtc_component, {}).update(
                        db_helper.generate_dynamodb_json_structure(f"{key}", v)
                    )
                else:
                    update_expression[dtc_component] = (
                        f"{update_expression[dtc_component]}, #{k} = :{k}"
                        if update_expression.get(dtc_component)
                        else f"#{k} = :{k}"
                    )

                    attr_values.setdefault(dtc_component, {}).update(
                        db_helper.generate_dynamodb_json_structure(k, v)
                    )
                attr_names.setdefault(dtc_component, {}).update({f"#{k}": f"{k}"})

    generate_expression_parameters(data)
    return update_expression, attr_names, attr_values, protected


def generate_records(body: dict):
    """
    Create each deal component as separate record and add unique id if required
    :param body: complete deal payload like credit app
    :return: list of records
    """
    records = []
    for deal_component in list(body.keys()):
        deal_component_val = body[deal_component]

        if (
            deal_component in common_settings.COMPONENTS_NOT_AS_SEPARATE_RECORDS
            or isinstance(deal_component_val, (str, numbers.Number, bool))
        ):
            continue
        elif isinstance(deal_component_val, dict):
            records.extend(process_record(deal_component_val, deal_component))
        elif isinstance(deal_component_val, list):
            records.extend(process_list_of_records(deal_component_val, deal_component))
        body.pop(deal_component)

    # Everything left in body becomes part of DTC.DEAL row
    body.update({"dealComponent": dc.DTC_DEAL, "dealRecord": True})
    body = add_ttl(body)
    records.append(body)
    records.append(generate_api_version_map())
    return records


def generate_api_version_map():
    """
    Adds another dealComponent called Version in dynamodb based on version file in stack. This version is
    used to compare update request from path parameters and stored value in db to check if correct endpoint version is
    used to perform update on a deal.
    :return: dict object with new deal component
    """
    version = Env.VERSION
    if re.compile(r"v\d\.?\d?\d?\.?\d?\d?").match(version):
        version = version[1:]

    record = {"dealComponent": dc.DTC_VERSION, "apiVersion": version}
    record = add_ttl(record)
    return record


def process_record(record: dict, deal_component: str):
    """
    If deal component has pii, extracts pii record. Add unique id if required.
    :param record: deal component record
    :param deal_component: name of deal component
    :return: list of records
    """
    records = []

    record_id = (
        ulid.new().str
        if deal_component in common_settings.DEAL_COMPONENT_ID_MAPPING
        else None
    )
    pii_record = extract_pii(record, deal_component, record_id)
    records.append(add_ttl(pii_record)) if pii_record else None

    record = add_deal_component(record, deal_component, record_id)
    record = add_ttl(record)
    records.append(record)

    return records


def process_list_of_records(records: list, deal_component: str):
    """
    Creates a record with deal component field with value as list of records
    :param records: deal component list of records
    :param deal_component: name of deal component
    :return: list of records
    """
    res_list = []
    record_id = (
        ulid.new().str
        if deal_component in common_settings.DEAL_COMPONENT_ID_MAPPING
        else None
    )
    record = {deal_component: records}
    record = add_deal_component(record, deal_component, record_id)
    record = add_ttl(record)
    res_list.append(record)
    return res_list


def extract_pii(record: dict, deal_component: str, record_id: str):
    """
    Extracts pii info as separate record
    :param record: deal component record from which pii info need to be extracted
    :param deal_component: deal component name
    :param record_id: unique id of deal component that need to be added in pii record
    :return: record containing pii info and unique id
    """
    rec = {}
    if PROTECTED_KEY_NAME in record:
        if record_id:
            rec.update(
                {common_settings.DEAL_COMPONENT_ID_MAPPING[deal_component]: record_id}
            )

        rec.update(
            {
                "dealComponent": dc.PROTECTED.format(
                    deal_component=deal_component, protected_key_name=PROTECTED_KEY_NAME
                ).upper(),
                PROTECTED_KEY_NAME: record.pop(PROTECTED_KEY_NAME),
            }
        )
    return rec


def add_deal_component(record: dict, deal_component: str, record_id: str = None):
    """
    Add a "dealComponent" key to record.
    :param dict record: A record representing an element from the Deal JSON object. Examples: financesummary, vehicle
    :param string deal_component: type of record
    :param record_id: unique id for particular record
    :return: (dict) record
    """
    if deal_component.startswith("REF_IDS"):
        record.update({"dealComponent": deal_component})
    else:
        record.update({"dealComponent": f"dtc.{deal_component}".upper()})
    if record_id:
        record.update(
            {common_settings.DEAL_COMPONENT_ID_MAPPING[deal_component]: record_id}
        )
    return record
