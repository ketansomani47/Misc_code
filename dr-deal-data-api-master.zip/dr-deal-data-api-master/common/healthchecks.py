# -*- coding: utf-8 -*-
import json
from http import HTTPStatus

import boto3
import requests
from common.settings import (
    HEALTHCHECK_HEADER_FIELD,
    HEALTHCHECK_HEADER_VALUE,
    Env,
)
from utils import logger
from utils.common import DealDataParameters


class HealthCheckRegistry:
    """Service registry for health check that need to verified"""

    QUEUE_LIST = [
        Env.DEAL_DATA_QUEUE,
        Env.DEAL_DATA_DLQ,
        Env.EVENT_QUEUE,
        Env.EVENT_ROUTE_QUEUE,
    ]
    API_LIST = [
        {"route": "deals/HCdealRefId/credit-apps", "method": "post"},
        {"route": "deals/HCdealRefId", "method": "get"},
    ]
    APIG_RESOURCES = (
        "/v1/deals/credit-apps",
        "/v1/deals/{dealRefId}/credit-apps",
        "/v1/deals/{dealRefId}/credit-apps/{creditAppId}",
        "/v1/deals/leads",
        "/v1/deals/{dealRefId}/leads",
        "/v1/deals/{dealRefId}/leads/{leadRefId}",
        "/v1/deals/{dealRefId}",
        "/v1/events",
        "/v1/deals/credit-bureaus",
        "/v1/deals/{dealRefId}/contract",
        "/v1/deals/{dealRefId}/contract/{contractRefId}/verify",
        "/v1/deals/{dealRefId}/contract/{contractRefId}/sign",
        "/v1/deals/{dealRefId}/contract/{contractRefId}/cancel",
        "/v2/deals/{dealRefId}/contract/sign",
        "/v1/deals/{dealRefId}/contract/{contractRefId}/status",
        "/v1/deals/{dealRefId}/partner-dealers/{partnerDealerId}/credit-apps/lenders/{lenderId}/decisions/latest",
        "/v1/deals/{dealRefId}/partner-dealers/{partnerDealerId}/credit-apps/{creditAppId}/lenders/{lenderId}/decisions/program",
        "/v1/deals/{dealRefId}/partner-dealers/{partnerDealerId}/credit-apps/{creditAppId}/lenders/{lenderId}/decisions/latest",
    )

    LAMBDA_LIST = [
        f"dr-deal-data-api-{Env.STAGE}-deal_consumer",
        f"dr-deal-data-api-{Env.STAGE}-event_producer",
        f"dr-deal-data-api-{Env.STAGE}-event_route",
        f"dr-deal-data-api-{Env.STAGE}-dlq_processing",
    ]

    S3_LIST = [Env.SNAPSHOT_BUCKET]

    @property
    def db_list(self):
        return [DealDataParameters().db_name]


def check_status(event, context):
    """
    This function pings the other health checks (which all test
    different components of deal data) and if an error is found, it will note
    which component failed into a dictionary and return a JSON which contains
    the status of all components, and an overall service_status of services
    """
    log = logger.new(
        env=Env.DEPLOY_ENV,
        stage=Env.STAGE,
        version=Env.VERSION,
        functionArn=context.invoked_function_arn,
        apiResource=event["resource"],
        path=event["path"],
    )
    body = {
        "service": Env.SERVICE_NAME,
        "region": Env.AWS_REGION,
        "version": Env.VERSION,
        "service_status": HealthCheck.normalize_status(False),
    }

    try:
        if Env.DEPLOY_STATUS != "Completed":
            body.update({"message": "Stack deployment in progress"})
            return {"statusCode": HTTPStatus.OK, "body": json.dumps(body)}

        health_check = HealthCheck(Env.URL, Env.KEY, Env.API_NAME)
        to_check = [
            {
                "function": health_check.check_queue,
                "resources": HealthCheckRegistry.QUEUE_LIST,
            },
            {
                "function": health_check.check_database,
                "resources": HealthCheckRegistry().db_list,
            },
            {
                "function": health_check.check_api,
                "resources": HealthCheckRegistry.API_LIST,
            },
            {
                "function": health_check.check_lambda,
                "resources": HealthCheckRegistry.LAMBDA_LIST,
            },
            {
                "function": health_check.check_s3,
                "resources": HealthCheckRegistry.S3_LIST,
            },
            {
                "function": health_check.check_apig_resource,
                "resources": HealthCheckRegistry.APIG_RESOURCES,
            },
        ]

        healthchecks = {}
        service_status = True
        for hc in to_check:
            func = hc["function"]
            for res in hc["resources"]:
                if isinstance(res, dict):
                    healthchecks[f"{res['route']} method-{res['method']}"] = func(res)
                    res = f"{res['route']} method-{res['method']}"
                else:
                    healthchecks[str(res)] = func(res)
                service_status = service_status and healthchecks[res]

        body["healthchecks"] = {
            k: health_check.normalize_status(v) for k, v in healthchecks.items()
        }
        body["service_status"] = health_check.normalize_status(service_status)

        return {"statusCode": HTTPStatus.OK, "body": json.dumps(body)}

    except Exception as error:
        log.exception("Resource not found ")
        body["error_message"] = str(error)
        return {
            "statusCode": HTTPStatus.INTERNAL_SERVER_ERROR,
            "body": json.dumps(body),
        }


class HealthCheck(object):
    def __init__(self, url, key, api_name):
        self.url = url
        self.key = key
        self.api_name = api_name
        self.apig_response_resources = None
        self.queue_client = boto3.client("sqs", region_name=Env.AWS_REGION)
        self.database_resource = boto3.resource("dynamodb", region_name=Env.AWS_REGION)
        self.lambda_client = boto3.client("lambda", region_name=Env.AWS_REGION)
        self.s3_bucket_client = boto3.client("s3", region_name=Env.AWS_REGION)
        self.apig_client = boto3.client("apigateway", region_name=Env.AWS_REGION)
        self.log = logger.bind()

    def check_queue(self, queue_name):
        """
        Pings the queue specified by the parameter, if it is down,
        it will raise an Exception and return False, otherwise return
        True to indicate operational queue
        """
        self.log = self.log.bind(resourceUnderTest=queue_name)
        try:
            self.queue_client.get_queue_url(QueueName=queue_name)
        except Exception:
            self.log.exception("Resource not found")
            return False
        return True

    def check_database(self, database_name):
        """
        Pings the database specified by the parameter, checks for a specific database
        entry, if it is found, the database is considered to be up and the calling function
        resumes, otherwise an Exception is raised and False is returned
        """
        self.log = self.log.bind(resourceUnderTest=database_name)
        try:
            table = self.database_resource.Table(database_name)
            component = f"{Env.AWS_REGION} Health Check DB Entry Do Not Delete"
            record = {"dealRefId": "0" * 29, "dealComponent": component}
            response = table.get_item(Key=record)
            if not response.get("Item"):
                raise Exception(f"No record found with dealId: {record['dealRefId']}")
        except Exception:
            self.log.exception("Resource not found")
            return False
        return True

    def check_api(self, endpoint):
        """
        Pings the api endpoint to ensure that it is up and running. In order to prevent
        the record from actually being created, will send some dummy data which will not
        end up in the actual database. Tests that a INTERNAL SERVER ERROR response was returned
        from the dummy payload sent
        :param endpoint: A dictionary of url and key to which requests will be made
        :return: Boolean, whether the ping was successful or not
        """
        self.log = self.log.bind(resourceUnderTest=endpoint)
        try:

            version = Env.VERSION[1]
            endpoint_url = f"https://{self.url}/v{version}/{endpoint['route']}"
            header = {
                "Content-Type": "application/json",
                "x-api-key": self.key,
                "Connection": "close",
                HEALTHCHECK_HEADER_FIELD: HEALTHCHECK_HEADER_VALUE,
            }

            res = getattr(requests, endpoint["method"])(endpoint_url, headers=header)
            if res.status_code != HTTPStatus.CREATED:
                raise Exception(
                    f"Error while trying to connect to API Gateway, Status Code: {res.status_code}"
                )
        except Exception:
            self.log.exception("Resource not found")
            return False
        return True

    def check_lambda(self, function_name):
        """
        Gets event source mapping for lambda and verify if event state is enabled. if event source mapping is empty or
        State is not enabled function raises exception and return False
        :param function_name: name of lambda function
        :return: Boolean value
        """
        self.log = self.log.bind(resourceUnderTest=function_name)
        try:
            response = self.lambda_client.list_event_source_mappings(
                FunctionName=function_name
            )
            event_resource_mapping = response["EventSourceMappings"]
            if not event_resource_mapping:
                raise Exception("No event resource mapping found")
            state = event_resource_mapping[0]["State"]
            if state != "Enabled":
                raise Exception("Event is not Enabled")
        except Exception:
            self.log.exception("Resource not found")
            return False
        return True

    def check_s3(self, bucket_name):
        """
        Pings the s3 bucket specified by the parameter, checks if the bucket exits. if its found
        the s3 bucket is considered to be available and True is returned, otherwise an Exception
        is raised and False is returned.
        """
        self.log = self.log.bind(resourceUnderTest=bucket_name)
        try:
            self.s3_bucket_client.get_bucket_acl(Bucket=bucket_name)
        except Exception:
            self.log.exception("S3 Bucket not found")
            return False
        return True

    def check_apig_resource(self, resource_path):
        """
        This methods check if passed resource name exist
        :param resource_path: name of API Gateway API resource path
        :return: Boolean value
        """
        self.log = self.log.bind(resourceUnderTest=resource_path)
        try:
            self.log.info(
                f"Started Checking API Gateway Resource path existence for {resource_path}"
            )
            if self.apig_response_resources is None:
                api_id = self.get_apig_api_id()
                self.apig_response_resources = self.get_apig_api_resources(api_id)
                self.log.info(
                    f"Completed Fetching API Gateway Resources response for Api Id {api_id}"
                )
            self.log.info(
                f"Completed Checking API Gateway Resource path existence for {resource_path}"
            )

            return resource_path in self.apig_response_resources
        except Exception:
            self.log.exception(
                f"Error occurred while checking API Gateway Resources path existence for {resource_path}"
            )
            return False

    def get_apig_api_id(self):
        """
        Gets the ID of a REST API from api_name by searching the list of REST APIs
        for the current account. Because names need not be unique, this returns only
        the first API with the specified name.
        :return: The ID of the specified API
        """
        try:
            rest_api = None
            self.log.info(
                "Started Fetching API Id based on API name",
                api_name=self.api_name,
            )
            paginator = self.apig_client.get_paginator("get_rest_apis")
            for page in paginator.paginate():
                rest_api = next(
                    (item for item in page["items"] if item["name"] == self.api_name),
                    None,
                )
                if rest_api is not None:
                    break
            api_id = rest_api.get("id")
            self.log.info(
                f"Completed Fetching API Id based on API name {self.api_name}"
            )
            return api_id
        except Exception as error:
            self.log.exception(
                f"Error Occurred while fetch API Id for {self.api_name}.",
                exc_info=error,
            )
            raise

    def get_apig_api_resources(self, api_id):
        """
        This method extracts list of paths based on rest API ID
        :param api_id: Rest API ID
        :return: list of resources path
        """
        try:
            self.log.info(f"Started Fetching API resources based on API Id {api_id}")
            paths = []
            response = self.apig_client.get_resources(restApiId=api_id, limit=500)
            items = response.get("items", [])
            for item in items:
                paths.append(item.get("path"))
            self.log.info(f"Completed Fetching API Resources for API Id {api_id}.")
            return paths
        except Exception:
            self.log.exception(
                f"Error occurred while getting resources for API ID {api_id}."
            )
            raise

    @staticmethod
    def normalize_status(status):
        if status:
            return "Operational"
        return "Down"
