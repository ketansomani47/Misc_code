# -*- coding: utf-8 -*-
import json
from http import HTTPStatus

from common.settings import Env


def get(event, context):
    """
    Api which give info of this micro-service
    :param event: An API Gateway event object (dict)
    :param context: AWS Lambda Context Object (dict)
    :return: Json with status code and body
    """
    body = {
        "service": Env.SERVICE_NAME,
        "region": Env.AWS_REGION,
        "version": Env.VERSION,
    }
    return {"statusCode": HTTPStatus.OK, "body": json.dumps(body)}
