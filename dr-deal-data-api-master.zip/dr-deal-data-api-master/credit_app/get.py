# -*- coding: utf-8 -*-
import json
from http import HTTPStatus

import utils.schema
from boto3.dynamodb.conditions import Key
from common.deal import (
    process_data_for_response_schema,
    process_trade_ins_list,
    remove_empty_data_nodes,
    transform_back_lender_list_payload,
)
from common.lambda_base import GetLambda
from common.settings import Env, ErrorMsgs, InfoMsgs, SchemaType as st
from utils import common, exceptions
from utils.db_helper import DynamoDbHelper


class CreditAppGetLambda(GetLambda):
    def __init__(self, **kwargs):

        super().__init__(**kwargs)
        self.deal_ref_id = None
        self.credit_app_id = None

    @GetLambda.catch_exceptions
    @GetLambda.is_handler
    def get(self, event: dict, context: dict):

        """
        Handles the Credit App Get based on the dealRefId provided.
        It will Get the Credit App data for the latest deal present.
        creditAppId will be used once multiple deals functionality is implemented.

        Endpoint: /deals/{dealRefId}/credit-apps/{creditAppId}/

        This API validates and queries data corresponding to the dealRefId.

        :param dict event: An API Gateway event object
        :param dict context: AWS Lambda Context Object
        :return: JSON with status code and body
        """

        self.deal_ref_id = common.get_path_parameter(event, "dealRefId")
        self.credit_app_id = common.get_path_parameter(event, "creditAppId")

        self.log.bind(
            dealRefId=self.deal_ref_id,
            creditAppId=self.credit_app_id,
            correlation_id=self.correlation_id,
        )

        key_expression = Key("dealRefId").eq(self.deal_ref_id)
        db = DynamoDbHelper(
            region=Env.AWS_REGION, table_name=common.DealDataParameters().db_name
        )
        db_records = db.query_items(key_expression=key_expression)

        if not db_records:
            raise exceptions.BadRequestError(
                ErrorMsgs.missing_deal_from_db.format(deal_ref_id=self.deal_ref_id)
            )

        self.log.info(InfoMsgs.received_data_from_db.format(operation="GET CREDIT APP"))

        schema = utils.schema.get_schema(self.request_api_version, st.CA_GET)

        data = process_data_for_response_schema(db_records, schema, True)
        self.log.info(
            InfoMsgs.payload_transformed_for_version.format(
                version=self.request_api_version
            )
        )

        process_trade_ins_list(data, schema.get("tradeIns")[0])

        # Transform lenders to original property
        response_data = transform_back_lender_list_payload(
            db_records=db_records, payload=data
        )
        self.log.info(InfoMsgs.lenders_transformed_back)
        response_data = remove_empty_data_nodes(response_data)

        return {
            "statusCode": HTTPStatus.OK,
            "body": json.dumps(response_data, cls=common.decimal_decoder()),
            "headers": self.response_headers,
        }


credit_app_get = CreditAppGetLambda.get_handler(handler_func="get")
