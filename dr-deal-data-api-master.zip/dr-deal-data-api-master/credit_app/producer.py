# -*- coding: utf-8 -*-
import json
from http import HTTPStatus

import dr_utils
import ulid
from common.lambda_base import ProducerLambda
from common.settings import (
    CREDIT_APP_ID_HEADER_KEY,
    DEAL_REF_ID_HEADER_KEY,
    DEAL_XG_ID_HEADER_KEY,
    DEAL_XG_VERSION_HEADER_KEY,
    Env,
    ErrorMsgs,
    PayloadType as pt,
    TargetPlatformIds,
)
from common.validators import ExistingDealValidator
from utils import common, exceptions


class CreditAppProducerLambda(ProducerLambda):
    def __init__(self, **kwargs):

        super().__init__(**kwargs)
        self.deal_ref_id = None
        self.credit_app_id = None

    @ProducerLambda.catch_exceptions
    @ProducerLambda.is_handler
    def new_deal_handler(self, event: dict, context: dict):

        """
        Handles the Credit App Post for new Deal endpoint. Creates a new Credit App and a new Deal simultaneously.

        Endpoint: /deals/credit-apps

        This asynchronous API generates new dealRefId and creditAppId submits a message to DealDataQueue, then returns
        these IDs to the client with HTTP status CREATED (201).

        :param dict event: An API Gateway event object
        :param dict context: AWS Lambda Context Object
        :return: JSON with status code and body
        """

        new_deal_ulid = False
        new_ca_ulid = False

        deal_ref_id_header = self.request_headers.get(DEAL_REF_ID_HEADER_KEY)
        credit__app_id_header = self.request_headers.get(CREDIT_APP_ID_HEADER_KEY)
        deal_xg_deal_id = self.request_headers.get(
            DEAL_XG_ID_HEADER_KEY
        ) or self.request_headers.get(DEAL_XG_ID_HEADER_KEY.lower())
        deal_xg_deal_version = self.request_headers.get(
            DEAL_XG_VERSION_HEADER_KEY
        ) or self.request_headers.get(DEAL_XG_VERSION_HEADER_KEY.lower())

        if deal_ref_id_header and deal_ref_id_header.strip():
            self.deal_ref_id = deal_ref_id_header
        else:
            self.deal_ref_id = ulid.new().str
            new_deal_ulid = True

        if credit__app_id_header and credit__app_id_header.strip():
            self.credit_app_id = credit__app_id_header
        else:
            self.credit_app_id = ulid.new().str
            new_ca_ulid = True

        common.verify_ulid(self.deal_ref_id) if not new_deal_ulid else None
        common.verify_ulid(self.credit_app_id) if not new_ca_ulid else None

        self.log.bind(
            dealRefId=self.deal_ref_id,
            creditAppId=self.credit_app_id,
            dealXgDealId=deal_xg_deal_id,
            dealXgDealVersion=deal_xg_deal_version,
        )
        self.log.info("Credit App creation request received for new deal")

        validator = ExistingDealValidator(event, self.deal_ref_id)

        if not new_deal_ulid and validator.deal_exists():
            raise exceptions.BadRequestError(
                ErrorMsgs.deal_ref_id_already_exists.format(
                    deal_ref_id=self.deal_ref_id
                )
            )

        data = validator.validate_body()

        # convert target platform id for route one
        self.convert_target_platform_id_for_route_one(data=data)

        validator.validate_id_uniqueness(
            self.payload_type, reference_id=self.credit_app_id
        )
        data["creditAppId"] = self.credit_app_id
        data["dealXgDealId"] = deal_xg_deal_id
        data["dealXgDealVersion"] = deal_xg_deal_version
        data["baggage"] = self.baggage

        # add key_data dict to data with keys extracted from headers
        data.update(self.key_data)
        data = common.verify_and_add_source_partner_dealer_id(data)

        self.log.bind(requestPayload=data)

        dr_utils.send_payload_to_queue(
            queue=Env.DEAL_DATA_QUEUE,
            payload=data,
            region=Env.AWS_REGION,
            msg_group_id=self.deal_ref_id,
            payloadType=self.payload_type,
            correlationId=self.correlation_id,
            dealRefId=self.deal_ref_id,
            creditAppId=self.credit_app_id,
        )

        self.log.info(
            f"Credit App creation request sent to queue: {Env.DEAL_DATA_QUEUE}"
        )

        return_body = {"dealRefId": self.deal_ref_id, "creditAppId": self.credit_app_id}

        return {
            "statusCode": HTTPStatus.CREATED,
            "body": json.dumps(return_body),
            "headers": self.response_headers,
        }

    @ProducerLambda.catch_exceptions
    @ProducerLambda.is_handler
    def existing_deal_handler(self, event, context):
        """
        Handles the Credit App Post for existing Deal endpoint. Creates a new Credit App under an existing Deal.

        Endpoint: /deals/{dealRefId}/credit-apps/

        This asynchronous API generates new creditAppId submits a message to DealDataQueue, then returns these IDs to
        the client with HTTP status CREATED (201).

        :param dict event: An API Gateway event object
        :param dict context: AWS Lambda Context Object
        :return: JSON with status code and body
        """

        credit__app_id_header = self.request_headers.get(CREDIT_APP_ID_HEADER_KEY)
        self.deal_ref_id = common.get_path_parameter(event, "dealRefId")
        self.credit_app_id = (
            credit__app_id_header
            if credit__app_id_header and credit__app_id_header.strip()
            else ulid.new().str
        )
        deal_xg_deal_id = self.request_headers.get(
            DEAL_XG_ID_HEADER_KEY
        ) or self.request_headers.get(DEAL_XG_ID_HEADER_KEY.lower())
        deal_xg_deal_version = self.request_headers.get(
            DEAL_XG_VERSION_HEADER_KEY
        ) or self.request_headers.get(DEAL_XG_VERSION_HEADER_KEY.lower())
        common.verify_ulid(self.credit_app_id)

        self.log.bind(
            dealRefId=self.deal_ref_id,
            creditAppId=self.credit_app_id,
            dealXgDealId=deal_xg_deal_id,
            dealXgDealVersion=deal_xg_deal_version,
        )
        self.log.info("Credit App creation request received for exiting deal")

        validator = ExistingDealValidator(event, self.deal_ref_id)
        validator.validate_body()
        validator.validate_api_version(self.request_api_version)
        validator.validate_id_uniqueness(
            self.payload_type, reference_id=self.credit_app_id
        )

        data = validator.data
        # convert target platform id for route one
        self.convert_target_platform_id_for_route_one(data=data)

        # adding creditAppId to the payload
        data["creditAppId"] = self.credit_app_id
        data["baggage"] = self.baggage
        data["dealXgDealId"] = deal_xg_deal_id
        data["dealXgDealVersion"] = deal_xg_deal_version

        # add key_data dict to data with keys extracted from headers
        data.update(self.key_data)
        data = common.drop_ref_ids_from_payload(data)

        self.log.bind(requestPayload=data)

        dr_utils.send_payload_to_queue(
            queue=Env.DEAL_DATA_QUEUE,
            payload=data,
            region=Env.AWS_REGION,
            msg_group_id=self.deal_ref_id,
            payloadType=self.payload_type,
            correlationId=self.correlation_id,
            dealTTL=validator.stored_ttl,
            dealRefId=self.deal_ref_id,
            creditAppId=self.credit_app_id,
        )

        self.log.info(
            f"Credit App creation request for existing deal sent to queue: {Env.DEAL_DATA_QUEUE}"
        )

        return_body = {"dealRefId": self.deal_ref_id, "creditAppId": self.credit_app_id}

        return {
            "statusCode": HTTPStatus.CREATED,
            "body": json.dumps(return_body),
            "headers": self.response_headers,
        }

    @ProducerLambda.catch_exceptions
    @ProducerLambda.is_handler
    def update_handler(self, event, context):
        """
        Handles the Credit App Update endpoint and the Credit App LenderList endpoint. Updates an existing
        Credit App and lenders list under an existing Deal.
        Endpoint: /deals/{dealRefId}/credit-apps/{creditAppId}/
        Endpoint: /deals/{dealRefId}/credit-apps/{creditAppId}/lenders/{lenderId}
        Endpoint: /deals/{dealRefId}/credit-apps/{creditAppId}/lenders

        This asynchronous API submits a message to DealDataQueue, then returns this ID to the client with
        HTTP status NO_CONTENT (204).

        :param dict event: An API Gateway event object
        :param dict context: AWS Lambda Context Object
        :return: JSON with status code and body
        """

        self.deal_ref_id = common.get_path_parameter(event, "dealRefId")
        self.credit_app_id = common.get_path_parameter(event, "creditAppId")

        self.log.bind(dealRefId=self.deal_ref_id, creditAppId=self.credit_app_id)
        if self.payload_type == pt.CREDIT_APP_LENDER_POST:
            self.log.info("Credit App lenders list update request received")
        else:
            self.log.info("Credit App update request received")

        validator = ExistingDealValidator(event, self.deal_ref_id)
        validator.validate_body()
        validator.validate_api_version(self.request_api_version)
        validator.validate_id_uniqueness(
            self.payload_type, resource_id=self.credit_app_id
        )

        data = validator.data

        # convert target platform id for route one
        self.convert_target_platform_id_for_route_one(data=data)

        # adding creditAppId to the payload
        data["creditAppId"] = self.credit_app_id
        data["baggage"] = self.baggage

        # add lenderId to payload for deal-update
        if self.payload_type == pt.DEAL_UPDATE:
            data["lenderId"] = common.get_path_parameter(event, "lenderId")

        # add key_data dict to data with keys extracted from headers
        data.update(self.key_data)
        data = common.drop_ref_ids_from_payload(data)

        self.log.bind(requestPayload=data)

        dr_utils.send_payload_to_queue(
            queue=Env.DEAL_DATA_QUEUE,
            payload=data,
            region=Env.AWS_REGION,
            msg_group_id=self.deal_ref_id,
            payloadType=self.payload_type,
            correlationId=self.correlation_id,
            dealTTL=validator.stored_ttl,
            dealRefId=self.deal_ref_id,
            creditAppId=self.credit_app_id,
        )
        if self.payload_type == pt.CREDIT_APP_LENDER_POST:
            self.log.info(
                f"Credit App lenders list update request sent to queue: {Env.DEAL_DATA_QUEUE}"
            )
        else:
            self.log.info(
                f"Credit App update request sent to queue: {Env.DEAL_DATA_QUEUE}"
            )

        return {
            "statusCode": HTTPStatus.NO_CONTENT,
            "body": "Credit Application updated",
            "headers": self.response_headers,
        }

    def convert_target_platform_id_for_route_one(self, data: dict):
        """
        Convert RouteOne target to R1J: Rally ID (US1395817)
        :param data: original validated payload dict
        """
        target_platform_records = data.get("targetPlatforms") or []
        for record in target_platform_records:
            if record.get("id") == TargetPlatformIds.RT1:
                record["id"] = TargetPlatformIds.R1J
                self.log.info(
                    f"Converted RouteOne target platform from {TargetPlatformIds.RT1} to {TargetPlatformIds.R1J}",
                    target_platform_records=target_platform_records,
                )

    @ProducerLambda.catch_exceptions
    @ProducerLambda.is_handler
    def ca_put_handler(self, event, context):
        """
        Handles the Credit App PUT for existing Deal. .

        Endpoint: /deals/{dealRefId}/credit-apps

        This asynchronous API generates  submits a message to DealDataQueue, then returns dealRefId and creditAppId to
        the client with HTTP status CREATED (201).

        :param dict event: An API Gateway event object
        :param dict context: AWS Lambda Context Object
        :return: JSON with status code and body
        """

        self.deal_ref_id = common.get_path_parameter(event, "dealRefId")
        self.credit_app_id = self.request_headers.get(CREDIT_APP_ID_HEADER_KEY)
        if not self.credit_app_id:
            raise exceptions.BadRequestError(
                f"Required header is missing: {CREDIT_APP_ID_HEADER_KEY}"
            )
        common.verify_ulid(self.credit_app_id)

        self.log.bind(
            dealRefId=self.deal_ref_id,
            creditAppId=self.credit_app_id,
        )
        self.log.info(
            "Credit App creation request received for exiting deal with credit app"
        )

        validator = ExistingDealValidator(event, self.deal_ref_id)
        validator.validate_body()
        validator.validate_api_version(self.request_api_version)
        validator.validate_id_uniqueness(
            self.payload_type, reference_id=self.credit_app_id
        )

        data = validator.data

        # adding creditAppId to the payload
        data["creditAppId"] = self.credit_app_id
        data["baggage"] = self.baggage

        # add key_data dict to data with keys extracted from headers
        data.update(self.key_data)
        data = common.drop_ref_ids_from_payload(data)

        self.log.bind(requestPayload=data)

        dr_utils.send_payload_to_queue(
            queue=Env.DEAL_DATA_QUEUE,
            payload=data,
            region=Env.AWS_REGION,
            msg_group_id=self.deal_ref_id,
            payloadType=self.payload_type,
            correlationId=self.correlation_id,
            dealTTL=validator.stored_ttl,
            dealRefId=self.deal_ref_id,
            creditAppId=self.credit_app_id,
        )

        self.log.info(
            f"Credit App creation request received for exiting deal with credit app sent to queue: {Env.DEAL_DATA_QUEUE}"
        )

        return_body = {"dealRefId": self.deal_ref_id, "creditAppId": self.credit_app_id}

        return {
            "statusCode": HTTPStatus.CREATED,
            "body": json.dumps(return_body),
            "headers": self.response_headers,
        }


def credit_apps_handlers(event, content):
    response = None
    if event.get("requestContext").get("operationName") == "ca_new_deal":
        response = CreditAppProducerLambda().get_handler(
            handler_func="new_deal_handler", payload_type=pt.CREDIT_APP_POST
        )(event, content)

    if event.get("requestContext").get("operationName") == "ca_existing_deal":
        response = CreditAppProducerLambda().get_handler(
            handler_func="existing_deal_handler", payload_type=pt.CREDIT_APP_PATCH
        )(event, content)

    if event.get("requestContext").get("operationName") == "ca_update":
        response = CreditAppProducerLambda().get_handler(
            handler_func="update_handler", payload_type=pt.CREDIT_APP_UPDATE
        )(event, content)

    if event.get("requestContext").get("operationName") == "ca_lenders_list":
        response = CreditAppProducerLambda().get_handler(
            handler_func="update_handler", payload_type=pt.CREDIT_APP_LENDER_POST
        )(event, content)

    if event.get("requestContext").get("operationName") == "deal_update":
        response = CreditAppProducerLambda().get_handler(
            handler_func="update_handler", payload_type=pt.DEAL_UPDATE
        )(event, content)

    if event.get("requestContext").get("operationName") == "ca_put_handler":
        response = CreditAppProducerLambda().get_handler(
            handler_func="ca_put_handler", payload_type=pt.CREDIT_APP_PUT
        )(event, content)

    return response
