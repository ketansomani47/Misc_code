# -*- coding: utf-8 -*-
import json
import os
import random
import secrets
from decimal import Decimal

import pytest
from faker import Faker


def pytest_addoption(parser):
    parser.addoption(
        "--api_url",
        action="store",
        default="",
        help="URL for the test endpoint to run functional tests.",
    )
    parser.addoption(
        "--env",
        action="store",
        default="",
        help="Environment at which functional tests to run against",
    )
    parser.addoption(
        "--region",
        action="store",
        default="",
        help="AWS region where application is pointing",
    )
    parser.addoption(
        "--stage",
        action="store",
        default="",
        help="Stage at which functional tests to run against",
    )
    parser.addoption(
        "--api_version",
        action="store",
        default="",
        help="Version of current deployment",
    )
    parser.addoption(
        "--table_suffix",
        action="store",
        default="",
        help="Suffix for Deals table name. Table name will have name deals-",
    )


@pytest.fixture(scope="session")
def api_url(request):
    url = request.config.getoption("--api_url")
    url = url.replace("/v1/healthchecks", "")
    return url


@pytest.fixture(scope="session")
def env(request):
    return request.config.getoption("--env")


@pytest.fixture(scope="session")
def region(request):
    return request.config.getoption("--region")


@pytest.fixture(scope="session")
def stage(request):
    return request.config.getoption("--stage")


@pytest.fixture(scope="session")
def get_api(request):
    return request.config.getoption("--get_api")


@pytest.fixture(scope="session")
def api_version(request):
    return request.config.getoption("--api_version")


@pytest.fixture(scope="session")
def table_suffix(request):
    return request.config.getoption("--table_suffix")


def pytest_configure(config):
    config.addinivalue_line("markers", "smoke: test eligible for smoke test")
    config.addinivalue_line("markers", "regression: test eligible for regression test")
    config.addinivalue_line("markers", "functional: test eligible for functional test")
    config.addinivalue_line("markers", "prod: test eligible for production env")
    config.addinivalue_line("markers", "apic: get test cases for APIC only")
    os.environ["env"] = config.getoption("env")


class RandomData:
    def __init__(self):
        fake = Faker("en_US")
        self.first_name = fake.first_name()
        self.last_name = fake.last_name()
        self.line1 = fake.street_address()
        self.city = fake.city()
        self.state = fake.state_abbr(include_territories=False)
        self.zip_code = fake.zipcode()
        self.ssn = fake.ssn().replace("-", "")
        self.email = fake.email()

    @staticmethod
    def generate_random_unifi_and_finance_service_ids():
        random_partner = ["MMD", "DRI", "VIN"]
        random_lenders = ["BOA", "ALY", "DT6"]
        app_ids_dict = {
            "sourcePartnerId": secrets.choice(random_partner),
            "sourcePartnerDealerId": f"{str(random.getrandbits(16))}_TEST",
            "dealRefIdFD": str(random.getrandbits(52)),
            "appRefIdFD": str(random.getrandbits(52)),
            "creditAppIdFI": str(random.getrandbits(52)),
            "dealRefIdFI": str(random.getrandbits(52)),
            "dealJacketId": str(random.getrandbits(52)),
            "dealIdFI": str(random.getrandbits(52)),
            "dealerCode": str(random.getrandbits(48)),
            "dealerId": str(random.getrandbits(24)),
            "lenderId": secrets.choice(random_lenders),
            "partnerCode": str(random.getrandbits(24)),
        }

        return app_ids_dict


@pytest.fixture()
def random_data_class():
    return RandomData


@pytest.fixture()
def to_decimal():
    def _to_decimal(obj):
        if isinstance(obj, list):
            for sub_obj in obj:
                return _to_decimal(sub_obj)
        elif isinstance(obj, dict):
            for k, v in obj.items():
                if type(v) in (int, float):
                    obj[k] = Decimal(str(v))
        return obj

    return _to_decimal


@pytest.fixture()
def decimal_encoder():
    class DecimalEncoder(json.JSONEncoder):
        def default(self, obj):
            if isinstance(obj, Decimal):
                return str(obj)
            return super(DecimalEncoder, self).default(obj)

    return DecimalEncoder


@pytest.fixture()
def invalid_event_id():
    def wrapper(event_id, deal_ref_id):
        return [
            {
                "code": "deal.invalidRefId",
                "properties": [
                    {
                        "property": "dealComponent",
                        "message": f"Provided eventId {event_id} is not associated to dealRefId {deal_ref_id}",
                    }
                ],
            }
        ]

    return wrapper


@pytest.fixture()
def no_resources_found_response():
    def wrapper(deal_ref_id, field=None, value=None):
        if not field:
            field = "dealRefId"
            message = f"No resources found for given dealRefId {deal_ref_id}."
        else:
            message = f"No resources found for given dealRefId: {deal_ref_id} and {field}: {value}."
        return [
            {
                "code": "deal.noResourcesFound",
                "properties": [
                    {
                        "property": field,
                        "message": message,
                    }
                ],
            }
        ]

    return wrapper


@pytest.fixture
def invalid_deal_ref_id_response():
    """
    Fixture is to generates error response for invalid dealRefId in the request url
    :return: error message with proper dealRefId
    """

    def wrapper(deal_ref_id):
        return [
            {
                "code": "deal.invalidRefId",
                "properties": [
                    {
                        "property": "dealRefId",
                        "message": f"Invalid dealRefId {deal_ref_id}",
                    }
                ],
            }
        ]

    return wrapper


@pytest.fixture()
def post_doc_payload():
    return {
        "customerRole": "Applicant",
        "documentType": "DriversLicense",
        "tags": ["CA"],
        "targetPlatforms": [{"id": "DTC"}],
        "extensionFields": {"UploadSystem": "VIN"},
        "uploadStatus": "Initialized",
    }


@pytest.fixture()
def post_doc_headers():
    def wrapper(request_type):
        headers = {
            "sourcePartnerId": "DXB",
            "sourcePartnerDealerId": "863907",
        }
        if request_type == "session_doc":
            headers.update({"pageCount": "4"})
        return headers

    return wrapper


@pytest.fixture()
def missing_headers_resp():
    def wrapper(headers):
        return [
            {
                "property": "headers",
                "message": f"The following headers are required to process the request: {headers}",
            }
        ]

    return wrapper


@pytest.fixture()
def missing_body_fields_docs_resp():
    def wrapper(fields):
        return [
            {
                "property": "body",
                "message": f"The following body fields are required to process the request: {fields}",
            }
        ]

    return wrapper


@pytest.fixture()
def post_duplicate_document_resp():
    return [
        {
            "code": "deal.invalidRefId",
            "properties": [
                {
                    "property": "dealComponent",
                    "message": "Document record already posted",
                }
            ],
        }
    ]


@pytest.fixture()
def invalid_customer_role_docs_resp():
    def wrapper(values):
        return [
            {
                "property": "body",
                "message": f"customerRole field must be one of the following: {values}",
            }
        ]

    return wrapper


@pytest.fixture()
def invalid_page_count_docs_resp():
    return [
        {
            "property": "headers",
            "message": "pageCount is a required header and must be of type int",
        }
    ]


@pytest.fixture()
def payload_signing_coordinates():
    return {
        "signingCoordinates": [
            {
                "pageNumber": 1,
                "pageSize": {},
                "signatureDetails": [
                    {
                        "signerType": "Dealer",
                        "signatureType": "Signature",
                        "signBoxPositionX": 40,
                        "signBoxPositionY": 76,
                        "signatureBoxHeight": 20,
                        "signatureBoxWidth": 40,
                    },
                    {
                        "signerType": "Applicant",
                        "signatureType": "Signature",
                        "signBoxPositionX": 40,
                        "signBoxPositionY": 5,
                        "signatureBoxHeight": 20,
                        "signatureBoxWidth": 40,
                    },
                ],
            }
        ]
    }


@pytest.fixture()
def missing_deal_ref_path_param():
    return [
        {
            "code": "deal.missingRequiredProperty",
            "properties": [
                {
                    "property": "dealRefId",
                    "message": "dealRefId is missing in provided path parameters",
                }
            ],
        }
    ]


@pytest.fixture()
def missing_body_message():
    return [
        {
            "code": "deal.missingRequiredProperty",
            "properties": [
                {
                    "property": "eventBody",
                    "message": "No record or body found in AWS event payload",
                }
            ],
        }
    ]
