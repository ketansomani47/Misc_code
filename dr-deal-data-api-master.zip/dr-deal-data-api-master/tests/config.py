# -*- coding: utf-8 -*-

RETRY_COUNT = 150  # How many times to retry HTTP requests in functional tests
WAIT_WITH_RETRIES = (
    0.5  # How long to wait between retries of HTTP requests in functional tests
)
WAIT_WITH_NO_RETRIES = (
    3  # How long to wait before HTTP requests in functional tests that have no retries
)

DD_ENV_MAPPING = {
    "api_name": "deal_data",
    "lab": {
        "url": "",
        "key": "",
        "aws_alias": "awscoxautolabs18",
        "bucket_suffix": "lab",
    },
    "np_pr": {
        "url": "",
        "key": "",
        "aws_alias": "awssfidrsvcnp",
        "bucket_suffix": "np-pr",
    },
    "dev": {
        "url": "https://deal-data-dvi1.drsvcnp.aws.dealertrack.com",
        "key": "VmjmjZpH5wcLd6VcSKUNxC301dT41YbzYME1EbIyn",
        "aws_alias": "awssfidrsvcnp",
        "bucket_suffix": "dev",
    },
    "qa": {
        "url": "https://deal-data-qa.drsvcnp.aws.dealertrack.com",
        "key": "ZNzY6z2yzJ3BDAOc3aQX03Pm6cqmk1ZR84VntVaOo",
        "aws_alias": "awssfidrsvcnp",
        "bucket_suffix": "qa",
    },
    "uat": {
        "url": "https://deal-data.drsvcpp.aws.dealertrack.com",
        "key": "jjQ1VYlZim9ZNHhR4LrYQ5Pf9jUIgUqF5Q6hqZwG",
        "aws_alias": "awssfidrsvcpp",
        "bucket_suffix": "uat",
    },
    "pa": {
        "url": "https://deal-data-pa.drapi-pp.aws.dealertrack.com",
        "key": "8bcm9vUZhL15Eci2yRP7h79HtaEbq3ceOeQcf8zgx",
        "aws_alias": "awssfidrapipp",
        "bucket_suffix": "pa",
    },
    "prod": {
        "url": "https://deal-data.drsvc.aws.dealertrack.com",
        "key": "8bcm9vUVhL15Eci2yRR7h79HtmEbq3ceOeQcf8zgx",
        "aws_alias": "awssfidrsvc",
        "bucket_suffix": "prod",
    },
}

STACK_SUPPORTER = {
    "api_name": "stack_supporter",
    "np_pr": {
        "aws_alias": "awssfidrsvcnp",
        "url": "https://stack-supporter-dev.drsvcnp.aws.dealertrack.com/v1",
        "key": "",
        "bucket_suffix": "np-pr",
    },
    "dev": {
        "aws_alias": "awssfidrsvcnp",
        "url": "https://stack-supporter-dev.drsvcnp.aws.dealertrack.com/v1",
        "key": "",
        "bucket_suffix": "dev",
    },
    "qa": {
        "aws_alias": "awssfidrsvcnp",
        "url": "https://stack-supporter-qa.drsvcnp.aws.dealertrack.com/v1",
        "key": "",
        "bucket_suffix": "qa",
    },
    "uat": {
        "aws_alias": "awssfidrsvcpp",
        "url": "https://stack-supporter.drsvcpp.aws.dealertrack.com/v1",
        "key": "",
        "bucket_suffix": "uat",
    },
    "pa": {
        "aws_alias": "awssfidrapipp",
        "url": "https://stack-supporter-pa.drapi-pp.aws.dealertrack.com/v1",
        "key": "",
        "bucket_suffix": "pa",
    },
    "prod": {
        "aws_alias": "awssfidrsvc",
        "url": "https://stack-supporter.drsvc.aws.dealertrack.com/v1",
        "key": "",
        "bucket_suffix": "prod",
    },
}

ROUTE_MAPPING = {
    "events": {"route": "/v1/events", "api": DD_ENV_MAPPING},
    "get_event": {
        "route": "/v1/deals/{deal_ref_id}/events/{event_id}",
        "api": DD_ENV_MAPPING,
    },
    "get_events": {"route": "/v1/deals/{deal_ref_id}/events", "api": DD_ENV_MAPPING},
    "post_event": {"route": "/v1/deals/{deal_ref_id}/events", "api": DD_ENV_MAPPING},
    "patch_event": {
        "route": "/v1/deals/{deal_ref_id}/events/{event_id}",
        "api": DD_ENV_MAPPING,
    },
    "post_lender_decision": {
        "route": "/v1/deals/{deal_ref_id}/credit-apps/{credit_app_id}/decisions",
        "api": DD_ENV_MAPPING,
    },
    "get_documents": {
        "route": "/v1/deals/{deal_ref_id}/documents",
        "api": DD_ENV_MAPPING,
    },
    "get_single_document": {
        "route": "/v1/deals/{deal_ref_id}/documents/{document_id}",
        "api": DD_ENV_MAPPING,
    },
    "get_session": {
        "route": "/v1/deals/{deal_ref_id}/uploads/{session_id}",
        "api": DD_ENV_MAPPING,
    },
    "post_document": {
        "route": "/v1/deals/{deal_ref_id}/documents",
        "api": DD_ENV_MAPPING,
    },
    "delete_document": {
        "route": "/v1/deals/{deal_ref_id}/documents/{document_id}",
        "api": DD_ENV_MAPPING,
    },
    "patch_document": {
        "route": "/v1/deals/{deal_ref_id}/documents/{document_id}",
        "api": DD_ENV_MAPPING,
    },
    "patch_session": {
        "route": "/v1/deals/{deal_ref_id}/uploads/{session_id}",
        "api": DD_ENV_MAPPING,
    },
    "patch_session_page": {
        "route": "/v1/deals/{deal_ref_id}/uploads/{session_id}/pages/{page_id}",
        "api": DD_ENV_MAPPING,
    },
    "event_reprocess": {
        "route": "/v1/events/{deal_ref_id}/reprocess-apps/{deal_component}",
        "api": DD_ENV_MAPPING,
    },
    "health_check": {"route": "/v1/healthchecks/", "api": DD_ENV_MAPPING},
    "info": {"route": "/v1/info", "api": DD_ENV_MAPPING},
    "credit_app": {"route": "/v1/deals/credit-apps/", "api": DD_ENV_MAPPING},
    "credit_app_with_deal_ref": {
        "route": "/v1/deals/{deal_ref_id}/credit-apps/",
        "api": DD_ENV_MAPPING,
    },
    "copy_credit_app": {
        "route": "/v1/deals/{deal_ref_id}/credit-apps/",
        "api": DD_ENV_MAPPING,
    },
    "ca_update": {
        "route": "/v1/deals/{deal_ref_id}/credit-apps/{credit_app_id}",
        "api": DD_ENV_MAPPING,
    },
    "leads": {"route": "/v1/deals/leads", "api": DD_ENV_MAPPING},
    "leads_with_deal_ref": {
        "route": "/v1/deals/{deal_ref_id}/leads",
        "api": DD_ENV_MAPPING,
    },
    "leads_update": {
        "route": "/v1/deals/{deal_ref_id}/leads/{lead_ref_id}",
        "api": DD_ENV_MAPPING,
    },
    "deal_get": {"route": "/v1/deals/{deal_ref_id}", "api": DD_ENV_MAPPING},
    "deal_update": {
        "route": "/v1/deals/{deal_ref_id}/credit-apps/{credit_app_id}/lenders/{lender_id}",
        "api": DD_ENV_MAPPING,
    },
    "cb_response": {"route": "/v1/deals/credit-bureau-response", "api": DD_ENV_MAPPING},
    "deal_get_with_pii": {
        "route": "/v1/deals/{deal_ref_id}?protected=true",
        "api": DD_ENV_MAPPING,
    },
    "credit_bureau": {"route": "/v1/deals/credit-bureaus", "api": DD_ENV_MAPPING},
    "credit_bureau_with_deal_ref": {
        "route": "/v1/deals/{deal_ref_id}/credit-bureaus",
        "api": DD_ENV_MAPPING,
    },
    "key_data": {"route": "/v1/deals/key-data", "api": DD_ENV_MAPPING},
    "key_data_patch": {
        "route": "/v1/deals/{deal_ref_id}/key-data",
        "api": DD_ENV_MAPPING,
    },
    "key_data_patch_v2": {
        "route": "/v2/deals/{deal_ref_id}/key-data",
        "api": DD_ENV_MAPPING,
    },
    "key_data_get": {"route": "/v1/deals/key-data", "api": DD_ENV_MAPPING},
    "key_data_get_v2": {"route": "/v2/deals/key-data", "api": DD_ENV_MAPPING},
    "create_contract": {
        "route": "/v1/deals/{deal_ref_id}/contract",
        "api": DD_ENV_MAPPING,
    },
    "create_contract_v2": {
        "route": "/v2/deals/{deal_ref_id}/contract",
        "api": DD_ENV_MAPPING,
    },
    "update_contract": {
        "route": "/v1/deals/{deal_ref_id}/contract/{contract_ref_id}",
        "api": DD_ENV_MAPPING,
    },
    "verify_contract": {
        "route": "/v1/deals/{deal_ref_id}/contract/{contract_ref_id}/verify",
        "api": DD_ENV_MAPPING,
    },
    "verify_contract_v2": {
        "route": "/v2/deals/{deal_ref_id}/contract/verify",
        "api": DD_ENV_MAPPING,
    },
    "cancel_contract": {
        "route": "/v1/deals/{deal_ref_id}/contract/{contract_ref_id}/cancel",
        "api": DD_ENV_MAPPING,
    },
    "cancel_contract_v2": {
        "route": "/v2/deals/{deal_ref_id}/contract/cancel",
        "api": DD_ENV_MAPPING,
    },
    "standalone_sign_contract": {
        "route": "/v2/deals/{deal_ref_id}/contract/sign",
        "api": DD_ENV_MAPPING,
    },
    "sign_contract": {
        "route": "/v1/deals/{deal_ref_id}/contract/{contract_ref_id}/sign",
        "api": DD_ENV_MAPPING,
    },
    "contract_status": {
        "route": "/v1/deals/{deal_ref_id}/contract/{contract_ref_id}/status",
        "api": DD_ENV_MAPPING,
    },
    "lender_decision": {
        "route": "/v1/deals/{deal_ref_id}/partner-dealers/{dealer_id}/credit-apps/lenders/{lender_id}/decisions/latest",
        "api": DD_ENV_MAPPING,
    },
    "deal_get_via_apic": {
        "route": "https://apigw.apic-gateway.dvt1.aws.dealertrack.com/draas/sandbox/deals/{deal_ref_id}",
        "api": DD_ENV_MAPPING,
    },
    "deal_get_via_apic_with_pii": {
        "route": "https://apigw.apic-gateway.dvt1.aws.dealertrack.com/draas/sandbox/deals/{deal_ref_id}?protected=true",
        "api": DD_ENV_MAPPING,
    },
    "get_lender_ids": {
        "route": "/v1/deals/{deal_ref_id}/lender-ids",
        "api": DD_ENV_MAPPING,
    },
    "submit_lenders": {
        "route": "/v1/deals/{deal_ref_id}/credit-apps/{credit_app_id}/lenders",
        "api": DD_ENV_MAPPING,
    },
    "stack_supporter": {"route": "/sqs/{sqs_name}", "api": STACK_SUPPORTER},
}

DEAL_GET_IGNORE_LIST = [
    "protected",
    "consentGiven",
    "communityPropertyDisclosureIndicator",
    "regulationBIndicator",
    "privacyNoticeIndicator",
    "sourcePartnerDealerId",
    "dateOfBirthDay",
    "dateOfBirthMonth",
    "dealerCode",
]

RANDOM_FIELDS = [
    "randomField1",
    "randomField2",
    "randomField3",
    "randomField",
    "randomNode",
]


LIST_PRIMARY_KEY = {
    "targetPlatforms": "id",
    "tradeIns": "otherMake",
    "references": "firstName",
    "extraData": "name",
    "wholesaleBookDetails": "source",
    "lenderList": "lenderId",
    "reports": ["provider", "type"],
    "fees": "feeType",
    "taxes": "taxType",
    "products": "productType",
}

ORIGIN_SECRET_MAPPING = {
    "np_pr": "01FGPMDVGP1ZSBANDFMXWRJ6ST",
    "dev": "01FGPMDVGP1ZSBANDFMXWRJ6ST",
    "qa": "01FGPMDVGP1ZSBANDFMXWRJ6ST",
    "uat": "01HGBWN2VM5T02P4DS3YYDSQPH",
    "pa": "01H8Y7T37WPAX18H9STH0Q99RC",
    "prod": "01HGBWQ72RBTEHWRJETTWKDWG0",
}

TIME_TO_LIVE = {"DTC": 5184000, "CB": 2592000, "TOLERANCE": 14400}

DEAL_IDS_TO_DELETE = []
S3_KEY_TO_DELETE = []
