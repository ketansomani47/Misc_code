# -*- coding: utf-8 -*-
import json
import time
import uuid
from decimal import Decimal

from locust import HttpUser, SequentialTaskSet, between, task


lead_post_payload = "tests/test_data/leads/leads_min_data.json"
lead_patch_payload = "tests/test_data/leads/max_app_coapp_guarantor_driver.json"
key_data_payload = "tests/test_data/key_data/key_data_min.json"
deal_events_payload = (
    "tests/test_data/events/dr_internal_contract_successful_event.json"
)

credit_app_max_payload = "tests/test_data/credit_app/credit_app_full_payload.json"
test_run_id = f"LOCUST_RUN_{str(uuid.uuid4())}_SIMRT1_SIMHONDA_SIMUNIFI_SIMEVENTS"
ENV = "pa"
ENV_MAPPING = {
    "pa": {
        "deal_data_url": "https://deal-data-pa.drapi-pp.aws.dealertrack.com/",
        "partner": "VIN",
        "lender": "BOA",
        "partner_dealer_id": "445",
    }
}

deal_ref_ids = []


class GetDecisions(HttpUser):
    wait_time = between(2, 3)
    host = ENV_MAPPING[ENV]["deal_data_url"]

    @task
    class TaskSet(SequentialTaskSet):
        def on_start(self):
            self.env = ENV
            self.partner_dealer_id = ENV_MAPPING[self.env]["partner_dealer_id"]
            self.partner = ENV_MAPPING[self.env]["partner"]
            self.lender = ENV_MAPPING[self.env]["lender"]
            self.credit_app_id = ""
            self.deal_ref_id = ""
            self.lead_ref_id = ""

        def post_lead(self):
            payload = self.open_data_file(lead_post_payload)
            payload["sourcePartnerDealerId"] = self.partner_dealer_id
            payload["sourcePartnerId"] = self.partner
            payload = json.dumps(payload, cls=self.decimal_encoder())

            response = self.client.post(
                "v1/deals/leads",
                headers=self.get_deal_data_headers(),
                data=payload,
                name="Create Leads",
            )
            resp_json = json.loads(response.text)
            print(resp_json)
            self.deal_ref_id = resp_json["dealRefId"]
            self.lead_ref_id = resp_json["leadRefId"]

            deal_ref_ids.append(self.deal_ref_id)

            return resp_json

        def key_data_update(self):
            payload = self.open_data_file(key_data_payload)
            payload = json.dumps(payload, cls=self.decimal_encoder())

            response = self.client.patch(
                f"v1/deals/{self.deal_ref_id}/key-data",
                headers=self.get_deal_data_headers(),
                data=payload,
                name="Key Data Patch",
            )
            return response

        def credit_app_patch(self):
            time.sleep(1)
            payload = self.open_data_file(credit_app_max_payload)
            payload = json.dumps(payload, cls=self.decimal_encoder())

            response = self.client.post(
                f"v1/deals/{self.deal_ref_id}/credit-apps",
                headers=self.get_deal_data_headers(),
                data=payload,
                name="Create Credit App",
            )
            resp_json = json.loads(response.text)
            return resp_json

        def lead_app_patch(self):
            payload = self.open_data_file(lead_patch_payload)
            payload = json.dumps(payload, cls=self.decimal_encoder())

            response = self.client.patch(
                f"v1/deals/{self.deal_ref_id}/leads/{self.lead_ref_id}",
                headers=self.get_deal_data_headers(),
                data=payload,
                name="Lead App Update",
            )
            resp_json = response.text
            return resp_json

        def deal_events_post(self):
            payload = self.open_data_file(deal_events_payload)
            payload["eventTransactionId"] = self.deal_ref_id
            payload["eventKeyData"]["dealRefIdDR"] = self.deal_ref_id
            payload["eventId"] = self.deal_ref_id

            payload = json.dumps(payload, cls=self.decimal_encoder())

            response = self.client.post(
                f"v1/deals/{self.deal_ref_id}/events",
                headers=self.get_deal_data_headers(),
                data=payload,
                name="Deal Events Post",
            )
            resp_json = response.text
            return resp_json

        def get_deal_data_headers(self):
            return {
                "Content-Type": "application/json",
                "Connection": "close",
                "X-CoxAuto-Correlation-Id": test_run_id,
                "Source-Partner": f"{self.partner}",
            }

        def decimal_encoder(self):
            class DecimalEncoder(json.JSONEncoder):
                def default(self, obj):
                    if isinstance(obj, Decimal):
                        return str(obj)
                    return super(DecimalEncoder, self).default(obj)

            return DecimalEncoder

        @staticmethod
        def open_data_file(file_path):
            with open(file_path) as payload:
                payload = json.load(payload)

            return payload

        def on_stop(self):
            with open("deal_ref_ids.txt", "w") as fp:
                for val in deal_ref_ids:
                    fp.write("%s\n" % val)

        @task(2)
        def run_scenario_1(self):
            self.post_lead()
            time.sleep(1)
            self.key_data_update()
            time.sleep(1)
            self.credit_app_patch()
            time.sleep(1)
            self.deal_events_post()

        @task(1)
        def run_scenario_2(self):
            self.post_lead()
            time.sleep(1)
            self.key_data_update()
            time.sleep(1)
            self.lead_app_patch()

        @task(4)
        def run_scenario_3(self):
            self.post_lead()


if __name__ == "__main__":
    d = GetDecisions()
    d.run()
