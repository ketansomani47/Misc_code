# Load Tests using Locust

Load tests are created using Locust, a python based free tool to swarm the apis with a simulated user laod.


## Installation

Locust can be installed with pip using the following command.
```
pip3 install locust
```

## Quick Start Guide

The quick start.
https://docs.locust.io/en/stable/quickstart.html
## Test Run
The following command will run a locust file in the same directory.
```.env
$ locust
```
A specific locust file can be run using the -f switch.

```.env
$ locust -f filepath/filename.
```

Once tests are started the locust control center can be opened using a browser with the following address.

```
http://localhost:8089
```
In the screen that appears, you can Start a Locust Swarm by providing the following.
1. Number of users to simulate
2. Hatch Rate (Users spawned per second)
3. The host URl.
4. Click on the Start Swarming button.
### Reports
Once locust starts to swarm the reports can be seen on the Charts tab. The data can also be downloaded from
the download data tab.
## Stop Execution
Execution can be stopped by clicking on the stop button on the web interface.
The Locust instance can be killed by with a ctrl + d on the command prompt.
