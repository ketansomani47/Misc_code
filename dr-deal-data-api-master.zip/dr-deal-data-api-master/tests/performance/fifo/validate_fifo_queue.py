# -*- coding: utf-8 -*-
import json
import random
import time

from locust import HttpUser, between, task
from tests.conftest import RandomData
from tests.functional.service_api import ServiceAPI


lead_file = "leads/app_coapp_retail_new_null_and_empty_string.json"
ca_file = "credit_app/ind_retail_new.json"
cb_file = "credit_bureau/app_cb_equ_exp_tru.json"

PATCH_PAYLOAD = {
    "dealIdFI": str(random.getrandbits(48)),
    "dealJacketId": str(random.getrandbits(48)),
    "dealerCode": str(random.getrandbits(24)),
}
cb_event = {
    "eventVersion": "1.1",
    "eventId": "",
    "eventTime": "2018-10-26T10:34:01",
    "eventName": "deal:CreditBureauResponse",
    "eventDetailHref": "https://fni-api.dealertrack.com/cb-response/report",
    "eventSource": "dr:CreditBureauResponse",
    "eventType": "dr:CreditBureaus",
    "eventIdentityId": 104334,
    "eventTransactionId": "",
    "eventKeyData": {
        "dealRefId": "",
        "creditBureauRefIdFD": "01DDY25TBPNE21EH3P287DNJQ0",
        "creditBureauRefIdUnifi": "123456789323234",
    },
    "payloadSchemaHref": "https://fni-static.aws.dealertrack.com/assets/schemas/CB/v1/creditBureauResponse.jsd",
    "payload": {
        "financeMethod": "Lease",
        "sourcePartnerId": "VIN",
        "sourcePartnerDealerId": "123456789",
        "targetPlatforms": [{"id": "VIN", "partyId": "123456789"}],
        "applicant": {
            "firstName": "Bella",
            "lastName": "Morris",
            "middleName": "K",
            "phone": "516-325-1514",
            "protected": {"ssn": "788999009", "dateOfBirth": "1963-06-18"},
        },
    },
}


class DealDataUserActions(HttpUser):
    wait_time = between(2, 4)
    env = "dev"
    # env = os.environ.get("env")  # can be use by passing {env_name} in the command line before locust command
    host = ""
    deal_data = ServiceAPI(random_data_class=RandomData, env=env, json_file={})

    def on_start(self):
        print("********* Starting the test***********")

    def post_lead(self):
        self.deal_data.set_payload(lead_file)
        payload = json.dumps(self.deal_data.payload)
        url = self.deal_data.get_url("", "leads")
        header = self.deal_data.get_headers("")
        response = self.client.post(
            url=url, data=payload, headers=header, name="Lead-Post"
        )
        lead_resp = json.loads(response.text)
        self.deal_data.dealRefId = lead_resp.get("dealRefId")
        print(f"Lead RESP: {lead_resp}")

    def post_credit_app_to_an_existing_deal(self):
        self.deal_data.set_payload(ca_file)
        payload = json.dumps(self.deal_data.payload)
        url = self.deal_data.get_url("", "credit_app_with_deal_ref")
        header = self.deal_data.get_headers("")
        response = self.client.post(
            url=url, data=payload, headers=header, name="CA-Post-dealRefId"
        )
        ca_resp = json.loads(response.text)
        self.deal_data.dealRefId = ca_resp.get("dealRefId")
        print(f"CA RESP: {ca_resp}")

    def post_credit_bureau_to_an_existing_deal(self):
        self.deal_data.cbRefId = self.deal_data.generate_random_id()
        self.deal_data.set_payload(cb_file)
        payload = json.dumps(self.deal_data.payload)
        url = self.deal_data.get_url("", "credit_bureau_with_deal_ref")
        header = self.deal_data.get_headers("", True)
        response = self.client.post(
            url=url, data=payload, headers=header, name="CB-Post-dealRefId"
        )
        cb_resp = json.loads(response.text)
        self.deal_data.dealRefId = cb_resp.get("dealRefId")
        print(f"CB RESP: {cb_resp}")

    def post_credit_bureau_response(self):
        self.deal_data.set_report_data("cb_resp_equifax")
        cb_resp_payload, reports = self.deal_data.append_report_data_to_payload(
            self.deal_data.payload, self.deal_data.cb_report, "applicant"
        )
        self.deal_data.update_payload_with_bureau_key_data(cb_event, cb_resp_payload)
        payload = self.deal_data.payload
        url = self.deal_data.get_url("", "cb_response")
        header = self.deal_data.get_headers("", True)
        response = self.client.post(
            url=url, data=payload, headers=header, name="CB-RESPONSE"
        )
        cb_resp = json.loads(response.text)
        self.deal_data.dealRefId = cb_resp.get("dealRefId")
        print(f"CB RESP: {cb_resp}")

    def patch_key_data(self):
        payload = json.dumps(PATCH_PAYLOAD)
        url = self.deal_data.get_url("", "key_data_patch")
        header = self.deal_data.get_headers("")
        response = self.client.patch(
            url=url, data=payload, headers=header, name="Key-Data-Patch"
        )
        print(
            f"Patch Status-Code: {response.status_code} DealRefID: {self.deal_data.dealRefId}"
        )

    def get_deal_data(self):
        url = self.deal_data.get_url("", "deal_get")
        header = self.deal_data.get_headers("")
        response = self.client.get(url=url, headers=header, name="DEAL-GET")
        print(
            f"GET Status-Code: {response.status_code} DealRefID: {self.deal_data.dealRefId}"
        )

    @task(1)
    def scenario1_validate_fifo_changes_for_deal_data(self):
        self.post_lead()
        time.sleep(200 / 1000)
        self.patch_key_data()
        self.get_deal_data()
        self.post_credit_app_to_an_existing_deal()
        self.get_deal_data()
        self.patch_key_data()
        self.post_credit_bureau_to_an_existing_deal()
        self.post_credit_bureau_response()
        self.get_deal_data()
