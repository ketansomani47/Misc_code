

// API ROUTES
export let api_routes = {
  "key_data_get": "v1/deals/key-data",
  "key_data_post": "v1/deals/key-data"
}

// URL and Secret
export const deal_data_urls = {
  dev: {
    "url": "https://deal-data-dvi1.drsvcnp.aws.dealertrack.com/",
    "secret": __ENV.DEV_ORG_Secret
  },
  qa: {
    "url": "https://deal-data-qa.drsvcnp.aws.dealertrack.com/",
    "secret": __ENV.QA_ORG_Secret
  },
  uat: {
    "url": "https://deal-data.drsvcpp.aws.dealertrack.com/",
    "secret": __ENV.UAT_ORG_Secret
  },
  pa: {
    "url": "https://deal-data-pa.drapi-pp.aws.dealertrack.com/",
    "secret": __ENV.PA_Origin_Secret
  },
  prod: {
    "url": "https://deal-data.drsvc.aws.dealertrack.com/",
    "secret": __ENV.PROD_ORG_Secret
  }
}
