import http from 'k6/http'
import { sleep, check } from 'k6'
import { uuidv4 } from 'https://jslib.k6.io/k6-utils/1.4.0/index.js';

import {api_routes, deal_data_urls} from "./config.js";

// Save dealRefId
export let deal_ref_id = NaN


export function getHeader(){
// Key-Data Headers
    const headers = {
    'Content-Type': 'application/json',
    'X-CoxAuto-Correlation-Id': 'LAMBDA-K6-test-' + uuidv4(),
    'x-origin-secret': __ENV.DEV_ORG_Secret
    };
  return headers;
}

export function generateKeyDataPayload(){
    // Key-Data Post Payload
    let payload = JSON.stringify({
    "targetPlatformId": "DTC",
    "dealRefIdFD": String(Math.floor(Math.random() * 999999999999)),
    "dealRefIdFDInt":  String(Math.floor(Math.random() * 999999999999))
    });
  return payload;
}

// Post Key-Data
export function postKeyData(url, payload, headers) {
    // Post Request
    let resp = http.post(url, payload, {headers: headers});
    console.log(`Response body: ${resp.body}`);
    sleep(1);

    check(resp, {
      'Status code is 201': (r) => r.status === 201,
      'Status code is none 201': (r) => r.status !==201,
    });

    // get dealRefId from Resp Body
    let resp_body = JSON.parse(resp.body);
    // let deal_ref_id = resp_body.dealRefId;
    deal_ref_id = resp_body.dealRefId;

    // API Response logging
    console.log(`Response status code: ${resp.status}`);
    console.log(`Updated dealRefId: ${deal_ref_id}`);
    return resp
}

// Get Key-Data
export function getKeyData(url, headers) {
    // Post Request
    let resp = http.get(url, {headers: headers});
    console.log(`GET Response body: ${resp.body}`);
    sleep(1);

    check(resp, {
      'Status code is 200': (r) => r.status === 200,
      'Status code is none 200': (r) => r.status !==200,
    });

    return resp
}


export function getUrl(route, query_pram= null) {
  //  Get All test envs from config
  const test_envs = Object.keys(deal_data_urls);
  // test env from command line
  const test_env = __ENV.ENV;
  console.log(`Test env: ${test_env}`);
  // Check if env argument is pass as command line argument
  if (!test_envs.includes(test_env)) {
      throw new Error("You must provide env as command line argument in order to continue with the test...");
  }
  let base_url = deal_data_urls[test_env]["url"]
  let api_route = api_routes[route]
  let url = base_url + api_route

  if (query_pram) {
    url = `${url}?${query_pram}`
  }
  return url
}
