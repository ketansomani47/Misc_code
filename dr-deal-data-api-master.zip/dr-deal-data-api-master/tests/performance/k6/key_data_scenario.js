
import {generateKeyDataPayload, getHeader, postKeyData, getKeyData, deal_ref_id, getUrl} from './common.js';


export let options = {
    summaryTrendStats: ["avg", "p(90)", "p(95)", "p(99)", "p(99.9)", "max"],
    scenarios: {
      Team_Lambda_V2_KEY_Data: {
        exec: 'KeyDataTesting',
        executor: 'per-vu-iterations',
        vus: __ENV.virtualK6Users || 1,
        iterations: __ENV.k6Iterations || 1,
        maxDuration: __ENV.testRunDurations || '15s',
        gracefulStop: __ENV.testGracefulStop || '3s',
      },
    },
    // To run in the cloud
    ext: {
        loadimpact: {
        projectID: 3719286,
        },
    }
  }


export function KeyDataTesting() {
    // Post Request
    let key_data_post_url = getUrl("key_data_post");
    let post_resp = postKeyData(key_data_post_url, generateKeyDataPayload(), getHeader());
    console.log(`API Response from post file ${post_resp.body}`);

    // Get Request
    let query_pram = `dealRefId=${deal_ref_id}`;
    let key_data_get_url = getUrl("key_data_get", query_pram);


    let get_resp = getKeyData(key_data_get_url, getHeader());
    console.log(`API Response from get file ${get_resp.body}`);

}
