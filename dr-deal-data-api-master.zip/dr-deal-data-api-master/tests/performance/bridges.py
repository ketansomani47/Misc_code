# -*- coding: utf-8 -*-
import json
import uuid
from decimal import Decimal

from locust import HttpUser, SequentialTaskSet, between, task


credit_app_max_payload = "tests/test_data/credit_app/ind_retail_used.json"
test_run_id = f"LOCUST_RUN_{str(uuid.uuid4())}_SIMRT1_SIMHONDA_SIMUNIFI_SIMEVENTS"
ENV = "pa"
ENV_MAPPING = {
    "pa": {
        "deal_data_url": "https://deal-data-pa.drapi-pp.aws.dealertrack.com/",
        "partner": "VIN",
        "lender": "BOA",
        "partner_dealer_id": "445",
    }
}


class GetDecisions(HttpUser):
    wait_time = between(1, 2)
    host = ENV_MAPPING[ENV]["deal_data_url"]

    @task
    class TaskSet(SequentialTaskSet):
        def on_start(self):
            print(test_run_id)
            self.env = ENV
            self.partner_dealer_id = ENV_MAPPING[self.env]["partner_dealer_id"]
            self.partner = ENV_MAPPING[self.env]["partner"]
            self.lender = ENV_MAPPING[self.env]["lender"]
            self.credit_app_id = ""
            self.deal_ref_id = ""

        @task(1)
        def credit_app_post_route_one(self):
            payload = self.open_data_file(credit_app_max_payload)
            payload["targetPlatforms"] = [{"id": "RT1", "partyId": "23125"}]
            payload = json.dumps(payload, cls=self.decimal_encoder())

            response = self.client.post(
                "v1/deals/credit-apps",
                headers=self.get_deal_data_headers(),
                data=payload,
                name="Create Credit App Route One",
            )
            resp_json = json.loads(response.text)
            print(resp_json)
            return resp_json

        @task(1)
        def credit_app_post_honda(self):
            payload = self.open_data_file(credit_app_max_payload)
            payload["targetPlatforms"] = [{"id": "IDL", "partyId": "23125"}]
            payload = json.dumps(payload, cls=self.decimal_encoder())

            response = self.client.post(
                "v1/deals/credit-apps",
                headers=self.get_deal_data_headers(),
                data=payload,
                name="Create Credit App Honda",
            )
            resp_json = json.loads(response.text)
            print(resp_json)
            return resp_json

        def get_deal_data_headers(self):
            return {
                "Content-Type": "application/json",
                "Connection": "close",
                "X-CoxAuto-Correlation-Id": test_run_id,
                "Source-Partner": f"{self.partner}",
            }

        def decimal_encoder(self):
            class DecimalEncoder(json.JSONEncoder):
                def default(self, obj):
                    if isinstance(obj, Decimal):
                        return str(obj)
                    return super(DecimalEncoder, self).default(obj)

            return DecimalEncoder

        @staticmethod
        def open_data_file(file_path):
            with open(file_path) as payload:
                payload = json.load(payload)

            return payload


if __name__ == "__main__":
    d = GetDecisions()
    d.run()
