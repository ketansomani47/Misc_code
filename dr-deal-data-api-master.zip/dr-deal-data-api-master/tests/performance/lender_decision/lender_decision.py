# -*- coding: utf-8 -*-
import json
import time

import ulid
from locust import HttpUser, between, task


deal_data_reqest_payload = "tests/test_data/credit_app/ind_lease_new.json"
events_payload = "tests/performance/lender_decision/events.json"
test_run_id = "LOC06-5USR"
ENV = "dev"
ENV_MAPPING = {
    "dev": {
        "events_url": "https://events-dvi1.drsvcnp.aws.dealertrack.com/v1/deals",
        # "events_api_key": "",
        "deal_data_url": "https://deal-data-dvi1.drsvcnp.aws.dealertrack.com/",
        "partner": "VIN",
        "lender": "BOA",
        "partner_dealer_id": "445",
    }
}


class Get_Decisions(HttpUser):
    def get_deal_data_headers(self):
        return {
            "Content-Type": "application/json",
            "Connection": "close",
            "X-CoxAuto-Correlation-Id": f"{test_run_id}-{self.uid}",
            "Source-Partner": f"{self.partner}",
        }

    def get_events_headers(self):
        return {
            "x-api-key": ENV_MAPPING[self.env]["events_api_key"],
            "Content-Type": "application/json",
            "Connection": "close",
            "X-CoxAuto-Correlation-Id": f"{test_run_id}-{self.uid}",
        }

    def get_deal_data_api_request(self):
        with open(deal_data_reqest_payload) as deal_payload:
            payload = json.load(deal_payload)

        payload["sourcePartnerDealerId"] = self.partner_dealer_id
        payload["sourcePartnerId"] = self.partner

        return json.dumps(payload)

    def get_events_request(self):
        f = open(events_payload)
        payload = json.load(f)

        payload["eventId"] = self.uid
        payload["eventIdentityId"] = self.uid
        payload["eventTransactionId"] = self.deal_ref_id
        payload["eventKeyData"]["dealRefId"] = self.deal_ref_id
        payload["eventKeyData"]["dealJacketId"] = f"{self.deal_ref_id}-dealrefid"
        payload["eventKeyData"]["dealerCode"] = self.unifi_dealer_code
        payload["eventKeyData"]["lenderId"] = self.lender
        payload["eventKeyData"]["sourcePartnerId"] = self.partner
        payload["eventKeyData"]["sourcePartnerDealerId"] = self.partner_dealer_id
        payload["eventKeyData"]["dealRefIdDR"] = self.deal_ref_id

        return json.dumps(payload)

    def create_credit_app(self):
        response = self.client.post(
            "v1/deals/credit-apps",
            headers=self.get_deal_data_headers(),
            data=self.get_deal_data_api_request(),
            name="Create Credit App",
        )
        resp_json = json.loads(response.text)
        self.credit_app_id = resp_json["creditAppId"]
        self.deal_ref_id = resp_json["dealRefId"]
        return resp_json

    def post_event(self):
        response = self.client.post(
            ENV_MAPPING[ENV]["events_url"],
            headers=self.get_events_headers(),
            data=self.get_events_request(),
            name="Post Event",
        )
        return response

    def on_start(self):
        self.env = ENV
        self.partner_dealer_id = ENV_MAPPING[self.env]["partner_dealer_id"]
        self.partner = ENV_MAPPING[self.env]["partner"]
        self.lender = ENV_MAPPING[self.env]["lender"]
        self.credit_app_id = ""
        self.deal_ref_id = ""
        self.unifi_dealer_code = ""
        self.uid = ulid.new().str
        self.events_url = ENV_MAPPING[self.env]["events_url"]

    @task(1)
    def get_lender_decision(self):
        self.create_credit_app()
        time.sleep(3)
        self.post_event()
        self.client.headers = self.get_deal_data_headers()
        time.sleep(3)
        response = self.client.get(
            f"v1/deals/{self.deal_ref_id}/partner-dealers/{self.partner_dealer_id}"
            f"/credit-apps/lenders/{self.lender}/decisions/latest",
            name="GetDecisions",
        )

        if response.status_code != 200:
            print(
                f"v1/deals/{self.deal_ref_id}/partner-dealers/{self.partner_dealer_id}/credit-apps/lenders/{self.lender}"
                f"/decisions/latest"
            )
            print(response.status_code)

    host = ENV_MAPPING[ENV]["deal_data_url"]
    wait_time = between(1, 3)


if __name__ == "__main__":
    d = Get_Decisions()
    d.run()
