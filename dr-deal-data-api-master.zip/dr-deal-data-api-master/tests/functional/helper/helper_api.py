# -*- coding: utf-8 -*-
from datetime import datetime
from http import HTTPStatus

from tests.functional.service_api import ServiceAPI


LEAD_ROUTE = "leads"
APP_ROUTE = "credit_app"
COPY_APP_ROUTE = "copy_credit_app"
CREATE_CONTRACT_ROUTE = "create_contract"
CONTRACT_STATUS_ROUTE = "contract_status"
CANCEL_CONTRACT_ROUTE = "cancel_contract"
VERIFY_CONTRACT_ROUTE = "verify_contract"


class HelperApi(ServiceAPI):
    def __init__(
        self, env, api_url, random_data_class, get_deal_component_details=None, **kwargs
    ):
        self.env = env
        self.api_url = api_url
        self.get_deal_component_details = get_deal_component_details
        self.resp_header = {}
        super().__init__(env=env, random_data_class=random_data_class)

    def create_lead(self, lead_file, expected_status=HTTPStatus.CREATED):
        # Add dealRefId in header - same value would be used for leadRefId
        fs_header_value = {
            "X-Deal-Reference-Id": self.generate_random_id(True),
            "X-Lead-Reference-Number": self.generate_random_id(True),
        }

        # Post Lead with FS IDs
        self.set_payload(lead_file)
        status_code, resp_body, self.resp_header = self.post_request(
            self.api_url, LEAD_ROUTE, cust_header=fs_header_value
        )

        if status_code != expected_status:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {resp_body}"
            )
        self.dealRefId = resp_body.get("dealRefId")

        # Verify leadRefId is saved in DB
        self.get_deal_component_details(
            deal_ref_id=self.dealRefId,
            deal_component="DTC.DEAL",
            additional_check_key="leadRefId",
            additional_check_value=self.dealRefId,
        )

    def create_credit_app(self, app_file, expected_status=HTTPStatus.CREATED):
        # Add dealRefId & creditAppId in header
        fs_header_value = {
            "X-Deal-Reference-Id": self.generate_random_id(True),
            "X-Credit-Application-Reference-Id": self.generate_random_id(True),
            "X-Deal-Jacket-ID": self.generate_random_id(True),
        }

        # Post a Credit App
        self.set_payload(app_file)
        status_code, resp_body, resp_header = self.post_request(
            self.api_url, APP_ROUTE, cust_header=fs_header_value
        )

        if status_code != expected_status:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {resp_body}"
            )
        self.dealRefId = resp_body.get("dealRefId")

        # Verify creditAppId is saved in DB
        self.get_deal_component_details(
            deal_ref_id=self.dealRefId,
            deal_component="DTC.DEAL",
            additional_check_key="creditAppId",
            additional_check_value=self.creditAppId,
        )

    def copy_credit_app(
        self,
        app_file=None,
        expected_status=HTTPStatus.CREATED,
        include_fs_headers=True,
        app_id=None,
    ):
        # Add creditAppId in header
        fs_header_value = {
            "X-Credit-Application-Reference-Id": app_id or self.generate_random_id(True)
        }

        # Copy Credit App
        if app_file:
            self.set_payload(app_file)
        status_code, resp_body, resp_header = self.put_request(
            self.api_url,
            COPY_APP_ROUTE,
            cust_header=fs_header_value if include_fs_headers else {},
        )

        if status_code != expected_status:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {resp_body}"
            )
        self.new_creditAppId = resp_body.get("creditAppId")

        if expected_status == HTTPStatus.CREATED:
            # Verify creditAppId is saved in DB
            self.get_deal_component_details(
                deal_ref_id=self.dealRefId,
                deal_component="REF_IDS.DTA",
                additional_check_key="creditAppId",
                additional_check_value=self.new_creditAppId,
            )

        return status_code, resp_body, resp_header

    def create_contract(
        self,
        contract_file,
        finance_type=None,
        expected_status=HTTPStatus.CREATED,
    ):
        finance_header = {"lenderId": "DT6"}

        # set contract payload
        self.set_payload(contract_file)

        # Update finance method
        if finance_type == "Cash":
            self.update_payload_to_cash()

        lender_header = {} if finance_type == "Cash" else finance_header

        # Posting Contract
        status_code, resp_body, self.resp_header = self.post_request(
            self.api_url, CREATE_CONTRACT_ROUTE, cust_header=lender_header
        )
        if status_code != expected_status:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {resp_body}"
            )
        self.contractRefId = resp_body.get("contractRefId")

        # Verify contractRefId is saved in DB
        self.get_deal_component_details(
            deal_ref_id=self.dealRefId,
            deal_component="DTC.DEAL",
            additional_check_key="contractRefId",
            additional_check_value=self.contractRefId,
        )

    def create_contract_status(
        self,
        payload,
        expected_status=HTTPStatus.ACCEPTED,
        expected_message=None,
        cust_header=None,
    ):
        expected_resp = expected_message or {"message": "Accepted"}
        # Contract Status
        self.payload = payload
        status_code, resp_body, self.resp_header = self.post_request(
            self.api_url, CONTRACT_STATUS_ROUTE, cust_header=cust_header
        )

        if status_code != expected_status:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {resp_body}"
            )
        assert (
            resp_body == expected_resp
        ), f"Response body is: {resp_body} and Expected body is: {expected_resp}"

    def cancel_contract(
        self,
        route=CANCEL_CONTRACT_ROUTE,
        expected_status=HTTPStatus.ACCEPTED,
        expected_message=None,
        cust_header={},
    ):
        expected_resp = expected_message or {"message": "Accepted"}

        status_code, cancel_resp, resp_headers = self.post_request(
            self.api_url, route, cust_header=cust_header
        )

        if status_code != expected_status:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {cancel_resp}"
            )
        assert (
            cancel_resp == expected_resp
        ), f"Expected {expected_resp} but api response {cancel_resp}"

        return status_code, cancel_resp, resp_headers

    def verify_contract(
        self,
        route=VERIFY_CONTRACT_ROUTE,
        expected_status=HTTPStatus.ACCEPTED,
        expected_message=None,
        cust_header={},
    ):
        expected_resp = expected_message or {"message": "Accepted"}

        status_code, verify_resp, resp_headers = self.post_request(
            self.api_url, route, cust_header=cust_header
        )

        if status_code != expected_status:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {verify_resp}"
            )
        assert (
            verify_resp == expected_resp
        ), f"Expected {expected_resp} but api response {verify_resp}"

        return status_code, verify_resp, resp_headers

    def update_payload_to_cash(self, request_type="app"):
        supported_type = {"app", "contract"}
        if request_type not in supported_type:
            raise Exception(f"Supported 'request_type' are {supported_type}")
        self.payload["financeMethod"] = "Cash"
        if request_type == "create_contract":
            self.payload["financeInformation"][
                "dateOfFirstPayment"
            ] = datetime.today().strftime("%Y-%m-%d")
            self.payload["financeInformation"]["term"] = 1
            self.payload["financeInformation"]["APR"] = 0
