# -*- coding: utf-8 -*-
import json
from http import HTTPStatus

import pytest
from tests.functional.service_api import ServiceAPI


LEAD_ROUTE = "leads"
CREATE_CONTRACT_ROUTE = "create_contract"
SIGN_CONTRACT_ROUTE = "sign_contract"

SIGNING_CUSTOMERS = [
    "applicant",
    "coApplicant",
    "dealer",
    "guarantorPrimary",
    "guarantorAdditional",
]


class TestContractSigningCashDeal:
    @classmethod
    @pytest.fixture(autouse=True)
    def setup_app_and_create_contract(
        cls,
        env,
        api_url,
        random_data_class,
        verify_contract_payload,
        get_deal_component_details,
    ):
        lead_file = "leads/ind_retail_new_no_income.json"
        contract_json_file = "contract/individual_retail_new.json"
        cls.deal_data = ServiceAPI(
            random_data_class=random_data_class, env=env, json_file=lead_file
        )

        # Add dealRefId & creditAppId in header
        fs_header_value = {
            "X-Deal-Reference-Id": cls.deal_data.generate_random_id(True),
            "X-Credit-Application-Reference-Id": cls.deal_data.generate_random_id(True),
            "X-Deal-Jacket-ID": cls.deal_data.generate_random_id(True),
        }

        # Post a lead
        status_code, lead_resp, resp_headers = cls.deal_data.post_request(
            api_url, LEAD_ROUTE, cust_header=fs_header_value
        )

        if status_code != HTTPStatus.CREATED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {lead_resp}"
            )
        cls.dealRefId = lead_resp["dealRefId"]

        get_deal_component_details(
            deal_ref_id=cls.deal_data.dealRefId, deal_component="DTC.DEAL"
        )

        # Posting Contract
        cls.deal_data.set_payload(contract_json_file)
        status_code, con_resp, resp_headers = cls.deal_data.post_request(
            api_url, CREATE_CONTRACT_ROUTE
        )

        if status_code != HTTPStatus.CREATED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {con_resp}"
            )

        # Confirm Contract is saved in DB
        get_deal_component_details(
            deal_ref_id=cls.deal_data.dealRefId,
            deal_component="DTC.DEAL",
            additional_check_key="contractRefId",
            additional_check_value=con_resp["contractRefId"],
        )

        # Since deal-data does not validate verify contract, we would skip the step and move on to sign contract

    @pytest.mark.smoke
    @pytest.mark.functional
    @pytest.mark.parametrize("signing_customer", SIGNING_CUSTOMERS)
    def test_contract_signing_post(
        self,
        api_url,
        assert_headers,
        signing_customer,
        signing_contract_payload,
        get_deal_component_details,
        verify_get_response_against_posted_data,
    ):
        signing_payload = signing_contract_payload([signing_customer])

        # Sign Contract
        self.deal_data.payload = signing_payload
        status_code, sign_resp, resp_headers = self.deal_data.post_request(
            api_url, SIGN_CONTRACT_ROUTE
        )

        if status_code != HTTPStatus.ACCEPTED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {sign_resp}"
            )
        assert sign_resp == {"message": "Accepted"}

        # Validate saved data from DB
        db_cust_data = get_deal_component_details(
            self.dealRefId, f"DTC.{signing_customer.upper()}"
        )
        db_data = get_deal_component_details(self.dealRefId, "DTC.DEAL")
        db_data[signing_customer] = db_cust_data

        verify_get_response_against_posted_data(json.loads(signing_payload), db_data)
        assert_headers(resp_headers)

    @pytest.mark.prod
    @pytest.mark.smoke
    @pytest.mark.functional
    def test_contract_signing_post_applicant_dealer(
        self,
        api_url,
        assert_headers,
        signing_contract_payload,
        get_deal_component_details,
        verify_get_response_against_posted_data,
    ):
        signing_payload = signing_contract_payload(["applicant", "dealer"])

        # Sign Contract
        self.deal_data.payload = signing_payload
        status_code, sign_resp, resp_headers = self.deal_data.post_request(
            api_url, SIGN_CONTRACT_ROUTE
        )

        if status_code != HTTPStatus.ACCEPTED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {sign_resp}"
            )
        assert sign_resp == {"message": "Accepted"}

        # Validate saved data from DB
        db_app_data = get_deal_component_details(self.dealRefId, "DTC.APPLICANT")
        db_dealer_data = get_deal_component_details(self.dealRefId, "DTC.DEALER")
        db_data = get_deal_component_details(self.dealRefId, "DTC.DEAL")
        db_data["applicant"] = db_app_data
        db_data["dealer"] = db_dealer_data

        verify_get_response_against_posted_data(json.loads(signing_payload), db_data)
        assert_headers(resp_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_contract_signing_post_max_payload(
        self,
        api_url,
        assert_headers,
        signing_contract_payload,
        get_deal_component_details,
        verify_get_response_against_posted_data,
    ):
        signing_payload = signing_contract_payload(
            [
                "applicant",
                "coApplicant",
                "dealer",
                "guarantorPrimary",
                "guarantorAdditional",
            ]
        )

        # Sign Contract
        self.deal_data.payload = signing_payload
        status_code, sign_resp, resp_headers = self.deal_data.post_request(
            api_url, SIGN_CONTRACT_ROUTE
        )

        if status_code != HTTPStatus.ACCEPTED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {sign_resp}"
            )
        assert sign_resp == {"message": "Accepted"}

        # Validate saved data from DB
        db_app_data = get_deal_component_details(self.dealRefId, "DTC.APPLICANT")
        db_coapp_data = get_deal_component_details(self.dealRefId, "DTC.COAPPLICANT")
        db_dealer_data = get_deal_component_details(self.dealRefId, "DTC.DEALER")
        db_guarantor_data = get_deal_component_details(
            self.dealRefId, "DTC.GUARANTORPRIMARY"
        )
        db_guarantor_additional_data = get_deal_component_details(
            self.dealRefId, "DTC.GUARANTORADDITIONAL"
        )
        db_data = get_deal_component_details(self.dealRefId, "DTC.DEAL")
        db_data["applicant"] = db_app_data
        db_data["coApplicant"] = db_coapp_data
        db_data["dealer"] = db_dealer_data
        db_data["guarantorPrimary"] = db_guarantor_data
        db_data["guarantorAdditional"] = db_guarantor_additional_data
        verify_get_response_against_posted_data(json.loads(signing_payload), db_data)
        assert_headers(resp_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_verify_signing_post_case_insensitive_lender_id(
        self,
        api_url,
        assert_headers,
        signing_contract_payload,
        get_deal_component_details,
        verify_get_response_against_posted_data,
    ):
        signing_payload = signing_contract_payload(["coApplicant", "dealer"])

        # Sign Contract
        self.deal_data.payload = signing_payload
        status_code, sign_resp, resp_headers = self.deal_data.post_request(
            api_url, SIGN_CONTRACT_ROUTE, cust_header={"lenderId": "boa"}
        )

        if status_code != HTTPStatus.ACCEPTED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {sign_resp}"
            )
        assert sign_resp == {"message": "Accepted"}

        # Confirm Contract is saved in DB
        get_deal_component_details(
            deal_ref_id=self.deal_data.dealRefId,
            deal_component="DTC.DEAL",
            additional_check_key="lenderId",
            additional_check_value="boa",
        )

        # Validate saved data from DB
        db_coapp_data = get_deal_component_details(self.dealRefId, "DTC.COAPPLICANT")
        db_dealer_data = get_deal_component_details(self.dealRefId, "DTC.DEALER")
        db_data = get_deal_component_details(self.dealRefId, "DTC.DEAL")

        db_data["coApplicant"] = db_coapp_data
        db_data["dealer"] = db_dealer_data

        verify_get_response_against_posted_data(json.loads(signing_payload), db_data)
        assert_headers(resp_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_contract_sign_multiple_posts(
        self,
        api_url,
        assert_headers,
        signing_contract_payload,
        get_deal_component_details,
        verify_get_response_against_posted_data,
    ):

        # post to signing API multiple times
        for customer in SIGNING_CUSTOMERS:
            # Sign Contract
            signing_payload = signing_contract_payload([customer])
            self.deal_data.payload = signing_payload
            status_code, sign_resp, resp_headers = self.deal_data.post_request(
                api_url, SIGN_CONTRACT_ROUTE
            )

            if status_code != HTTPStatus.ACCEPTED:
                raise Exception(
                    f"Response code is: {status_code} and the response message is: {sign_resp}"
                )
            assert sign_resp == {"message": "Accepted"}

            # Confirm data is saved in DB
            customer_data = get_deal_component_details(
                self.deal_data.dealRefId, deal_component=f"DTC.{customer.upper()}"
            )
            deal_data = get_deal_component_details(
                self.deal_data.dealRefId, deal_component="DTC.DEAL"
            )

            deal_data[customer] = customer_data

            verify_get_response_against_posted_data(
                json.loads(signing_payload), deal_data
            )
            assert_headers(resp_headers)

    reference_ids = ["dealRefId", "contractRefId"]

    @pytest.mark.smoke
    @pytest.mark.functional
    @pytest.mark.parametrize("reference_id", reference_ids)
    def test_signing_contract_missing_reference_id_single_response(
        self,
        api_url,
        reference_id,
        assert_headers,
        signing_contract_payload,
        missing_reference_ids_response,
    ):

        # Sign Contract
        self.deal_data.payload = signing_contract_payload(["applicant"])
        setattr(self.deal_data, reference_id, "")
        status_code, sign_resp, resp_headers = self.deal_data.post_request(
            api_url, SIGN_CONTRACT_ROUTE
        )

        if status_code != HTTPStatus.BAD_REQUEST:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {sign_resp}"
            )
        assert sign_resp == missing_reference_ids_response(field_list=[reference_id])

        assert_headers(resp_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_signing_contract_missing_multiple_reference_ids_response(
        self,
        api_url,
        assert_headers,
        signing_contract_payload,
        missing_reference_ids_response,
    ):
        # Signing Contract
        self.deal_data.payload = signing_contract_payload(["applicant"])
        self.deal_data.dealRefId = ""
        self.deal_data.contractRefId = ""
        status_code, sign_resp, resp_headers = self.deal_data.post_request(
            api_url, SIGN_CONTRACT_ROUTE
        )

        if status_code != HTTPStatus.BAD_REQUEST:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {sign_resp}"
            )

        expected_resp = missing_reference_ids_response(
            field_list=["dealRefId", "contractRefId"]
        )

        assert expected_resp[0]["code"] == sign_resp[0]["code"]
        assert sorted(
            expected_resp[0]["properties"], key=lambda ele: sorted(ele.items())
        ) == sorted(sign_resp[0]["properties"], key=lambda ele: sorted(ele.items()))

        assert_headers(resp_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_signing_contract_invalid_deal_ref_id(
        self,
        api_url,
        assert_headers,
        signing_contract_payload,
        invalid_deal_ref_id_response,
    ):

        # Signing Contract
        self.deal_data.payload = signing_contract_payload(["applicant"])
        self.deal_data.dealRefId = self.deal_data.generate_random_id(True)
        status_code, sign_resp, resp_headers = self.deal_data.post_request(
            api_url, SIGN_CONTRACT_ROUTE
        )

        if status_code != HTTPStatus.BAD_REQUEST:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {sign_resp}"
            )
        assert sign_resp == invalid_deal_ref_id_response(self.deal_data.dealRefId)

        assert_headers(resp_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_signing_contract_invalid_contract_ref_id_single(
        self,
        api_url,
        assert_headers,
        signing_contract_payload,
        invalid_reference_ids_response,
    ):

        reference_id = "contractRefId"
        # Sign Contract
        self.deal_data.payload = signing_contract_payload(["applicant"])
        invalid_id = self.deal_data.generate_random_id(True)
        setattr(self.deal_data, reference_id, invalid_id)
        status_code, sign_resp, resp_headers = self.deal_data.post_request(
            api_url, SIGN_CONTRACT_ROUTE
        )

        if status_code != HTTPStatus.BAD_REQUEST:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {sign_resp}"
            )
        assert sign_resp == invalid_reference_ids_response(
            self.dealRefId, {reference_id: invalid_id}
        )

        assert_headers(resp_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_signing_missing_request_payload(
        self, api_url, assert_headers, missing_payload_response
    ):

        # Signing Contract
        self.deal_data.payload = ""
        status_code, sign_resp, resp_headers = self.deal_data.post_request(
            api_url, SIGN_CONTRACT_ROUTE
        )

        if status_code != HTTPStatus.BAD_REQUEST:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {sign_resp}"
            )
        assert sign_resp == missing_payload_response
        assert_headers(resp_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_signing_contract_invalid_payload(
        self, api_url, assert_headers, invalid_payload
    ):

        # Sign Contract
        self.deal_data.payload = invalid_payload
        status_code, sign_resp, resp_headers = self.deal_data.post_request(
            api_url, SIGN_CONTRACT_ROUTE
        )

        if status_code != HTTPStatus.BAD_REQUEST:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {sign_resp}"
            )

        assert_headers(resp_headers)
