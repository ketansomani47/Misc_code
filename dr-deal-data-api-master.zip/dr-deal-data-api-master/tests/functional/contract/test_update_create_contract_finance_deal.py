# -*- coding: utf-8 -*-
from http import HTTPStatus

import pytest
from tests.functional.service_api import ServiceAPI


APP_ROUTE = "credit_app"
CONTRACT_ROUTE = "create_contract"
UPDATE_CONTRACT_ROUTE = "update_contract"


class TestContractPatchFinanceDeal:
    @classmethod
    @pytest.fixture(autouse=True)
    def setup_contract(
        cls,
        env,
        api_url,
        random_data_class,
        get_deal_updated_timestamp,
        query_dynamodb_for_specified_key,
        query_dynamodb_with_deal_component,
    ):
        cls.api_url = api_url
        cls.contract_timestamp = None

        ca_test_data = "credit_app/app_min_data.json"
        cls.deal_data = ServiceAPI(
            random_data_class=random_data_class, env=env, json_file=ca_test_data
        )
        # Add dealRefId & DJ Id in header
        fs_header_value = {
            "X-Deal-Reference-Id": cls.deal_data.generate_random_id(True),
            "X-Deal-Jacket-ID": cls.deal_data.generate_random_id(True),
        }

        # Post a Credit App
        status_code, app_resp, resp_headers = cls.deal_data.post_request(
            url=api_url, route_url=APP_ROUTE, cust_header=fs_header_value
        )

        if status_code != HTTPStatus.CREATED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {app_resp}"
            )
        cls.dealRefId = app_resp["dealRefId"]

        app_timestamp = get_deal_updated_timestamp(deal_ref_id=cls.dealRefId)

        # Create Contract
        contract_json_file = "contract/individual_retail_new_min_data.json"

        # Posting initial Contract
        cls.deal_data.set_payload(contract_json_file)
        status_code, con_resp, resp_headers = cls.deal_data.post_request(
            url=api_url,
            route_url=CONTRACT_ROUTE,
        )

        if status_code != HTTPStatus.CREATED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {con_resp}"
            )

        contract_ref_id = query_dynamodb_for_specified_key(
            cls.dealRefId, "contractRefId"
        )
        assert con_resp["contractRefId"] == contract_ref_id

        cls.contract_timestamp = get_deal_updated_timestamp(
            cls.dealRefId, updated_timestamp=app_timestamp
        )
        assert cls.contract_timestamp > app_timestamp

    test_data = [
        "individual_retail_new_min_data.json",
        "joint_retail_used.json",
        "individual_retail_cert_trade.json",
        "individual_retail_used_extradata.json",
        "individual_retail_used_multiple_trades.json",
        "joint_retail_demo_spouse.json",
        "joint_retail_new_max_data_pre_add_pre_emp.json",
        "individual_retail_used_max_fees.json",
        "individual_retail_used_max_taxes.json",
        "individual_retail_used_max_products.json",
    ]

    @pytest.mark.smoke
    @pytest.mark.functional
    @pytest.mark.parametrize("contract_json", test_data)
    def test_update_contract_post_for_a_finance_deal(
        self,
        contract_json,
        assert_headers,
        verify_deal_component,
        get_deal_updated_timestamp,
        get_records_by_deal_ref_id,
        verify_deal_component_protected,
        query_dynamodb_for_specified_key,
    ):
        # Update/Patch Contract for Re-verification
        contract_json_file = f"contract/{contract_json}"
        self.deal_data.set_payload(contract_json_file)
        status_code, con_resp, resp_headers = self.deal_data.patch(
            url=self.api_url, route_url=UPDATE_CONTRACT_ROUTE
        )

        if status_code != HTTPStatus.ACCEPTED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {con_resp}"
            )

        update_contract_timestamp = get_deal_updated_timestamp(
            deal_ref_id=self.dealRefId, updated_timestamp=self.contract_timestamp
        )
        assert update_contract_timestamp > self.contract_timestamp

        records, count = get_records_by_deal_ref_id(self.dealRefId)
        assert_headers(resp_headers)
        verify_deal_component(records, self.deal_data.payload, "applicant")
        verify_deal_component_protected(records, self.deal_data.payload, "applicant")
        if self.deal_data.payload.get("coApplicant"):
            verify_deal_component(records, self.deal_data.payload, "coApplicant")
            verify_deal_component_protected(
                records, self.deal_data.payload, "coApplicant"
            )

    @pytest.mark.prod
    @pytest.mark.functional
    def test_update_contract_post_ind_finance_new(
        self,
        assert_headers,
        get_response_data,
        verify_deal_component,
        get_deal_updated_timestamp,
        get_records_by_deal_ref_id,
        verify_deal_component_protected,
        query_dynamodb_for_specified_key,
    ):
        # Update/Patch Contract for Re-verification
        contract_json_file = "contract/individual_retail_new.json"
        self.deal_data.set_payload(contract_json_file)
        # Update dealRefIdFD in payload
        self.deal_data.payload["dealRefIdFD"] = self.deal_data.generate_random_id(True)
        status_code, con_resp, resp_headers = self.deal_data.patch(
            url=self.api_url, route_url=UPDATE_CONTRACT_ROUTE
        )

        if status_code != HTTPStatus.ACCEPTED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {con_resp}"
            )

        update_contract_timestamp = get_deal_updated_timestamp(
            deal_ref_id=self.dealRefId, updated_timestamp=self.contract_timestamp
        )
        assert update_contract_timestamp > self.contract_timestamp

        records, count = get_records_by_deal_ref_id(self.dealRefId)
        assert_headers(resp_headers)
        verify_deal_component(records, self.deal_data.payload, "applicant")
        verify_deal_component_protected(records, self.deal_data.payload, "applicant")
        deal_resp = get_response_data(records, "DEAL")
        assert "dealRefIdFD" not in deal_resp

    @pytest.mark.prod
    @pytest.mark.smoke
    @pytest.mark.functional
    def test_contract_post_for_a_finance_deal_with_lender_id(
        self,
        assert_headers,
        verify_deal_component,
        get_deal_updated_timestamp,
        get_records_by_deal_ref_id,
        verify_deal_component_protected,
        query_dynamodb_for_specified_key,
    ):
        # Posting Contract
        lender_header = {"lenderId": "DTH"}
        contract_json_file = "contract/individual_retail_new.json"
        self.deal_data.set_payload(contract_json_file)
        status_code, con_resp, resp_headers = self.deal_data.patch(
            url=self.api_url,
            route_url=UPDATE_CONTRACT_ROUTE,
            cust_header=lender_header,
        )

        if status_code != HTTPStatus.ACCEPTED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {con_resp}"
            )

        update_contract_timestamp = get_deal_updated_timestamp(
            deal_ref_id=self.dealRefId, updated_timestamp=self.contract_timestamp
        )
        assert update_contract_timestamp > self.contract_timestamp

        records, count = get_records_by_deal_ref_id(self.dealRefId)
        assert_headers(resp_headers)
        verify_deal_component(records, self.deal_data.payload, "applicant")
        verify_deal_component_protected(records, self.deal_data.payload, "applicant")

    lender_id_headers = [{"lenderId": ""}, {}]

    @pytest.mark.smoke
    @pytest.mark.functional
    @pytest.mark.parametrize("lender_id_header", lender_id_headers)
    def test_contract_post_for_a_finance_deal_with_empty_lender_id(
        self,
        assert_headers,
        lender_id_header,
        verify_deal_component,
        get_deal_updated_timestamp,
        get_records_by_deal_ref_id,
        verify_deal_component_protected,
        query_dynamodb_for_specified_key,
    ):
        # Posting Contract
        contract_json_file = "contract/individual_retail_new.json"
        self.deal_data.set_payload(contract_json_file)
        status_code, con_resp, resp_headers = self.deal_data.patch(
            url=self.api_url,
            route_url=UPDATE_CONTRACT_ROUTE,
            cust_header=lender_id_header,
        )

        if status_code != HTTPStatus.ACCEPTED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {con_resp}"
            )

        update_contract_timestamp = get_deal_updated_timestamp(
            deal_ref_id=self.dealRefId, updated_timestamp=self.contract_timestamp
        )
        assert update_contract_timestamp > self.contract_timestamp

        records, count = get_records_by_deal_ref_id(self.dealRefId)
        assert_headers(resp_headers)
        verify_deal_component(records, self.deal_data.payload, "applicant")
        verify_deal_component_protected(records, self.deal_data.payload, "applicant")
