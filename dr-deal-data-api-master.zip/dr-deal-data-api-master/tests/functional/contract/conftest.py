# -*- coding: utf-8 -*-
import logging

import pytest


log = logging.getLogger(__name__)


@pytest.fixture()
def dealxg_create_contract_payload():
    """
    Create Contract Payload for DealXG
    :return: payload
    """

    def wrapper(finance_method, target_id):
        finance_methods = ["Finance", "Cash"]
        target_ids = ["DTC", "IDL"]
        if finance_method not in finance_methods:
            raise Exception(
                f"Provided financeMethod {finance_method} is not supported. Valid values are {finance_methods}"
            )
        if target_id not in target_ids:
            raise Exception(
                f"Provided target_id {target_id} is not supported. Valid values are {target_ids}"
            )

        return {
            "financeMethod": finance_method,
            "sourcePartnerId": "DXR",
            "targetPlatforms": [{"id": target_id, "partyId": "100025"}],
        }

    return wrapper


@pytest.fixture()
def dealxg_invalid_payload():
    """
    This is an invalid json payload that is used to validate
    error message handling from Deal Data API
    :return: Payload
    """
    return """
        "sourcePartnerId": "DXR",
        "targetPlatforms": [
            {
                "id": "DTX",
                "partyId": "1234"
            }
        ],
        "financeMethod": "Finance",
    }
    """


@pytest.fixture()
def validate_data_updated_for_dtc(get_deal_component_details):
    def wrapper(deal_ref_id, requ_payload, key_name):
        """
        For a deal that has simple payload like verify, cancel, and status update, the data is saved under deal.dtc record
        For these apis only, validate the data is updated successfully
        """
        db_record = get_deal_component_details(
            deal_ref_id=deal_ref_id,
            deal_component="DTC.DEAL",
            additional_check_key=key_name,
            additional_check_value=requ_payload[key_name],
        )
        for field in requ_payload:
            assert requ_payload[field] == db_record[field]

    return wrapper
