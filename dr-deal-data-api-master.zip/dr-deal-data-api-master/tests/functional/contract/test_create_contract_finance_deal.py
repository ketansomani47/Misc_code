# -*- coding: utf-8 -*-
from http import HTTPStatus

import pytest
from tests.functional.helper.helper_api import HelperApi


CONTRACT_ROUTE = "create_contract"


class TestContractPostFinanceDeal:
    @classmethod
    @pytest.fixture(autouse=True)
    def setup_credit_app(
        cls,
        env,
        api_url,
        random_data_class,
        get_deal_component_details,
    ):
        cls.api_url = api_url
        cls.helper = HelperApi(
            env=env,
            api_url=api_url,
            random_data_class=random_data_class,
            get_deal_component_details=get_deal_component_details,
        )
        ca_test_data = "credit_app/app_min_data.json"
        cls.helper.create_credit_app(app_file=ca_test_data)

    test_data = [
        "individual_retail_new_min_data.json",
        "joint_retail_used.json",
        "individual_retail_cert_trade.json",
        "individual_retail_used_extradata.json",
        "individual_retail_used_multiple_trades.json",
        "joint_retail_demo_spouse.json",
        "joint_retail_new_max_data_pre_add_pre_emp.json",
        "individual_retail_used_max_fees.json",
        "individual_retail_used_max_taxes.json",
        "individual_retail_used_max_products.json",
    ]

    @pytest.mark.prod
    @pytest.mark.smoke
    @pytest.mark.functional
    @pytest.mark.parametrize("contract_json", test_data)
    def test_contract_post_for_a_finance_deal(
        self,
        contract_json,
        assert_headers,
        verify_deal_component,
        get_records_by_deal_ref_id,
        get_deal_component_details,
        verify_deal_component_protected,
    ):
        contract_json_file = f"contract/{contract_json}"

        # Posting Contract
        lender_header = {"lenderId": "BOA"}
        self.helper.set_payload(contract_json_file)
        status_code, con_resp, resp_headers = self.helper.post_request(
            self.api_url, CONTRACT_ROUTE, cust_header=lender_header
        )

        if status_code != HTTPStatus.CREATED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {con_resp}"
            )

        # Verify contractRefId is saved in DB
        get_deal_component_details(
            deal_ref_id=self.helper.dealRefId,
            deal_component="DTC.DEAL",
            additional_check_key="contractRefId",
            additional_check_value=con_resp["contractRefId"],
        )
        assert_headers(resp_headers)

        records, count = get_records_by_deal_ref_id(self.helper.dealRefId)
        verify_deal_component(records, self.helper.payload, "applicant")
        verify_deal_component_protected(records, self.helper.payload, "applicant")
        if self.helper.payload.get("coApplicant"):
            verify_deal_component(records, self.helper.payload, "coApplicant")
            verify_deal_component_protected(records, self.helper.payload, "coApplicant")

    @pytest.mark.prod
    @pytest.mark.functional
    def test_contract_post_ind_retail_new(
        self,
        assert_headers,
        get_response_data,
        verify_deal_component,
        get_records_by_deal_ref_id,
        get_deal_component_details,
        verify_deal_component_protected,
    ):
        contract_json_file = "contract/individual_retail_new.json"

        # Posting Contract
        lender_header = {"lenderId": "BOA"}
        self.helper.set_payload(contract_json_file)
        # Update dealRefIdFD in payload
        self.helper.payload["dealRefIdFD"] = self.helper.generate_random_id(True)
        status_code, con_resp, resp_headers = self.helper.post_request(
            self.api_url, CONTRACT_ROUTE, cust_header=lender_header
        )

        if status_code != HTTPStatus.CREATED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {con_resp}"
            )

        # Verify contractRefId is saved in DB
        deal_record = get_deal_component_details(
            deal_ref_id=self.helper.dealRefId,
            deal_component="DTC.DEAL",
            additional_check_key="contractRefId",
            additional_check_value=con_resp["contractRefId"],
        )
        assert_headers(resp_headers)
        assert "dealRefIdFD" not in deal_record

        records, count = get_records_by_deal_ref_id(self.helper.dealRefId)
        verify_deal_component(records, self.helper.payload, "applicant")
        verify_deal_component_protected(records, self.helper.payload, "applicant")

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_contract_post_with_invalid_deal_ref_id(
        self,
    ):
        # Update dealRefId
        self.helper.dealRefId = self.helper.generate_random_id(True)

        # Posting Contract
        lender_header = {"lenderId": "BOA"}
        contract_json_file = "contract/individual_retail_new.json"
        self.helper.set_payload(contract_json_file)
        status_code, con_resp, resp_headers = self.helper.post_request(
            self.api_url, CONTRACT_ROUTE, cust_header=lender_header
        )

        if status_code != HTTPStatus.BAD_REQUEST:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {con_resp}"
            )

        assert con_resp.get("message") == f"No deal found for {self.helper.dealRefId}"
        assert resp_headers.get("X-CoxAuto-Correlation-Id") is not None

    lender_id_headers = [{"lenderId": ""}, {}]

    @pytest.mark.smoke
    @pytest.mark.functional
    @pytest.mark.parametrize("lender_id_header", lender_id_headers)
    def test_contract_post_with_empty_lender_id_in_header(
        self,
        assert_headers,
        lender_id_header,
        verify_deal_component,
        get_records_by_deal_ref_id,
        get_deal_component_details,
        verify_deal_component_protected,
    ):
        contract_json_file = "contract/individual_retail_new.json"

        # Posting Contract
        self.helper.set_payload(contract_json_file)
        status_code, con_resp, resp_headers = self.helper.post_request(
            self.api_url, CONTRACT_ROUTE, cust_header=lender_id_header
        )

        if status_code != HTTPStatus.CREATED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {con_resp}"
            )

        # Verify contractRefId is saved in DB
        get_deal_component_details(
            deal_ref_id=self.helper.dealRefId,
            deal_component="DTC.DEAL",
            additional_check_key="contractRefId",
            additional_check_value=con_resp["contractRefId"],
        )
        assert_headers(resp_headers)

        records, count = get_records_by_deal_ref_id(self.helper.dealRefId)
        verify_deal_component(records, self.helper.payload, "applicant")
        verify_deal_component_protected(records, self.helper.payload, "applicant")

    @pytest.mark.functional
    def test_duplicate_contract_post(
        self,
        get_deal_component_details,
    ):
        contract_json_file = "contract/individual_retail_new.json"

        # Posting First Contract
        lender_header = {"lenderId": "BOA"}
        self.helper.set_payload(contract_json_file)
        status_code, con_resp, resp_headers = self.helper.post_request(
            self.api_url, CONTRACT_ROUTE, cust_header=lender_header
        )

        if status_code != HTTPStatus.CREATED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {con_resp}"
            )

        # Verify contractRefId is saved in DB
        get_deal_component_details(
            deal_ref_id=self.helper.dealRefId,
            deal_component="DTC.DEAL",
            additional_check_key="contractRefId",
            additional_check_value=con_resp["contractRefId"],
        )

        # Posting Second Contract using same dealRefId
        lender_header = {"lenderId": "BOA"}
        self.helper.set_payload(contract_json_file)
        status_code, con_resp, resp_headers = self.helper.post_request(
            self.api_url, CONTRACT_ROUTE, cust_header=lender_header
        )

        if status_code != HTTPStatus.BAD_REQUEST:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {con_resp}"
            )

        assert (
            con_resp.get("message")
            == "You have tired to post to an endpoint for which the resource already exists."
        )

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_contract_post_with_invalid_test_data(
        self,
        invalid_payload,
    ):
        # Posting Contract
        lender_header = {"lenderId": "BOA"}
        self.helper.payload = invalid_payload
        status_code, con_resp, resp_headers = self.helper.post_request(
            self.api_url, CONTRACT_ROUTE, cust_header=lender_header
        )

        if status_code != HTTPStatus.BAD_REQUEST:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {con_resp}"
            )

        assert status_code == HTTPStatus.BAD_REQUEST
        assert resp_headers.get("X-CoxAuto-Correlation-Id") is not None

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_contract_post_with_source_partner_dealer_id(
        self,
        get_deal_component_details,
    ):
        ca_party_id = self.helper.payload["targetPlatforms"][0]["partyId"]
        contract_json_file = "contract/individual_retail_cert_trade.json"

        # Posting Contract
        lender_header = {"lenderId": "BOA"}
        self.helper.set_payload(contract_json_file)
        # remove sourcePartnerDealerId from payload if present
        self.helper.payload.pop("sourcePartnerDealerId", None)
        status_code, con_resp, resp_headers = self.helper.post_request(
            self.api_url, CONTRACT_ROUTE, cust_header=lender_header
        )

        if status_code != HTTPStatus.CREATED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {con_resp}"
            )

        # Verify contractRefId is saved in DB
        deal_record = get_deal_component_details(
            deal_ref_id=self.helper.dealRefId,
            deal_component="DTC.DEAL",
            additional_check_key="contractRefId",
            additional_check_value=con_resp["contractRefId"],
        )

        # partyId from targetPlatforms
        assert deal_record.get("sourcePartnerDealerId") == ca_party_id
