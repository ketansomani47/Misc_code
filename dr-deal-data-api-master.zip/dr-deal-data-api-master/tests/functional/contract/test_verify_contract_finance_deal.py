# -*- coding: utf-8 -*-
import random
import string
import time
from http import HTTPStatus

import pytest
from tests.functional.helper.helper_api import HelperApi


APP_ROUTE = "credit_app"
CREATE_CONTRACT_ROUTE = "create_contract"
VERIFY_CONTRACT_ROUTE = "verify_contract"

FINANCE_LENDER = {"lenderId": "DT6"}


class TestVerifyContractFinanceDeal:
    @classmethod
    @pytest.fixture(autouse=True)
    def setup_app_and_contract(
        cls,
        env,
        api_url,
        random_data_class,
        get_deal_component_details,
    ):
        cls.api_url = api_url
        cls.helper = HelperApi(
            env=env,
            api_url=api_url,
            random_data_class=random_data_class,
            get_deal_component_details=get_deal_component_details,
        )
        cls.get_deal_component_details = get_deal_component_details
        cls.create_app_and_contract()

    def create_app_and_contract(self):
        self.helper.create_credit_app(app_file="credit_app/ind_retail_new.json")
        self.helper.create_contract(contract_file="contract/individual_retail_new.json")

    @pytest.mark.prod
    @pytest.mark.smoke
    @pytest.mark.functional
    def test_contract_verify_post(
        self,
        assert_headers,
        verify_contract_payload,
        validate_data_updated_for_dtc,
    ):

        # Verify Contract
        self.helper.payload = verify_contract_payload
        status_code, verify_resp, resp_headers = self.helper.verify_contract(
            cust_header=FINANCE_LENDER
        )

        # Confirm verify contract data is saved in DB
        validate_data_updated_for_dtc(
            deal_ref_id=self.helper.dealRefId,
            requ_payload=self.helper.payload,
            key_name="sourcePartnerId",
        )
        assert_headers(resp_headers)

    @pytest.mark.functional
    def test_verify_contract_post_case_insensitive_lender_id(
        self,
        assert_headers,
        verify_contract_payload,
        validate_data_updated_for_dtc,
    ):
        # Verify Contract
        lender_header = {"lenderId": "dt6"}
        self.helper.payload = verify_contract_payload
        status_code, verify_resp, resp_headers = self.helper.verify_contract(
            cust_header=lender_header
        )
        # Confirm verify contract data is saved in DB
        validate_data_updated_for_dtc(
            deal_ref_id=self.helper.dealRefId,
            requ_payload=self.helper.payload,
            key_name="sourcePartnerId",
        )
        assert_headers(resp_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_contract_verify_multiple_posts(
        self,
        assert_headers,
        verify_contract_payload,
        validate_data_updated_for_dtc,
    ):
        # Verify Contract
        self.helper.payload = verify_contract_payload
        for i in range(5):
            time.sleep(2)
            self.helper.payload["sourcePartnerId"] = "".join(
                random.choices(string.ascii_uppercase, k=3)
            )
            status_code, verify_resp, resp_headers = self.helper.verify_contract(
                cust_header=FINANCE_LENDER
            )
            # Confirm contract cancel data is saved in DB
            validate_data_updated_for_dtc(
                deal_ref_id=self.helper.dealRefId,
                requ_payload=self.helper.payload,
                key_name="sourcePartnerId",
            )
            assert_headers(resp_headers)

    reference_ids = ["dealRefId", "contractRefId"]

    @pytest.mark.smoke
    @pytest.mark.functional
    @pytest.mark.parametrize("reference_id", reference_ids)
    def test_verify_contract_missing_reference_id_single_response(
        self,
        reference_id,
        assert_headers,
        verify_contract_payload,
        missing_reference_ids_response,
    ):
        # Verify Contract
        self.helper.payload = verify_contract_payload
        setattr(self.helper, reference_id, "")
        expected_resp = missing_reference_ids_response(field_list=[reference_id])
        status_code, verify_resp, resp_headers = self.helper.verify_contract(
            expected_status=HTTPStatus.BAD_REQUEST,
            expected_message=expected_resp,
            cust_header=FINANCE_LENDER,
        )
        assert_headers(resp_headers)

    lender_id_headers = [{"lenderId": ""}, {}]

    @pytest.mark.functional
    @pytest.mark.parametrize("lender_id_header", lender_id_headers)
    def test_verify_contract_with_empty_lender_id_in_header(
        self,
        assert_headers,
        lender_id_header,
        verify_contract_payload,
        validate_data_updated_for_dtc,
    ):
        # Verify Contract
        self.helper.payload = verify_contract_payload
        status_code, verify_resp, resp_headers = self.helper.verify_contract(
            cust_header=lender_id_header
        )

        # Confirm contract cancel data is saved in DB
        validate_data_updated_for_dtc(
            deal_ref_id=self.helper.dealRefId,
            requ_payload=self.helper.payload,
            key_name="sourcePartnerId",
        )
        assert_headers(resp_headers)

    @pytest.mark.functional
    def test_verify_contract_missing_multiple_reference_ids_response(
        self,
        assert_headers,
        verify_contract_payload,
        missing_reference_ids_response,
    ):
        # Verify Contract
        self.helper.payload = verify_contract_payload
        self.helper.dealRefId = ""
        self.helper.contractRefId = ""
        expected_resp = missing_reference_ids_response(
            field_list=["dealRefId", "contractRefId"]
        )
        status_code, verify_resp, resp_headers = self.helper.verify_contract(
            expected_status=HTTPStatus.BAD_REQUEST,
            expected_message=expected_resp,
            cust_header=FINANCE_LENDER,
        )
        assert_headers(resp_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_verify_contract_invalid_deal_ref_id(
        self,
        assert_headers,
        verify_contract_payload,
        invalid_deal_ref_id_response,
    ):
        # Verify Contract
        self.helper.payload = verify_contract_payload
        self.helper.dealRefId = self.helper.generate_random_id(True)
        expected_resp = invalid_deal_ref_id_response(self.helper.dealRefId)
        status_code, verify_resp, resp_headers = self.helper.verify_contract(
            expected_status=HTTPStatus.BAD_REQUEST,
            expected_message=expected_resp,
            cust_header=FINANCE_LENDER,
        )

        assert_headers(resp_headers)

    @pytest.mark.functional
    def test_verify_contract_invalid_contract_ref_id_single(
        self,
        assert_headers,
        verify_contract_payload,
        invalid_reference_ids_response,
    ):
        ref_id_field = "contractRefId"

        # Verify Contract
        self.helper.payload = verify_contract_payload
        invalid_id = self.helper.generate_random_id(True)
        setattr(self.helper, ref_id_field, invalid_id)
        expected_resp = invalid_reference_ids_response(
            self.helper.dealRefId, {ref_id_field: invalid_id}
        )
        status_code, verify_resp, resp_headers = self.helper.verify_contract(
            expected_status=HTTPStatus.BAD_REQUEST,
            expected_message=expected_resp,
            cust_header=FINANCE_LENDER,
        )
        assert_headers(resp_headers)

    @pytest.mark.functional
    def test_verify_missing_request_payload(
        self,
        assert_headers,
        missing_payload_response,
    ):
        # Verify Contract
        self.helper.payload = ""
        status_code, verify_resp, resp_headers = self.helper.verify_contract(
            expected_status=HTTPStatus.BAD_REQUEST,
            expected_message=missing_payload_response,
            cust_header=FINANCE_LENDER,
        )
        assert_headers(resp_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_verify_contract_invalid_payload(
        self,
        assert_headers,
        invalid_payload,
    ):
        # Verify Contract
        expected_resp = {"message": "Extra data: line 2 column 26 (char 26)"}
        self.helper.payload = invalid_payload
        status_code, verify_resp, resp_headers = self.helper.verify_contract(
            expected_status=HTTPStatus.BAD_REQUEST,
            expected_message=expected_resp,
            cust_header=FINANCE_LENDER,
        )
        assert_headers(resp_headers)
