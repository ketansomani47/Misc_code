# -*- coding: utf-8 -*-
import pytest
from tests.functional.helper.helper_api import HelperApi


class TestCancelContractCashDeal:
    @classmethod
    @pytest.fixture(autouse=True)
    def setup_lead_and_contract(
        cls, env, api_url, random_data_class, get_deal_component_details
    ):
        cls.api_url = api_url
        cls.helper = HelperApi(
            env=env,
            api_url=api_url,
            random_data_class=random_data_class,
            get_deal_component_details=get_deal_component_details,
        )
        cls.get_deal_component_details = get_deal_component_details
        cls.create_lead_and_contract()

    def create_lead_and_contract(self):
        self.helper.create_lead(lead_file="leads/leads_min_data.json")
        self.helper.create_contract(
            contract_file="contract/individual_retail_new.json", finance_type="Cash"
        )

    @pytest.mark.prod
    @pytest.mark.smoke
    @pytest.mark.functional
    def test_contract_cancel_post_cash(
        self,
        assert_headers,
        cancel_contract_payload,
        validate_data_updated_for_dtc,
    ):
        # cancel Contract
        self.helper.payload = cancel_contract_payload
        status_code, cancel_resp, resp_headers = self.helper.cancel_contract()

        # Confirm contract cancel data is saved in DB
        validate_data_updated_for_dtc(
            deal_ref_id=self.helper.dealRefId,
            requ_payload=self.helper.payload,
            key_name="sourcePartnerId",
        )
        assert_headers(resp_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_cancel_contract_post_with_lender_id(
        self,
        assert_headers,
        cancel_contract_payload,
        validate_data_updated_for_dtc,
    ):
        # cancel Contract
        lender_header = {"lenderId": "DTH"}
        self.helper.payload = cancel_contract_payload
        status_code, cancel_resp, resp_headers = self.helper.cancel_contract(
            cust_header=lender_header
        )

        # Confirm contract cancel data is saved in DB
        validate_data_updated_for_dtc(
            deal_ref_id=self.helper.dealRefId,
            requ_payload=self.helper.payload,
            key_name="sourcePartnerId",
        )
        assert_headers(resp_headers)
