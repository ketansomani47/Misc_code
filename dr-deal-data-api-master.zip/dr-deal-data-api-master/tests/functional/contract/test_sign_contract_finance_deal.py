# -*- coding: utf-8 -*-
import json
from http import HTTPStatus

import pytest
from tests.functional.service_api import ServiceAPI


APP_ROUTE = "credit_app"
CREATE_CONTRACT_ROUTE = "create_contract"
SIGN_CONTRACT_ROUTE = "sign_contract"

SIGNING_CUSTOMERS = [
    "applicant",
    "coApplicant",
    "dealer",
    "guarantorPrimary",
    "guarantorAdditional",
]
FINANCE_LENDER_HEADER = {"lenderId": "BOA"}


class TestContractSigningFinanceDeal:
    @classmethod
    @pytest.fixture(autouse=True)
    def setup_app_and_create_contract(
        cls,
        env,
        api_url,
        random_data_class,
        verify_contract_payload,
        query_dynamodb_with_deal_component,
        query_dynamodb_for_specified_key,
    ):
        ca_json_file = "credit_app/app_min_data.json"
        contract_json_file = "contract/individual_retail_new.json"
        cls.deal_data = ServiceAPI(
            random_data_class=random_data_class, env=env, json_file=ca_json_file
        )

        # Add dealRefId & creditAppId in header
        fs_header_value = {
            "X-Deal-Reference-Id": cls.deal_data.generate_random_id(True),
            "X-Credit-Application-Reference-Id": cls.deal_data.generate_random_id(True),
            "X-Deal-Jacket-ID": cls.deal_data.generate_random_id(True),
        }

        # Post a Credit App
        status_code, app_resp, resp_headers = cls.deal_data.post_request(
            api_url, APP_ROUTE, cust_header=fs_header_value
        )

        if status_code != HTTPStatus.CREATED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {app_resp}"
            )
        cls.dealRefId = app_resp["dealRefId"]

        # Posting Contract
        cls.deal_data.set_payload(contract_json_file)
        status_code, con_resp, resp_headers = cls.deal_data.post_request(
            api_url, CREATE_CONTRACT_ROUTE, cust_header=FINANCE_LENDER_HEADER
        )

        if status_code != HTTPStatus.CREATED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {con_resp}"
            )

        contract_ref_id = query_dynamodb_for_specified_key(
            app_resp.get("dealRefId"), "contractRefId"
        )
        assert con_resp["contractRefId"] == contract_ref_id

        # Get Create Contract Timestamp
        dtc_deal_record = query_dynamodb_with_deal_component(
            app_resp["dealRefId"], "DTC.DEAL"
        )
        cls.contract_created_timestamp = dtc_deal_record[0].get("updatedTimestamp")

        # Since deal-data does not validate verify contract, we would skip the step and move on to sign contract

    @pytest.mark.smoke
    @pytest.mark.functional
    @pytest.mark.parametrize("signing_customer", SIGNING_CUSTOMERS)
    def test_contract_signing_post(
        self,
        api_url,
        assert_headers,
        signing_customer,
        signing_contract_payload,
        get_deal_updated_timestamp,
        query_dynamodb_with_deal_component,
        verify_get_response_against_posted_data,
    ):
        signing_payload = signing_contract_payload([signing_customer])

        # Sign Contract
        self.deal_data.payload = signing_payload
        status_code, sign_resp, resp_headers = self.deal_data.post_request(
            api_url, SIGN_CONTRACT_ROUTE, cust_header=FINANCE_LENDER_HEADER
        )

        if status_code != HTTPStatus.ACCEPTED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {sign_resp}"
            )
        assert sign_resp == {"message": "Accepted"}

        # Get Sign Contract Timestamp
        sign_created_timestamp = get_deal_updated_timestamp(
            deal_ref_id=self.dealRefId,
            updated_timestamp=self.contract_created_timestamp,
        )
        assert (
            sign_created_timestamp > self.contract_created_timestamp
        ), "Sign-contract updatedTimestamp should be greater than create-contract updatedTimestamp"

        # Validate saved data from DB
        db_data = query_dynamodb_with_deal_component(self.dealRefId, "DTC.DEAL")[0]
        db_cust_data = query_dynamodb_with_deal_component(
            self.dealRefId, f"DTC.{signing_customer.upper()}"
        )[0]
        db_data[signing_customer] = db_cust_data

        verify_get_response_against_posted_data(json.loads(signing_payload), db_data)
        assert_headers(resp_headers)

    @pytest.mark.prod
    @pytest.mark.smoke
    @pytest.mark.functional
    def test_contract_signing_post_applicant_dealer(
        self,
        api_url,
        assert_headers,
        signing_contract_payload,
        get_deal_updated_timestamp,
        query_dynamodb_with_deal_component,
        verify_get_response_against_posted_data,
    ):
        signing_payload = signing_contract_payload(["applicant", "dealer"])

        # Sign Contract
        self.deal_data.payload = signing_payload
        status_code, sign_resp, resp_headers = self.deal_data.post_request(
            api_url, SIGN_CONTRACT_ROUTE, cust_header=FINANCE_LENDER_HEADER
        )

        if status_code != HTTPStatus.ACCEPTED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {sign_resp}"
            )
        assert sign_resp == {"message": "Accepted"}

        # Get Sign Contract Timestamp
        sign_created_timestamp = get_deal_updated_timestamp(
            deal_ref_id=self.dealRefId,
            updated_timestamp=self.contract_created_timestamp,
        )
        assert (
            sign_created_timestamp > self.contract_created_timestamp
        ), "Sign-contract updatedTimestamp should be greater than create-contract updatedTimestamp"

        # Validate saved data from DB
        db_data = query_dynamodb_with_deal_component(self.dealRefId, "DTC.DEAL")[0]
        db_app_data = query_dynamodb_with_deal_component(
            self.dealRefId, "DTC.APPLICANT"
        )[0]
        db_dealer_data = query_dynamodb_with_deal_component(
            self.dealRefId, "DTC.DEALER"
        )[0]
        db_data["applicant"] = db_app_data
        db_data["dealer"] = db_dealer_data

        verify_get_response_against_posted_data(json.loads(signing_payload), db_data)
        assert_headers(resp_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_contract_signing_post_max_payload(
        self,
        api_url,
        assert_headers,
        signing_contract_payload,
        get_deal_updated_timestamp,
        query_dynamodb_with_deal_component,
        verify_get_response_against_posted_data,
    ):
        signing_payload = signing_contract_payload(
            [
                "applicant",
                "coApplicant",
                "dealer",
                "guarantorPrimary",
                "guarantorAdditional",
            ]
        )

        # Sign Contract
        self.deal_data.payload = signing_payload
        status_code, sign_resp, resp_headers = self.deal_data.post_request(
            api_url, SIGN_CONTRACT_ROUTE, cust_header=FINANCE_LENDER_HEADER
        )

        if status_code != HTTPStatus.ACCEPTED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {sign_resp}"
            )
        assert sign_resp == {"message": "Accepted"}

        # Get Sign Contract Timestamp
        sign_created_timestamp = get_deal_updated_timestamp(
            deal_ref_id=self.dealRefId,
            updated_timestamp=self.contract_created_timestamp,
        )
        assert (
            sign_created_timestamp > self.contract_created_timestamp
        ), "Sign-contract updatedTimestamp should be greater than create-contract updatedTimestamp"

        # Validate saved data from DB
        db_data = query_dynamodb_with_deal_component(self.dealRefId, "DTC.DEAL")[0]

        db_app_data = query_dynamodb_with_deal_component(
            self.dealRefId, "DTC.APPLICANT"
        )[0]
        db_coapp_data = query_dynamodb_with_deal_component(
            self.dealRefId, "DTC.COAPPLICANT"
        )[0]
        db_dealer_data = query_dynamodb_with_deal_component(
            self.dealRefId, "DTC.DEALER"
        )[0]
        db_guarantor_data = query_dynamodb_with_deal_component(
            self.dealRefId, "DTC.GUARANTORPRIMARY"
        )[0]
        db_guarantor_additional_data = query_dynamodb_with_deal_component(
            self.dealRefId, "DTC.GUARANTORADDITIONAL"
        )[0]
        db_data["applicant"] = db_app_data
        db_data["coApplicant"] = db_coapp_data
        db_data["dealer"] = db_dealer_data
        db_data["guarantorPrimary"] = db_guarantor_data
        db_data["guarantorAdditional"] = db_guarantor_additional_data
        verify_get_response_against_posted_data(json.loads(signing_payload), db_data)
        assert_headers(resp_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_verify_signing_post_case_insensitive_lender_id(
        self,
        api_url,
        assert_headers,
        signing_contract_payload,
        get_deal_updated_timestamp,
        query_dynamodb_with_deal_component,
        verify_get_response_against_posted_data,
    ):
        signing_payload = signing_contract_payload(["coApplicant", "dealer"])

        # Sign Contract
        self.deal_data.payload = signing_payload
        status_code, sign_resp, resp_headers = self.deal_data.post_request(
            api_url, SIGN_CONTRACT_ROUTE, cust_header={"lenderId": "boa"}
        )

        if status_code != HTTPStatus.ACCEPTED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {sign_resp}"
            )
        assert sign_resp == {"message": "Accepted"}

        # Get Sign Contract Timestamp
        sign_created_timestamp = get_deal_updated_timestamp(
            deal_ref_id=self.dealRefId,
            updated_timestamp=self.contract_created_timestamp,
        )
        assert (
            sign_created_timestamp > self.contract_created_timestamp
        ), "Sign-contract updatedTimestamp should be greater than create-contract updatedTimestamp"

        # Validate saved data from DB
        db_data = query_dynamodb_with_deal_component(self.dealRefId, "DTC.DEAL")[0]
        db_coapp_data = query_dynamodb_with_deal_component(
            self.dealRefId, "DTC.COAPPLICANT"
        )[0]
        db_dealer_data = query_dynamodb_with_deal_component(
            self.dealRefId, "DTC.DEALER"
        )[0]

        db_data["coApplicant"] = db_coapp_data
        db_data["dealer"] = db_dealer_data

        verify_get_response_against_posted_data(json.loads(signing_payload), db_data)
        assert_headers(resp_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_contract_sign_multiple_posts(
        self,
        api_url,
        assert_headers,
        signing_contract_payload,
        get_deal_component_details,
        verify_get_response_against_posted_data,
    ):

        # post to signing API multiple times
        for customer in SIGNING_CUSTOMERS:
            # Sign Contract
            signing_payload = signing_contract_payload([customer])
            self.deal_data.payload = signing_payload
            status_code, sign_resp, resp_headers = self.deal_data.post_request(
                api_url, SIGN_CONTRACT_ROUTE, cust_header=FINANCE_LENDER_HEADER
            )

            if status_code != HTTPStatus.ACCEPTED:
                raise Exception(
                    f"Response code is: {status_code} and the response message is: {sign_resp}"
                )
            assert sign_resp == {"message": "Accepted"}

            # Confirm data is saved in DB
            customer_data = get_deal_component_details(
                self.deal_data.dealRefId, deal_component=f"DTC.{customer.upper()}"
            )
            deal_data = get_deal_component_details(
                self.deal_data.dealRefId, deal_component="DTC.DEAL"
            )

            deal_data[customer] = customer_data

            verify_get_response_against_posted_data(
                json.loads(signing_payload), deal_data
            )
            assert_headers(resp_headers)

    reference_ids = ["dealRefId", "contractRefId"]

    @pytest.mark.smoke
    @pytest.mark.functional
    @pytest.mark.parametrize("reference_id", reference_ids)
    def test_signing_contract_missing_reference_id_single_response(
        self,
        api_url,
        reference_id,
        assert_headers,
        signing_contract_payload,
        missing_reference_ids_response,
    ):

        # Sign Contract
        self.deal_data.payload = signing_contract_payload(["applicant"])
        setattr(self.deal_data, reference_id, "")
        status_code, sign_resp, resp_headers = self.deal_data.post_request(
            api_url, SIGN_CONTRACT_ROUTE, cust_header=FINANCE_LENDER_HEADER
        )

        if status_code != HTTPStatus.BAD_REQUEST:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {sign_resp}"
            )
        assert sign_resp == missing_reference_ids_response(field_list=[reference_id])

        assert_headers(resp_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_signing_contract_missing_multiple_reference_ids_response(
        self,
        api_url,
        assert_headers,
        signing_contract_payload,
        missing_reference_ids_response,
    ):
        # Signing Contract
        self.deal_data.payload = signing_contract_payload(["applicant"])
        self.deal_data.dealRefId = ""
        self.deal_data.contractRefId = ""
        status_code, sign_resp, resp_headers = self.deal_data.post_request(
            api_url, SIGN_CONTRACT_ROUTE, cust_header=FINANCE_LENDER_HEADER
        )

        if status_code != HTTPStatus.BAD_REQUEST:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {sign_resp}"
            )

        expected_resp = missing_reference_ids_response(
            field_list=["dealRefId", "contractRefId"]
        )

        assert expected_resp[0]["code"] == sign_resp[0]["code"]
        assert sorted(
            expected_resp[0]["properties"], key=lambda ele: sorted(ele.items())
        ) == sorted(sign_resp[0]["properties"], key=lambda ele: sorted(ele.items()))

        assert_headers(resp_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_signing_contract_invalid_deal_ref_id(
        self,
        api_url,
        assert_headers,
        signing_contract_payload,
        invalid_deal_ref_id_response,
    ):

        # Signing Contract
        self.deal_data.payload = signing_contract_payload(["applicant"])
        self.deal_data.dealRefId = self.deal_data.generate_random_id(True)
        status_code, sign_resp, resp_headers = self.deal_data.post_request(
            api_url, SIGN_CONTRACT_ROUTE, cust_header=FINANCE_LENDER_HEADER
        )

        if status_code != HTTPStatus.BAD_REQUEST:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {sign_resp}"
            )
        assert sign_resp == invalid_deal_ref_id_response(self.deal_data.dealRefId)

        assert_headers(resp_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_signing_contract_invalid_contract_ref_id_single(
        self,
        api_url,
        assert_headers,
        signing_contract_payload,
        invalid_reference_ids_response,
    ):

        reference_id = "contractRefId"
        # Sign Contract
        self.deal_data.payload = signing_contract_payload(["applicant"])
        invalid_id = self.deal_data.generate_random_id(True)
        setattr(self.deal_data, reference_id, invalid_id)
        status_code, sign_resp, resp_headers = self.deal_data.post_request(
            api_url, SIGN_CONTRACT_ROUTE, cust_header=FINANCE_LENDER_HEADER
        )

        if status_code != HTTPStatus.BAD_REQUEST:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {sign_resp}"
            )
        assert sign_resp == invalid_reference_ids_response(
            self.dealRefId, {reference_id: invalid_id}
        )

        assert_headers(resp_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_signing_missing_request_payload(
        self, api_url, assert_headers, missing_payload_response
    ):

        # Signing Contract
        self.deal_data.payload = ""
        status_code, sign_resp, resp_headers = self.deal_data.post_request(
            api_url, SIGN_CONTRACT_ROUTE, cust_header=FINANCE_LENDER_HEADER
        )

        if status_code != HTTPStatus.BAD_REQUEST:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {sign_resp}"
            )
        assert sign_resp == missing_payload_response
        assert_headers(resp_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_signing_contract_invalid_payload(
        self, api_url, assert_headers, invalid_payload
    ):

        # Sign Contract
        self.deal_data.payload = invalid_payload
        status_code, sign_resp, resp_headers = self.deal_data.post_request(
            api_url, SIGN_CONTRACT_ROUTE, cust_header=FINANCE_LENDER_HEADER
        )

        if status_code != HTTPStatus.BAD_REQUEST:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {sign_resp}"
            )

        assert_headers(resp_headers)
