# -*- coding: utf-8 -*-
from http import HTTPStatus

import pytest
from tests.functional.helper.helper_api import HelperApi


CONTRACT_V2_ROUTE = "create_contract_v2"
KEY_DATA_ROUTE = "key_data_get"


class TestContractV2Deal:
    @classmethod
    @pytest.fixture(autouse=True)
    def setup_key_data(
        cls,
        env,
        api_url,
        random_data_class,
        get_deal_component_details,
        get_records_by_deal_ref_id,
        key_data_test_data_dtc_record,
        query_dynamodb_with_deal_component,
        query_dynamodb_for_specified_key,
    ):
        cls.api_url = api_url
        cls.helper = HelperApi(
            env=env,
            api_url=api_url,
            random_data_class=random_data_class,
            get_deal_component_details=get_deal_component_details,
        )
        key_data_test_data_dtc_record.pop("dealXgDealId")
        key_data_test_data_dtc_record.pop("dealXgDealVersion")

        cls.helper.payload = key_data_test_data_dtc_record

        # Create a deal using key-data
        status_code, resp, headers = cls.helper.post_request(
            cls.api_url,
            KEY_DATA_ROUTE,
        )

        if status_code != HTTPStatus.CREATED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {resp}"
            )

        # Verify deal created in DB
        get_deal_component_details(
            deal_ref_id=cls.helper.dealRefId, deal_component="DTC.DEAL"
        )

    test_data = [
        ("dealxg_create_contract_payload", "Finance", "DTC"),
        ("dealxg_create_contract_payload", "Cash", "DTC"),
        ("dealxg_create_contract_payload", "Finance", "IDL"),
        ("dealxg_create_contract_payload", "Cash", "IDL"),
    ]

    @pytest.mark.prod
    @pytest.mark.smoke
    @pytest.mark.functional
    @pytest.mark.parametrize(
        "dealxg_contract_payload, finance_method, target_id", test_data
    )
    def test_dealxg_contract_post(
        self,
        dealxg_contract_payload,
        finance_method,
        target_id,
        dealxg_create_contract_payload,
        get_deal_component_details,
        assert_headers,
    ):
        # Posting Contract
        dealxg_header = {
            "lenderId": "DT6",
            "dealXgDealId": self.helper.generate_random_id(True),
            "dealXgDealVersion": "v3",
        }
        contract_payload = eval(dealxg_contract_payload)
        self.helper.payload = contract_payload(finance_method, target_id)
        status_code, con_resp, resp_headers = self.helper.post_request(
            self.api_url, CONTRACT_V2_ROUTE, cust_header=dealxg_header
        )

        if status_code != HTTPStatus.ACCEPTED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {con_resp}"
            )
        assert con_resp == {"message": "Accepted"}
        assert_headers(resp_headers)

        # Verify contract created in DB
        get_deal_component_details(
            deal_ref_id=self.helper.dealRefId,
            deal_component="DTC.DEAL",
            additional_check_key="dealXgDealId",
            additional_check_value=None,
        )

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_contract_post_with_invalid_deal_ref_id(
        self,
        dealxg_create_contract_payload,
    ):
        # Update dealRefId
        self.helper.dealRefId = self.helper.generate_random_id(True)

        # Posting Contract
        dealxg_header = {
            "lenderId": "DT6",
            "dealXgDealId": self.helper.generate_random_id(True),
            "dealXgDealVersion": "v3",
        }
        self.helper.payload = dealxg_create_contract_payload("Finance", "DTC")
        status_code, con_resp, resp_headers = self.helper.post_request(
            self.api_url, CONTRACT_V2_ROUTE, cust_header=dealxg_header
        )

        if status_code != HTTPStatus.BAD_REQUEST:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {con_resp}"
            )

        assert con_resp.get("message") == f"No deal found for {self.helper.dealRefId}"
        assert resp_headers.get("X-CoxAuto-Correlation-Id") is not None

    empty_headers = [
        "lenderId",
        "dealXgDealId",
        "dealXgDealVersion",
    ]

    @pytest.mark.smoke
    @pytest.mark.functional
    @pytest.mark.parametrize("empty_field_name", empty_headers)
    def test_contract_post_with_empty_field_in_header(
        self,
        assert_headers,
        empty_field_name,
        get_deal_component_details,
        dealxg_create_contract_payload,
    ):

        # Posting Contract
        dealxg_header = {
            "lenderId": "DT6",
            "dealXgDealId": self.helper.generate_random_id(True),
            "dealXgDealVersion": "v3",
            empty_field_name: "",
        }
        self.helper.payload = dealxg_create_contract_payload("Finance", "IDL")
        status_code, con_resp, resp_headers = self.helper.post_request(
            self.api_url, CONTRACT_V2_ROUTE, cust_header=dealxg_header
        )

        if status_code != HTTPStatus.ACCEPTED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {con_resp}"
            )

        assert con_resp == {"message": "Accepted"}
        assert_headers(resp_headers)

        if empty_field_name != "dealXgDealId":
            check_field = "dealXgDealId"
        else:
            check_field = "dealXgDealVersion"

        # Verify contract created in DB
        get_deal_component_details(
            deal_ref_id=self.helper.dealRefId,
            deal_component="DTC.DEAL",
            additional_check_key=check_field,
            additional_check_value=None,
        )

    @pytest.mark.prod
    @pytest.mark.smoke
    @pytest.mark.functional
    def test_multiple_contract_post(
        self,
        assert_headers,
        get_deal_component_details,
        dealxg_create_contract_payload,
    ):
        for contract in [
            dealxg_create_contract_payload("Finance", "IDL"),
            dealxg_create_contract_payload("Cash", "IDL"),
            dealxg_create_contract_payload("Finance", "DTC"),
            dealxg_create_contract_payload("Cash", "DTC"),
        ]:
            # Posting Contract
            dealxg_header = {
                "lenderId": "DT6",
                "dealXgDealId": self.helper.generate_random_id(True),
                "dealXgDealVersion": "v3",
            }
            self.helper.payload = contract
            status_code, con_resp, resp_headers = self.helper.post_request(
                self.api_url, CONTRACT_V2_ROUTE, cust_header=dealxg_header
            )

            if status_code != HTTPStatus.ACCEPTED:
                raise Exception(
                    f"Response code is: {status_code} and the response message is: {con_resp}"
                )
            assert con_resp == {"message": "Accepted"}
            assert_headers(resp_headers)

            # Verify contract created in DB
            get_deal_component_details(
                deal_ref_id=self.helper.dealRefId,
                deal_component="DTC.DEAL",
                additional_check_key="dealXgDealId",
                additional_check_value=None,
            )

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_contract_post_with_invalid_test_data(
        self,
        dealxg_invalid_payload,
    ):
        # Posting Contract
        dealxg_header = {
            "lenderId": "DT6",
            "dealXgDealId": self.helper.generate_random_id(True),
            "dealXgDealVersion": "v3",
        }
        self.helper.payload = dealxg_invalid_payload
        status_code, con_resp, resp_headers = self.helper.post_request(
            self.api_url, CONTRACT_V2_ROUTE, cust_header=dealxg_header
        )

        if status_code != HTTPStatus.BAD_REQUEST:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {con_resp}"
            )

        assert status_code == HTTPStatus.BAD_REQUEST
        assert resp_headers.get("X-CoxAuto-Correlation-Id") is not None
