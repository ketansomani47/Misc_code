# -*- coding: utf-8 -*-
import json
from http import HTTPStatus

import pytest
from tests.functional.service_api import ServiceAPI


KEY_DATA_POST_ROUTE = "key_data"
SIGN_STANDALONE_CONTRACT_ROUTE = "standalone_sign_contract"

IDl_TARGET = "IDL"
SIGNING_CUSTOMERS = [
    "applicant",
    "coApplicant",
    "dealer",
    "guarantorPrimary",
    "guarantorAdditional",
]


class TestContractSigningCashDeal:
    @classmethod
    @pytest.fixture(autouse=True)
    def setup_method(
        cls,
        env,
        api_url,
        random_data_class,
        get_deal_component_details,
        key_data_test_data_idl_deal_jacket_record,
    ):
        cls.env = env
        cls.api_url = api_url
        cls.key_data_timestamp = None
        cls.deal_data = ServiceAPI(random_data_class=random_data_class, env=env)
        cls.post_key_data(
            key_data_test_data_idl_deal_jacket_record, get_deal_component_details
        )

    def post_key_data(self, key_data_payload, get_deal_component_details):
        self.deal_data.payload = key_data_payload
        status_code, post_resp, resp_headers = self.deal_data.post_request(
            self.api_url, KEY_DATA_POST_ROUTE
        )

        if status_code != HTTPStatus.CREATED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {post_resp}"
            )

        # Confirm data is saved in DB
        get_deal_component_details(self.deal_data.dealRefId, deal_component="DTC.DEAL")

    def sign_stand_alone_contract(self, payload, expected_status):
        self.deal_data.payload = payload
        status_code, sign_resp, resp_headers = self.deal_data.post_request(
            self.api_url, SIGN_STANDALONE_CONTRACT_ROUTE
        )

        if status_code != expected_status:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {sign_resp}"
            )

        return sign_resp, resp_headers

    @pytest.mark.smoke
    @pytest.mark.functional
    @pytest.mark.parametrize("signing_customer", SIGNING_CUSTOMERS)
    def test_contract_signing_post(
        self,
        api_url,
        assert_headers,
        signing_customer,
        signing_contract_payload,
        get_deal_component_details,
        query_dynamodb_with_deal_component,
        verify_get_response_against_posted_data,
        key_data_test_data_idl_deal_jacket_record,
    ):
        # Sign Contract
        signing_payload = signing_contract_payload([signing_customer], IDl_TARGET)
        sign_resp, sign_headers = self.sign_stand_alone_contract(
            signing_payload, HTTPStatus.ACCEPTED
        )

        assert sign_resp == {"message": "Accepted"}

        # Confirm requested in saved in DB
        db_cust_data = get_deal_component_details(
            deal_ref_id=self.deal_data.dealRefId,
            deal_component=f"DTC.{signing_customer.upper()}",
        )

        # Validate saved data from DB
        db_data = get_deal_component_details(self.deal_data.dealRefId, "DTC.DEAL")
        db_data[signing_customer] = db_cust_data

        verify_get_response_against_posted_data(json.loads(signing_payload), db_data)
        assert_headers(sign_headers)

    @pytest.mark.prod
    @pytest.mark.smoke
    @pytest.mark.functional
    def test_contract_signing_post_applicant_dealer(
        self,
        api_url,
        assert_headers,
        get_deal_component_details,
        signing_contract_payload,
        verify_get_response_against_posted_data,
    ):
        # Sign Contract
        signing_payload = signing_contract_payload(["applicant", "dealer"], IDl_TARGET)
        sign_resp, sign_headers = self.sign_stand_alone_contract(
            signing_payload, HTTPStatus.ACCEPTED
        )

        assert sign_resp == {"message": "Accepted"}

        # Confirm requested in saved in DB
        get_deal_component_details(
            deal_ref_id=self.deal_data.dealRefId, deal_component="DTC.APPLICANT"
        )

        # Validate saved data from DB
        db_data = get_deal_component_details(self.deal_data.dealRefId, "DTC.DEAL")
        db_app_data = get_deal_component_details(
            self.deal_data.dealRefId, "DTC.APPLICANT"
        )
        db_dealer_data = get_deal_component_details(
            self.deal_data.dealRefId, "DTC.DEALER"
        )
        db_data["applicant"] = db_app_data
        db_data["dealer"] = db_dealer_data

        verify_get_response_against_posted_data(json.loads(signing_payload), db_data)
        assert_headers(sign_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_contract_signing_post_max_payload(
        self,
        api_url,
        assert_headers,
        get_deal_component_details,
        signing_contract_payload,
        verify_get_response_against_posted_data,
    ):
        # Sign Contract
        signing_payload = signing_contract_payload(
            [
                "applicant",
                "coApplicant",
                "dealer",
                "guarantorPrimary",
                "guarantorAdditional",
            ],
            IDl_TARGET,
        )
        sign_resp, sign_headers = self.sign_stand_alone_contract(
            signing_payload, HTTPStatus.ACCEPTED
        )
        assert sign_resp == {"message": "Accepted"}

        # Confirm requested in saved in DB
        get_deal_component_details(
            deal_ref_id=self.deal_data.dealRefId,
            deal_component="DTC.GUARANTORADDITIONAL",
        )

        # Validate saved data from DB
        db_data = get_deal_component_details(self.deal_data.dealRefId, "DTC.DEAL")

        db_app_data = get_deal_component_details(
            self.deal_data.dealRefId, "DTC.APPLICANT"
        )
        db_coapp_data = get_deal_component_details(
            self.deal_data.dealRefId, "DTC.COAPPLICANT"
        )
        db_dealer_data = get_deal_component_details(
            self.deal_data.dealRefId, "DTC.DEALER"
        )
        db_guarantor_data = get_deal_component_details(
            self.deal_data.dealRefId, "DTC.GUARANTORPRIMARY"
        )
        db_guarantor_additional_data = get_deal_component_details(
            self.deal_data.dealRefId, "DTC.GUARANTORADDITIONAL"
        )
        db_data["applicant"] = db_app_data
        db_data["coApplicant"] = db_coapp_data
        db_data["dealer"] = db_dealer_data
        db_data["guarantorPrimary"] = db_guarantor_data
        db_data["guarantorAdditional"] = db_guarantor_additional_data
        verify_get_response_against_posted_data(json.loads(signing_payload), db_data)
        assert_headers(sign_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_verify_signing_post_case_insensitive_lender_id(
        self,
        api_url,
        assert_headers,
        signing_contract_payload,
        get_deal_component_details,
        verify_get_response_against_posted_data,
    ):
        # Sign Contract
        signing_payload = signing_contract_payload(
            ["coApplicant", "dealer"], IDl_TARGET
        )
        sign_resp, sign_headers = self.sign_stand_alone_contract(
            signing_payload, HTTPStatus.ACCEPTED
        )
        assert sign_resp == {"message": "Accepted"}

        # Confirm requested in saved in DB
        get_deal_component_details(
            deal_ref_id=self.deal_data.dealRefId, deal_component="DTC.DEALER"
        )

        # Validate saved data from DB
        db_data = get_deal_component_details(self.deal_data.dealRefId, "DTC.DEAL")
        db_coapp_data = get_deal_component_details(
            self.deal_data.dealRefId, "DTC.COAPPLICANT"
        )
        db_dealer_data = get_deal_component_details(
            self.deal_data.dealRefId, "DTC.DEALER"
        )

        db_data["coApplicant"] = db_coapp_data
        db_data["dealer"] = db_dealer_data

        verify_get_response_against_posted_data(json.loads(signing_payload), db_data)
        assert_headers(sign_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_contract_sign_multiple_posts(
        self,
        api_url,
        assert_headers,
        get_deal_component_details,
        signing_contract_payload,
        verify_get_response_against_posted_data,
    ):
        # post to signing API multiple times
        for customer in SIGNING_CUSTOMERS:
            # Sign Contract
            signing_payload = signing_contract_payload([customer], IDl_TARGET)
            sign_resp, sign_headers = self.sign_stand_alone_contract(
                signing_payload, HTTPStatus.ACCEPTED
            )
            assert sign_resp == {"message": "Accepted"}

            # Confirm data is saved in DB
            customer_data = get_deal_component_details(
                self.deal_data.dealRefId, deal_component=f"DTC.{customer.upper()}"
            )
            deal_data = get_deal_component_details(
                self.deal_data.dealRefId, deal_component="DTC.DEAL"
            )

            deal_data[customer] = customer_data

            verify_get_response_against_posted_data(
                json.loads(signing_payload), deal_data
            )
            assert_headers(sign_headers)

    reference_ids = ["dealRefId"]

    @pytest.mark.smoke
    @pytest.mark.functional
    @pytest.mark.parametrize("reference_id", reference_ids)
    def test_signing_contract_missing_reference_id_single_response(
        self,
        api_url,
        reference_id,
        assert_headers,
        signing_contract_payload,
        missing_reference_ids_response,
    ):
        # Sign Contract
        setattr(self.deal_data, reference_id, "")
        signing_payload = signing_contract_payload(
            ["coApplicant", "dealer"], IDl_TARGET
        )
        sign_resp, sign_headers = self.sign_stand_alone_contract(
            signing_payload, HTTPStatus.BAD_REQUEST
        )
        assert sign_resp == missing_reference_ids_response(field_list=[reference_id])

        assert_headers(sign_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_signing_contract_invalid_deal_ref_id(
        self,
        api_url,
        assert_headers,
        signing_contract_payload,
        invalid_deal_ref_id_response,
    ):
        # Sign Contract
        signing_payload = signing_contract_payload(["applicant"], IDl_TARGET)
        self.deal_data.dealRefId = self.deal_data.generate_random_id(True)
        sign_resp, sign_headers = self.sign_stand_alone_contract(
            signing_payload, HTTPStatus.BAD_REQUEST
        )
        assert sign_resp == invalid_deal_ref_id_response(self.deal_data.dealRefId)

        assert_headers(sign_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_signing_missing_request_payload(
        self, api_url, assert_headers, missing_payload_response
    ):
        # Sign Contract
        signing_payload = {}
        sign_resp, sign_headers = self.sign_stand_alone_contract(
            signing_payload, HTTPStatus.BAD_REQUEST
        )
        assert sign_resp == missing_payload_response
        assert_headers(sign_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_signing_contract_invalid_payload(
        self, api_url, assert_headers, invalid_payload
    ):
        # Sign Contract
        signing_payload = invalid_payload
        sign_resp, sign_headers = self.sign_stand_alone_contract(
            signing_payload, HTTPStatus.BAD_REQUEST
        )

        assert_headers(sign_headers)
