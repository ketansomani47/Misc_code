# -*- coding: utf-8 -*-
import random
import string
from http import HTTPStatus

import pytest
from tests.functional.helper.helper_api import HelperApi


class TestContractStatus:
    @classmethod
    @pytest.fixture(autouse=True)
    def setup_class(
        cls,
        env,
        api_url,
        random_data_class,
        get_deal_component_details,
    ):
        cls.api_url = api_url
        cls.helper = HelperApi(
            env=env,
            api_url=api_url,
            random_data_class=random_data_class,
            get_deal_component_details=get_deal_component_details,
        )

    def create_a_contract_with_credit_app(self):
        app_test_data = "credit_app/app_min_data.json"
        contract_file = "contract/individual_retail_new.json"
        self.helper.create_credit_app(app_file=app_test_data)
        self.helper.create_contract(contract_file=contract_file)

    def create_a_contract_with_lead(self):
        lead_test_data = "leads/leads_min_data.json"
        contract_file = "contract/individual_retail_new.json"
        self.helper.create_lead(lead_file=lead_test_data)
        self.helper.create_contract(
            contract_file=contract_file,
            finance_type="Cash",
        )

    @pytest.mark.prod
    @pytest.mark.smoke
    @pytest.mark.functional
    def test_contract_status_post_cash_deal(
        self,
        assert_headers,
        contract_status_payload,
        validate_data_updated_for_dtc,
    ):
        # Create a lead and start a contract
        self.create_a_contract_with_lead()

        # Contract Status
        self.helper.create_contract_status(
            payload=contract_status_payload,
        )

        # Verify Status payload saved in DB
        validate_data_updated_for_dtc(
            deal_ref_id=self.helper.dealRefId,
            requ_payload=self.helper.payload,
            key_name="contractStatusCode",
        )
        assert_headers(self.helper.resp_header)

    @pytest.mark.prod
    @pytest.mark.smoke
    @pytest.mark.functional
    def test_contract_status_post_finance_deal(
        self,
        assert_headers,
        contract_status_payload,
        validate_data_updated_for_dtc,
    ):
        # Create a lead and start a contract
        self.create_a_contract_with_credit_app()

        # Contract Status
        lender_id = {"lenderId": "DT6"}
        self.helper.create_contract_status(
            payload=contract_status_payload,
            cust_header=lender_id,
        )

        # Verify Status payload saved in DB
        validate_data_updated_for_dtc(
            deal_ref_id=self.helper.dealRefId,
            requ_payload=self.helper.payload,
            key_name="contractStatusCode",
        )

        assert_headers(self.helper.resp_header)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_contract_status_multiple_posts_cash_deal(
        self,
        assert_headers,
        contract_status_payload,
        get_deal_component_details,
    ):
        # Create a lead and start a contract
        self.create_a_contract_with_lead()

        # Contract Status
        self.helper.payload = contract_status_payload

        for i in range(5):
            random_partner_id = "".join(random.choices(string.ascii_uppercase, k=3))
            self.helper.payload["sourcePartnerId"] = random_partner_id
            self.helper.create_contract_status(
                payload=self.helper.payload,
            )
            # Verify Status payload saved in DB
            get_deal_component_details(
                deal_ref_id=self.helper.dealRefId,
                deal_component="DTC.DEAL",
                additional_check_key="sourcePartnerId",
                additional_check_value=random_partner_id,
            )
            assert_headers(self.helper.resp_header)

    reference_ids = ["dealRefId", "contractRefId"]

    @pytest.mark.smoke
    @pytest.mark.functional
    @pytest.mark.parametrize("reference_id", reference_ids)
    def test_contract_status_missing_reference_id_single_response_cash_deal(
        self,
        reference_id,
        assert_headers,
        contract_status_payload,
        missing_reference_ids_response,
    ):
        # Create a lead and start a contract
        self.create_a_contract_with_lead()

        # Contract Status
        setattr(self.helper, reference_id, "")

        # Contract Status
        self.helper.create_contract_status(
            payload=contract_status_payload,
            expected_status=HTTPStatus.BAD_REQUEST,
            expected_message=missing_reference_ids_response(field_list=[reference_id]),
        )

        assert_headers(self.helper.resp_header)

    lender_id_headers = [{"lenderId": ""}, {}]

    @pytest.mark.smoke
    @pytest.mark.functional
    @pytest.mark.parametrize("lender_id_header", lender_id_headers)
    def test_contract_status_with_empty_lender_id_in_header_cash_deal(
        self,
        assert_headers,
        lender_id_header,
        contract_status_payload,
        validate_data_updated_for_dtc,
    ):
        # Create a lead and start a contract
        self.create_a_contract_with_lead()

        # Contract Status
        self.helper.create_contract_status(
            payload=contract_status_payload,
            cust_header=lender_id_header,
        )

        # Verify Status payload saved in DB
        validate_data_updated_for_dtc(
            deal_ref_id=self.helper.dealRefId,
            requ_payload=self.helper.payload,
            key_name="contractStatusCode",
        )

        assert_headers(self.helper.resp_header)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_contract_status_missing_multiple_reference_ids_response_cash_deal(
        self,
        assert_headers,
        contract_status_payload,
        missing_reference_ids_response,
    ):
        # Create a lead and start a contract
        self.create_a_contract_with_lead()

        # Contract Status
        self.helper.dealRefId = ""
        self.helper.contractRefId = ""
        self.helper.create_contract_status(
            payload=contract_status_payload,
            expected_status=HTTPStatus.BAD_REQUEST,
            expected_message=missing_reference_ids_response(
                field_list=["dealRefId", "contractRefId"]
            ),
        )

        assert_headers(self.helper.resp_header)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_contract_status_invalid_deal_ref_id_cash_deal(
        self,
        assert_headers,
        contract_status_payload,
        invalid_deal_ref_id_response,
    ):
        # Create a lead and start a contract
        self.create_a_contract_with_lead()

        # Contract Status
        self.helper.payload = contract_status_payload
        self.helper.dealRefId = self.helper.generate_random_id(True)
        self.helper.create_contract_status(
            payload=contract_status_payload,
            expected_status=HTTPStatus.BAD_REQUEST,
            expected_message=invalid_deal_ref_id_response(self.helper.dealRefId),
        )

        assert_headers(self.helper.resp_header)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_contract_status_invalid_contract_ref_id_single_cash_deal(
        self,
        assert_headers,
        contract_status_payload,
        invalid_reference_ids_response,
    ):
        # Create a lead and start a contract
        self.create_a_contract_with_lead()

        ref_id_field = "contractRefId"

        # Contract Status
        invalid_id = self.helper.generate_random_id(True)
        setattr(self.helper, ref_id_field, invalid_id)

        self.helper.create_contract_status(
            payload=contract_status_payload,
            expected_status=HTTPStatus.BAD_REQUEST,
            expected_message=invalid_reference_ids_response(
                self.helper.dealRefId, {ref_id_field: invalid_id}
            ),
        )

        assert_headers(self.helper.resp_header)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_contract_status_missing_request_payload_cash_deal(
        self,
        assert_headers,
        missing_payload_response,
    ):
        # Create a lead and start a contract
        self.create_a_contract_with_lead()

        # Contract Status
        self.helper.create_contract_status(
            payload="",
            expected_status=HTTPStatus.BAD_REQUEST,
            expected_message=missing_payload_response,
        )

        assert_headers(self.helper.resp_header)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_contract_status_invalid_payload_cash_deal(
        self,
        assert_headers,
        invalid_payload,
    ):
        # Create a lead and start a contract
        self.create_a_contract_with_lead()

        # Contract Status
        expected_resp = {"message": "Extra data: line 2 column 26 (char 26)"}
        self.helper.create_contract_status(
            payload=invalid_payload,
            expected_status=HTTPStatus.BAD_REQUEST,
            expected_message=expected_resp,
        )

        assert_headers(self.helper.resp_header)
