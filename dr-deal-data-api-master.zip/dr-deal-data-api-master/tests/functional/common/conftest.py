# -*- coding: utf-8 -*-
import pytest
from tests.config import DD_ENV_MAPPING


@pytest.fixture()
def expected_health_check_payload():
    def wrapper(env, stage, region):
        stage = stage or env
        return {
            "service": "dr_deal_data_api",
            "region": region,
            "service_status": "Operational",
            "healthchecks": {
                f"DealDataQueue-{stage}.fifo": "Operational",
                f"DealDataDLQ-{stage}.fifo": "Operational",
                f"EventQueue-{stage}.fifo": "Operational",
                f"EventRouteQueue-{stage}.fifo": "Operational",
                f"dr-deals-{env}": "Operational",
                "deals/HCdealRefId/credit-apps method-post": "Operational",
                "deals/HCdealRefId method-get": "Operational",
                f"dr-deal-data-api-{stage}-deal_consumer": "Operational",
                f"dr-deal-data-api-{stage}-event_producer": "Operational",
                f"dr-deal-data-api-{stage}-event_route": "Operational",
                f"dr-deal-data-api-{stage}-dlq_processing": "Operational",
                f"{DD_ENV_MAPPING[env]['aws_alias']}-deal-data-{region}-{DD_ENV_MAPPING[env]['bucket_suffix']}": "Operational",
                "/v1/deals/credit-apps": "Operational",
                "/v1/deals/{dealRefId}/credit-apps": "Operational",
                "/v1/deals/{dealRefId}/credit-apps/{creditAppId}": "Operational",
                "/v1/deals/leads": "Operational",
                "/v1/deals/{dealRefId}/leads": "Operational",
                "/v1/deals/{dealRefId}/leads/{leadRefId}": "Operational",
                "/v1/deals/{dealRefId}": "Operational",
                "/v1/events": "Operational",
                "/v1/deals/credit-bureaus": "Operational",
                "/v1/deals/{dealRefId}/contract": "Operational",
                "/v1/deals/{dealRefId}/contract/{contractRefId}/verify": "Operational",
                "/v1/deals/{dealRefId}/contract/{contractRefId}/sign": "Operational",
                "/v1/deals/{dealRefId}/contract/{contractRefId}/cancel": "Operational",
                "/v2/deals/{dealRefId}/contract/sign": "Operational",
                "/v1/deals/{dealRefId}/contract/{contractRefId}/status": "Operational",
                "/v1/deals/{dealRefId}/partner-dealers/{partnerDealerId}/credit-apps/lenders/{lenderId}/decisions/latest": "Operational",
                "/v1/deals/{dealRefId}/partner-dealers/{partnerDealerId}/credit-apps/{creditAppId}/lenders/{lenderId}/decisions/program": "Operational",
                "/v1/deals/{dealRefId}/partner-dealers/{partnerDealerId}/credit-apps/{creditAppId}/lenders/{lenderId}/decisions/latest": "Operational",
            },
        }

    return wrapper


@pytest.fixture()
def expected_info_response(api_version, region):
    return {"service": "dr_deal_data_api", "region": region, "version": api_version}
