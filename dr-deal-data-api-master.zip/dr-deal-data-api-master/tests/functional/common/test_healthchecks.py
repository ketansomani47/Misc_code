# -*- coding: utf-8 -*-
from http import HTTPStatus

import pytest
from tests.functional.service_api import ServiceAPI


@pytest.mark.smoke
@pytest.mark.prod
@pytest.mark.functional
def test_health_checks(env, stage, region, api_url, expected_health_check_payload):
    expected_health_check_payload = expected_health_check_payload(env, stage, region)
    headers = {"Connection": "close"}
    deal_data = ServiceAPI(env=env)
    status_code, resp_body, resp_headers = deal_data.get_request(
        api_url, route_url="health_check", headers=headers
    )
    assert status_code == HTTPStatus.OK
    assert resp_body["service"] == expected_health_check_payload["service"]
    assert resp_body["region"] == expected_health_check_payload["region"]

    # Check deal data services health check
    healthchecks = resp_body.pop("healthchecks")
    expected_health_checks = expected_health_check_payload.pop("healthchecks")
    assert list(healthchecks.items()) == list(expected_health_checks.items())
