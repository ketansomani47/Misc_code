# -*- coding: utf-8 -*-
from http import HTTPStatus

import pytest
from tests.functional.service_api import ServiceAPI


@pytest.mark.prod
@pytest.mark.functional
def test_info(env, api_url, expected_info_response):
    headers = {"Connection": "close"}
    deal_data = ServiceAPI(env=env)
    status_code, resp_body, resp_headers = deal_data.get_request(
        api_url, route_url="info", headers=headers
    )
    assert status_code == HTTPStatus.OK
    assert resp_body == expected_info_response
