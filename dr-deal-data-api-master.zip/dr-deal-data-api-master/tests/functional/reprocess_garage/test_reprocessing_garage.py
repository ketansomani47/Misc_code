# -*- coding: utf-8 -*-
import copy
import json
import logging
import time
import uuid
from http import HTTPStatus

import pytest
from common.settings import PayloadType
from tests.config import DD_ENV_MAPPING, S3_KEY_TO_DELETE, WAIT_WITH_RETRIES
from tests.functional.service_api import ServiceAPI


log = logging.getLogger(__name__)

EXPECTED_TAGS = {
    "payloadType": "",
    "correlationId": "",
    "dealRefId": "",
    "x-aws-region": "",
}


class ReprocessingGarageHelper:
    def __init__(self, env, stage, region, s3_client):
        self.env = env
        self.stage = stage
        self.region = region
        self.s3_client = s3_client
        self.deal_ref_id = ""
        suffix = DD_ENV_MAPPING[env]["bucket_suffix"]
        self.bucket_name = f"{DD_ENV_MAPPING[self.env]['aws_alias']}-reprocessing-garage-{self.region}-{suffix}"
        self.queue_name = f"DealDataDLQ-{stage or self.env}.fifo"

    def get_files(self, deal_ref_id, expected_count=1):
        self.deal_ref_id = deal_ref_id
        tries = 0
        key_count = 0
        files = []
        log.info(f"Attempting to get file:{self.queue_name}/{self.deal_ref_id}")
        while key_count != expected_count and tries < 120:
            time.sleep(WAIT_WITH_RETRIES)
            tries = tries + 1
            files = self.s3_client.list_objects_v2(
                Bucket=self.bucket_name, Prefix=f"{self.queue_name}/{self.deal_ref_id}"
            )
            key_count = files["KeyCount"]
            log.info(f"Key Count:{key_count}, tries:{tries}")
        return files

    def get_file_content(self, key):
        obj = self.s3_client.get_object(Bucket=self.bucket_name, Key=key)
        file_content = json.loads(obj["Body"].read())
        return file_content

    def get_tags(self, key):
        response = self.s3_client.get_object_tagging(Bucket=self.bucket_name, Key=key)
        tag_set = response["TagSet"]
        tags = {}
        for tag in tag_set:
            if tag["Key"] in EXPECTED_TAGS:
                tags[tag["Key"]] = tag["Value"]

        return tags

    def update_payload_and_header_for_sqs(
        self, deal_ref_id, payload, payload_type, reference_id
    ):
        """
        update payload with header for sqs simulator
        """
        payload_type_mapping = {
            "CREDIT_APP_POST": {
                "header_key": "contractRefId",
                "payload_key": "creditAppId",
                "value": reference_id,
            },
            "CREDIT_APP_PATCH": {
                "header_key": "contractRefId",
                "payload_key": "creditAppId",
                "value": reference_id,
            },
            "CREDIT_APP_UPDATE": {
                "header_key": "contractRefId",
                "payload_key": "creditAppId",
                "value": reference_id,
            },
            "CONTRACT_POST": {
                "header_key": "contractRefId",
                "payload_key": "contractRefId",
                "value": reference_id,
            },
            "VERIFY_CONTRACT_POST": {
                "header_key": "contractRefId",
                "payload_key": "contractRefId",
                "value": reference_id,
            },
            "SIGN_CONTRACT_POST": {
                "header_key": "contractRefId",
                "payload_key": "contractRefId",
                "value": reference_id,
            },
            "LEAD_POST": {
                "header_key": "leadRefId",
                "payload_key": "leadRefId",
                "value": reference_id,
            },
            "LEAD_PATCH": {
                "header_key": "leadRefId",
                "payload_key": "leadRefId",
                "value": reference_id,
            },
            "LEAD_UPDATE": {
                "header_key": "leadRefId",
                "payload_key": "leadRefId",
                "value": reference_id,
            },
            "KEY_DATA_POST": {"header_key": "", "payload_key": "", "value": ""},
            "KEY_DATA_PATCH": {"header_key": "", "payload_key": "", "value": ""},
            "KEY_DATA_UPDATE": {"header_key": "", "payload_key": "", "value": ""},
        }
        if payload_type not in payload_type_mapping.keys():
            raise Exception(
                f"Invalid payload type is provided. Valid payload type are {payload_type_mapping.keys()}"
            )
        payload["dealRefId"] = deal_ref_id
        payload[
            payload_type_mapping[payload_type]["payload_key"]
        ] = payload_type_mapping[payload_type]["value"]

        headers = {
            "payloadType": payload_type,
            "dealRefId": deal_ref_id,
            "correlationId": f"{str(uuid.uuid4())}_SIMBRIDGE",
            "region": self.region,
            "encryption": "disable",
        }
        if payload_type_mapping[payload_type]["header_key"]:
            payload_type_mapping[payload_type]["header_key"] = payload_type_mapping[
                payload_type
            ]["value"]
        return headers


class TestReprocessingGarage:
    @classmethod
    @pytest.fixture(autouse=True)
    def setup_class(
        cls,
        env,
        stage,
        region,
        api_url,
        random_data_class,
        s3_client,
    ):
        cls.env = env
        cls.stage = stage
        cls.region = region
        cls.api_url = api_url

        cls.s3_client = s3_client
        cls.reprocessing_garage = ReprocessingGarageHelper(
            env=cls.env, stage=cls.stage, region=cls.region, s3_client=s3_client
        )
        cls.deal_data = ServiceAPI(env=cls.env, random_data_class=random_data_class)
        cls.deal_data.dealRefId = cls.deal_data.generate_random_id(True)
        cls.deal_data.leadRefId = cls.deal_data.generate_random_id(True)
        cls.deal_data.creditAppId = cls.deal_data.generate_random_id(True)
        cls.deal_data.contractRefId = cls.deal_data.generate_random_id(True)

        S3_KEY_TO_DELETE.append(cls.deal_data.dealRefId)

    def validate_posted_data_with_s3_data(
        self, test_data, key_id="payload_type", expected_count=1
    ):
        post_payload_type = [
            PayloadType.LEAD_POST,
            PayloadType.LEAD_PATCH,
            PayloadType.CREDIT_APP_POST,
            PayloadType.CREDIT_APP_PATCH,
            PayloadType.CONTRACT_POST,
        ]
        update_payload_type = [PayloadType.LEAD_UPDATE, PayloadType.CREDIT_APP_UPDATE]
        test_payload_list = []
        for data in test_data:
            # Send a message to DLQ
            if data["payload_type"] in post_payload_type:
                self.deal_data.set_payload(data["file_name"])
            elif data["payload_type"] in update_payload_type:
                self.deal_data.set_payload(data["file_name"][0], data["file_name"][1])
                self.deal_data.payload = self.deal_data.patch_payload
            else:
                self.deal_data.payload = data["file_name"]

            if isinstance(self.deal_data.payload, str):
                self.deal_data.payload = json.loads(self.deal_data.payload)

            sim_headers = self.reprocessing_garage.update_payload_and_header_for_sqs(
                deal_ref_id=self.deal_data.dealRefId,
                payload=self.deal_data.payload,
                payload_type=data["payloadType"],
                reference_id=data["reference_value"],
            )
            data = copy.deepcopy(
                {"sim_headers": sim_headers, "payload": self.deal_data.payload}
            )
            test_payload_list.append(data)
            status_code, simulator_resp, resp_headers = self.deal_data.post_request(
                url=self.api_url,
                route_url="stack_supporter",
                cust_header=sim_headers,
                sqs_name=self.reprocessing_garage.queue_name,
            )
            if status_code != HTTPStatus.CREATED:
                raise Exception(
                    f"Response code is: {status_code} and the response message is: {simulator_resp}"
                )
        files = self.reprocessing_garage.get_files(
            deal_ref_id=self.deal_data.dealRefId, expected_count=expected_count
        )
        assert files["KeyCount"] == len(test_data)

        files_contents = files["Contents"]
        s3_payload_list = []
        for file in files_contents:
            key = file["Key"]
            s3_tags = self.reprocessing_garage.get_tags(key)
            file_data = self.reprocessing_garage.get_file_content(key)
            file = {"sim_headers": s3_tags, "payload": file_data}
            s3_payload_list.append(file)
        for requ in test_payload_list:
            resp_found = False
            for resp in s3_payload_list:
                if requ["sim_headers"][key_id] == resp["sim_headers"][key_id]:
                    resp_found = True
                    assert requ["payload"] == resp["payload"]
                    requ["sim_headers"]["x-aws-region"] = self.region
                    for i in EXPECTED_TAGS:
                        assert requ["sim_headers"][i] == resp["sim_headers"][i]
            assert resp_found

    test_data = [
        (
            PayloadType.LEAD_POST,
            "self.deal_data.leadRefId",
            "leads/leads_min_data.json",
        ),
        (
            PayloadType.CREDIT_APP_POST,
            "self.deal_data.creditAppId",
            "credit_app/app_min_data.json",
        ),
        (PayloadType.KEY_DATA_POST, "", "key_data_test_data['single_id']"),
        (
            PayloadType.CONTRACT_POST,
            "self.deal_data.contractRefId",
            "contract/individual_retail_new.json",
        ),
        (
            PayloadType.VERIFY_CONTRACT_POST,
            "self.deal_data.contractRefId",
            "verify_contract_payload",
        ),
        (
            PayloadType.SIGN_CONTRACT_POST,
            "self.deal_data.contractRefId",
            "signing_contract_payload(['applicant'])",
        ),
    ]

    @pytest.mark.prod
    @pytest.mark.smoke
    @pytest.mark.functional
    @pytest.mark.parametrize(
        "payload_type, reference_value, payload_file_or_payload", test_data
    )
    def test_dlq_to_s3_for_single_event(
        self,
        payload_type,
        reference_value,
        payload_file_or_payload,
        key_data_test_data,  # do not remove
        verify_contract_payload,  # do not remove
        signing_contract_payload,  # do not remove
    ):
        fixture_payload = [
            PayloadType.VERIFY_CONTRACT_POST,
            PayloadType.SIGN_CONTRACT_POST,
            PayloadType.KEY_DATA_POST,
            PayloadType.KEY_DATA_UPDATE,
        ]

        reference_id = eval(reference_value) if reference_value else None
        test_data = [
            {
                "file_name": eval(payload_file_or_payload)
                if payload_type in fixture_payload
                else payload_file_or_payload,
                "payload_type": payload_type,
                "reference_value": reference_id,
            }
        ]
        self.validate_posted_data_with_s3_data(test_data=test_data)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_dlq_to_s3_for_multiple_events(
        self, key_data_test_data, verify_contract_payload, signing_contract_payload
    ):
        test_data = [
            {
                "file_name": "leads/leads_min_data.json",
                "payload_type": PayloadType.LEAD_POST,
                "reference_value": self.deal_data.leadRefId,
            },
            {
                "file_name": "credit_app/ind_retail_new.json",
                "payload_type": PayloadType.CREDIT_APP_POST,
                "reference_value": self.deal_data.creditAppId,
            },
            {
                "file_name": key_data_test_data["single_id"],
                "payload_type": PayloadType.KEY_DATA_POST,
                "reference_value": "",
            },
            {
                "file_name": "contract/individual_retail_new.json",
                "payload_type": PayloadType.CONTRACT_POST,
                "reference_value": self.deal_data.contractRefId,
            },
            {
                "file_name": verify_contract_payload,
                "payload_type": PayloadType.VERIFY_CONTRACT_POST,
                "reference_value": self.deal_data.contractRefId,
            },
            {
                "file_name": signing_contract_payload(["applicant"]),
                "payload_type": PayloadType.SIGN_CONTRACT_POST,
                "reference_value": self.deal_data.contractRefId,
            },
        ]
        self.validate_posted_data_with_s3_data(
            test_data=test_data, expected_count=len(test_data), key_id="correlation_id"
        )

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_dlq_to_s3_for_multiple_post_with_same_payload_type(self):
        test_data = [
            {
                "file_name": "leads/leads_min_data.json",
                "payload_type": PayloadType.LEAD_POST,
                "reference_value": self.deal_data.leadRefId,
            },
            {
                "file_name": "leads/leads_min_data.json",
                "payload_type": PayloadType.LEAD_POST,
                "reference_value": self.deal_data.leadRefId,
            },
            {
                "file_name": "leads/leads_min_data.json",
                "payload_type": PayloadType.LEAD_POST,
                "reference_value": self.deal_data.leadRefId,
            },
        ]
        self.validate_posted_data_with_s3_data(
            test_data=test_data, expected_count=len(test_data), key_id="correlation_id"
        )

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_dlq_to_s3_for_update_events(self, key_data_test_data):
        test_data = [
            {
                "file_name": "leads/leads_min_data.json",
                "payload_type": PayloadType.LEAD_POST,
                "reference_value": self.deal_data.leadRefId,
            },
            {
                "file_name": "leads/leads_min_data.json",
                "payload_type": PayloadType.LEAD_PATCH,
                "reference_value": self.deal_data.leadRefId,
            },
            {
                "file_name": ["credit_app/credit_app_full_payload.json", "tradeIns"],
                "payload_type": PayloadType.LEAD_UPDATE,
                "reference_value": self.deal_data.leadRefId,
            },
            {
                "file_name": "credit_app/ind_retail_new.json",
                "payload_type": PayloadType.CREDIT_APP_PATCH,
                "reference_value": self.deal_data.creditAppId,
            },
            {
                "file_name": ["credit_app/credit_app_full_payload.json", "applicant"],
                "payload_type": PayloadType.CREDIT_APP_UPDATE,
                "reference_value": self.deal_data.creditAppId,
            },
            {
                "file_name": key_data_test_data["multiple_ids"],
                "payload_type": PayloadType.KEY_DATA_UPDATE,
                "reference_value": "",
            },
        ]
        self.validate_posted_data_with_s3_data(
            test_data=test_data, expected_count=len(test_data)
        )
