# -*- coding: utf-8 -*-

from http import HTTPStatus

import pytest
import ulid
from tests.functional.service_api import ServiceAPI


GET_FLD_ROUTE = "lender_decision"
POST_FLD_ROUTE = "post_lender_decision"
PII_FLAG = "protected=true"
KEY_DATA_ROUTER = "key_data"

EVENT_PAYLOAD = "events/fs_internal_credit_decision_counter.json"


@pytest.mark.prod
@pytest.mark.smoke
@pytest.mark.functional
def test_full_decision_get_for_individual_retail_new_declined(
    env,
    api_url,
    common_assert,
    random_data_class,
    delete_data_from_s3_bucket,
    upload_full_lender_decision_to_s3_bucket,
):
    json_file_name = "individual_retail_new_declined.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"full_lender_decision/{json_file_name}",
    )

    # Upload Sample decision payload to S3
    (
        source_partner,
        partner_dealer_id,
        lender_id,
        event_id,
    ) = deal_data.generate_s3_bucket_key()
    upload_full_lender_decision_to_s3_bucket(
        source_partner,
        partner_dealer_id,
        deal_data.dealRefId,
        lender_id,
        event_id,
        deal_data.payload,
    )

    # GET Full Lender Decision Response from S3
    status_code, resp_body, resp_headers = deal_data.get_request(
        url=api_url,
        route_url=GET_FLD_ROUTE,
        source_partner=source_partner,
        dealer_id=partner_dealer_id,
        lender_id=lender_id,
        decision_get=True,
    )

    if status_code != HTTPStatus.OK:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {resp_body}"
        )

    deal_data.mask_pii_fields_in_request_payload()
    assert resp_body == deal_data.payload

    common_assert(resp_headers=resp_headers, with_ttl=False)
    delete_data_from_s3_bucket(
        deal_data.payload["sourcePartnerId"],
        deal_data.payload["sourcePartnerDealerId"],
        deal_data.dealRefId,
        deal_data.payload["lenderDecision"]["lenderId"],
        event_id,
    )


@pytest.mark.functional
def test_full_decision_get_for_individual_retail_used_counteroffer(
    env,
    api_url,
    common_assert,
    random_data_class,
    delete_data_from_s3_bucket,
    upload_full_lender_decision_to_s3_bucket,
):
    json_file_name = "individual_retail_used_counteroffer.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"full_lender_decision/{json_file_name}",
    )

    # Upload Sample decision payload to S3
    (
        source_partner,
        partner_dealer_id,
        lender_id,
        event_id,
    ) = deal_data.generate_s3_bucket_key()
    upload_full_lender_decision_to_s3_bucket(
        source_partner,
        partner_dealer_id,
        deal_data.dealRefId,
        lender_id,
        event_id,
        deal_data.payload,
    )

    # GET Full Lender Decision Response from S3
    status_code, resp_body, resp_headers = deal_data.get_request(
        url=api_url,
        route_url=GET_FLD_ROUTE,
        source_partner=source_partner,
        dealer_id=partner_dealer_id,
        lender_id=lender_id,
        decision_get=True,
    )

    if status_code != HTTPStatus.OK:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {resp_body}"
        )

    deal_data.mask_pii_fields_in_request_payload()
    assert resp_body == deal_data.payload
    common_assert(resp_headers=resp_headers, with_ttl=False)

    delete_data_from_s3_bucket(
        source_partner, partner_dealer_id, deal_data.dealRefId, lender_id, event_id
    )


@pytest.mark.functional
def test_full_decision_get_individual_lease_new_counteroffer_trade(
    env,
    api_url,
    common_assert,
    random_data_class,
    delete_data_from_s3_bucket,
    upload_full_lender_decision_to_s3_bucket,
):
    json_file_name = "individual_lease_new_counteroffer_trade.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"full_lender_decision/{json_file_name}",
    )

    # Upload Sample decision payload to S3
    (
        source_partner,
        partner_dealer_id,
        lender_id,
        event_id,
    ) = deal_data.generate_s3_bucket_key()
    upload_full_lender_decision_to_s3_bucket(
        source_partner,
        partner_dealer_id,
        deal_data.dealRefId,
        lender_id,
        event_id,
        deal_data.payload,
    )

    # GET Full Lender Decision Response from S3
    status_code, resp_body, resp_headers = deal_data.get_request(
        url=api_url,
        route_url=GET_FLD_ROUTE,
        source_partner=source_partner,
        dealer_id=partner_dealer_id,
        lender_id=lender_id,
        decision_get=True,
    )

    if status_code != HTTPStatus.OK:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {resp_body}"
        )

    deal_data.mask_pii_fields_in_request_payload()
    assert resp_body == deal_data.payload
    common_assert(resp_headers=resp_headers, with_ttl=False)

    delete_data_from_s3_bucket(
        source_partner, partner_dealer_id, deal_data.dealRefId, lender_id, event_id
    )


@pytest.mark.prod
@pytest.mark.smoke
@pytest.mark.functional
def test_full_decision_get_individual_lease_new_approved_previous_emp_add(
    env,
    api_url,
    common_assert,
    random_data_class,
    delete_data_from_s3_bucket,
    upload_full_lender_decision_to_s3_bucket,
):
    json_file_name = "individual_lease_new_approved_previous_emp_add.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"full_lender_decision/{json_file_name}",
    )

    # Upload Sample decision payload to S3
    (
        source_partner,
        partner_dealer_id,
        lender_id,
        event_id,
    ) = deal_data.generate_s3_bucket_key()
    upload_full_lender_decision_to_s3_bucket(
        source_partner,
        partner_dealer_id,
        deal_data.dealRefId,
        lender_id,
        event_id,
        deal_data.payload,
    )

    # GET Full Lender Decision Response from S3
    status_code, resp_body, resp_headers = deal_data.get_request(
        url=api_url,
        route_url=GET_FLD_ROUTE,
        source_partner=source_partner,
        dealer_id=partner_dealer_id,
        lender_id=lender_id,
        decision_get=True,
    )

    if status_code != HTTPStatus.OK:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {resp_body}"
        )

    deal_data.mask_pii_fields_in_request_payload()
    assert resp_body == deal_data.payload
    common_assert(resp_headers=resp_headers, with_ttl=False)

    delete_data_from_s3_bucket(
        source_partner, partner_dealer_id, deal_data.dealRefId, lender_id, event_id
    )


@pytest.mark.functional
def test_full_decision_get_joint_lease_new_declined(
    env,
    api_url,
    common_assert,
    random_data_class,
    delete_data_from_s3_bucket,
    upload_full_lender_decision_to_s3_bucket,
):
    json_file_name = "individual_lease_new_approved_previous_emp_add.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"full_lender_decision/{json_file_name}",
    )

    # Upload Sample decision payload to S3
    (
        source_partner,
        partner_dealer_id,
        lender_id,
        event_id,
    ) = deal_data.generate_s3_bucket_key()
    upload_full_lender_decision_to_s3_bucket(
        source_partner,
        partner_dealer_id,
        deal_data.dealRefId,
        lender_id,
        event_id,
        deal_data.payload,
    )

    # GET Full Lender Decision Response from S3
    status_code, resp_body, resp_headers = deal_data.get_request(
        url=api_url,
        route_url=GET_FLD_ROUTE,
        source_partner=source_partner,
        dealer_id=partner_dealer_id,
        lender_id=lender_id,
        decision_get=True,
    )

    if status_code != HTTPStatus.OK:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {resp_body}"
        )

    deal_data.mask_pii_fields_in_request_payload()
    assert resp_body == deal_data.payload
    common_assert(resp_headers=resp_headers, with_ttl=False)

    delete_data_from_s3_bucket(
        source_partner, partner_dealer_id, deal_data.dealRefId, lender_id, event_id
    )


@pytest.mark.functional
def test_full_decision_get_joint_retail_used_approved(
    env,
    api_url,
    common_assert,
    random_data_class,
    delete_data_from_s3_bucket,
    upload_full_lender_decision_to_s3_bucket,
):
    json_file_name = "joint_retail_used_approved.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"full_lender_decision/{json_file_name}",
    )

    # Upload Sample decision payload to S3
    (
        source_partner,
        partner_dealer_id,
        lender_id,
        event_id,
    ) = deal_data.generate_s3_bucket_key()
    upload_full_lender_decision_to_s3_bucket(
        source_partner,
        partner_dealer_id,
        deal_data.dealRefId,
        lender_id,
        event_id,
        deal_data.payload,
    )

    # GET Full Lender Decision Response from S3
    status_code, resp_body, resp_headers = deal_data.get_request(
        url=api_url,
        route_url=GET_FLD_ROUTE,
        source_partner=source_partner,
        dealer_id=partner_dealer_id,
        lender_id=lender_id,
        decision_get=True,
    )

    if status_code != HTTPStatus.OK:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {resp_body}"
        )

    deal_data.mask_pii_fields_in_request_payload()
    common_assert(resp_headers=resp_headers, with_ttl=False)

    delete_data_from_s3_bucket(
        source_partner, partner_dealer_id, deal_data.dealRefId, lender_id, event_id
    )


@pytest.mark.smoke
@pytest.mark.functional
def test_full_decision_get_with_multiple_files(
    env,
    api_url,
    common_assert,
    random_data_class,
    delete_data_from_s3_bucket,
    upload_full_lender_decision_to_s3_bucket,
):
    json_file_name = "joint_retail_used_approved.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"full_lender_decision/{json_file_name}",
    )

    # Upload Sample decision payload to S3
    (
        source_partner,
        partner_dealer_id,
        lender_id,
        event_id,
    ) = deal_data.generate_s3_bucket_key()
    upload_full_lender_decision_to_s3_bucket(
        source_partner,
        partner_dealer_id,
        deal_data.dealRefId,
        lender_id,
        event_id,
        deal_data.payload,
    )

    # Upload 2nd file to same bucket
    deal_data.set_payload(
        "full_lender_decision/individual_lease_new_approved_previous_emp_add.json"
    )
    second_event_id = ulid.new().str
    upload_full_lender_decision_to_s3_bucket(
        source_partner,
        partner_dealer_id,
        deal_data.dealRefId,
        lender_id,
        second_event_id,
        deal_data.payload,
    )

    # GET Full Lender Decision Response from S3
    status_code, resp_body, resp_headers = deal_data.get_request(
        url=api_url,
        route_url=GET_FLD_ROUTE,
        source_partner=source_partner,
        dealer_id=partner_dealer_id,
        lender_id=lender_id,
        decision_get=True,
    )

    if status_code != HTTPStatus.OK:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {resp_body}"
        )

    deal_data.mask_pii_fields_in_request_payload()
    assert resp_body == deal_data.payload
    assert resp_headers["X-CoxAuto-Correlation-Id"] is not None

    # Upload 3nd file to same bucket
    deal_data.set_payload(
        "full_lender_decision/individual_lease_new_counteroffer_trade.json"
    )
    third_event_id = ulid.new().str
    upload_full_lender_decision_to_s3_bucket(
        source_partner,
        partner_dealer_id,
        deal_data.dealRefId,
        lender_id,
        third_event_id,
        deal_data.payload,
    )

    # GET Full Lender Decision Response from S3
    status_code, resp_body, resp_headers = deal_data.get_request(
        url=api_url,
        route_url=GET_FLD_ROUTE,
        source_partner=source_partner,
        dealer_id=partner_dealer_id,
        lender_id=lender_id,
        decision_get=True,
    )

    if status_code != HTTPStatus.OK:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {resp_body}"
        )

    deal_data.mask_pii_fields_in_request_payload()
    assert resp_body == deal_data.payload
    common_assert(resp_headers=resp_headers, with_ttl=False)

    delete_data_from_s3_bucket(
        source_partner, partner_dealer_id, deal_data.dealRefId, lender_id, event_id
    )
    delete_data_from_s3_bucket(
        source_partner,
        partner_dealer_id,
        deal_data.dealRefId,
        lender_id,
        second_event_id,
    )
    delete_data_from_s3_bucket(
        source_partner,
        partner_dealer_id,
        deal_data.dealRefId,
        lender_id,
        third_event_id,
    )


@pytest.mark.smoke
@pytest.mark.functional
def test_full_decision_get_with_url_in_lower_case(
    env,
    api_url,
    common_assert,
    random_data_class,
    delete_data_from_s3_bucket,
    upload_full_lender_decision_to_s3_bucket,
):
    json_file_name = "joint_retail_used_approved.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"full_lender_decision/{json_file_name}",
    )

    # Upload Sample decision payload to S3
    (
        source_partner,
        partner_dealer_id,
        lender_id,
        event_id,
    ) = deal_data.generate_s3_bucket_key()
    upload_full_lender_decision_to_s3_bucket(
        source_partner,
        partner_dealer_id,
        deal_data.dealRefId,
        lender_id,
        event_id,
        deal_data.payload,
    )
    # GET Full Lender Decision Response from S3
    deal_data.dealRefId = deal_data.dealRefId.lower()
    status_code, resp_body, resp_headers = deal_data.get_request(
        url=api_url,
        route_url=GET_FLD_ROUTE,
        source_partner=source_partner,
        dealer_id=partner_dealer_id,
        lender_id=lender_id.lower(),
        decision_get=True,
    )

    if status_code != HTTPStatus.OK:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {resp_body}"
        )

    deal_data.mask_pii_fields_in_request_payload()
    assert resp_body == deal_data.payload
    common_assert(resp_headers=resp_headers, with_ttl=False)

    deal_data.dealRefId = deal_data.dealRefId.upper()
    delete_data_from_s3_bucket(
        source_partner, partner_dealer_id, deal_data.dealRefId, lender_id, event_id
    )


@pytest.mark.functional
def test_full_decision_get_with_header_in_lower_case(
    env,
    api_url,
    common_assert,
    random_data_class,
    delete_data_from_s3_bucket,
    upload_full_lender_decision_to_s3_bucket,
):
    json_file_name = "joint_retail_used_approved.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"full_lender_decision/{json_file_name}",
    )

    # Upload Sample decision payload to S3
    (
        source_partner,
        partner_dealer_id,
        lender_id,
        event_id,
    ) = deal_data.generate_s3_bucket_key()
    upload_full_lender_decision_to_s3_bucket(
        source_partner,
        partner_dealer_id,
        deal_data.dealRefId,
        lender_id,
        event_id,
        deal_data.payload,
    )
    # GET Full Lender Decision Response from S3
    status_code, resp_body, resp_headers = deal_data.get_request(
        url=api_url,
        route_url=GET_FLD_ROUTE,
        source_partner=source_partner.lower(),
        dealer_id=partner_dealer_id,
        lender_id=lender_id,
        decision_get=True,
    )

    if status_code != HTTPStatus.OK:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {resp_body}"
        )

    deal_data.mask_pii_fields_in_request_payload()
    assert resp_body == deal_data.payload
    common_assert(resp_headers=resp_headers, with_ttl=False)

    delete_data_from_s3_bucket(
        source_partner, partner_dealer_id, deal_data.dealRefId, lender_id, event_id
    )


@pytest.mark.smoke
@pytest.mark.functional
def test_full_decision_get_missing_source_partner_in_header(
    env,
    api_url,
    common_assert,
    random_data_class,
    delete_data_from_s3_bucket,
    upload_full_lender_decision_to_s3_bucket,
):
    json_file_name = "joint_retail_used_approved.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"full_lender_decision/{json_file_name}",
    )

    # Upload Sample decision payload to S3
    (
        source_partner,
        partner_dealer_id,
        lender_id,
        event_id,
    ) = deal_data.generate_s3_bucket_key()
    upload_full_lender_decision_to_s3_bucket(
        source_partner,
        partner_dealer_id,
        deal_data.dealRefId,
        lender_id,
        event_id,
        deal_data.payload,
    )

    # GET Full Lender Decision Response from S3
    status_code, resp_body, resp_headers = deal_data.get_request(
        url=api_url,
        route_url=GET_FLD_ROUTE,
        source_partner=source_partner,
        dealer_id=partner_dealer_id,
        lender_id=lender_id,
        decision_get=False,
    )

    if status_code != HTTPStatus.BAD_REQUEST:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {resp_body}"
        )

    assert (
        resp_body["message"]
        == "Missing header(s): 'Source-Partner' is needed to process request"
    )
    common_assert(resp_headers=resp_headers, with_ttl=False)

    delete_data_from_s3_bucket(
        source_partner, partner_dealer_id, deal_data.dealRefId, lender_id, event_id
    )


@pytest.mark.smoke
@pytest.mark.functional
def test_full_decision_get_with_out_source_partner_value_in_header(
    env,
    api_url,
    common_assert,
    random_data_class,
    delete_data_from_s3_bucket,
    upload_full_lender_decision_to_s3_bucket,
):
    json_file_name = "joint_retail_used_approved.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"full_lender_decision/{json_file_name}",
    )

    # Upload Sample decision payload to S3
    (
        source_partner,
        partner_dealer_id,
        lender_id,
        event_id,
    ) = deal_data.generate_s3_bucket_key()
    upload_full_lender_decision_to_s3_bucket(
        source_partner,
        partner_dealer_id,
        deal_data.dealRefId,
        lender_id,
        event_id,
        deal_data.payload,
    )

    # GET Full Lender Decision Response from S3
    status_code, resp_body, resp_headers = deal_data.get_request(
        url=api_url,
        route_url=GET_FLD_ROUTE,
        source_partner="",
        dealer_id=partner_dealer_id,
        lender_id=lender_id,
        decision_get=True,
    )

    if status_code != HTTPStatus.BAD_REQUEST:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {resp_body}"
        )

    assert (
        resp_body["message"]
        == "Missing header(s): 'Source-Partner' is needed to process request"
    )
    common_assert(resp_headers=resp_headers, with_ttl=False)

    delete_data_from_s3_bucket(
        source_partner, partner_dealer_id, deal_data.dealRefId, lender_id, event_id
    )


@pytest.mark.smoke
@pytest.mark.functional
def test_full_decision_get_with_invalid_deal_ref_id(
    env,
    api_url,
    common_assert,
    random_data_class,
    delete_data_from_s3_bucket,
    upload_full_lender_decision_to_s3_bucket,
):
    json_file_name = "joint_retail_used_approved.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"full_lender_decision/{json_file_name}",
    )

    # Upload Sample decision payload to S3
    (
        source_partner,
        partner_dealer_id,
        lender_id,
        event_id,
    ) = deal_data.generate_s3_bucket_key()
    upload_full_lender_decision_to_s3_bucket(
        source_partner,
        partner_dealer_id,
        deal_data.dealRefId,
        lender_id,
        event_id,
        deal_data.payload,
    )

    # GET Full Lender Decision Response from S3
    original_red_ref_id = deal_data.dealRefId
    deal_data.dealRefId = deal_data.generate_random_id()
    status_code, resp_body, resp_headers = deal_data.get_request(
        url=api_url,
        route_url=GET_FLD_ROUTE,
        source_partner=source_partner,
        dealer_id=partner_dealer_id,
        lender_id=lender_id,
        decision_get=True,
    )

    if status_code != HTTPStatus.NOT_FOUND:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {resp_body}"
        )

    assert resp_body["message"] == "Not Found"
    common_assert(resp_headers=resp_headers, with_ttl=False)

    delete_data_from_s3_bucket(
        source_partner, partner_dealer_id, original_red_ref_id, lender_id, event_id
    )


@pytest.mark.functional
def test_full_decision_get_with_invalid_lender_id(
    env,
    api_url,
    common_assert,
    random_data_class,
    delete_data_from_s3_bucket,
    upload_full_lender_decision_to_s3_bucket,
):
    json_file_name = "joint_retail_used_approved.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"full_lender_decision/{json_file_name}",
    )

    # Upload Sample decision payload to S3
    (
        source_partner,
        partner_dealer_id,
        lender_id,
        event_id,
    ) = deal_data.generate_s3_bucket_key()
    upload_full_lender_decision_to_s3_bucket(
        source_partner,
        partner_dealer_id,
        deal_data.dealRefId,
        lender_id,
        event_id,
        deal_data.payload,
    )

    # GET Full Lender Decision Response from S3
    status_code, resp_body, resp_headers = deal_data.get_request(
        url=api_url,
        route_url=GET_FLD_ROUTE,
        source_partner=source_partner,
        dealer_id=partner_dealer_id,
        lender_id="TTT",
        decision_get=True,
    )

    if status_code != HTTPStatus.NOT_FOUND:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {resp_body}"
        )

    assert resp_body["message"] == "Not Found"
    common_assert(resp_headers=resp_headers, with_ttl=False)

    delete_data_from_s3_bucket(
        source_partner, partner_dealer_id, deal_data.dealRefId, lender_id, event_id
    )


@pytest.mark.functional
def test_full_decision_get_only_with_latest_file(
    env,
    api_url,
    common_assert,
    random_data_class,
    delete_data_from_s3_bucket,
    upload_full_lender_decision_to_s3_bucket,
):
    json_file_name = "individual_retail_new_declined.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"full_lender_decision/{json_file_name}",
    )

    # Upload Sample decision payload to S3
    (
        source_partner,
        partner_dealer_id,
        lender_id,
        event_id,
    ) = deal_data.generate_s3_bucket_key()
    upload_full_lender_decision_to_s3_bucket(
        source_partner,
        partner_dealer_id,
        deal_data.dealRefId,
        lender_id,
        event_id,
        deal_data.payload,
        False,
        True,
    )

    # GET Full Lender Decision Response from S3
    status_code, resp_body, resp_headers = deal_data.get_request(
        url=api_url,
        route_url=GET_FLD_ROUTE,
        source_partner=source_partner,
        dealer_id=partner_dealer_id,
        lender_id=lender_id,
        decision_get=True,
    )

    if status_code != HTTPStatus.OK:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {resp_body}"
        )

    deal_data.mask_pii_fields_in_request_payload()
    assert resp_body == deal_data.payload
    common_assert(resp_headers=resp_headers, with_ttl=False)

    delete_data_from_s3_bucket(
        source_partner, partner_dealer_id, deal_data.dealRefId, lender_id, event_id
    )


@pytest.mark.smoke
@pytest.mark.functional
def test_full_decision_get_without_latest_file(
    env,
    api_url,
    common_assert,
    random_data_class,
    delete_data_from_s3_bucket,
    upload_full_lender_decision_to_s3_bucket,
):
    json_file_name = "individual_retail_new_declined.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"full_lender_decision/{json_file_name}",
    )

    # Upload Sample decision payload to S3
    (
        source_partner,
        partner_dealer_id,
        lender_id,
        event_id,
    ) = deal_data.generate_s3_bucket_key()
    upload_full_lender_decision_to_s3_bucket(
        source_partner,
        partner_dealer_id,
        deal_data.dealRefId,
        lender_id,
        event_id,
        deal_data.payload,
        True,
        False,
    )

    # GET Full Lender Decision Response from S3
    status_code, resp_body, resp_headers = deal_data.get_request(
        url=api_url,
        route_url=GET_FLD_ROUTE,
        source_partner=source_partner,
        dealer_id=partner_dealer_id,
        lender_id=lender_id,
        decision_get=True,
    )

    if status_code != HTTPStatus.NOT_FOUND:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {resp_body}"
        )

    common_assert(resp_headers=resp_headers, with_ttl=False)

    delete_data_from_s3_bucket(
        source_partner, partner_dealer_id, deal_data.dealRefId, lender_id, event_id
    )


@pytest.mark.smoke
@pytest.mark.functional
@pytest.mark.xfail(reason="Validation on GET is pending.")
def test_full_decision_get_with_invalid_payload_in_s3(
    env,
    api_url,
    common_assert,
    invalid_payload,
    random_data_class,
    delete_data_from_s3_bucket,
    upload_full_lender_decision_to_s3_bucket,
):
    deal_data = ServiceAPI(
        env=env, random_data_class=random_data_class, payload=invalid_payload
    )
    # Upload Sample decision payload to S3
    (
        source_partner,
        partner_dealer_id,
        lender_id,
        event_id,
    ) = deal_data.generate_s3_bucket_key()
    upload_full_lender_decision_to_s3_bucket(
        source_partner,
        partner_dealer_id,
        deal_data.dealRefId,
        lender_id,
        event_id,
        deal_data.payload,
    )

    # GET Full Lender Decision Response from S3
    status_code, resp_body, resp_headers = deal_data.get_request(
        url=api_url,
        route_url=GET_FLD_ROUTE,
        source_partner=source_partner,
        dealer_id=partner_dealer_id,
        lender_id=lender_id,
        decision_get=True,
    )

    if status_code != HTTPStatus.INTERNAL_SERVER_ERROR:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {resp_body}"
        )

    assert resp_body["message"] == "Unable to Process"
    common_assert(resp_headers=resp_headers, with_ttl=False)

    delete_data_from_s3_bucket(
        source_partner, partner_dealer_id, deal_data.dealRefId, lender_id, event_id
    )


@pytest.mark.prod
@pytest.mark.smoke
@pytest.mark.functional
def test_ignore_pii_unmasking_query(
    env,
    api_url,
    common_assert,
    random_data_class,
    validate_pii_masking,
    delete_data_from_s3_bucket,
    upload_full_lender_decision_to_s3_bucket,
):
    json_file_name = "joint_lease_new_declined.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"full_lender_decision/{json_file_name}",
    )

    # Upload Sample decision payload to S3
    (
        source_partner,
        partner_dealer_id,
        lender_id,
        event_id,
    ) = deal_data.generate_s3_bucket_key()
    upload_full_lender_decision_to_s3_bucket(
        source_partner,
        partner_dealer_id,
        deal_data.dealRefId,
        lender_id,
        event_id,
        deal_data.payload,
    )

    # GET Full Lender Decision Response from S3
    status_code, resp_body, resp_headers = deal_data.get_request(
        url=api_url,
        route_url=GET_FLD_ROUTE,
        source_partner=source_partner,
        dealer_id=partner_dealer_id,
        lender_id=lender_id,
        decision_get=True,
        query_param=PII_FLAG,
    )

    if status_code != HTTPStatus.OK:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {resp_body}"
        )

    validate_pii_masking(resp_body)
    common_assert(resp_headers=resp_headers, with_ttl=False)

    delete_data_from_s3_bucket(
        source_partner, partner_dealer_id, deal_data.dealRefId, lender_id, event_id
    )
