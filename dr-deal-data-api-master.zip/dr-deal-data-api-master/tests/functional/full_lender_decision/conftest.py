# -*- coding: utf-8 -*-
import pytest


@pytest.fixture()
def generate_decision_record():
    def decision_payload(lender_id=None):
        return {
            "approvalStatus": "Approved",
            "approvedAmount": "29088",
            "approvedRate": "5",
            "approvedTerm": "60",
            "customerMoneyFactor": "0.002",
            "downPayment": "4380",
            "financeMethod": "Retail",
            "lenderId": lender_id or "DT6",
            "lenderMoneyFactor": "0.005",
            "lenderName": "American Honda Finance Corporation",
            "monthlyPayment": "458",
            "stipulations": [{"text": "test1"}, {"text": "test2"}],
            "tier": "Gold",
        }

    return decision_payload


@pytest.fixture()
def update_decision_payload(generate_decision_record):
    def wrapper(full_lender_decision):
        decision_filter = generate_decision_record().keys()
        full_lender_decision["lenderDecision"] = {
            k: v
            for k, v in full_lender_decision["lenderDecision"].items()
            if k in decision_filter
        }

    return wrapper


@pytest.fixture()
def invalid_credit_app_id_mismatch():
    def wrapper(credit_app_id):
        return [
            {
                "code": "deal.invalidRefId",
                "properties": [
                    {
                        "property": "creditAppId",
                        "message": f"Invalid creditAppId {credit_app_id}",
                    }
                ],
            }
        ]

    return wrapper


@pytest.fixture()
def invalid_credit_app_id_ulid_check():
    return [
        {
            "code": "deal.invalidRefId",
            "properties": [
                {
                    "property": "creditAppId",
                    "message": "Invalid ulid provided. Error Expects 26 characters for decoding; got 20",
                }
            ],
        }
    ]


@pytest.fixture()
def missing_credit_app_id_path_params():
    return [
        {
            "code": "deal.missingRequiredProperty",
            "properties": [
                {
                    "property": "creditAppId",
                    "message": "creditAppId is missing in provided path parameters",
                }
            ],
        }
    ]


@pytest.fixture()
def missing_lender_id_error():
    return [
        {
            "code": "deal.missingRequiredProperty",
            "properties": [
                {
                    "property": "lenderId",
                    "message": "lenderId is missing in provided decision",
                }
            ],
        }
    ]
