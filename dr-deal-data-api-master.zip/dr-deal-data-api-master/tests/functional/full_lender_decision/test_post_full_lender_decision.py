# -*- coding: utf-8 -*-
import time
from http import HTTPStatus

import pytest
import ulid
from tests import config
from tests.functional.service_api import ServiceAPI


APP_ROUTE = "credit_app"
GET_EVENT_ROUTE = "get_event"
POST_LENDER_DECISION_ROUTE = "post_lender_decision"

DECISION_FILE_NAME = [
    "individual_lease_new_approved_previous_emp_add.json",
    "individual_lease_new_counteroffer_trade.json",
    "individual_retail_new_declined.json",
    "individual_retail_used_counteroffer.json",
]


@pytest.mark.prod
@pytest.mark.smoke
@pytest.mark.functional
@pytest.mark.parametrize("decision_file", DECISION_FILE_NAME)
def test_post_lender_decision_using_deal_ref_id(
    env,
    api_url,
    decision_file,
    update_decision_payload,
    get_deal_component_details_begins_with,
    random_data_class,
):
    ca_json_file = "credit_app/app_min_data.json"
    decision_file = f"full_lender_decision/{decision_file}"
    deal_data = ServiceAPI(
        random_data_class=random_data_class, env=env, json_file=ca_json_file
    )

    # Add dealRefId & creditAppId in header
    fs_header_value = {
        "X-Deal-Reference-Id": deal_data.generate_random_id(True),
        "X-Credit-Application-Reference-Id": deal_data.generate_random_id(True),
    }

    # Post a Credit App
    status_code, app_resp, resp_headers = deal_data.post_request(
        api_url, APP_ROUTE, cust_header=fs_header_value
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {app_resp}"
        )

    deal_ref_id = app_resp["dealRefId"]

    deal_data.set_payload(decision_file)
    update_decision_payload(deal_data.payload)
    deal_data.payload = deal_data.payload["lenderDecision"]

    lender_id = deal_data.payload["lenderId"]
    credit_app_id = deal_data.creditAppId
    deal_component = f"CD.{lender_id}.{credit_app_id}"

    # Give some time for deal to be created if we get bad request
    status_code = HTTPStatus.BAD_REQUEST
    retries = 3
    retry = 0
    while status_code == HTTPStatus.BAD_REQUEST and retry < retries:
        time.sleep(config.WAIT_WITH_NO_RETRIES)
        retry = retry + 1
        status_code, decision_resp, resp_headers = deal_data.post_request(
            url=api_url,
            route_url=POST_LENDER_DECISION_ROUTE,
            lender_id=lender_id,
        )

    assert status_code == HTTPStatus.CREATED
    assert decision_resp["message"] == "Lender decision posted"

    lender_decision_record = get_deal_component_details_begins_with(deal_ref_id, "CD")

    assert lender_decision_record[0]["dealComponent"] == deal_component


@pytest.mark.smoke
@pytest.mark.functional
@pytest.mark.parametrize("decision_file", DECISION_FILE_NAME)
def test_post_lender_decision_missing_deal_ref_id(
    env,
    api_url,
    decision_file,
    assert_headers,
    missing_reference_ids_response,
    random_data_class,
    update_decision_payload,
):
    ca_json_file = "credit_app/app_min_data.json"
    decision_file = f"full_lender_decision/{decision_file}"
    deal_data = ServiceAPI(
        random_data_class=random_data_class, env=env, json_file=ca_json_file
    )

    # Add dealRefId & creditAppId in header
    fs_header_value = {
        "X-Deal-Reference-Id": deal_data.generate_random_id(True),
        "X-Credit-Application-Reference-Id": deal_data.generate_random_id(True),
    }

    # Post a Credit App
    status_code, app_resp, resp_headers = deal_data.post_request(
        api_url, APP_ROUTE, cust_header=fs_header_value
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {app_resp}"
        )

    deal_data.set_payload(decision_file)
    update_decision_payload(deal_data.payload)
    deal_data.payload = deal_data.payload["lenderDecision"]

    deal_data.dealRefId = ""
    status_code, get_resp, resp_headers = deal_data.post_request(
        url=api_url, route_url=POST_LENDER_DECISION_ROUTE
    )

    assert status_code == HTTPStatus.BAD_REQUEST
    assert get_resp == missing_reference_ids_response(field_list=["dealRefId"])
    assert_headers(resp_headers)


@pytest.mark.smoke
@pytest.mark.functional
def test_post_lender_decision_missing_lender_id(
    env,
    api_url,
    update_decision_payload,
    random_data_class,
    missing_lender_id_error,
):
    decision_file = (
        "full_lender_decision/individual_lease_new_approved_previous_emp_add.json"
    )
    ca_json_file = "credit_app/app_min_data.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class, env=env, json_file=ca_json_file
    )

    # Add dealRefId & creditAppId in header
    fs_header_value = {
        "X-Deal-Reference-Id": deal_data.generate_random_id(True),
        "X-Credit-Application-Reference-Id": deal_data.generate_random_id(True),
    }

    # Post a Credit App
    status_code, app_resp, resp_headers = deal_data.post_request(
        api_url, APP_ROUTE, cust_header=fs_header_value
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {app_resp}"
        )

    deal_data.set_payload(decision_file)
    update_decision_payload(deal_data.payload)
    deal_data.payload = deal_data.payload["lenderDecision"]
    deal_data.payload["lenderId"] = ""

    time.sleep(config.WAIT_WITH_NO_RETRIES)
    status_code, get_resp, resp_headers = deal_data.post_request(
        url=api_url, route_url=POST_LENDER_DECISION_ROUTE
    )

    assert status_code == HTTPStatus.BAD_REQUEST
    assert get_resp == missing_lender_id_error


@pytest.mark.smoke
@pytest.mark.functional
@pytest.mark.parametrize("decision_file", DECISION_FILE_NAME)
def test_post_lender_decision_invalid_deal_ref_id(
    env,
    api_url,
    assert_headers,
    decision_file,
    invalid_deal_ref_id_response,
    update_decision_payload,
    random_data_class,
):
    decision_file = f"full_lender_decision/{decision_file}"
    deal_data = ServiceAPI(env=env, random_data_class=random_data_class)

    deal_data.set_payload(decision_file)
    update_decision_payload(deal_data.payload)
    deal_data.payload = deal_data.payload["lenderDecision"]
    deal_data.creditAppId = ulid.new().str

    deal_data.dealRefId = deal_data.generate_random_id(True)
    status_code, get_resp, resp_headers = deal_data.post_request(
        url=api_url, route_url=POST_LENDER_DECISION_ROUTE
    )

    assert status_code == HTTPStatus.BAD_REQUEST
    assert get_resp == invalid_deal_ref_id_response(deal_data.dealRefId)
    assert_headers(resp_headers)


@pytest.mark.smoke
@pytest.mark.functional
@pytest.mark.parametrize("decision_file", DECISION_FILE_NAME)
def test_post_lender_decision_empty_body(
    env,
    api_url,
    assert_headers,
    decision_file,
    missing_payload_response,
    update_decision_payload,
    random_data_class,
):
    ca_json_file = "credit_app/app_min_data.json"
    decision_file = f"full_lender_decision/{decision_file}"
    deal_data = ServiceAPI(
        random_data_class=random_data_class, env=env, json_file=ca_json_file
    )

    # Add dealRefId & creditAppId in header
    fs_header_value = {
        "X-Deal-Reference-Id": deal_data.generate_random_id(True),
        "X-Credit-Application-Reference-Id": deal_data.generate_random_id(True),
    }

    # Post a Credit App
    status_code, app_resp, resp_headers = deal_data.post_request(
        api_url, APP_ROUTE, cust_header=fs_header_value
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {app_resp}"
        )

    deal_data.set_payload(decision_file)
    update_decision_payload(deal_data.payload)
    deal_data.payload = deal_data.payload["lenderDecision"]

    deal_data.payload = {}
    status_code, get_resp, resp_headers = deal_data.post_request(
        url=api_url, route_url=POST_LENDER_DECISION_ROUTE
    )

    assert status_code == HTTPStatus.BAD_REQUEST
    assert get_resp == missing_payload_response
    assert_headers(resp_headers)


@pytest.mark.prod
@pytest.mark.smoke
@pytest.mark.functional
@pytest.mark.parametrize("decision_file", DECISION_FILE_NAME)
def test_post_lender_decision_missing_credit_app_id(
    env,
    api_url,
    decision_file,
    update_decision_payload,
    random_data_class,
    missing_credit_app_id_path_params,
):
    ca_json_file = "credit_app/app_min_data.json"
    decision_file = f"full_lender_decision/{decision_file}"
    deal_data = ServiceAPI(
        random_data_class=random_data_class, env=env, json_file=ca_json_file
    )

    # Add dealRefId & creditAppId in header
    fs_header_value = {
        "X-Deal-Reference-Id": deal_data.generate_random_id(True),
        "X-Credit-Application-Reference-Id": deal_data.generate_random_id(True),
    }

    # Post a Credit App
    status_code, app_resp, resp_headers = deal_data.post_request(
        api_url, APP_ROUTE, cust_header=fs_header_value
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {app_resp}"
        )

    deal_data.set_payload(decision_file)
    update_decision_payload(deal_data.payload)
    deal_data.payload = deal_data.payload["lenderDecision"]

    deal_data.creditAppId = ""

    status_code, get_resp, resp_headers = deal_data.post_request(
        url=api_url, route_url=POST_LENDER_DECISION_ROUTE
    )

    assert status_code == HTTPStatus.BAD_REQUEST
    assert get_resp == missing_credit_app_id_path_params


@pytest.mark.prod
@pytest.mark.smoke
@pytest.mark.functional
@pytest.mark.parametrize("decision_file", DECISION_FILE_NAME)
def test_post_lender_decision_invalid_ulid_credit_app_id(
    env,
    api_url,
    decision_file,
    update_decision_payload,
    random_data_class,
    invalid_credit_app_id_ulid_check,
):
    ca_json_file = "credit_app/app_min_data.json"
    decision_file = f"full_lender_decision/{decision_file}"
    deal_data = ServiceAPI(
        random_data_class=random_data_class, env=env, json_file=ca_json_file
    )

    # Add dealRefId & creditAppId in header
    fs_header_value = {
        "X-Deal-Reference-Id": deal_data.generate_random_id(True),
        "X-Credit-Application-Reference-Id": deal_data.generate_random_id(True),
    }

    # Post a Credit App
    status_code, app_resp, resp_headers = deal_data.post_request(
        api_url, APP_ROUTE, cust_header=fs_header_value
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {app_resp}"
        )

    deal_data.set_payload(decision_file)
    update_decision_payload(deal_data.payload)
    deal_data.payload = deal_data.payload["lenderDecision"]

    deal_data.creditAppId = "invalid-creditapp-id"

    status_code, get_resp, resp_headers = deal_data.post_request(
        url=api_url, route_url=POST_LENDER_DECISION_ROUTE
    )

    assert status_code == HTTPStatus.BAD_REQUEST
    assert get_resp == invalid_credit_app_id_ulid_check


@pytest.mark.prod
@pytest.mark.smoke
@pytest.mark.functional
@pytest.mark.parametrize("decision_file", DECISION_FILE_NAME)
def test_post_lender_decision_credit_app_id_mismatch_deal_record(
    env,
    api_url,
    decision_file,
    update_decision_payload,
    random_data_class,
    invalid_reference_ids_response,
    invalid_deal_ref_id_response,
):
    ca_json_file = "credit_app/app_min_data.json"
    decision_file = f"full_lender_decision/{decision_file}"
    deal_data = ServiceAPI(
        random_data_class=random_data_class, env=env, json_file=ca_json_file
    )

    # Add dealRefId & creditAppId in header
    fs_header_value = {
        "X-Deal-Reference-Id": deal_data.generate_random_id(True),
        "X-Credit-Application-Reference-Id": deal_data.generate_random_id(True),
    }

    # Post a Credit App
    status_code, app_resp, resp_headers = deal_data.post_request(
        api_url, APP_ROUTE, cust_header=fs_header_value
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {app_resp}"
        )

    deal_data.set_payload(decision_file)
    update_decision_payload(deal_data.payload)
    deal_data.payload = deal_data.payload["lenderDecision"]

    deal_data.creditAppId = ulid.new().str

    decision_resp = invalid_deal_ref_id_response(deal_data.dealRefId)
    retries = 3
    retry = 0
    while (
        decision_resp[0]["properties"][0]["message"].startswith("Invalid dealRefId")
        and retry < retries
    ):
        time.sleep(config.WAIT_WITH_NO_RETRIES)
        retry = retry + 1
        status_code, decision_resp, resp_headers = deal_data.post_request(
            url=api_url, route_url=POST_LENDER_DECISION_ROUTE
        )

    assert status_code == HTTPStatus.BAD_REQUEST
    assert decision_resp == invalid_reference_ids_response(
        deal_data.dealRefId, {"creditAppId": deal_data.creditAppId}
    )
