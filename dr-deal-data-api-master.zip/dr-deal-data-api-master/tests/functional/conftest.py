# -*- coding: utf-8 -*-
import decimal
import json
import logging
import secrets
import string
import time
import uuid
from datetime import datetime, timedelta
from decimal import Decimal

import boto3
import dpath.util
import pytest
import ulid
from boto3.dynamodb.conditions import Key
from tests import config
from tests.config import DD_ENV_MAPPING, DEAL_IDS_TO_DELETE, S3_KEY_TO_DELETE
from tests.conftest import RandomData
from tests.functional.key_data import conftest as key_data
from tests.functional.key_data.config import (
    KEY_DATA_V2_FIELDS_BY_RECORD,
    KEY_DATA_V2_GET_FIELDS_BY_RECORD,
)
from tests.functional.service_api import ServiceAPI as dealData


log = logging.getLogger(__name__)
random = secrets.SystemRandom()


@pytest.fixture()
def retry_number():
    return config.RETRY_COUNT


@pytest.fixture()
def wait_with_retries():
    def wait():
        time.sleep(config.WAIT_WITH_RETRIES)

    return wait


@pytest.fixture()
def wait_with_no_retries():
    def wait():
        time.sleep(config.WAIT_WITH_NO_RETRIES)

    return wait


@pytest.fixture()
def dealdata_dlq(region, stage, env):
    """
    get deal-data dlq object
    :param region: aws active region
    :return: sqs client and sqs url/name
    """
    env_name = stage or env
    client = boto3.client("sqs", region_name=region)
    queue_url = client.get_queue_url(QueueName=f"DealDataDLQ-{env_name}.fifo")[
        "QueueUrl"
    ]
    return client, queue_url


@pytest.fixture()
def get_message_from_sqs(dealdata_dlq, wait_with_retries):
    def wrapper(deal_ref_id, app_id, request_type):
        """
        Getting message(s) from SQS queue
        :param deal_ref_id: dealRefId / groupMessageId
        :param app_id: app or lead IDs
        :param request_type: type of the request
        :return: dlq_messages(s) from sqs
        """

        res = dealdata_dlq[0].get_queue_attributes(
            QueueUrl=dealdata_dlq[1], AttributeNames=["ApproximateNumberOfMessages"]
        )

        total_items_in_dlq = int(
            res.get("Attributes").get("ApproximateNumberOfMessages")
        )

        accepted_requ_type = ("CREDIT_APP_POST", "LEAD_POST", "CONTRACT_POST")
        if request_type not in accepted_requ_type:
            raise ValueError(
                f"Invalid message type is provided. Value values: {accepted_requ_type}"
            )
        dlq_msgs_found = 0
        for item in range(total_items_in_dlq):
            response = dealdata_dlq[0].receive_message(
                QueueUrl=dealdata_dlq[1],
                AttributeNames=["All"],
                MaxNumberOfMessages=1,
                VisibilityTimeout=180,
                MessageAttributeNames=["MessageGroupId"],
            )

            if response.get("Messages"):
                dlq_deal_ref_id = (
                    response.get("Messages")[0].get("Attributes").get("MessageGroupId")
                )
                if dlq_deal_ref_id == deal_ref_id:
                    resp_body = json.loads(response.get("Messages")[0].get("Body"))
                    payload = json.loads(resp_body.get("Records")[0].get("body"))
                    app_type_mapping = {
                        "CREDIT_APP_POST": "creditAppId",
                        "LEAD_POST": "leadRefId",
                        "CONTRACT_POST": "contractRefId",
                    }
                    dlq_app_id = payload.get(app_type_mapping[request_type])
                    if dlq_app_id == app_id:
                        dlq_msgs_found += 1

        return dlq_msgs_found

    return wrapper


@pytest.fixture()
def post_message_to_queue(dealdata_dlq, deal_data_dlq_message, region):
    def wrapper(deal_ref_id, app_id, payload, request_type, lender_id=None):
        """
        Post a test payload to SQS queue
        :param deal_ref_id: message group id to query
        :param app_id: id of the resource: - credit_app, lead, or contract
        :param payload: json payload to post to sqs queue
        :param request_type: type of payload being save
        :param lender_id: lender id
        :return:
        """
        accepted_requ_type = (
            "CREDIT_APP_POST",
            "LEAD_POST",
            "CONTRACT_POST",
            "VERIFY_CONTRACT_POST",
            "SIGN_CONTRACT_POST",
        )
        if request_type not in accepted_requ_type:
            raise ValueError(
                f"Invalid message type is provided. Value values: {accepted_requ_type}"
            )
        correlation_id = f"{uuid.uuid4()}_SIMBRIDGE"
        receipt_handle = str(uuid.uuid4())
        request_type_mapping = {
            "CREDIT_APP_POST": "creditAppId",
            "LEAD_POST": "leadRefId",
            "CONTRACT_POST": "contractRefId",
            "VERIFY_CONTRACT_POST": "contractRefId",
            "SIGN_CONTRACT_POST": "contractRefId",
        }
        ids_payload = {
            "dealRefId": deal_ref_id,
            request_type_mapping[request_type]: app_id,
        }
        if request_type == "CONTRACT_POST" or request_type == "VERIFY_CONTRACT_POST":
            ids_payload["lenderId"] = lender_id

        payload.update(ids_payload)

        # Update DLQ payload with test data
        deal_data_dlq_message["Records"][0]["receiptHandle"] = receipt_handle
        deal_data_dlq_message["Records"][0]["body"] = json.dumps(payload)
        deal_data_dlq_message["Records"][0]["messageAttributes"]["payload_type"][
            "stringValue"
        ] = request_type
        deal_data_dlq_message["Records"][0]["messageAttributes"]["correlation_id"][
            "stringValue"
        ] = correlation_id
        deal_data_dlq_message["Records"][0]["messageAttributes"]["deal_ref_id"][
            "stringValue"
        ] = deal_ref_id
        deal_data_dlq_message["Records"][0]["awsRegion"] = region
        dealdata_dlq[0].send_message(
            QueueUrl=dealdata_dlq[1],
            MessageBody=json.dumps(deal_data_dlq_message),
            MessageGroupId=deal_ref_id,
            MessageAttributes={
                "payload_type": {"DataType": "String", "StringValue": request_type},
                "correlation_id": {"DataType": "String", "StringValue": correlation_id},
                "deal_ref_id": {"DataType": "String", "StringValue": deal_ref_id},
            },
        )
        time.sleep(5)

    return wrapper


@pytest.fixture(scope="session")
def dynamodb_table(env, table_suffix, region):
    suffix = table_suffix or env
    dynamodb = boto3.resource("dynamodb", region_name=region)
    return dynamodb.Table(f"dr-deals-{suffix}")


@pytest.fixture(scope="session")
def query_dynamodb(dynamodb_table):
    def wrapper(deal_ref_id):
        records = dynamodb_table.query(
            KeyConditionExpression=Key("dealRefId").eq(deal_ref_id)
        )
        return records.get("Items", []), records.get("Count")

    return wrapper


@pytest.fixture()
def query_dynamodb_with_deal_component(dynamodb_table):
    def wrapper(deal_ref_id, deal_component):
        key_expression = Key("dealRefId").eq(deal_ref_id) & Key("dealComponent").eq(
            deal_component
        )
        records = dynamodb_table.query(KeyConditionExpression=key_expression)
        return records.get("Items", [])

    return wrapper


@pytest.fixture()
def query_dynamodb_for_specified_key(dynamodb_table, wait_with_retries, retry_number):
    """
    Lookup DTC.DEAL record for a specified key like contractRefId, creditAppId, etc
    :param dynamodb_table:
    :param wait_with_retries:
    :param retry_number:
    :return:
    """

    def wrapper(deal_ref_id, db_key_name):
        requ_key = ""
        tries = 0
        key_expression = Key("dealRefId").eq(deal_ref_id) & Key("dealComponent").eq(
            "DTC.DEAL"
        )
        while not requ_key and tries < retry_number:
            wait_with_retries()
            tries += 1
            record = dynamodb_table.query(KeyConditionExpression=key_expression)
            if record["Count"]:
                requ_key = record.get("Items")[0].get(db_key_name)

        return requ_key

    return wrapper


@pytest.fixture()
def get_records_by_deal_ref_id(
    query_dynamodb, get_response_data, retry_number, wait_with_retries
):
    def wrapper(deal_ref_id):
        time.sleep(2)
        response = []
        tries = 0
        count = 0
        while not response and tries < retry_number:
            wait_with_retries()
            tries = tries + 1
            response, count = query_dynamodb(deal_ref_id)

        return response, count

    return wrapper


@pytest.fixture()
def get_deal_component_details(
    query_dynamodb_with_deal_component, wait_with_retries, retry_number
):
    def wrapper(
        deal_ref_id,
        deal_component,
        additional_check_key=None,
        additional_check_value=None,
        zero_resp=False,
    ):
        """
        :param deal_ref_id: DTA dealRefId
        :param deal_component: Sort key of the dynamoDB
        :param additional_check_key: is to check if any specific additional field in the record to be verified before
        returning
        :param additional_check_value: It's the value to be verified for the given additional_check_value
        :param zero_resp: If expected zero response in DB
        """
        response = []
        tries = 0
        retry_count = 10 if zero_resp else retry_number
        while not response and tries < retry_count:
            wait_with_retries()
            tries += 1
            response = query_dynamodb_with_deal_component(deal_ref_id, deal_component)
            if (
                response
                and additional_check_key
                and response[0].get(additional_check_key) == additional_check_value
            ):
                return response[0]
            elif response and not additional_check_key:
                return response[0]
            else:
                response = []

        if not response and not zero_resp:
            raise Exception(
                f"Unable to retrieve data for dealRefId: {deal_ref_id}, dealComponent: {deal_component}, "
                f"additional_check_key: {additional_check_key} and additional_check_value: {additional_check_value}"
                f"response: {response}"
            )

    return wrapper


@pytest.fixture()
def get_deal_component_details_begins_with(
    dynamodb_table, wait_with_retries, retry_number
):
    """
    Query DynamoDB with deal ref id and a deal component's starting string
    :param dynamodb_table: deal table
    :param wait_with_retries:
    :param retry_number:
    :return: DB Response
    """

    def wrapper(deal_ref_id, deal_component_begins_with, custom_retry=retry_number):
        response = []
        tries = 0
        key_expression = Key("dealRefId").eq(deal_ref_id) & Key(
            "dealComponent"
        ).begins_with(deal_component_begins_with)
        while not response and tries < custom_retry:
            wait_with_retries()
            tries += 1
            records = dynamodb_table.query(KeyConditionExpression=key_expression)
            response = records.get("Items", [])
            if response:
                return response

        return response

    return wrapper


@pytest.fixture(scope="session", autouse=True)
def delete_test_records(env, region, stage, dynamodb_table, query_dynamodb, s3_client):
    yield
    partition_key = "dealRefId"
    sort_key = "dealComponent"
    suffix = DD_ENV_MAPPING[env]["bucket_suffix"]
    bucket_name = (
        f"{DD_ENV_MAPPING[env]['aws_alias']}-reprocessing-garage-{region}-{suffix}"
    )
    for ref_id in DEAL_IDS_TO_DELETE:
        records, count = query_dynamodb(ref_id)
        for record in records:
            del_rec = {partition_key: record[partition_key], sort_key: record[sort_key]}
            log.info(f"Deleting data from Dynamodb: {del_rec}")
            dynamodb_table.delete_item(Key=del_rec)
    for ref_id in S3_KEY_TO_DELETE:
        prefix = f"DealDataDLQ-{stage or env}.fifo/{ref_id}"
        s3_resp = s3_client.list_objects_v2(Bucket=bucket_name, Prefix=prefix)
        resp_contents = s3_resp.get("Contents")
        if resp_contents:
            for obj in s3_resp["Contents"]:
                log.info(f"Deleting test data from s3: {obj['Key']}")
                s3_client.delete_object(Bucket=bucket_name, Key=obj["Key"])
        else:
            log.info(f"Contents missing for: {s3_resp}")


@pytest.fixture(scope="session")
def s3_client():
    return boto3.client("s3")


@pytest.fixture(scope="session")
def get_s3_bucket_name(env, region, bucket="deal-data"):
    region = region
    alias = DD_ENV_MAPPING[env]["aws_alias"]
    suffix = DD_ENV_MAPPING[env]["bucket_suffix"]
    return f"{alias}-{bucket}-{region}-{suffix}"


@pytest.fixture()
def get_response_data():
    def wrapper(
        response: list, deal_component: str, get_protected: bool = False, reports=None
    ):
        """
        Loops over response list and return deal component if exists
        :param response: response object from dynamoDb for one dealRefID
        :param deal_component: specified component. like, applicant, coapplicant, status
        :param get_protected: whether or not to get pii/protected component
        :param reports: optional parameter for credit bureau pull, accepts values are
               'PULL' for Credit Bureau hard or 'SoftPull', 'OFAC', or 'Redflag';
                for credit bureau response, value is 'response'
        :return: deal_component_record
        """
        if reports != "CBR":
            deal_component = f"DTC.{deal_component.upper()}"

        deal_component = (
            f"{deal_component}.PROTECTED" if get_protected else deal_component
        )
        for attribute in response:
            if attribute.get("dealComponent") == deal_component:
                if get_protected:
                    deal_component_record = attribute.get("protected")
                else:
                    deal_component_record = attribute
                return deal_component_record

    return wrapper


@pytest.fixture()
def verify_deal_component(
    get_response_data,
    verify_list_object,
    verify_given_dict_object,
    verify_list_of_given_fields,
):
    def wrapper(response, payload, deal_component, additional_header_keys=False):
        """
        Validates different component of a payload
        :param response: response object from dynamoDb for one dealRefID
        :param payload: posted data
        :param deal_component: different part of the response data to be validated
        :param additional_header_keys: Flag to verify additional key data headers saved in DTC.DEAL
        :return:
        """
        deal_component_record = get_response_data(
            response, deal_component=deal_component
        )
        if deal_component == "tradeIns":
            # verify tradeIns list
            verify_list_object(
                payload[deal_component],
                deal_component_record[deal_component],
                "otherMake",
            )
        elif deal_component == "extraData":
            # verify list
            verify_list_object(
                payload[deal_component], deal_component_record[deal_component], "name"
            )
        elif "lenderList" in deal_component:
            # verify lenders
            lenderId = deal_component[11:]
            # need to go through each lender as it is saved individually on the db
            payloadLender = [
                lender
                for lender in payload["lenderList"]
                if lender["lenderId"] == lenderId
            ]
            verify_given_dict_object(
                payloadLender[0],
                deal_component_record,
                deal_component,
            )
        elif deal_component in [
            "vehicle",
            "decisionSummary",
            "financeSummary",
            "sessionInfo",
        ]:
            # verify dict data
            verify_given_dict_object(
                payload[deal_component], deal_component_record, deal_component
            )
        elif deal_component == "deal" and additional_header_keys:
            key_data.verify_deal_additional_key_data(payload, deal_component_record)
        else:
            # verify customer name
            fields = ["firstName", "lastName"]
            verify_list_of_given_fields(
                payload[deal_component], deal_component_record, fields
            )

    return wrapper


@pytest.fixture()
def verify_deal_component_protected(get_response_data):
    def wrapper(response, payload, deal_component):
        deal_component_record = get_response_data(
            response, deal_component=deal_component, get_protected=True
        )
        assert deal_component_record != json.dumps(payload[deal_component]["protected"])

    return wrapper


def verify_shopper_object(requ_obj, resp_obj):
    for k, v in requ_obj.items():
        resp_v = resp_obj.get(k)
        if isinstance(v, dict):
            verify_shopper_object(v, resp_v)
        elif isinstance(v, list):
            for ind, value in enumerate(v):
                if isinstance(value, dict):
                    resp_i = resp_v[ind]
                    verify_shopper_object(value, resp_i)
        else:
            error_msg = f"""The value for field: {k}: did not match.
            Expected: {v} Actual: {resp_obj.get(resp_v)}. \n
            requ_obj = {requ_obj} \n resp_obj = {resp_obj}"""
            assert v == resp_v, error_msg


@pytest.fixture()
def verify_given_dict_object():
    def wrapper_dict(requ_obj, resp_obj, verify_list_object=None):
        ignore_random_list = [*config.DEAL_GET_IGNORE_LIST, *config.RANDOM_FIELDS]
        for key, value in requ_obj.items():
            expected = value
            if key == "shopperQuotePayload":
                verify_shopper_object(value, resp_obj.get(key))
            elif isinstance(value, dict):
                if key not in ignore_random_list:
                    wrapper_dict(value, resp_obj.get(key, {}), verify_list_object)
            elif isinstance(value, list) and key not in config.DEAL_GET_IGNORE_LIST:
                field = config.LIST_PRIMARY_KEY.get(key)
                verify_list_object(value, resp_obj.get(key, {}), field)
            elif isinstance(key, str) and value in ("", None):
                assert resp_obj.get(key) is None
            elif key not in ignore_random_list:
                try:
                    if isinstance(resp_obj.get(key), decimal.Decimal):
                        expected = decimal.Decimal(expected).quantize(
                            decimal.Decimal(".01")
                        )
                    assert expected == resp_obj.get(key)
                except AssertionError:
                    raise Exception(
                        f"The value for field: {key}: did not match. Expected: {expected} Actual: {resp_obj.get(key)}. \n requ_obj = {requ_obj} \n resp_obj = {resp_obj}"
                    )

    return wrapper_dict


@pytest.fixture()
def verify_list_object(verify_given_dict_object):
    def wrapper_list(requ_list, resp_list, key):
        for req_obj in requ_list:
            found = False
            for resp_obj in resp_list:
                if isinstance(key, str) and req_obj[key] == resp_obj[key]:
                    verify_given_dict_object(req_obj, resp_obj, wrapper_list)
                    found = True
                    break
                elif isinstance(key, list) and all(
                    [(req_obj[i] == resp_obj[i]) for i in key]
                ):
                    verify_given_dict_object(req_obj, resp_obj, wrapper_list)
                    found = True
                    break
            if not found:
                raise Exception(
                    f"{key} not found. Request object: {req_obj}, response list: {resp_list}"
                )

    return wrapper_list


@pytest.fixture()
def verify_get_response_against_posted_data(
    verify_list_object, verify_given_dict_object
):
    """
    This method is to validate posted payload with GET payload
    This method would take a help of method verify_list_objects to loop over
    list and return a list object to be validated
    requ_obj: Posted payload
    resp_obj: GET payload
    :return:
    """

    def wrapper(req_obj, resp_obj, fields=None):
        if isinstance(resp_obj, list):
            verify_list_object(req_obj, resp_obj, fields)
        elif isinstance(resp_obj, dict):
            verify_given_dict_object(req_obj, resp_obj, verify_list_object)
        else:
            raise Exception("Incorrect object type is provided for validation.")

    return wrapper


@pytest.fixture()
def verify_list_of_given_fields():
    """
    This method would validate list of given fields
    :return:
    """

    def wrapper(requ_data, resp_data, fields_list):
        for field in fields_list:
            assert requ_data.get(field) == resp_data.get(field)

    return wrapper


@pytest.fixture()
def verify_credit_bureau_reports(get_response_data):
    def wrapper(requ_reports, records, app_type, cb_id, requ_type):
        """
        This method would validate credit bureau report data
        :param:requ_reports: posted reports data
        :param:records: data from DynamoDb
        :param:app_type: Type of customer - applicant or coApplicant)
        :param:cb_id: creditBureauRefId
        :param:requ_type: Accepted values are 'request' for PULL or 'response' for response
        :return:
        """
        for obj in requ_reports:
            cb_type = {"request": "PULL", "response": "RESP"}
            deal_comp = f"CB.{cb_type[requ_type]}.{obj['provider']}.{obj['type']}.{app_type}.{cb_id}".upper()

            resp_data = get_response_data(
                response=records, deal_component=deal_comp, reports="CBR"
            )
            if not resp_data:
                raise Exception(
                    "Response data is not available in DB for given report for validation."
                )
            assert obj.items() <= resp_data.items()
            assert cb_id == resp_data["creditBureauRefId"]

    return wrapper


@pytest.fixture()
def verify_field_does_not_exist_in_get_response():
    """
    This method verify that unwanted fields are not available in GET response
    :return:
    """

    def wrapper(get_resp):
        for field in config.DEAL_GET_IGNORE_LIST:
            # protected
            if field == "protected":
                assert get_resp.get("applicant", {}).get("protected") is None
                assert get_resp.get("coApplicant", {}).get("protected") is None
                assert get_resp.get("guarantor", {}).get("protected") is None
                assert get_resp.get("driver", {}).get("protected") is None
                # consentGiven
            elif field == "consentGiven":
                assert get_resp.get("applicant", {}).get("consentGiven") is None
                assert get_resp.get("coApplicant", {}).get("consentGiven") is None
                assert get_resp.get("guarantor", {}).get("consentGiven") is None
                assert get_resp.get("driver", {}).get("consentGiven") is None
                # partnerSource & communityPropertyDisclosureIndicator
            elif field == "communityPropertyDisclosureIndicator":
                assert get_resp.get("communityPropertyDisclosureIndicator") is None
            elif field == "sourcePartnerDealerId":
                assert get_resp.get("sourcePartnerDealerId") is None
                # regulationBIndicator & privacyNoticeIndicator
            elif field == "regulationBIndicator":
                assert get_resp.get("regulationBIndicator") is None
            elif field == "privacyNoticeIndicator":
                assert get_resp.get("privacyNoticeIndicator") is None
                # dateOfBirthDay & dateOfBirthMonth
            elif field == "dateOfBirthDay":
                assert get_resp.get("applicant", {}).get("dateOfBirthDay") is None
                assert get_resp.get("coApplicant", {}).get("dateOfBirthDay") is None
                assert get_resp.get("guarantor", {}).get("dateOfBirthDay") is None
                assert get_resp.get("driver", {}).get("dateOfBirthDay") is None
            elif field == "dateOfBirthMonth":
                assert get_resp.get("applicant", {}).get("dateOfBirthMonth") is None
                assert get_resp.get("coApplicant", {}).get("dateOfBirthMonth") is None
                assert get_resp.get("guarantor", {}).get("dateOfBirthMonth") is None
                assert get_resp.get("driver", {}).get("dateOfBirthMonth") is None
            elif field == "dealerCode":
                assert get_resp.get("dealerCode") is None
            else:
                raise Exception(f"{field} not found in the assert list")

    return wrapper


@pytest.fixture()
def verify_protected_fields():
    """
    Validates the fields within protected node for a customer
    """

    def wrapper(requ_payload, get_resp, applicant_type):
        requ__protected = requ_payload.get(applicant_type).get("protected", {})
        get_cust = get_resp.get(applicant_type, {})
        protected = [
            "ssn",
            "dateOfBirth",
            "driversLicenseNumber",
            "driversLicenseState",
        ]
        for field in protected:
            assert requ__protected.get(field) == get_cust.get(field)

    return wrapper


@pytest.fixture()
def assert_deleted_value_from_deal():
    def wrapper(get_resp, fields_list):
        """
        Remove/delete key/obj from json payload
        :param get_resp: json payload
        :param fields_list: list of json path to be deleted
        :return: updated payload
        """
        deleted_value = True
        for field in fields_list:
            try:
                exp = dpath.util.get(get_resp, glob=field, separator=".", default=None)
                assert (
                    exp is None
                ), f"Did not delete field: {field} as expected by patch. Response value: {exp}"
            except AssertionError as er:
                log.error(er)
                deleted_value = False
        return deleted_value

    return wrapper


@pytest.fixture()
def validate_v2_key_data():
    """
    Validate v2 key data saved in database successfully
    posted_payload: key_data payload posted to DB
    database_resp: Response payload from database
    key_name: Name of the key_data key
    :return:
    """

    def wrapper(posted_payload, database_resp, key_name):
        if key_name not in KEY_DATA_V2_FIELDS_BY_RECORD.keys():
            raise Exception(f"Provided key_data key '{key_name}' is not support.")
        key_data_field = KEY_DATA_V2_FIELDS_BY_RECORD[key_name]
        for field in posted_payload:
            if field in key_data_field.keys():
                db_key = key_data_field[field]
                assert posted_payload.get(field) == database_resp.get(
                    db_key
                ), f"Posted key-data '{field}' field did not save under v2 key-data record {database_resp}"

    return wrapper


@pytest.fixture()
def validate_v2_key_data_get_response():
    """
    Validate v2 key data get response
    posted_payload: key_data payload posted to DB
    database_resp: Response payload from GET API
    key_name: Name of the key_data key
    :return:
    """

    def wrapper(posted_payload, get_response, key_name):
        if key_name not in KEY_DATA_V2_GET_FIELDS_BY_RECORD.keys():
            raise Exception(f"Provided key_data key '{key_name}' is not support.")
        get_fields = KEY_DATA_V2_GET_FIELDS_BY_RECORD[key_name]
        for field in posted_payload:
            if field in get_fields:
                assert posted_payload.get(field) == get_response.get(
                    field
                ), f"Posted '{field}' field is not found in v2 key-data response {get_response}"

    return wrapper


@pytest.fixture()
def invalid_payload():
    """
    This is an invalid json payload that is used to validate
    error message handling from Deal Data API
    :return: Payload
    """
    return """
        "sourcePartnerId": "DXR",
        "targetPlatforms": [
            {
                "id": "DTC",
                "partyId": "12345"
            }
        ],
        "financeMethod": "Finance",
        "customerType": "Individual",
        "applicant": {
            "relationship": "Self",
            "salutation": "Ms.",
            "firstName": "Retail New",
            "middleName": "T",
            "lastName": "Individual"
        }
    }
    """


@pytest.fixture
def cb_event_payload():
    """
    eventId: Correlation id from FD or Event
    eventTransactionId: creditBureauRefId associated with credit bureau pull
    dealRefId: dealRefId from DealData API
    :return:
    """
    return {
        "eventVersion": "1.1",
        "eventId": "",
        "eventTime": "2018-10-26T10:34:01",
        "eventName": "deal:CreditBureauResponse",
        "eventDetailHref": "https://fni-api.dealertrack.com/cb-response/report",
        "eventSource": "dr:CreditBureauResponse",
        "eventType": "dr:CreditBureaus",
        "eventIdentityId": 104334,
        "eventTransactionId": "",
        "eventKeyData": {
            "dealRefId": "",
            "creditBureauRefIdFD": "01DDY25TBPNE21EH3P287DNJQ0",
            "creditBureauRefIdUnifi": "123456789323234",
        },
        "payloadSchemaHref": "https://fni-static.aws.dealertrack.com/assets/schemas/CB/v1/creditBureauResponse.jsd",
        "payload": {
            "financeMethod": "Lease",
            "sourcePartnerId": "VIN",
            "sourcePartnerDealerId": "123456789",
            "targetPlatforms": [{"id": "VIN", "partyId": "123456789"}],
            "applicant": {
                "firstName": "Bella",
                "lastName": "Morris",
                "middleName": "K",
                "phone": "516-325-1514",
                "protected": {"ssn": "788999009", "dateOfBirth": "1963-06-18"},
            },
        },
    }


@pytest.fixture(autouse=True)
def update_test_data():
    """
    payload for update data
    :return: payload
    """
    return {
        "update_applicant_top_level": {
            "applicant": {
                "suffix": "JR",
                "firstName": "UpdateFirst",
                "lastName": "updateLast",
                "income": 1111,
                "incomeFrequency": "Monthly",
                "mortgageOrRentAmount": 3501.83,
            }
        },
        "update_applicant_add_emp": {
            "applicant": {
                "address": {
                    "line1": "123 update street",
                    "state": "MD",
                    "postalCode": "21230",
                },
                "currentEmployment": {
                    "employerName": "US Navy",
                    "workPhone": "7130780239",
                    "occupation": "updateOccuption",
                    "employerAddress": {"line2": "update1", "city": "updateCity"},
                },
            }
        },
        "update_applicant_pii": {
            "applicant": {
                "protected": {
                    "ssn": "788999009",
                    "dateOfBirth": "1963-06-18",
                    "driversLicenseNumber": "UpdateDrivNum",
                    "driversLicenseState": "NY",
                }
            },
        },
        "update_co_applicant_top_level": {
            "financeMethod": "Lease",
            "coApplicant": {
                "email": "Testemail@testserver.com",
                "middleName": "T",
                "otherPhone": "5167349659",
            },
        },
        "update_co_applicant_add_emp": {
            "coApplicant": {
                "relationship": "Relative",
                "currentEmployment": {
                    "status": "ActiveMilitary",
                    "employerAddress": {"city": "UpdateCity"},
                },
            }
        },
        "update_co_applicant_pii": {
            "coApplicant": {
                "protected": {"ssn": "524526352", "dateOfBirth": "1995-05-25"}
            }
        },
        "update_vehicle": {
            "vehicle": {
                "certifiedUsed": True,
                "stockNumber": "181425RT",
                "vin": "1HGCV1F35KA029661",
                "otherTrim": "Sport 1.5T CVT",
            }
        },
        "update_trade_in": {
            "tradeIns": [
                {
                    "chromeStyleId": "125534",
                    "otherYear": 2017,
                    "otherMake": "UpdateMake",
                    "otherModel": "UpdateModel",
                    "otherTrim": "4dr Reg WB Plus 1SB Pkg",
                    "tradeInType": "Lease",
                    "actualCashValue": 15000,
                    "monthlyPayment": 250,
                    "payoffAmount": 18000,
                    "allowanceAmount": 1880,
                    "tradeInLicensePlateNumber": "Update-1234",
                    "vehicleBookCondition": "VeryGood",
                    "lienHolder": {
                        "name": "UpdateLiemHolder",
                        "phone": "336-968-4645",
                        "address": {
                            "line1": "8374 Test St",
                            "line2": "APT #D19",
                            "city": "Littleton",
                            "state": "CO",
                            "postalCode": "80128",
                        },
                    },
                }
            ]
        },
        "update_financeSummary": {
            "financeSummary": {
                "vehicleSellingPrice": 28007.99,
                "salesTax": 2007.99,
                "governmentFees": 307.99,
                "cashDown": 3997.99,
                "rebate": 1007.99,
                "creditLifeIns": 39.79,
                "term": 67,
                "requestedAPR": 1.97,
                "acquisitionFees": 397.99,
                "invoiceAmount": 29007.99,
                "warranty": 317.99,
                "gap": 317.99,
                "accidentHealthIns": 30.00,
                "frontEndFees": 390.90,
                "msrp": 24000,
                "estimatedBalloonAmount": 23317.90,
                "estimatedPayment": 317.99,
                "usedCarBook": "KBB",
                "mileage": 3107,
                "usedCarValue": 317.99,
                "otherFees": 317.99,
                "wholesaleBookDetails": [
                    {"source": "KBB", "value": 19590, "condition": "VeryGood"}
                ],
                "wholesaleValueType": "Loan",
                "netTrade": -31888.99,
                "amountRequested": 23376,
                "creditScoreClassification": "SuperPrime",
                "applicantType": "Individual",
                "unpaidBalance": 18003,
                "customerNegotiatedPrice": 310.97,
                "dealerNegotiatedPrice": 310.09,
                "baseMonthlyPayment": 10.98,
                "monthlyUseTax": 181,
                "adjustedCapitalizedCost": 310.99,
            }
        },
        "remove_applicant_add_emp": {
            "applicant": {"address": {}, "currentEmployment": {}}
        },
        "remove_co_applicant": {"coApplicant": {}},
        "remove_co_applicant_pre_add_pre_emp_curr_emp_add": {
            "coApplicant": {
                "previousAddress": {},
                "currentEmployment": {"employerAddress": {}},
                "previousEmployment": {},
            }
        },
        "remove_trade_in": {"tradeIns": []},
        "remove_vehicle": {"vehicle": {}},
    }


@pytest.fixture()
def upload_full_lender_decision_to_s3_bucket(get_s3_bucket_name, wait_with_no_retries):
    """
    Upload full lender decision to s3 bucket for testing
    :return:
    """

    def wrapper(
        source_partner,
        partner_dealer_id,
        deal_ref_id,
        lender_id,
        event_id,
        payload,
        upload_event=True,
        upload_latest=True,
    ):
        s3_payload = json.dumps(payload)
        s3 = boto3.resource("s3")

        if upload_event:
            # Save decision Json
            s3_key = f"{source_partner}/{partner_dealer_id}/{deal_ref_id}/CA/{lender_id}/{event_id}.json"
            obj_data = s3.Object(get_s3_bucket_name, s3_key)
            obj_data.put(Body=s3_payload)
            wait_with_no_retries()
            s3.Object(get_s3_bucket_name, s3_key).load()

        if upload_latest:
            # Save decision json to latest folder
            s3_key_latest = f"{source_partner}/{partner_dealer_id}/{deal_ref_id}/CA/{lender_id}/LATEST.json"
            obj_data_latest = s3.Object(get_s3_bucket_name, s3_key_latest)
            obj_data_latest.put(Body=s3_payload)
            wait_with_no_retries()
            s3.Object(get_s3_bucket_name, s3_key_latest).load()

    return wrapper


@pytest.fixture()
def validate_pii_masking():
    """
    Validate PII data is masked with 'XXXX'
    :return:
    """

    def wrapper(payload):
        pii_fields = [
            "ssn",
            "dateOfBirth",
            "driversLicenseNumber",
            "driversLicenseState",
        ]
        applicant = payload.get("applicant")
        co_applicant = payload.get("coApplicant")
        for field in pii_fields:
            assert applicant.get(field) == "XXXX"
            if co_applicant:
                assert co_applicant.get(field) == "XXXX"

    return wrapper


@pytest.fixture()
def delete_data_from_s3_bucket(get_s3_bucket_name):
    """
    Delete test data in S3
    :return:
    """

    def wrapper(source_partner, partner_dealer_id, deal_ref_id, lender_id, event_id):
        s3 = boto3.resource("s3")
        s3_key = f"{source_partner}/{partner_dealer_id}/{deal_ref_id}/CA/{lender_id}/{event_id}.json"
        s3_key_latest = f"{source_partner}/{partner_dealer_id}/{deal_ref_id}/CA/{lender_id}/LATEST.json"
        s3.Object(get_s3_bucket_name, s3_key).delete()
        s3.Object(get_s3_bucket_name, s3_key_latest).delete()

    return wrapper


@pytest.fixture()
def validate_deal_data_keys():
    def wrapper(api_resp, db_value, requ_header={}):
        """
        Validate key IDs passed by consumer in header or generated by deal-data.
        It would be validate ID generated by deal-data or passed in by a consumer of the API.
        :return: n/a
        """
        field_mapping = {
            "dealRefId": "X-Deal-Reference-Id",
            "creditAppId": "X-Credit-Application-Reference-Id",
            "leadRefId": "X-Deal-Reference-Id",  # --> leadRefId is same has dealRefId
        }
        for key in api_resp:
            assert api_resp[key] is not None
            if requ_header.get(field_mapping.get(key)):
                assert api_resp[key] == requ_header[field_mapping[key]] == db_value[key]
            else:
                assert api_resp[key] == db_value[key]

    return wrapper


@pytest.fixture()
def assert_headers(region, api_version):
    """
    asserts using the assert_common_headers function
    :return:
    """

    def wrapper(resp_headers: dict):
        assert_common_headers(resp_headers, region, api_version)

    return wrapper


def assert_common_headers(resp_headers, region, api_version):
    """
    :param resp_headers:
    :param region:
    :param api_version:
    :return:
    Asserts the following common headers as required by the NFR
    X-CoxAuto-Correlation-Id, Cache-Control, Content-Security-Policy,
    X-Frame-Options, X-Content-Type-Options
    """
    assert resp_headers.get("X-CoxAuto-Correlation-Id") is not None
    assert resp_headers.get("Cache-Control") == "public, max-age=3600, s-maxage=3600"
    assert resp_headers.get("Content-Security-Policy") == "default-src 'none'"
    assert resp_headers.get("X-Frame-Options") == "deny"
    assert resp_headers.get("X-Content-Type-Options") == "nosniff"
    assert resp_headers.get("x-aws-region") == region
    assert resp_headers.get("x-api-version") == api_version


@pytest.fixture()
def common_assert(region, api_version):
    """
    Contains the following common assertions on deal data api test case.
    1. Time to live field exists for all records
    2. Time to live is set with the right value based on the record type.
        60 days for deals (DTC records)
        30 days for all credit bureau (CB records).
        The validation will check if the actual ttl and expected ttl is within
        the tolerance of an hour( or as set in the config.TIME_TO_LIVE)
    3. correlation id is not none
    """

    def wrapper(records: list = (), resp_headers: dict = [], with_ttl=True):
        if with_ttl:
            for rec in records:
                assert (
                    "ttl" in rec
                ), f"TTL field is not found on the deal component {rec['dealComponent']}"

                # TODO: this will be enhanced once new key-data APIs are created
                if "REF_IDS" in rec["dealComponent"]:
                    continue

                record_type = str(rec["dealComponent"]).split(".")[0]
                ttl = int(rec.pop("ttl"))

                assert get_ttl_time(record_type) - ttl <= int(
                    config.TIME_TO_LIVE.get("TOLERANCE")
                )
        assert_common_headers(resp_headers, region, api_version)

    return wrapper


def get_ttl_time(rec_type: str):
    """
    Calculates time to live value based on deal data api record
    :param rec_type: deal data api record type
    :return:
    """
    return int(time.time() + config.TIME_TO_LIVE.get(rec_type))


@pytest.fixture
def ca_event_payload():
    """
    Credit app lender decision payload.
    """
    return {
        "eventEntityId": "104334",
        "eventId": "01EHKTEGC7BB3DR4VYK5NTFA3H",
        "eventIdentityId": "104334",
        "eventName": "Deal:CreditDecisionResponse",
        "eventSource": "AHC:decisions",
        "eventTime": "2020-01-23T04:10:09.021244Z",
        "eventTransactionId": "00000000000000000000000000_TEST",
        "eventType": "AHC:decisions",
        "eventVersion": "1.0",
        "payload": {
            "approvalStatus": "Approved",
            "approvedAmount": "29088",
            "approvedRate": "5",
            "approvedTerm": "60",
            "customerMoneyFactor": "0.002",
            "downPayment": "4380",
            "financeMethod": "Retail",
            "lenderId": "AHC",
            "lenderMoneyFactor": "0.005",
            "lenderName": "American Honda Finance Corporation",
            "monthlyPayment": "458",
            "stipulations": [{"text": "test1"}, {"text": "test2"}],
            "tier": "Gold",
        },
        "payloadSchema": "DealDecisionsSummary/v1.0",
        "payloadSchemaHref": None,
    }


@pytest.fixture
def deal_data_dlq_message():
    """
    Payload for deal-data DLQ
    """
    return {
        "Records": [
            {
                "receiptHandle": "Random Id here",
                "body": "Payload with ids goes here",
                "attributes": {
                    "ApproximateReceiveCount": "1",
                    "SentTimestamp": "1618261622090",
                    "SequenceNumber": "18861019048964592128",
                    "MessageGroupId": "deal_ref_id here",
                    "SenderId": "AROAY27LRDBX463DUPLW7:dr-deal-data-api-QA-TEST-ca_new_deal",
                    "MessageDeduplicationId": "d9668772ca7f12be36513cb456e1c14b39d76abcf5c7c31064cfc0b85d694029",
                    "ApproximateFirstReceiveTimestamp": "1618261622090",
                },
                "messageAttributes": {
                    "payload_type": {
                        "stringValue": "CREDIT_APP_POST/LEAD_POST",
                        "stringListValues": [],
                        "binaryListValues": [],
                        "dataType": "String",
                    },
                    "correlation_id": {
                        "stringValue": "correlation id goes here",
                        "stringListValues": [],
                        "binaryListValues": [],
                        "dataType": "String",
                    },
                    "deal_ref_id": {
                        "stringValue": "dealRefId",
                        "stringListValues": [],
                        "binaryListValues": [],
                        "dataType": "String",
                    },
                },
                "md5OfBody": "f0744ee90c1235119d09afb9834de000",
                "md5OfMessageAttributes": "a2f68567bfbde0e2458a07dc46682eff",
                "eventSource": "aws:sqs",
                "eventSourceARN": "SQS ARN goes here. Not required for test record",
                "awsRegion": "us-east-1",
            }
        ]
    }


@pytest.fixture()
def create_deal_record(dynamodb_table):
    """
    Create deal record
    :return:
    """

    def wrapper(deal_ref_id, deal_comp, record):
        record = json.loads(json.dumps(record), parse_float=Decimal)
        record.update(
            {
                "dealRefId": deal_ref_id,
                "dealComponent": deal_comp,
            }
        )
        dynamodb_table.put_item(Item=record)

    return wrapper


@pytest.fixture()
def get_deal_updated_timestamp(dynamodb_table, wait_with_retries, retry_number):
    """
    Get updated timestamp from database
    :param dynamodb_table:
    :param wait_with_retries:
    :param retry_number:
    :return:
    """

    def wrapper(deal_ref_id, deal_component="DTC.DEAL", updated_timestamp=None):
        provided_timestamp = updated_timestamp or datetime.isoformat(datetime.now())
        db_updated_timestamp = datetime.isoformat(datetime.now() - timedelta(hours=1))

        tries = 0
        key_expression = Key("dealRefId").eq(deal_ref_id) & Key("dealComponent").eq(
            deal_component
        )
        retry_count = retry_number if updated_timestamp else 60
        log.info(f"Provided timestamp is: {provided_timestamp}")
        while provided_timestamp >= db_updated_timestamp and tries < retry_count:
            log.info(f"tries count is: {tries}")
            wait_with_retries()
            tries += 1
            record = dynamodb_table.query(KeyConditionExpression=key_expression)
            if record["Count"]:
                db_updated_timestamp = record.get("Items")[0].get("updatedTimestamp")
                log.info(f"Updated timestamp is: {db_updated_timestamp}")

        return db_updated_timestamp

    return wrapper


@pytest.fixture
def missing_reference_ids_response():
    """
    Fixture is to generates error response for missing reference id(dealRefId, creditAppId, lenderId, contractRefId) in the request url
    It would generates error message for one or more missing ids
    :return:
    """

    def wrapper(field_list: list):
        error_list = []
        for field in field_list:
            error_message = {
                "property": field,
                "message": f"{field} is missing in provided path parameters",
            }
            error_list.append(error_message)

        data = [{"code": "deal.missingRequiredProperty", "properties": error_list}]
        return data

    return wrapper


@pytest.fixture
def invalid_query_parameters_response():
    """
    Fixture is to generates error response for invalid query parameters
    :return: error message with valid query parameters
    """

    def wrapper(valid_query_list):
        return [
            {
                "code": "deal.invalidQueryParameter",
                "properties": [
                    {
                        "property": "queryParameters",
                        "message": f"Given filter parameters aren't supported. Supported filters: {valid_query_list}",
                    }
                ],
            }
        ]

    return wrapper


@pytest.fixture
def missing_payload_response():
    """
    Fixture is to return expected error message when a payload is missing
    :return: missing payload error message
    """
    return [
        {
            "code": "deal.missingRequiredProperty",
            "properties": [
                {
                    "property": "eventBody",
                    "message": "No record or body found in AWS event payload",
                }
            ],
        }
    ]


@pytest.fixture
def invalid_reference_ids_response():
    def wrapper(deal_ref_id, fields_dict: dict):
        error_list = []
        for field, value in fields_dict.items():
            error_message = {
                "property": field,
                "message": f"Provided {field} {value} is not associated to dealRefId {deal_ref_id}",
            }
            error_list.append(error_message)

        data = [{"code": "deal.invalidRefId", "properties": error_list}]
        return data

    return wrapper


@pytest.fixture
def get_lender_ids_valid_response():
    return ["ALY", "BOA"]


@pytest.fixture
def get_lender_ids_empty_response():
    return {"lenderIds": []}


@pytest.fixture(autouse=True)
def verify_contract_payload():
    return {
        "sourcePartnerId": "".join(random.choices(string.ascii_uppercase, k=3)),
        "targetPlatforms": [
            {
                "id": "DTC",
                "partyId": "".join(
                    random.choices(string.ascii_uppercase + string.digits, k=6)
                ),
            }
        ],
    }


@pytest.fixture(autouse=True)
def contract_status_payload():
    return {
        "sourcePartnerId": "".join(random.choices(string.ascii_uppercase, k=3)),
        "targetPlatforms": [
            {
                "id": "DTC",
                "partyId": "".join(
                    random.choices(string.ascii_uppercase + string.digits, k=6)
                ),
            }
        ],
        "contractStatusCode": "Book",
    }


@pytest.fixture(autouse=True)
def cancel_contract_payload():
    return {
        "sourcePartnerId": "".join(random.choices(string.ascii_uppercase, k=3)),
        "targetPlatforms": [
            {
                "id": "DTC",
                "partyId": "".join(
                    random.choices(string.ascii_uppercase + string.digits, k=6)
                ),
            }
        ],
    }


@pytest.fixture(autouse=True)
def signing_contract_payload(random_data_class):
    def wrapper(customer_list: list, target_platform="DTC"):
        random_data = random_data_class()
        supported_cust = (
            "applicant",
            "coApplicant",
            "dealer",
            "guarantorPrimary",
            "guarantorAdditional",
        )
        for cust in customer_list:
            if cust not in supported_cust:
                raise Exception(
                    f"Provided invalid customer key is provided. Supported customers are {supported_cust}"
                )
        payload = {
            "applicant": {"email": random_data.email, "phone": "6467349659"},
            "coApplicant": {"email": random_data.email, "phone": "9297349659"},
            "dealer": {
                "email": random_data.email,
                "firstName": random_data.first_name,
                "lastName": random_data.last_name,
                "phone": "5167349659",
            },
            "guarantorPrimary": {"email": random_data.email, "phone": "3477349659"},
            "guarantorAdditional": {"email": random_data.email, "phone": "7187349659"},
        }
        test_data = {
            "sourcePartnerId": "DXR",
            "targetPlatforms": [{"id": target_platform, "partyId": "1234"}],
        }
        for cust in customer_list:
            test_data[cust] = payload[cust]
        return json.dumps(test_data)

    return wrapper


@pytest.fixture
def generate_random_id():
    return dealData.generate_random_id()


@pytest.fixture()
def generate_decision_record():
    def decision_payload(deal_ref_id, deal_component, lender_id):
        return {
            "approvalStatus": "Approved",
            "approvedAmount": "29088",
            "approvedRate": "5",
            "approvedTerm": "60",
            "customerMoneyFactor": "0.002",
            "downPayment": "4380",
            "financeMethod": "Retail",
            "lenderId": lender_id,
            "lenderMoneyFactor": "0.005",
            "lenderName": "American Honda Finance Corporation",
            "monthlyPayment": "458",
            "stipulations": [{"text": "test1"}, {"text": "test2"}],
            "tier": "Gold",
            "dealRefId": deal_ref_id,
            "dealComponent": deal_component,
        }

    return decision_payload


@pytest.fixture()
def key_data_test_data_dtc_record_single_key():
    """
    Key-Data payload for DTC record with single key and targetPlatforms
    :return: payload
    """
    return {
        "targetPlatformId": "DTC",
        "dealJacketId": str(random.getrandbits(52)),
    }


@pytest.fixture()
def key_data_test_data_idl_deal_jacket_record():
    """
    Key-Data payload for IDL record
    :return: payload
    """
    return {
        "targetPlatformId": "IDL",
        "dealJacketId": str(random.getrandbits(52)),
    }


@pytest.fixture()
def key_data_test_data_dtc_record():
    """
    Key-Data payload for DTC record
    :return: payload
    """
    return {
        "targetPlatformId": "DTC",
        "dealJacketId": str(random.getrandbits(52)),
        "dealRefIdFI": dealData.generate_random_id(),
        "dealIdFI": dealData.generate_random_id(),
        "dealerId": str(random.getrandbits(52)),
        "dealerCode": str(random.getrandbits(52)),
        "documentMasterIndexIdFI": dealData.generate_random_id(),
        "dealXgDealId": str(random.getrandbits(52)),
        "dealXgDealVersion": str(random.getrandbits(52)),
        "commonOrgId": "".join(
            random.choices(string.ascii_uppercase + string.digits, k=6)
        ),
    }


@pytest.fixture()
def update_event_payload_random_data():
    def wrapper(payload, deal_ref_id, event_source, lender_id=None):
        rd = RandomData()
        random_data = rd.generate_random_unifi_and_finance_service_ids()
        guid = str(uuid.uuid4())
        event_source_options = ("fs", "dr", "unifi")
        if event_source not in event_source_options:
            raise ValueError(
                f"Event source must be one of these: {event_source_options}"
            )

        # Common for both systems
        payload["eventId"] = guid
        payload["eventIdentityId"] = guid
        payload["eventTime"] = time.strftime("%Y-%m-%dT%H:%M:%S")
        # payload["eventDetailHref"] = SIMULATORS.get("e2e_get").format(decision_resp_id)
        payload["eventKeyData"]["dealJacketId"] = random_data["dealJacketId"]
        payload["eventKeyData"]["dealerCode"] = random_data["dealerCode"]
        payload["eventKeyData"]["dealerId"] = random_data["dealerId"]
        payload["eventKeyData"]["appRefIdFD"] = random_data["appRefIdFD"]
        payload["eventKeyData"]["lenderId"] = lender_id or random_data["lenderId"]
        payload["eventKeyData"]["sourcePartnerId"] = random_data["sourcePartnerId"]
        payload["eventKeyData"]["sourcePartnerDealerId"] = random_data[
            "sourcePartnerDealerId"
        ]

        # for FS & DR Events
        if event_source in ["fs", "dr"]:
            payload["eventTransactionId"] = deal_ref_id  # DR dealRefId
            payload["eventKeyData"]["dealRefIdDR"] = deal_ref_id  # DR dealRefId
            payload["eventKeyData"]["leadRefIdFD"] = random_data["dealRefIdFD"]
            payload["eventKeyData"]["dealRefId"] = random_data[
                "dealRefIdFI"
            ]  # uniFI dealRefId
            payload["eventKeyData"]["creditAppId"] = random_data[
                "creditAppIdFI"
            ]  # uniFI credit app Id short
            payload["eventKeyData"]["creditAppIdDR"] = ulid.new().str
            payload["eventKeyData"]["unifiLeadFirst"] = False

        # for uniFI Events
        elif event_source == "unifi":
            payload["eventTransactionId"] = random_data[
                "dealRefIdFI"
            ]  # uniFI dealRefId
            payload["eventKeyData"]["dealRefId"] = random_data[
                "dealRefIdFI"
            ]  # uniFI dealRefId
            payload["eventKeyData"]["creditAppId"] = random_data[
                "creditAppIdFI"
            ]  # uniFI credit app Id short
            payload["eventKeyData"]["dealJacketId"] = random_data[
                "dealJacketId"
            ]  # uniFI DJ ID
            payload["eventKeyData"]["dealId"] = random_data["dealIdFI"]  # uniFI Deal ID
            payload["eventKeyData"]["creditAppIdDR"] = ulid.new().str
            payload["eventKeyData"]["unifiLeadFirst"] = False

        if payload.get("eventName").startswith(
            ("CreditApplications", "CreditDecisions")
        ):
            payload["eventKeyData"]["partnerCode"] = random_data["partnerCode"]

    return wrapper
