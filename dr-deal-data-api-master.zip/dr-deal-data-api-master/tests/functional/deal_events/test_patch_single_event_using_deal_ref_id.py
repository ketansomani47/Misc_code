# -*- coding: utf-8 -*-
from http import HTTPStatus

import pytest
from tests.functional.deal_events.events import EVENTS_FILE_NAME
from tests.functional.service_api import ServiceAPI


@pytest.mark.prod
@pytest.mark.smoke
@pytest.mark.functional
@pytest.mark.parametrize("event_file, event_source", EVENTS_FILE_NAME)
def test_patch_single_event_using_deal_ref_id(
    env,
    api_url,
    event_file,
    event_source,
    key_data_route,
    patch_event_route,
    post_event_route,
    get_events_route,
    get_deal_updated_timestamp,
    validate_deal_event_schema,
    update_event_payload_random_data,
    key_data_test_data_dtc_record_single_key,
):
    event_file = f"events/{event_file}"
    deal_data = ServiceAPI(env=env)

    deal_data.payload = key_data_test_data_dtc_record_single_key

    status_code, key_data_resp, headers = deal_data.post_request(
        api_url, key_data_route
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {key_data_resp}"
        )

    deal_ref_id = key_data_resp["dealRefId"]
    key_data_timestamp = get_deal_updated_timestamp(deal_ref_id=deal_data.dealRefId)

    deal_data.set_payload(event_file)
    update_event_payload_random_data(deal_data.payload, deal_ref_id, event_source)

    status_code, event_resp, headers = deal_data.post_request(api_url, post_event_route)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {event_resp}"
        )
    event_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId,
        deal_component=f"DTC.EVENTS.{event_resp['eventId']}",
        updated_timestamp=key_data_timestamp,
    )
    assert event_timestamp > key_data_timestamp

    inbound_event_id = deal_data.payload["eventId"]
    inbound_event_version = deal_data.payload["eventVersion"]

    deal_data.payload = {
        "eventVersion": "1.3",
    }
    deal_data.dealRefId = deal_ref_id
    deal_data.eventId = inbound_event_id

    status_code, get_resp, resp_headers = deal_data.patch(
        url=api_url,
        route_url=patch_event_route,
        cust_status_code=HTTPStatus.NO_CONTENT,
    )

    assert status_code == HTTPStatus.NO_CONTENT

    patch_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId,
        deal_component=f"DTC.EVENTS.{event_resp['eventId']}",
        updated_timestamp=event_timestamp,
    )
    assert patch_timestamp > event_timestamp

    deal_data.payload = {
        "pathParameters": {"dealRefId": deal_ref_id},
        "dealRefId": deal_ref_id,
    }

    get_status_code, check_get_resp, get_resp_headers = deal_data.get_request(
        url=api_url, route_url=get_events_route
    )

    assert check_get_resp[0]["eventVersion"] != inbound_event_version
    assert len(check_get_resp) == 1
    assert get_status_code == HTTPStatus.OK
    validate_deal_event_schema(check_get_resp[0])
