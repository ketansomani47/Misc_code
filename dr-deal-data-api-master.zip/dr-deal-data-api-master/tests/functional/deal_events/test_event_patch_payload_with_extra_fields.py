# -*- coding: utf-8 -*-
from http import HTTPStatus

import pytest
from tests.functional.service_api import ServiceAPI


INVALID_EVENT_PAYLOADS = [
    ("dr_internal_contract_successful_event.json", "dr", "creditAppId"),
    ("dr_internal_contract_successful_event.json", "dr", "contractRefId"),
    ("dr_internal_contract_successful_event.json", "dr", "dealRefIdFDInt"),
    ("dr_internal_contract_successful_event.json", "dr", "appRefIdFD"),
    ("dr_internal_contract_successful_event.json", "dr", "dealJacketId"),
    ("fs_internal_credit_decision_counter.json", "fs", "dealRefId"),
    ("unifi_internal_compliance_redflagofac.json", "unifi", "randomTestId"),
]


@pytest.mark.prod
@pytest.mark.smoke
@pytest.mark.functional
@pytest.mark.parametrize(
    "event_file, event_source, extra_field", INVALID_EVENT_PAYLOADS
)
def test_event_patch_payload_with_extra_fields(
    env,
    api_url,
    event_file,
    extra_field,
    event_source,
    key_data_route,
    patch_event_route,
    post_event_route,
    get_events_route,
    get_deal_updated_timestamp,
    key_data_test_data_dtc_record_single_key,
    validate_deal_event_schema,
    update_event_payload_random_data,
    query_dynamodb_with_deal_component,
):
    event_file = f"events/{event_file}"
    deal_data = ServiceAPI(env=env)

    # key-Data Post
    deal_data.payload = key_data_test_data_dtc_record_single_key
    status_code, key_data_resp, headers = deal_data.post_request(
        api_url,
        key_data_route,
    )
    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {key_data_resp}"
        )
    key_data_timestamp = get_deal_updated_timestamp(deal_data.dealRefId)

    # Post Event
    deal_data.set_payload(event_file)
    update_event_payload_random_data(
        deal_data.payload, deal_data.dealRefId, event_source
    )
    status_code, post_resp, headers = deal_data.post_request(
        api_url,
        post_event_route,
    )
    assert status_code == HTTPStatus.CREATED
    assert post_resp == {"dealRefId": deal_data.dealRefId, "eventId": deal_data.eventId}

    inbound_event_version = deal_data.payload["eventVersion"]
    event_comp = f"DTC.EVENTS.{deal_data.eventId}"
    event_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId,
        deal_component=event_comp,
        updated_timestamp=key_data_timestamp,
    )
    assert event_timestamp > key_data_timestamp

    extra_field_value = deal_data.generate_random_id()
    deal_data.payload = {
        "eventVersion": "1.3",
        extra_field: extra_field_value,
    }

    # Patch event
    status_code, get_resp, resp_headers = deal_data.patch(
        url=api_url,
        route_url=patch_event_route,
        cust_status_code=HTTPStatus.NO_CONTENT,
    )

    assert status_code == HTTPStatus.NO_CONTENT

    patch_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId,
        deal_component=event_comp,
        updated_timestamp=event_timestamp,
    )
    assert patch_timestamp > event_timestamp

    # Get Event
    get_status_code, check_get_resp, get_resp_headers = deal_data.get_request(
        url=api_url, route_url=get_events_route
    )

    assert check_get_resp[0]["eventVersion"] != inbound_event_version
    assert len(check_get_resp) == 1
    assert get_status_code == HTTPStatus.OK
    validate_deal_event_schema(check_get_resp[0])

    # Confirm the extra field is not in DB
    db_comp = f"DTC.EVENTS.{deal_data.eventId}"
    db_event = query_dynamodb_with_deal_component(deal_data.dealRefId, db_comp)[0]
    if extra_field == "dealRefId":
        assert extra_field_value != deal_data.dealRefId
    else:
        assert (
            extra_field not in db_event
        ), f"The extra field found in event schema: {extra_field}"
