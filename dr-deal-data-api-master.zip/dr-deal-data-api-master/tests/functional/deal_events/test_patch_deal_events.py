# -*- coding: utf-8 -*-
from http import HTTPStatus

import pytest
from tests.functional.deal_events.events import EVENTS_FILE_NAME
from tests.functional.service_api import ServiceAPI


@pytest.mark.prod
@pytest.mark.smoke
@pytest.mark.functional
def test_patch_no_existing_resource(
    env, api_url, patch_event_route, generate_random_id, invalid_deal_ref_id_response
):
    deal_data = ServiceAPI(env=env)

    deal_ref_id = generate_random_id
    event_id = generate_random_id

    deal_data.payload = {
        "eventVersion": "1.3",
    }
    deal_data.dealRefId = deal_ref_id
    deal_data.eventId = event_id

    status_code, get_resp, resp_headers = deal_data.patch(
        url=api_url,
        route_url=patch_event_route,
        cust_status_code=HTTPStatus.BAD_REQUEST,
    )

    assert status_code == HTTPStatus.BAD_REQUEST
    assert get_resp == invalid_deal_ref_id_response(deal_ref_id)


@pytest.mark.smoke
@pytest.mark.functional
def test_patch_no_path_param_deal_ref(
    env, api_url, patch_event_route, generate_random_id, missing_reference_ids_response
):
    deal_data = ServiceAPI(env=env)

    event_id = generate_random_id

    deal_data.payload = {
        "eventVersion": "1.3",
    }
    deal_data.dealRefId = ""
    deal_data.eventId = event_id

    status_code, get_resp, resp_headers = deal_data.patch(
        url=api_url,
        route_url=patch_event_route,
        cust_status_code=HTTPStatus.BAD_REQUEST,
    )

    assert status_code == HTTPStatus.BAD_REQUEST
    assert get_resp == missing_reference_ids_response(field_list=["dealRefId"])


@pytest.mark.smoke
@pytest.mark.functional
def test_patch_no_path_param_event_id(
    env,
    api_url,
    generate_random_id,
    patch_event_route,
):
    deal_data = ServiceAPI(env=env)

    deal_ref_id = generate_random_id

    deal_data.payload = {
        "eventVersion": "1.3",
    }
    deal_data.dealRefId = deal_ref_id
    deal_data.eventId = ""

    status_code, get_resp, resp_headers = deal_data.patch(
        url=api_url,
        route_url=patch_event_route,
        cust_status_code=HTTPStatus.FORBIDDEN,
    )

    assert status_code == HTTPStatus.FORBIDDEN


@pytest.mark.smoke
@pytest.mark.functional
@pytest.mark.parametrize("event_file, event_source", EVENTS_FILE_NAME)
def test_patch_valid_deal_invalid_event_id(
    env,
    api_url,
    event_file,
    event_source,
    key_data_route,
    patch_event_route,
    post_event_route,
    get_events_route,
    invalid_event_id,
    get_deal_updated_timestamp,
    key_data_test_data_dtc_record_single_key,
    update_event_payload_random_data,
):
    event_file = f"events/{event_file}"
    deal_data = ServiceAPI(env=env)

    deal_data.payload = key_data_test_data_dtc_record_single_key

    status_code, key_data_resp, headers = deal_data.post_request(
        api_url,
        key_data_route,
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {key_data_resp}"
        )

    deal_ref_id = key_data_resp["dealRefId"]
    key_data_timestamp = get_deal_updated_timestamp(deal_data.dealRefId)

    deal_data.set_payload(event_file)
    update_event_payload_random_data(deal_data.payload, deal_ref_id, event_source)

    status_code, post_event_resp, headers = deal_data.post_request(
        api_url, post_event_route
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {post_event_resp}"
        )
    event_comp = f"DTC.EVENTS.{deal_data.eventId}"
    event_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId,
        deal_component=event_comp,
        updated_timestamp=key_data_timestamp,
    )
    assert event_timestamp > key_data_timestamp

    deal_data.payload = {"eventVersion": "1.3"}
    deal_data.dealRefId = deal_ref_id
    deal_data.eventId = "INVALID"

    status_code, get_resp, resp_headers = deal_data.patch(
        url=api_url,
        route_url=patch_event_route,
        cust_status_code=HTTPStatus.BAD_REQUEST,
    )

    assert status_code == HTTPStatus.BAD_REQUEST
    assert get_resp == invalid_event_id(deal_data.eventId, deal_data.dealRefId)
