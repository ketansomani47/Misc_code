# -*- coding: utf-8 -*-
import time
from http import HTTPStatus

from tests.config import RETRY_COUNT


# -*- coding: utf-8 -*-
EVENTS_FILE_NAME = [
    ("dr_internal_contract_successful_event.json", "dr"),
    ("dr_internal_contract_failed_event.json", "dr"),
    ("fs_internal_credit_decision_counter.json", "fs"),
    ("unifi_internal_compliance_redflagofac.json", "unifi"),
    ("unifi_internal_contract_booked.json", "unifi"),
    ("unifi_internal_contract_documents_submitted_for_signing.json", "unifi"),
    ("unifi_internal_contract_partially_signed.json", "unifi"),
    ("unifi_internal_credit_application_submitted.json", "unifi"),
    ("unifi_internal_credit_decision_approved.json", "unifi"),
    ("unifi_internal_dealjacket_created.json", "unifi"),
]


def get_deal_events_with_count(
    api_url,
    service_api,
    get_events_route,
    expected_status_code=HTTPStatus.OK,
    expected_event_count=1,
    query_param=None,
):
    status_code = HTTPStatus.FORBIDDEN
    get_resp = []
    resp_headers = []
    event_count = ""
    retry = 0
    retry_count = 5 if expected_status_code == HTTPStatus.BAD_REQUEST else RETRY_COUNT
    while (
        status_code != expected_status_code or event_count != expected_event_count
    ) and retry < retry_count:
        retry += 1
        time.sleep(0.5)
        status_code, get_resp, resp_headers = service_api.get_request(
            url=api_url,
            route_url=get_events_route,
            query_param=query_param,
        )
        event_count = len(get_resp)
    assert expected_status_code == status_code
    if status_code == HTTPStatus.OK:
        assert expected_event_count == event_count
    return get_resp, resp_headers
