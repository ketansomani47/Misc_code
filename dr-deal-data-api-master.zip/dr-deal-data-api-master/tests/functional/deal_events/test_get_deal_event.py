# -*- coding: utf-8 -*-
import time
from http import HTTPStatus

import pytest
from tests.config import RETRY_COUNT
from tests.functional.service_api import ServiceAPI


KEY_DATA_ROUTER = "key_data"
GET_EVENT_ROUTE = "get_event"
APP_ROUTE = "credit_app"
POST_EVENT_ROUTE = "post_event"


class TestGetDealEvent:
    @classmethod
    @pytest.fixture(autouse=True)
    def setup_class(cls, env, api_url):
        cls.api_url = api_url
        cls.deal_data = ServiceAPI(env=env)

    def get_deal_event_with_count(
        self,
        expected_status_code=HTTPStatus.OK,
        expected_event_count=1,
        query_param=None,
    ):
        status_code = HTTPStatus.FORBIDDEN
        get_resp = []
        resp_headers = []
        event_count = ""
        retry = 0
        retry_count = (
            5 if expected_status_code == HTTPStatus.BAD_REQUEST else RETRY_COUNT
        )
        while (
            status_code != expected_status_code or event_count != expected_event_count
        ) and retry < retry_count:
            retry += 1
            time.sleep(0.5)
            status_code, get_resp, resp_headers = self.deal_data.get_request(
                url=self.api_url,
                route_url=GET_EVENT_ROUTE,
                query_param=query_param,
            )
            event_count = len(get_resp)
        assert expected_status_code == status_code
        if status_code == HTTPStatus.OK:
            assert expected_event_count == event_count
        return get_resp, resp_headers

    FS_DR_EVENTS = [
        ("fs_internal_credit_decision_counter.json", "fs"),
        ("dr_internal_contract_successful_event.json", "dr"),
        ("dr_internal_contract_failed_event.json", "dr"),
    ]

    @pytest.mark.prod
    @pytest.mark.smoke
    @pytest.mark.functional
    @pytest.mark.parametrize("event_file, event_source", FS_DR_EVENTS)
    def test_get_single_event_using_deal_ref_id_fs_and_dr_events(
        self,
        event_file,
        event_source,
        assert_headers,
        get_deal_component_details,
        key_data_test_data_dtc_record_single_key,
        validate_deal_event_payload,
        get_deal_updated_timestamp,
        update_event_payload_random_data,
    ):
        event_file = f"events/{event_file}"
        self.deal_data.payload = key_data_test_data_dtc_record_single_key
        status_code, key_data_resp, headers = self.deal_data.post_request(
            self.api_url, KEY_DATA_ROUTER
        )

        if status_code != HTTPStatus.CREATED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {key_data_resp}"
            )
        key_data_timestamp = get_deal_updated_timestamp(
            deal_ref_id=self.deal_data.dealRefId
        )
        # Upload events in DB
        self.deal_data.set_payload(event_file)
        update_event_payload_random_data(
            self.deal_data.payload, key_data_resp["dealRefId"], event_source
        )

        status_code, post_resp, headers = self.deal_data.post_request(
            self.api_url, POST_EVENT_ROUTE
        )
        if status_code != HTTPStatus.CREATED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {post_resp}"
            )
        event_comp = f"DTC.EVENTS.{self.deal_data.eventId}"
        event_timestamp = get_deal_updated_timestamp(
            deal_ref_id=self.deal_data.dealRefId,
            deal_component=event_comp,
            updated_timestamp=key_data_timestamp,
        )
        assert event_timestamp > key_data_timestamp

        get_deal_component_details(self.deal_data.dealRefId, event_comp)

        # Get event data
        get_resp, resp_headers = self.get_deal_event_with_count()

        # Validate event payload
        validate_deal_event_payload(self.deal_data.payload, get_resp)
        assert_headers(resp_headers)
        # TODO: Add check for AWS region and API Version

    UNIFI_EVENTS = [
        ("unifi_internal_compliance_redflagofac.json", "unifi"),
        ("unifi_internal_contract_booked.json", "unifi"),
        ("unifi_internal_contract_documents_submitted_for_signing.json", "unifi"),
        ("unifi_internal_contract_partially_signed.json", "unifi"),
        ("unifi_internal_credit_application_submitted.json", "unifi"),
        ("unifi_internal_credit_decision_approved.json", "unifi"),
        ("unifi_internal_dealjacket_created.json", "unifi"),
    ]

    @pytest.mark.smoke
    @pytest.mark.functional
    @pytest.mark.parametrize("event_file, event_source", UNIFI_EVENTS)
    def test_get_single_event_using_deal_ref_id_unifi_events(
        self,
        event_file,
        event_source,
        assert_headers,
        get_deal_component_details,
        validate_deal_event_payload,
        get_deal_updated_timestamp,
        key_data_test_data_dtc_record_single_key,
        update_event_payload_random_data,
    ):
        event_file = f"events/{event_file}"

        self.deal_data.payload = key_data_test_data_dtc_record_single_key
        status_code, key_data_resp, headers = self.deal_data.post_request(
            self.api_url, KEY_DATA_ROUTER
        )

        if status_code != HTTPStatus.CREATED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {key_data_resp}"
            )
        key_data_timestamp = get_deal_updated_timestamp(
            deal_ref_id=self.deal_data.dealRefId
        )
        # Upload events in DB
        self.deal_data.set_payload(event_file)
        update_event_payload_random_data(
            self.deal_data.payload, key_data_resp["dealRefId"], event_source
        )

        status_code, post_resp, headers = self.deal_data.post_request(
            self.api_url,
            POST_EVENT_ROUTE,
        )
        if status_code != HTTPStatus.CREATED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {post_resp}"
            )
        event_comp = f"DTC.EVENTS.{self.deal_data.eventId}"
        event_timestamp = get_deal_updated_timestamp(
            deal_ref_id=self.deal_data.dealRefId,
            deal_component=event_comp,
            updated_timestamp=key_data_timestamp,
        )
        assert event_timestamp > key_data_timestamp

        get_deal_component_details(self.deal_data.dealRefId, event_comp)
        get_resp, resp_headers = self.get_deal_event_with_count()

        # Validate event payload
        validate_deal_event_payload(self.deal_data.payload, get_resp)
        assert_headers(resp_headers)
        # TODO: Add check for AWS region and API Version

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_get_zero_event_response(
        self,
        assert_headers,
        invalid_event_id,
        get_deal_updated_timestamp,
        key_data_test_data_dtc_record_single_key,
    ):

        self.deal_data.payload = key_data_test_data_dtc_record_single_key
        status_code, key_data_resp, headers = self.deal_data.post_request(
            self.api_url,
            KEY_DATA_ROUTER,
        )

        if status_code != HTTPStatus.CREATED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {key_data_resp}"
            )
        get_deal_updated_timestamp(deal_ref_id=self.deal_data.dealRefId)
        # Get Events
        get_resp, resp_headers = self.get_deal_event_with_count(
            expected_status_code=HTTPStatus.BAD_REQUEST, expected_event_count=0
        )

        assert get_resp == invalid_event_id(
            self.deal_data.eventId, self.deal_data.dealRefId
        )
        assert_headers(resp_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_get_event_missing_deal_ref_id(
        self,
        assert_headers,
        key_data_test_data_dtc_record_single_key,
        missing_reference_ids_response,
    ):

        # Get Events
        self.deal_data.dealRefId = ""
        get_resp, resp_headers = self.get_deal_event_with_count(
            expected_status_code=HTTPStatus.BAD_REQUEST, expected_event_count=0
        )
        assert get_resp == missing_reference_ids_response(field_list=["dealRefId"])
        assert_headers(resp_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_get_event_invalid_deal_ref_id(
        self,
        assert_headers,
        key_data_test_data_dtc_record_single_key,
        invalid_deal_ref_id_response,
    ):

        # Get Events
        self.deal_data.dealRefId = self.deal_data.generate_random_id(True)
        get_resp, resp_headers = self.get_deal_event_with_count(
            expected_status_code=HTTPStatus.BAD_REQUEST, expected_event_count=0
        )
        assert get_resp == invalid_deal_ref_id_response(self.deal_data.dealRefId)
        assert_headers(resp_headers)
