# -*- coding: utf-8 -*-
from http import HTTPStatus

import pytest
from tests.functional.service_api import ServiceAPI


KEY_DATA_ROUTER = "key_data"
GET_EVENT_ROUTE = "get_events"
POST_EVENT_ROUTE = "post_event"
APP_ROUTE = "credit_app"

VALID_QUERY_PRAMS = "['eventName', 'eventSource', 'eventType', 'targetPlatformId']"

EVENTS_FILE_NAME = [
    ("dr_internal_contract_successful_event.json", "dr"),
    ("dr_internal_contract_failed_event.json", "dr"),
    ("fs_internal_credit_decision_counter.json", "fs"),
    ("unifi_internal_compliance_redflagofac.json", "unifi"),
    ("unifi_internal_contract_booked.json", "unifi"),
    ("unifi_internal_contract_documents_submitted_for_signing.json", "unifi"),
    ("unifi_internal_contract_partially_signed.json", "unifi"),
    ("unifi_internal_credit_application_submitted.json", "unifi"),
    ("unifi_internal_credit_decision_approved.json", "unifi"),
    ("unifi_internal_dealjacket_created.json", "unifi"),
]


@pytest.mark.smoke
@pytest.mark.functional
@pytest.mark.parametrize("event_file, event_source", EVENTS_FILE_NAME)
def test_post_success(
    env,
    api_url,
    event_file,
    event_source,
    assert_headers,
    get_deal_updated_timestamp,
    get_deal_component_details,
    key_data_test_data_dtc_record_single_key,
    validate_deal_event_schema,
    update_event_payload_random_data,
):
    event_file = f"events/{event_file}"
    deal_data = ServiceAPI(env=env)

    deal_data.payload = key_data_test_data_dtc_record_single_key
    status_code, key_data_resp, headers = deal_data.post_request(
        api_url, KEY_DATA_ROUTER
    )
    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {key_data_resp}"
        )

    key_data_timestamp = get_deal_updated_timestamp(deal_ref_id=deal_data.dealRefId)
    deal_data.set_payload(event_file)
    update_event_payload_random_data(
        deal_data.payload, deal_data.dealRefId, event_source
    )
    status_code, post_resp, headers = deal_data.post_request(api_url, POST_EVENT_ROUTE)

    assert status_code == HTTPStatus.CREATED
    assert post_resp == {"dealRefId": deal_data.dealRefId, "eventId": deal_data.eventId}
    assert_headers(headers)
    event_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId,
        deal_component=f"DTC.EVENTS.{post_resp['eventId']}",
        updated_timestamp=key_data_timestamp,
    )
    assert event_timestamp > key_data_timestamp

    get_status_code, check_get_resp, get_resp_headers = deal_data.get_request(
        url=api_url, route_url=GET_EVENT_ROUTE
    )

    assert len(check_get_resp) == 1
    assert get_status_code == HTTPStatus.OK
    assert check_get_resp[0]["eventName"] == deal_data.payload["eventName"]
    assert check_get_resp[0]["eventType"] == deal_data.payload["eventType"]
    assert check_get_resp[0]["eventSource"] == deal_data.payload["eventSource"]
    validate_deal_event_schema(check_get_resp[0])


@pytest.mark.smoke
@pytest.mark.functional
@pytest.mark.parametrize("event_file, event_source", EVENTS_FILE_NAME)
def test_post_event_missing_deal_ref_id(
    env,
    api_url,
    event_file,
    event_source,
    assert_headers,
    key_data_test_data_dtc_record_single_key,
    update_event_payload_random_data,
    missing_reference_ids_response,
):
    event_file = f"events/{event_file}"
    deal_data = ServiceAPI(env=env)

    deal_data.payload = key_data_test_data_dtc_record_single_key

    status_code, key_data_resp, headers = deal_data.post_request(
        api_url, KEY_DATA_ROUTER
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {key_data_resp}"
        )

    deal_ref_id = key_data_resp["dealRefId"]

    deal_data.set_payload(event_file)
    update_event_payload_random_data(deal_data.payload, deal_ref_id, event_source)

    deal_data.dealRefId = ""

    status_code, post_resp, headers = deal_data.post_request(api_url, POST_EVENT_ROUTE)

    assert_headers(headers)
    assert status_code == HTTPStatus.BAD_REQUEST
    assert post_resp == missing_reference_ids_response(field_list=["dealRefId"])

    deal_data.dealRefId = key_data_resp["dealRefId"]

    get_status_code, check_get_resp, get_resp_headers = deal_data.get_request(
        url=api_url, route_url=GET_EVENT_ROUTE
    )

    assert len(check_get_resp) == 0
    assert get_status_code == HTTPStatus.NOT_FOUND


@pytest.mark.smoke
@pytest.mark.functional
@pytest.mark.parametrize("event_file, event_source", EVENTS_FILE_NAME)
def test_post_invalid_deal_ref_id(
    env,
    api_url,
    event_file,
    event_source,
    key_data_test_data_dtc_record_single_key,
    assert_headers,
    generate_random_id,
    invalid_deal_ref_id_response,
    update_event_payload_random_data,
):
    event_file = f"events/{event_file}"
    deal_data = ServiceAPI(env=env)

    deal_data.payload = key_data_test_data_dtc_record_single_key

    status_code, key_data_resp, headers = deal_data.post_request(
        api_url, KEY_DATA_ROUTER
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {key_data_resp}"
        )

    deal_ref_id = key_data_resp["dealRefId"]

    deal_data.set_payload(event_file)
    update_event_payload_random_data(deal_data.payload, deal_ref_id, event_source)

    deal_data.dealRefId = generate_random_id

    status_code, post_resp, headers = deal_data.post_request(api_url, POST_EVENT_ROUTE)

    assert_headers(headers)
    assert status_code == HTTPStatus.BAD_REQUEST
    assert post_resp == invalid_deal_ref_id_response(deal_data.dealRefId)

    deal_data.dealRefId = key_data_resp["dealRefId"]

    get_status_code, check_get_resp, get_resp_headers = deal_data.get_request(
        url=api_url, route_url=GET_EVENT_ROUTE
    )

    assert len(check_get_resp) == 0
    assert get_status_code == HTTPStatus.NOT_FOUND


@pytest.mark.smoke
@pytest.mark.functional
@pytest.mark.parametrize("event_file, event_source", EVENTS_FILE_NAME)
def test_post_empty_payload(
    env,
    api_url,
    event_file,
    assert_headers,
    key_data_test_data_dtc_record_single_key,
    event_source,
    missing_payload_response,
):
    event_file = f"events/{event_file}"
    deal_data = ServiceAPI(env=env)

    deal_data.payload = key_data_test_data_dtc_record_single_key

    status_code, key_data_resp, headers = deal_data.post_request(
        api_url,
        KEY_DATA_ROUTER,
    )
    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {key_data_resp}"
        )

    deal_data.payload = {}

    status_code, post_resp, headers = deal_data.post_request(
        api_url,
        POST_EVENT_ROUTE,
    )

    assert status_code == HTTPStatus.BAD_REQUEST
    assert post_resp == missing_payload_response
    assert_headers(headers)

    get_status_code, check_get_resp, get_resp_headers = deal_data.get_request(
        url=api_url, route_url=GET_EVENT_ROUTE
    )

    assert len(check_get_resp) == 0
    assert get_status_code == HTTPStatus.NOT_FOUND


@pytest.mark.smoke
@pytest.mark.functional
@pytest.mark.parametrize("event_file, event_source", EVENTS_FILE_NAME)
def test_post_duplicate_events(
    env,
    api_url,
    event_file,
    event_source,
    assert_headers,
    get_deal_component_details,
    key_data_test_data_dtc_record_single_key,
    update_event_payload_random_data,
    error_posting_duplicate_event,
):
    event_file = f"events/{event_file}"
    deal_data = ServiceAPI(env=env)

    deal_data.payload = key_data_test_data_dtc_record_single_key

    status_code, key_data_resp, headers = deal_data.post_request(
        api_url,
        KEY_DATA_ROUTER,
    )
    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {key_data_resp}"
        )

    deal_ref_id = key_data_resp["dealRefId"]

    deal_data.set_payload(event_file)
    update_event_payload_random_data(deal_data.payload, deal_ref_id, event_source)
    status_code, post_resp, headers = deal_data.post_request(
        api_url,
        POST_EVENT_ROUTE,
    )

    assert status_code == HTTPStatus.CREATED
    assert post_resp == {"dealRefId": deal_ref_id, "eventId": deal_data.eventId}
    assert_headers(headers)
    get_deal_component_details(deal_ref_id, f"DTC.EVENTS.{post_resp['eventId']}")

    get_status_code, check_get_resp, get_resp_headers = deal_data.get_request(
        url=api_url, route_url=GET_EVENT_ROUTE
    )

    assert len(check_get_resp) == 1
    assert get_status_code == HTTPStatus.OK
    assert check_get_resp[0]["eventName"] == deal_data.payload["eventName"]
    assert check_get_resp[0]["eventType"] == deal_data.payload["eventType"]
    assert check_get_resp[0]["eventSource"] == deal_data.payload["eventSource"]

    status_code, post_resp, headers = deal_data.post_request(
        api_url,
        POST_EVENT_ROUTE,
    )

    assert status_code == HTTPStatus.BAD_REQUEST
    assert post_resp == error_posting_duplicate_event
    assert_headers(headers)


@pytest.mark.smoke
@pytest.mark.functional
@pytest.mark.parametrize("event_file, event_source", EVENTS_FILE_NAME)
def test_post_multiple_events(
    env,
    api_url,
    event_file,
    event_source,
    assert_headers,
    get_deal_component_details,
    key_data_test_data_dtc_record_single_key,
    update_event_payload_random_data,
):
    event_file = f"events/{event_file}"
    deal_data = ServiceAPI(env=env)

    deal_data.payload = key_data_test_data_dtc_record_single_key

    status_code, key_data_resp, headers = deal_data.post_request(
        api_url,
        KEY_DATA_ROUTER,
    )
    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {key_data_resp}"
        )

    deal_ref_id = key_data_resp["dealRefId"]

    deal_data.set_payload(event_file)

    update_event_payload_random_data(deal_data.payload, deal_ref_id, event_source)
    deal_data.payload.update({"eventId": "123"})
    status_code, post_resp, headers = deal_data.post_request(
        api_url,
        POST_EVENT_ROUTE,
    )

    assert status_code == HTTPStatus.CREATED
    assert post_resp == {"dealRefId": deal_ref_id, "eventId": "123"}
    assert_headers(headers)
    get_deal_component_details(deal_ref_id, f"DTC.EVENTS.{post_resp['eventId']}")

    get_status_code, check_get_resp, get_resp_headers = deal_data.get_request(
        url=api_url, route_url=GET_EVENT_ROUTE
    )

    assert len(check_get_resp) == 1
    assert get_status_code == HTTPStatus.OK
    assert check_get_resp[0]["eventName"] == deal_data.payload["eventName"]
    assert check_get_resp[0]["eventType"] == deal_data.payload["eventType"]
    assert check_get_resp[0]["eventSource"] == deal_data.payload["eventSource"]

    update_event_payload_random_data(deal_data.payload, deal_ref_id, event_source)
    deal_data.payload.update({"eventId": "456"})
    status_code, post_resp, headers = deal_data.post_request(
        api_url,
        POST_EVENT_ROUTE,
    )

    assert status_code == HTTPStatus.CREATED
    assert post_resp == {"dealRefId": deal_ref_id, "eventId": "456"}
    assert_headers(headers)
    get_deal_component_details(deal_ref_id, f"DTC.EVENTS.{post_resp['eventId']}")

    get_status_code, check_get_resp, get_resp_headers = deal_data.get_request(
        url=api_url, route_url=GET_EVENT_ROUTE
    )

    assert len(check_get_resp) == 2
    assert get_status_code == HTTPStatus.OK
    assert check_get_resp[1]["eventName"] == deal_data.payload["eventName"]
    assert check_get_resp[1]["eventType"] == deal_data.payload["eventType"]
    assert check_get_resp[1]["eventSource"] == deal_data.payload["eventSource"]


INVALID_EVENT_PAYLOADS = [
    ("dr_internal_contract_successful_event.json", "dr", "creditAppId"),
    ("dr_internal_contract_successful_event.json", "dr", "contractRefId"),
    ("dr_internal_contract_successful_event.json", "dr", "dealRefIdFDInt"),
    ("dr_internal_contract_successful_event.json", "dr", "appRefIdFD"),
    ("dr_internal_contract_successful_event.json", "dr", "dealJacketId"),
    ("fs_internal_credit_decision_counter.json", "fs", "dealRefId"),
    ("unifi_internal_compliance_redflagofac.json", "unifi", "randomTestId"),
]


@pytest.mark.prod
@pytest.mark.smoke
@pytest.mark.functional
@pytest.mark.parametrize(
    "event_file, event_source, extra_field", INVALID_EVENT_PAYLOADS
)
def test_event_post_payload_with_extra_fields(
    env,
    api_url,
    event_file,
    extra_field,
    event_source,
    assert_headers,
    get_deal_component_details,
    key_data_test_data_dtc_record_single_key,
    validate_deal_event_schema,
    update_event_payload_random_data,
    query_dynamodb_with_deal_component,
):
    event_file = f"events/{event_file}"
    deal_data = ServiceAPI(env=env)

    deal_data.payload = key_data_test_data_dtc_record_single_key

    status_code, key_data_resp, headers = deal_data.post_request(
        api_url,
        KEY_DATA_ROUTER,
    )
    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {key_data_resp}"
        )

    deal_ref_id = key_data_resp["dealRefId"]

    deal_data.set_payload(event_file)
    update_event_payload_random_data(deal_data.payload, deal_ref_id, event_source)
    extra_field_value = deal_data.generate_random_id()
    deal_data.payload[extra_field] = extra_field_value
    status_code, post_resp, headers = deal_data.post_request(
        api_url,
        POST_EVENT_ROUTE,
    )

    assert status_code == HTTPStatus.CREATED
    assert post_resp == {"dealRefId": deal_ref_id, "eventId": deal_data.eventId}
    assert_headers(headers)
    get_deal_component_details(deal_ref_id, f"DTC.EVENTS.{post_resp['eventId']}")

    get_status_code, check_get_resp, get_resp_headers = deal_data.get_request(
        url=api_url, route_url=GET_EVENT_ROUTE
    )

    assert len(check_get_resp) == 1
    assert get_status_code == HTTPStatus.OK
    assert check_get_resp[0]["eventName"] == deal_data.payload["eventName"]
    assert check_get_resp[0]["eventType"] == deal_data.payload["eventType"]
    assert check_get_resp[0]["eventSource"] == deal_data.payload["eventSource"]
    validate_deal_event_schema(check_get_resp[0])

    # Confirm the extra field is not in DB
    db_comp = f"DTC.EVENTS.{deal_data.eventId}"
    db_event = query_dynamodb_with_deal_component(deal_ref_id, db_comp)[0]
    if extra_field == "dealRefId":
        assert extra_field_value != deal_ref_id
    else:
        assert (
            extra_field not in db_event
        ), f"The extra field found in event schema: {extra_field}"
