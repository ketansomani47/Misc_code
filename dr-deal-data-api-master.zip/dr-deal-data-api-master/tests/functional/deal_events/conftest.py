# -*- coding: utf-8 -*-
import pytest
from jsonschema import Draft7Validator


@pytest.fixture()
def key_data_route():
    return "key_data"


@pytest.fixture()
def patch_event_route():
    return "patch_event"


@pytest.fixture()
def get_events_route():
    return "get_events"


@pytest.fixture()
def post_event_route():
    return "post_event"


@pytest.fixture()
def error_posting_duplicate_event():
    return [
        {
            "code": "deal.invalidRefId",
            "properties": [
                {"property": "dealComponent", "message": "Event record already posted"}
            ],
        }
    ]


@pytest.fixture()
def generate_s3_key_issue():
    return [
        {
            "code": "deal.missingRequiredProperty",
            "properties": [
                {
                    "message": "sourcePartnerId is missing in eventKeyData",
                    "property": "eventKeyData.sourcePartnerId",
                },
                {
                    "message": "sourcePartnerDealerId is missing in eventKeyData",
                    "property": "eventKeyData.sourcePartnerDealerId",
                },
                {
                    "message": "creditAppIdDR is missing in eventKeyData",
                    "property": "eventKeyData.creditAppIdDR",
                },
            ],
        }
    ]


@pytest.fixture()
def validate_deal_event_schema(dr_deal_event_schema):
    def wrapper(response_event):
        validator = Draft7Validator(dr_deal_event_schema)
        validator_error = sorted(
            validator.iter_errors(response_event), key=lambda e: e.path
        )
        if validator_error:
            raise Exception(
                f"Error occur which validating the schema: {validator_error}"
            )

    return wrapper


@pytest.fixture()
def validate_deal_event_payload():
    """
    This fixture would accept posted event payload and get event payload to compare them.
    For The initial pass, we would skip a few fields and run basic validations
    :param post_payload:
    :param get_payload:
    :return:
    """

    def wrapper(post_payload, get_payload):
        # TODO: Add payload from s3 only if it is managed by deal-data API
        expected_payload = (
            post_payload if isinstance(post_payload, list) else [post_payload]
        )
        for payload in expected_payload:
            payload.pop("payload", None)
            payload.pop("payloadSchemaHref", None)
            if not payload.get("eventDetailHref"):
                payload.pop("eventDetailHref", None)
            payload.pop("eventId", None)
        # assert expected_payload == get_payload
        assert sorted(expected_payload, key=lambda ele: sorted(ele.items())) == sorted(
            get_payload, key=lambda ele: sorted(ele.items())
        )

    return wrapper


@pytest.fixture()
def dr_deal_event_schema():
    return {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "type": "object",
        "properties": {
            "eventVersion": {"type": "string"},
            "eventId": {"type": "string"},
            "eventTime": {"type": "string"},
            "eventName": {"type": "string"},
            "eventDetailHref": {"type": "string"},
            "eventSource": {"type": "string"},
            "eventType": {"type": "string"},
            "eventIdentityId": {"type": "string"},
            "eventEntityId": {"type": "string"},
            "eventTransactionId": {"type": "string"},
            "payloadSchemaHref": {"type": "string"},
            "eventKeyData": {"type": "object"},
            "payload": {"type": "object"},
        },
        "required": [
            "eventVersion",
            # "eventId" or "eventIdInbound",  # TODO : confirm it is not required anymore
            "eventTime",
            "eventName",
            "eventSource",
            "eventType",
            "eventIdentityId",
            "eventEntityId",
            "eventTransactionId",
            "eventKeyData",
        ],
        "additionalProperties": False,
    }
