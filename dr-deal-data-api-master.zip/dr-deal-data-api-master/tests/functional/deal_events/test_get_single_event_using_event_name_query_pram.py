# -*- coding: utf-8 -*-
from http import HTTPStatus

import pytest
from tests.functional.deal_events.events import (
    EVENTS_FILE_NAME,
    get_deal_events_with_count,
)
from tests.functional.service_api import ServiceAPI


@pytest.mark.prod
@pytest.mark.smoke
@pytest.mark.functional
@pytest.mark.parametrize("event_file, event_source", EVENTS_FILE_NAME)
def test_get_single_event_using_event_name_query_pram(
    env,
    api_url,
    event_file,
    event_source,
    assert_headers,
    key_data_route,
    post_event_route,
    get_events_route,
    get_deal_component_details,
    get_deal_updated_timestamp,
    key_data_test_data_dtc_record_single_key,
    validate_deal_event_payload,
    update_event_payload_random_data,
):
    event_file = f"events/{event_file}"

    deal_data = ServiceAPI(env=env)

    deal_data.payload = key_data_test_data_dtc_record_single_key
    status_code, key_data_resp, headers = deal_data.post_request(
        api_url, key_data_route
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {key_data_resp}"
        )
    key_data_timestamp = get_deal_updated_timestamp(deal_ref_id=deal_data.dealRefId)
    # Upload events in DB
    deal_data.set_payload(event_file)
    update_event_payload_random_data(
        deal_data.payload, key_data_resp["dealRefId"], event_source
    )

    status_code, post_resp, headers = deal_data.post_request(api_url, post_event_route)
    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {post_resp}"
        )
    event_comp = f"DTC.EVENTS.{deal_data.eventId}"
    event_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId,
        deal_component=event_comp,
        updated_timestamp=key_data_timestamp,
    )
    assert event_timestamp > key_data_timestamp
    get_deal_component_details(deal_data.dealRefId, event_comp)

    # Get Events
    query_param = f"eventName={deal_data.payload['eventName']}"
    get_resp, resp_headers = get_deal_events_with_count(
        api_url=api_url,
        service_api=deal_data,
        get_events_route=get_events_route,
        query_param=query_param,
    )

    # Validate event payload
    validate_deal_event_payload(deal_data.payload, get_resp)
    assert_headers(resp_headers)
