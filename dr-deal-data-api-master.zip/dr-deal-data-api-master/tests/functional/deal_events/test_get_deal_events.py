# -*- coding: utf-8 -*-
from http import HTTPStatus

import pytest
from tests.functional.deal_events.events import get_deal_events_with_count
from tests.functional.service_api import ServiceAPI


VALID_QUERY_PRAMS = "['eventName', 'eventSource', 'eventType', 'targetPlatformId']"


class TestGetDealEvents:
    @classmethod
    @pytest.fixture(autouse=True)
    def setup_class(cls, env, api_url):
        cls.api_url = api_url
        cls.deal_data = ServiceAPI(env=env)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_get_single_event_using_two_queries_params(
        self,
        assert_headers,
        key_data_route,
        post_event_route,
        get_events_route,
        get_deal_component_details,
        get_deal_updated_timestamp,
        key_data_test_data_dtc_record_single_key,
        validate_deal_event_payload,
        update_event_payload_random_data,
    ):
        event_file = "events/fs_internal_credit_decision_counter.json"

        self.deal_data.payload = key_data_test_data_dtc_record_single_key
        status_code, key_data_resp, headers = self.deal_data.post_request(
            self.api_url,
            key_data_route,
        )

        if status_code != HTTPStatus.CREATED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {key_data_resp}"
            )
        key_data_timestamp = get_deal_updated_timestamp(
            deal_ref_id=self.deal_data.dealRefId
        )
        # Upload events in DB
        self.deal_data.set_payload(event_file)
        update_event_payload_random_data(
            self.deal_data.payload, key_data_resp["dealRefId"], "fs"
        )

        status_code, post_resp, headers = self.deal_data.post_request(
            self.api_url,
            post_event_route,
        )
        if status_code != HTTPStatus.CREATED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {post_resp}"
            )
        event_comp = f"DTC.EVENTS.{self.deal_data.eventId}"
        event_timestamp = get_deal_updated_timestamp(
            deal_ref_id=self.deal_data.dealRefId,
            deal_component=event_comp,
            updated_timestamp=key_data_timestamp,
        )
        assert event_timestamp > key_data_timestamp
        get_deal_component_details(self.deal_data.dealRefId, event_comp)

        # Get Events
        query_param = f"eventName={self.deal_data.payload['eventName']}&eventSource={self.deal_data.payload['eventSource']}"
        get_resp, resp_headers = get_deal_events_with_count(
            api_url=self.api_url,
            service_api=self.deal_data,
            get_events_route=get_events_route,
            query_param=query_param,
        )

        # Validate event payload
        validate_deal_event_payload(self.deal_data.payload, get_resp)
        assert_headers(resp_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_get_single_event_using_three_queries_prams(
        self,
        assert_headers,
        key_data_route,
        post_event_route,
        get_events_route,
        get_deal_component_details,
        get_deal_updated_timestamp,
        key_data_test_data_dtc_record_single_key,
        validate_deal_event_payload,
        update_event_payload_random_data,
    ):
        event_file = "events/fs_internal_credit_decision_counter.json"

        self.deal_data.payload = key_data_test_data_dtc_record_single_key
        status_code, key_data_resp, headers = self.deal_data.post_request(
            self.api_url,
            key_data_route,
        )

        if status_code != HTTPStatus.CREATED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {key_data_resp}"
            )
        key_data_timestamp = get_deal_updated_timestamp(
            deal_ref_id=self.deal_data.dealRefId
        )
        # Upload events in DB
        self.deal_data.set_payload(event_file)
        update_event_payload_random_data(
            self.deal_data.payload, key_data_resp["dealRefId"], "fs"
        )

        status_code, post_resp, headers = self.deal_data.post_request(
            self.api_url,
            post_event_route,
        )
        if status_code != HTTPStatus.CREATED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {post_resp}"
            )
        event_comp = f"DTC.EVENTS.{self.deal_data.eventId}"
        event_timestamp = get_deal_updated_timestamp(
            deal_ref_id=self.deal_data.dealRefId,
            deal_component=event_comp,
            updated_timestamp=key_data_timestamp,
        )
        assert event_timestamp > key_data_timestamp
        get_deal_component_details(self.deal_data.dealRefId, event_comp)
        get_deal_component_details(self.deal_data.dealRefId, event_comp)

        # Get Events
        query_param = f"eventName={self.deal_data.payload['eventName']}&eventSource={self.deal_data.payload['eventSource']}&eventType={self.deal_data.payload['eventType']}"
        get_resp, resp_headers = get_deal_events_with_count(
            api_url=self.api_url,
            service_api=self.deal_data,
            get_events_route=get_events_route,
            query_param=query_param,
        )

        # Validate event payload
        validate_deal_event_payload(self.deal_data.payload, get_resp)
        assert_headers(resp_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_get_multiple_events_using_deal_ref_id(
        self,
        assert_headers,
        key_data_route,
        post_event_route,
        get_events_route,
        get_deal_component_details,
        get_deal_updated_timestamp,
        key_data_test_data_dtc_record_single_key,
        validate_deal_event_payload,
        update_event_payload_random_data,
    ):
        event_file1 = ("events/unifi_internal_dealjacket_created.json", "unifi")
        event_file2 = (
            "events/unifi_internal_credit_application_submitted.json",
            "unifi",
        )
        event_file3 = ("events/unifi_internal_credit_decision_approved.json", "unifi")
        event_file4 = ("events/dr_internal_contract_successful_event.json", "dr")

        self.deal_data.payload = key_data_test_data_dtc_record_single_key
        status_code, key_data_resp, headers = self.deal_data.post_request(
            self.api_url,
            key_data_route,
        )

        if status_code != HTTPStatus.CREATED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {key_data_resp}"
            )
        key_data_timestamp = get_deal_updated_timestamp(
            deal_ref_id=self.deal_data.dealRefId
        )

        # Post multiple events
        previous_timestamp = key_data_timestamp
        expected_event_resp = []
        for event, event_source in [event_file1, event_file2, event_file3, event_file4]:
            self.deal_data.set_payload(event)
            update_event_payload_random_data(
                self.deal_data.payload, self.deal_data.dealRefId, event_source
            )

            status_code, post_resp, headers = self.deal_data.post_request(
                self.api_url,
                post_event_route,
            )
            if status_code != HTTPStatus.CREATED:
                raise Exception(
                    f"Response code is: {status_code} and the response message is: {post_resp}"
                )

            event_comp = f"DTC.EVENTS.{self.deal_data.eventId}"
            event_timestamp = get_deal_updated_timestamp(
                deal_ref_id=self.deal_data.dealRefId,
                deal_component=event_comp,
                updated_timestamp=previous_timestamp,
            )
            assert event_timestamp > previous_timestamp
            get_deal_component_details(self.deal_data.dealRefId, event_comp)
            previous_timestamp = event_timestamp

            # Add event to the list
            expected_event_resp.append(self.deal_data.payload)

        # Get Events
        get_resp, resp_headers = get_deal_events_with_count(
            api_url=self.api_url,
            service_api=self.deal_data,
            get_events_route=get_events_route,
            expected_event_count=4,
        )
        validate_deal_event_payload(expected_event_resp, get_resp)
        assert_headers(resp_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_get_multiple_events_using_event_source(
        self,
        assert_headers,
        key_data_route,
        post_event_route,
        get_events_route,
        get_deal_component_details,
        get_deal_updated_timestamp,
        key_data_test_data_dtc_record_single_key,
        validate_deal_event_payload,
        update_event_payload_random_data,
    ):
        event_file1 = (
            "events/unifi_internal_contract_documents_submitted_for_signing.json",
            "unifi",
        )
        event_file2 = ("events/unifi_internal_contract_booked.json", "unifi")

        self.deal_data.payload = key_data_test_data_dtc_record_single_key
        status_code, key_data_resp, headers = self.deal_data.post_request(
            self.api_url,
            key_data_route,
        )

        if status_code != HTTPStatus.CREATED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {key_data_resp}"
            )
        key_data_timestamp = get_deal_updated_timestamp(
            deal_ref_id=self.deal_data.dealRefId
        )

        # Post multiple events
        previous_timestamp = key_data_timestamp
        expected_event_resp = []
        for event, event_source in [event_file1, event_file2]:
            self.deal_data.set_payload(event)
            update_event_payload_random_data(
                self.deal_data.payload, self.deal_data.dealRefId, event_source
            )

            status_code, post_resp, headers = self.deal_data.post_request(
                self.api_url,
                post_event_route,
            )
            if status_code != HTTPStatus.CREATED:
                raise Exception(
                    f"Response code is: {status_code} and the response message is: {post_resp}"
                )

            event_comp = f"DTC.EVENTS.{self.deal_data.eventId}"
            event_timestamp = get_deal_updated_timestamp(
                deal_ref_id=self.deal_data.dealRefId,
                deal_component=event_comp,
                updated_timestamp=previous_timestamp,
            )
            assert event_timestamp > previous_timestamp
            get_deal_component_details(self.deal_data.dealRefId, event_comp)
            previous_timestamp = event_timestamp

            # Add event to the list
            expected_event_resp.append(self.deal_data.payload)

        # Get Events
        query_param = f"eventSource={self.deal_data.payload['eventSource']}"
        get_resp, resp_headers = get_deal_events_with_count(
            api_url=self.api_url,
            service_api=self.deal_data,
            get_events_route=get_events_route,
            query_param=query_param,
            expected_event_count=2,
        )

        validate_deal_event_payload(expected_event_resp, get_resp)
        assert_headers(resp_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_get_multiple_events_using_event_type(
        self,
        assert_headers,
        key_data_route,
        post_event_route,
        get_events_route,
        get_deal_component_details,
        get_deal_updated_timestamp,
        key_data_test_data_dtc_record_single_key,
        validate_deal_event_payload,
        update_event_payload_random_data,
    ):
        event_file1 = ("events/dr_internal_contract_failed_event.json", "dr")
        event_file2 = ("events/dr_internal_contract_successful_event.json", "dr")

        self.deal_data.payload = key_data_test_data_dtc_record_single_key
        status_code, key_data_resp, headers = self.deal_data.post_request(
            self.api_url,
            key_data_route,
        )

        if status_code != HTTPStatus.CREATED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {key_data_resp}"
            )
        key_data_timestamp = get_deal_updated_timestamp(
            deal_ref_id=self.deal_data.dealRefId
        )

        # Post multiple events
        previous_timestamp = key_data_timestamp
        expected_event_resp = []
        for event, event_source in [event_file1, event_file2]:
            self.deal_data.set_payload(event)
            update_event_payload_random_data(
                self.deal_data.payload, self.deal_data.dealRefId, event_source
            )

            status_code, post_resp, headers = self.deal_data.post_request(
                self.api_url,
                post_event_route,
            )
            if status_code != HTTPStatus.CREATED:
                raise Exception(
                    f"Response code is: {status_code} and the response message is: {post_resp}"
                )

            event_comp = f"DTC.EVENTS.{self.deal_data.eventId}"
            event_timestamp = get_deal_updated_timestamp(
                deal_ref_id=self.deal_data.dealRefId,
                deal_component=event_comp,
                updated_timestamp=previous_timestamp,
            )
            assert event_timestamp > previous_timestamp
            get_deal_component_details(self.deal_data.dealRefId, event_comp)
            previous_timestamp = event_timestamp

            # Add event to the list
            expected_event_resp.append(self.deal_data.payload)

        # Get Events
        query_param = f"eventType={self.deal_data.payload['eventType']}"
        get_resp, resp_headers = get_deal_events_with_count(
            api_url=self.api_url,
            service_api=self.deal_data,
            get_events_route=get_events_route,
            query_param=query_param,
            expected_event_count=2,
        )
        get_deal_component_details(self.deal_data.dealRefId, event_comp)

        validate_deal_event_payload(expected_event_resp, get_resp)
        assert_headers(resp_headers)

    @pytest.mark.prod
    @pytest.mark.smoke
    @pytest.mark.functional
    def test_get_single_events_from_multiple_using_query(
        self,
        assert_headers,
        key_data_route,
        post_event_route,
        get_events_route,
        get_deal_component_details,
        get_deal_updated_timestamp,
        key_data_test_data_dtc_record_single_key,
        validate_deal_event_payload,
        update_event_payload_random_data,
    ):
        event_file1 = ("events/fni_internal_credit_decision_approved.json", "unifi")
        event_file2 = ("events/fs_internal_credit_decision_counter.json", "unifi")
        event_file3 = ("events/fs_internal_credit_decision_declined.json", "unifi")

        self.deal_data.payload = key_data_test_data_dtc_record_single_key
        status_code, key_data_resp, headers = self.deal_data.post_request(
            self.api_url,
            key_data_route,
        )

        if status_code != HTTPStatus.CREATED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {key_data_resp}"
            )
        key_data_timestamp = get_deal_updated_timestamp(
            deal_ref_id=self.deal_data.dealRefId
        )

        # Post multiple events
        previous_timestamp = key_data_timestamp
        expected_event_resp = []
        for event, event_source in [event_file1, event_file2, event_file3]:
            self.deal_data.set_payload(event)
            update_event_payload_random_data(
                self.deal_data.payload, self.deal_data.dealRefId, event_source
            )

            status_code, post_resp, headers = self.deal_data.post_request(
                self.api_url,
                post_event_route,
            )
            if status_code != HTTPStatus.CREATED:
                raise Exception(
                    f"Response code is: {status_code} and the response message is: {post_resp}"
                )

            event_comp = f"DTC.EVENTS.{self.deal_data.eventId}"
            event_timestamp = get_deal_updated_timestamp(
                deal_ref_id=self.deal_data.dealRefId,
                deal_component=event_comp,
                updated_timestamp=previous_timestamp,
            )
            assert event_timestamp > previous_timestamp
            get_deal_component_details(self.deal_data.dealRefId, event_comp)
            previous_timestamp = event_timestamp

            # Add event to the list
            expected_event_resp.append(self.deal_data.payload)

        # Get Events
        query_param = f"eventSource={expected_event_resp[0]['eventSource']}&eventName={expected_event_resp[1]['eventName']}&eventType={expected_event_resp[2]['eventType']}"
        get_resp, resp_headers = get_deal_events_with_count(
            api_url=self.api_url,
            service_api=self.deal_data,
            get_events_route=get_events_route,
            query_param=query_param,
        )

        validate_deal_event_payload(expected_event_resp[1], get_resp)
        assert_headers(resp_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_get_zero_event_response(
        self,
        assert_headers,
        key_data_route,
        post_event_route,
        get_events_route,
        get_deal_updated_timestamp,
        key_data_test_data_dtc_record_single_key,
    ):

        self.deal_data.payload = key_data_test_data_dtc_record_single_key
        status_code, key_data_resp, headers = self.deal_data.post_request(
            self.api_url,
            key_data_route,
        )

        if status_code != HTTPStatus.CREATED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {key_data_resp}"
            )
        get_deal_updated_timestamp(deal_ref_id=self.deal_data.dealRefId)

        # Get Events
        get_resp, resp_headers = get_deal_events_with_count(
            api_url=self.api_url,
            service_api=self.deal_data,
            get_events_route=get_events_route,
            expected_status_code=HTTPStatus.NOT_FOUND,
            expected_event_count=0,
        )

        assert get_resp == []
        assert_headers(resp_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_get_event_missing_deal_ref_id(
        self,
        assert_headers,
        get_events_route,
        key_data_test_data_dtc_record_single_key,
        missing_reference_ids_response,
    ):

        # Get Events
        self.deal_data.dealRefId = ""
        get_resp, resp_headers = get_deal_events_with_count(
            api_url=self.api_url,
            service_api=self.deal_data,
            get_events_route=get_events_route,
            expected_status_code=HTTPStatus.BAD_REQUEST,
            expected_event_count=0,
        )
        assert get_resp == missing_reference_ids_response(field_list=["dealRefId"])
        assert_headers(resp_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_get_event_invalid_deal_ref_id(
        self,
        assert_headers,
        get_events_route,
        key_data_test_data_dtc_record_single_key,
        invalid_deal_ref_id_response,
    ):

        # Get Events
        self.deal_data.dealRefId = self.deal_data.generate_random_id(True)
        get_resp, resp_headers = get_deal_events_with_count(
            api_url=self.api_url,
            service_api=self.deal_data,
            get_events_route=get_events_route,
            expected_status_code=HTTPStatus.BAD_REQUEST,
            expected_event_count=0,
        )
        assert get_resp == invalid_deal_ref_id_response(self.deal_data.dealRefId)
        assert_headers(resp_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_get_event_invalid_query_pram(
        self,
        assert_headers,
        key_data_route,
        post_event_route,
        get_events_route,
        get_deal_updated_timestamp,
        key_data_test_data_dtc_record_single_key,
        invalid_query_parameters_response,
    ):

        self.deal_data.payload = key_data_test_data_dtc_record_single_key
        status_code, key_data_resp, headers = self.deal_data.post_request(
            self.api_url,
            key_data_route,
        )

        if status_code != HTTPStatus.CREATED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {key_data_resp}"
            )
        get_deal_updated_timestamp(deal_ref_id=self.deal_data.dealRefId)

        # Get Events
        query_param = "eventsource=unifi:Deals"
        get_resp, resp_headers = get_deal_events_with_count(
            api_url=self.api_url,
            service_api=self.deal_data,
            get_events_route=get_events_route,
            expected_status_code=HTTPStatus.BAD_REQUEST,
            expected_event_count=0,
            query_param=query_param,
        )
        assert get_resp == invalid_query_parameters_response(VALID_QUERY_PRAMS)
        assert_headers(resp_headers)
