# -*- coding: utf-8 -*-
import datetime
import json
import logging
import os
import random
import time
import uuid
from http import HTTPStatus

import dpath.util
import requests
import ulid
from common import settings
from jsonmerge import merge
from tests import config
from tests.config import (
    DEAL_IDS_TO_DELETE,
    ORIGIN_SECRET_MAPPING,
    ROUTE_MAPPING,
)
from tests.functional.key_data.config import KEY_DATA_MAPPING


log = logging.getLogger(__name__)


class ServiceAPI:
    def __init__(
        self,
        random_data_class=None,
        json_file=None,
        env=None,
        payload=None,
        request_type="ca",
    ):
        self.env = env
        self.payload = payload or {}
        self.request_type = request_type
        self.random_data_class = random_data_class
        self.status_code = 0
        self.dealRefId = 0
        self.creditAppId = 0
        self.new_creditAppId = 0
        self.leadRefId = 0
        self.cbRefId = 0
        self.contractRefId = 0
        self.eventId = 0
        self.sessionId = 0
        self.documentId = 0
        self.pageId = 0
        self.patch_payload = {}
        self.cb_report = []
        self.module_dir = os.path.dirname(__file__)
        if not self.payload and json_file:
            self.set_payload(json_file)

    def generate_s3_bucket_key(
        self,
        source_partner=None,
        partner_dealer_id=None,
        deal_ref_id=None,
        lender_id=None,
        event_id=None,
    ):
        """
        {sourcePartner}/{partnerDealerId}/{dealRefId}/CA/{lenderId}/{eventId}.json
        :return: s3 key for storage
        """
        source_partner = source_partner or "QAT"
        partner_dealer_id = partner_dealer_id or random.getrandbits(25)
        self.dealRefId = deal_ref_id or ulid.new().str
        lender_id = lender_id or "BOA"
        event_id = event_id or ulid.new().str
        return source_partner, partner_dealer_id, lender_id, event_id

    @staticmethod
    def generate_random_id(ulid_id=False):
        """
        This method would generate random ID or ulid id
        :return: Randomly generated ID
        """
        random_id = str(random.getrandbits(48))
        if ulid_id:
            random_id = ulid.new().str
        return random_id

    def get_headers(
        self,
        route_url,
        cb_post=False,
        decision_get=False,
        source_partner="",
        cust_header={},
    ):
        header = {
            "Content-Type": "application/json",
            "x-origin-secret": ORIGIN_SECRET_MAPPING.get(self.env),
            "X-CoxAuto-Correlation-Id": f"dealDataTest-{str(uuid.uuid4())}_SIMBRIDGE",
        }
        if cb_post:
            header["Credit-Bureau-Reference-Id"] = self.cbRefId
        if decision_get:
            header["Source-Partner"] = source_partner
        if cust_header:
            header.update(cust_header)

        return header

    def get_url(
        self,
        url,
        route_url,
        feature=None,
        file_type=None,
        query_param=None,
        dealer_id=None,
        lender_id=None,
        sqs_name=None,
        target_platform=None,
    ):
        route_mapping = ROUTE_MAPPING[route_url]
        url = url or route_mapping["api"][self.env]["url"]
        if route_mapping["api"]["api_name"] != "deal_data":
            url = route_mapping["api"][self.env]["url"]
        url = f"{url}{route_mapping.get('route')}"

        api_url = url.format(
            deal_ref_id=self.dealRefId,
            credit_app_id=self.creditAppId,
            lead_ref_id=self.leadRefId,
            contract_ref_id=self.contractRefId,
            app_cb_id=self.cbRefId,
            event_id=self.eventId,
            session_id=self.sessionId,
            page_id=self.pageId,
            document_id=self.documentId,
            dealer_id=dealer_id,
            lender_id=lender_id,
            feature=feature,
            file_type=file_type,
            sqs_name=sqs_name,
            target_platform=target_platform,
            deal_component="AHC.DECISION",
        )

        api_url = f"{api_url}?{query_param}" if query_param else api_url

        return api_url

    def set_payload(self, file_name, dataset=None):
        """
        Function will read given json file and set to payload
        :param file_name: json file name
        :param dataset: key with root element from the file. This is used for patch.
        :return: None
        """
        test_data_path = os.path.join(self.module_dir, "../test_data/")
        json_file = os.path.join(test_data_path, file_name)
        with open(json_file, "r") as test_file:
            if dataset:
                patch_payload = json.load(test_file)
                self.patch_payload[dataset] = patch_payload.get(dataset)
                self.payload[dataset] = patch_payload.get(dataset)
            else:
                self.payload = json.load(test_file)
            self.update_payload_with_random_data()

    def set_report_data(self, resp_key):
        """
        This method would get the credit bureau report data from test data file and update cb_report
        :param resp_key: credit bureau report key from test data file
        :return:
        """
        resp_file = "credit_bureau_response_test_data.json"
        dir_path = os.path.join(self.module_dir, "../test_data/credit_bureau")
        resp_file = os.path.join(dir_path, resp_file)
        with open(resp_file, "r") as resp_data:
            cb_resp = json.load(resp_data)
            self.cb_report = cb_resp["cb_reports_data"][resp_key]

    @staticmethod
    def append_report_data_to_payload(
        cb_payload, reports, cust_type, operation="replace_report"
    ):
        """
        Update payload with credit bureau report data or append the response to the payload
        :param cb_payload:
        :param reports:
        :param cust_type:
        :param operation: accept value 'replace_report' or 'append_report', or 'update_report'
        :return: cb_payload
        """

        cb_cust_type = ["applicant", "coApplicant"]

        if operation == "replace_report" and cust_type in cb_cust_type:
            cb_payload[cust_type]["reports"] = reports
        elif operation == "append_report":
            cb_payload[cust_type]["reports"].extend(reports)
        elif operation == "update_report":
            for count, item in enumerate(cb_payload[cust_type]["reports"]):
                for rep_item in reports:
                    if (
                        item["provider"] == rep_item["provider"]
                        and item["type"] == rep_item["type"]
                    ):
                        cb_payload[cust_type]["reports"][count] = rep_item

        else:
            raise Exception(
                f"provided {cust_type} is not supported by credit bureau or is not valid for this request"
            )

        cb_report = cb_payload[cust_type]["reports"]

        return cb_payload, cb_report

    def update_payload_with_random_data(self):
        """
        This function will update customer details will replace with faker data
        :return: None
        """
        try:
            applicant = self.payload.get("applicant")
            coapplicant = self.payload.get("coApplicant")
            guarantor = self.payload.get("guarantor")
            customers = []
            customers.append(applicant) if applicant else None
            customers.append(coapplicant) if coapplicant else None
            customers.append(guarantor) if guarantor else None
            for customer in customers:
                random_data = self.random_data_class()
                customer["firstName"] = random_data.first_name
                customer["lastName"] = random_data.last_name
                if customer.get("address"):
                    customer["address"]["line1"] = random_data.line1
                    if customer["address"].get("line2"):
                        customer["address"]["line2"] = customer["address"]["line2"]
                    customer["address"]["city"] = random_data.city
                    customer["address"]["state"] = random_data.state
                    customer["address"]["postalCode"] = random_data.zip_code
                if customer.get("protected"):
                    customer["protected"]["ssn"] = random_data.ssn
        except Exception as error:
            log.error(f"Error while generating random data: {error}")
            raise

    def post_request(
        self,
        url,
        route_url,
        cb_post=False,
        generate_id=True,
        cust_header={},
        lender_id=None,
        sqs_name=None,
    ):
        """
        Function to request post api with given payload and gets status code, response payload
        :return: status_code, resp_body, resp_headers
        """
        if generate_id:
            self.cbRefId = self.generate_random_id()

        headers = self.get_headers(
            route_url=route_url,
            cb_post=cb_post,
            cust_header=cust_header,
        )

        url = self.get_url(
            url=url, route_url=route_url, lender_id=lender_id, sqs_name=sqs_name
        )
        log.info(f"Post request url: {url}")
        try:
            tries = 0
            status_code = HTTPStatus.FORBIDDEN
            resp_body = None
            resp_headers = {}
            payload = (
                json.dumps(self.payload)
                if isinstance(self.payload, dict)
                else self.payload
            )
            api_status_code = [HTTPStatus.FORBIDDEN, HTTPStatus.BAD_GATEWAY]
            while status_code in api_status_code and tries < config.RETRY_COUNT:
                time.sleep(config.WAIT_WITH_RETRIES)
                tries = tries + 1
                response = requests.post(url, payload, headers=headers)
                status_code = response.status_code
                log.info(f"API Response Status Code: {status_code}")
                resp_body = json.loads(response.text)
                resp_headers = response.headers
                if status_code == HTTPStatus.CREATED:
                    if "dealRefId" in resp_body:
                        self.dealRefId = resp_body.get("dealRefId")
                        DEAL_IDS_TO_DELETE.append(self.dealRefId)
                    if "creditAppId" in resp_body:
                        self.creditAppId = resp_body.get("creditAppId")
                    elif "leadRefId" in resp_body:
                        self.leadRefId = resp_body.get("leadRefId")
                    elif "creditBureauRefId" in resp_body:
                        self.cbRefId = resp_body.get("creditBureauRefId")
                    elif "contractRefId" in resp_body:
                        self.contractRefId = resp_body.get("contractRefId")
                    elif "eventId" in resp_body:
                        self.eventId = resp_body.get("eventId")

        except Exception as error:
            log.error(f"Error while posting customer data, with response log: {error}")
            raise error
        return status_code, resp_body, resp_headers

    def put_request(
        self,
        url,
        route_url,
        # cb_post=False,
        # generate_id=True,
        cust_header={},
        # lender_id=None,
        # sqs_name=None,
    ):
        """
        Function to request put api with given payload and gets status code, response payload
        :return: status_code, resp_body, resp_headers
        """
        headers = self.get_headers(
            route_url=route_url,
            cust_header=cust_header,
        )

        url = self.get_url(url=url, route_url=route_url)
        log.info(f"Put request url: {url}")

        try:
            tries = 0
            status_code = HTTPStatus.FORBIDDEN
            resp_body = None
            resp_headers = {}
            payload = (
                json.dumps(self.payload)
                if isinstance(self.payload, dict)
                else self.payload
            )
            api_status_code = [HTTPStatus.FORBIDDEN, HTTPStatus.BAD_GATEWAY]
            while status_code in api_status_code and tries < config.RETRY_COUNT:
                time.sleep(config.WAIT_WITH_RETRIES)
                tries = tries + 1
                response = requests.put(url, payload, headers=headers)
                status_code = response.status_code
                log.info(f"API Response Status Code: {status_code}")
                resp_body = json.loads(response.text)
                resp_headers = response.headers
                if status_code == HTTPStatus.CREATED:
                    if "creditAppId" in resp_body:
                        self.new_creditAppId = resp_body.get("creditAppId")

        except Exception as error:
            log.error(f"Error while posting customer data, with response log: {error}")
            raise error
        return status_code, resp_body, resp_headers

    def patch(
        self,
        url,
        route_url,
        cust_header={},
        query_param=None,
        target_platform=None,
        cust_status_code=None,
        lender_id=None,
    ):
        """
        Function to request post api with given payload and gets status code, response payload
        :return: None
        """
        headers = self.get_headers(route_url=route_url)
        headers.update(cust_header)
        url = self.get_url(
            url=url,
            route_url=route_url,
            query_param=query_param,
            target_platform=target_platform,
            lender_id=lender_id,
        )
        payload = json.dumps(self.payload) if self.payload else self.payload
        log.info(f"Patch request url: {url}")
        try:
            tries = 0
            status_code = HTTPStatus.FORBIDDEN
            resp_body = None
            resp_headers = {}
            api_status_code = [
                HTTPStatus.NO_CONTENT,
                HTTPStatus.ACCEPTED,
                cust_status_code,
            ]
            while status_code not in api_status_code and tries < config.RETRY_COUNT:
                time.sleep(config.WAIT_WITH_RETRIES)
                tries = tries + 1
                response = requests.patch(url, payload, headers=headers)
                status_code = response.status_code
                log.info(f"API Response Status Code: {status_code}")
                if status_code != HTTPStatus.NO_CONTENT:
                    resp_body = json.loads(response.text)
                resp_headers = response.headers

        except Exception as error:
            log.error(f"Error while patching credit app, with response log: {error}")
            raise error
        return status_code, resp_body, resp_headers

    def get_request(
        self,
        url=None,
        route_url=None,
        headers=None,
        via_apic=False,
        dealer_id=None,
        feature=None,
        file_type="json",
        query_param=None,
        decision_get=False,
        source_partner=None,
        lender_id=None,
        cust_header={},
    ):
        """
        Method is to GET a deal from DynamoDb or snapshot from S3
        The method would return full deal get payload or snapshot payload
        In case of an error, like S3 bucket is down, we would receive an error
        payload in XML format which is being handle as well or any other error or payload in json
        :param url: full endpoint for the api
        :param route_url: route endpoint to hit a specific api
        :param headers: headers required to access the api
        :param via_apic: whether the get is via apic connect
        :param decision_get: decision get
        :param feature: feature for snapshot get - CA/LEAD, etc
        :param file_type: filed type of the snapshot - json/XML, etc. Default: json
        :param query_param: key data api url query string
        :param source_partner: Full lender decision souse partner
        :param dealer_id: Full lender decision partner dealer id
        :param lender_id: Full lender decision lender id
        :return: status_code, resp_body, resp_headers
        """
        headers = headers or self.get_headers(
            route_url=route_url,
            decision_get=decision_get,
            source_partner=source_partner,
            cust_header=cust_header,
        )
        if not via_apic:
            url = self.get_url(
                url=url,
                route_url=route_url,
                feature=feature,
                file_type=file_type,
                query_param=query_param,
                dealer_id=dealer_id,
                lender_id=lender_id,
            )
        else:
            url = f"{ROUTE_MAPPING[route_url].format(self.dealRefId)}"
        log.info(f"Request url for get deal from db: {url}")
        try:
            tries = 0
            status_code = HTTPStatus.FORBIDDEN
            resp_body = None
            resp_headers = {}
            api_status_code = [HTTPStatus.FORBIDDEN, HTTPStatus.BAD_GATEWAY]
            while status_code in api_status_code and tries < config.RETRY_COUNT:
                time.sleep(config.WAIT_WITH_RETRIES)
                tries = tries + 1
                if not via_apic:
                    response = requests.get(url, headers=headers)
                else:
                    response = requests.get(url)
                status_code = response.status_code
                log.info(f"API Response Status Code: {status_code}")
                # Handle error message from aws which is in XML format
                if response.text.startswith("<?xml"):
                    resp_body = response.text
                elif status_code == HTTPStatus.NO_CONTENT:
                    resp_headers = response.headers
                else:
                    resp_body = json.loads(response.text)
                    resp_headers = response.headers
        except Exception as error:
            raise error
        return status_code, resp_body, resp_headers

    def delete_request(
        self,
        url=None,
        route_url=None,
        headers=None,
    ):
        """
        Method is to DELETE a deal from DynamoDb
        :param url: full endpoint for the api
        :param route_url: route endpoint to hit a specific api
        :param headers: headers required to access the api
        :return: status_code, resp_body, resp_headers
        """
        headers = headers or self.get_headers(route_url=route_url)
        url = self.get_url(url=url, route_url=route_url)
        log.info(f"Request url for delete deal from db: {url}")
        try:
            tries = 0
            status_code = HTTPStatus.FORBIDDEN
            resp_body = None
            resp_headers = {}
            api_status_code = [HTTPStatus.FORBIDDEN, HTTPStatus.BAD_GATEWAY]
            while status_code in api_status_code and tries < config.RETRY_COUNT:
                time.sleep(config.WAIT_WITH_RETRIES)
                tries = tries + 1

                response = requests.delete(url, headers=headers)
                status_code = response.status_code

                log.info(f"API Response Status Code: {status_code}")

                if status_code != HTTPStatus.NO_CONTENT:
                    resp_body = json.loads(response.text)

                resp_headers = response.headers

        except Exception as error:
            raise error
        return status_code, resp_body, resp_headers

    def update_payload_with_bureau_key_data(
        self, event_payload, cb_payload=None, is_virtual=False
    ):
        event_payload["eventId"] = ulid.new().str
        if not self.cbRefId:
            self.dealRefId = ulid.new().str
            self.cbRefId = self.generate_random_id()
        event_payload["eventTransactionId"] = self.cbRefId
        event_payload["eventKeyData"]["dealRefId"] = self.dealRefId
        if is_virtual:
            self.cbRefId = event_payload["eventTransactionId"] = (
                f"{self.cbRefId}_TEST" if is_virtual else self.cbRefId
            )
        if cb_payload:
            event_payload["payload"] = cb_payload
        self.payload = json.dumps(event_payload)

    def mask_pii_fields_in_request_payload(self):
        """
        VSince PII data in response payload is masked,
        we would mask request payload to validate entire payload in once. 'XXXX'
        :return:
        """
        pii_fields = [
            "ssn",
            "dateOfBirth",
            "driversLicenseNumber",
            "driversLicenseState",
        ]
        applicant = self.payload.get("applicant")
        co_applicant = self.payload.get("coApplicant")
        for field in pii_fields:
            if field in applicant:
                applicant[field] = "XXXX"
            if co_applicant:
                if field in applicant:
                    co_applicant[field] = "XXXX"

    @staticmethod
    def get_decision_payload_from_virtual_endpoint(deal_ref_id):
        """
        This will call virtual_fd GET endpoint and retrieve posted payload details.
        :param deal_ref_id: Extracted from sample_credit_app payload.
        :return: response if virtual_fd GET retrieved it else None
        """
        tries = 0
        status_code = HTTPStatus.NOT_FOUND
        endpoint = f"{settings.SIMULATOR_GET}/{deal_ref_id}"
        log.info(f"Request url to get decision payload: {endpoint}")
        while status_code != HTTPStatus.OK and tries < config.RETRY_COUNT:
            time.sleep(config.WAIT_WITH_RETRIES)
            tries = tries + 1
            response = requests.get(endpoint)
            status_code = response.status_code
            log.info(f"API Response Status Code: {status_code}")
            if status_code == HTTPStatus.OK:
                resp_body = response.json()
                resp_headers = response.headers
                return resp_body, resp_headers

    @staticmethod
    def delete_data_from_virtual_endpoint(deal_ref_id):
        """
        This will call virtual_fd GET endpoint and retrieve posted payload details.
        :param deal_ref_id: Id to identify a record in simulator DB
        :return: Status Code
        """
        tries = 0
        status_code = HTTPStatus.FORBIDDEN
        endpoint = f"{settings.SIMULATOR_GET}/delete/{deal_ref_id}"
        log.info(f"Request url to delete virtual_fd data: {endpoint}")
        while status_code != HTTPStatus.NO_CONTENT and tries < config.RETRY_COUNT:
            time.sleep(config.WAIT_WITH_RETRIES)
            tries += 1
            response = requests.delete(endpoint)
            status_code = response.status_code
            log.info(f"API Response Status Code: {status_code}")
            return status_code

    def update_contract_payloads_with_ids(self, payload_type: str, ids_dict: dict):
        supported_type = ("credit_app", "contract")
        if payload_type not in supported_type:
            raise Exception(
                f"Unsupported payload type provided. Value payload types are: {supported_type}"
            )
        for i in self.payload.get("targetPlatforms"):
            if i.get("id") == "DTC":
                i["partyId"] = ids_dict["sourcePartnerDealerId"]

        if payload_type == "credit_app":
            for field in ids_dict.keys():
                self.payload[field] = ids_dict[field]

        elif payload_type == "contract":
            self.payload["sourcePartnerId"] = ids_dict.get("sourcePartnerId")
            self.payload["sourcePartnerDealerId"] = ids_dict.get(
                "sourcePartnerDealerId"
            )
            if self.payload["financeInformation"].get("dateOfFirstPayment"):
                self.payload["financeInformation"]["dateOfFirstPayment"] = (
                    datetime.datetime.today() + datetime.timedelta(weeks=1)
                ).strftime("%Y-%m-%d")
            if self.payload["financeInformation"].get("deferredDownPaymentDate"):
                self.payload["financeInformation"]["deferredDownPaymentDate"] = (
                    datetime.datetime.today() + datetime.timedelta(weeks=1)
                ).strftime("%Y-%m-%d")

    def update_event_payload_key_data(self, app_ids_dict: dict):
        self.payload["eventId"] = str(uuid.uuid4())
        self.payload["eventIdentityId"] = str(uuid.uuid4())
        self.payload["eventTime"] = time.strftime("%Y-%m-%dT%H:%M:%S")
        self.payload["eventKeyData"]["sourcePartnerId"] = app_ids_dict.get(
            "sourcePartnerId"
        )
        self.payload["eventKeyData"]["sourcePartnerDealerId"] = app_ids_dict.get(
            "sourcePartnerDealerId"
        )
        self.payload["eventKeyData"]["dealerCode"] = app_ids_dict.get("dealerCode")
        self.payload["eventKeyData"]["leadRefIdFD"] = app_ids_dict.get("dealRefIdFD")
        self.payload["eventKeyData"]["appRefIdFD"] = app_ids_dict.get("appRefIdFD")
        self.payload["eventKeyData"]["lenderId"] = app_ids_dict.get("lenderId")
        self.payload["eventKeyData"]["dealJacketId"] = app_ids_dict.get(
            "dealJacketId"
        )  # uniFI DJ ID
        self.payload["eventTransactionId"] = app_ids_dict.get(
            "dealRefIdFI"
        )  # uniFI dealRefId
        self.payload["eventKeyData"]["dealRefId"] = app_ids_dict.get(
            "dealRefIdFI"
        )  # uniFI dealRefId
        self.payload["eventKeyData"]["creditAppId"] = str(
            random.getrandbits(48)
        )  # uniFI credit app Id short
        self.payload["eventKeyData"]["dealJacketId"] = app_ids_dict.get("dealJacketId")
        self.payload["eventKeyData"]["dealId"] = app_ids_dict.get(
            "dealIdFI"
        )  # uniFI Deal ID

    @staticmethod
    def merge_payloads_and_remove_pii(posted_payload, updated_payload):
        """
        Method to merge two json payloads into one.
        Extract pii fields out of protected node
        :param posted_payload:payload one or the original payload or base payload
        :param updated_payload: new payload or the secondary payload
        :return: return two merged payloads
        """
        # Merge posted and updated payloads
        updated_payload = merge(posted_payload, updated_payload)

        # Validate Credit App request and response payloads
        app_pii = updated_payload["applicant"].get("protected")
        coapp_pii = updated_payload.get("coApplicant", {}).get("protected")
        if app_pii:
            for field in app_pii:
                updated_payload["applicant"][field] = updated_payload["applicant"][
                    "protected"
                ][field]
        if coapp_pii:
            for field in coapp_pii:
                updated_payload["coApplicant"][field] = updated_payload["coApplicant"][
                    "protected"
                ][field]
        return updated_payload

    @staticmethod
    def remove_key_from_json_obj(payload, fields_list):
        """
        Remove/delete key/obj from json payload
        :param payload: json payload
        :param fields_list: list of json path to be deleted
        :return: updated payload
        """
        for field in fields_list:
            dpath.util.delete(payload, glob=field, separator=".")
        return payload

    def update_key_data_fields_mapping(self):
        """
        Update key-data fields mapping between API and DB names
        :return: Update payload with DB field name
        """
        payload_target = self.payload.get("targetPlatformId", "DTC")
        dta_mapping = KEY_DATA_MAPPING["DTA"]
        mapped_obj = {**KEY_DATA_MAPPING[payload_target], **dta_mapping}

        self.payload.pop("targetPlatformId", None)
        for field in list(self.payload):
            self.payload[mapped_obj[field]] = self.payload.pop(field)
