# -*- coding: utf-8 -*-
import pytest
import ulid
from common.settings import DealComponent


@pytest.fixture
def validate_deal_component_session_docs():
    def wrapper(deal_component):
        ulid_id = deal_component.split(".")[3]
        assert (
            deal_component.startswith(DealComponent.DTC_DOCS_UPLOAD)
            and ulid.parse(ulid_id) == ulid_id
        )

    return wrapper


@pytest.fixture
def validate_deal_component_single_docs():
    def wrapper(document_type, customer_role):
        document_type = document_type.upper()
        applicant_types = {"Applicant": "APP", "Coapplicant": "COAPP", "Generic": "GEN"}
        app_type_key = applicant_types[customer_role]
        return f"{DealComponent.DTC_DOCS}.{app_type_key}.{document_type}"

    return wrapper
