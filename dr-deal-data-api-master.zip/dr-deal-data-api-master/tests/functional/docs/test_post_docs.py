# -*- coding: utf-8 -*-
from http import HTTPStatus

import pytest
from common.settings import DOCS_CUSTOMER_TYPES
from tests.functional.service_api import ServiceAPI
from tests.unit.docs.conftest import SESSION_DOC, SINGLE_DOC


KEY_DATA_ROUTER = "key_data"
POST_DOCUMENT_ROUTE = "post_document"
GET_SESSION_ROUTE = "get_session"
GET_SINGLE_DOC_ROUTE = "get_single_document"
GET_DOCS_ROUTE = "get_documents"

DOCS_APP_COMPONENT = "DTC.DOCS.APP.DRIVERSLICENSE"


@pytest.mark.prod
@pytest.mark.smoke
@pytest.mark.functional
def test_post_document(
    env,
    api_url,
    assert_headers,
    post_doc_headers,
    post_doc_payload,
    get_deal_updated_timestamp,
    validate_deal_component_single_docs,
    key_data_test_data_dtc_record_single_key,
):

    deal_data = ServiceAPI(env=env)

    deal_data.payload = key_data_test_data_dtc_record_single_key

    status_code, key_data_resp, headers = deal_data.post_request(
        api_url, KEY_DATA_ROUTER
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {key_data_resp}"
        )
    key_data_timestamp = get_deal_updated_timestamp(deal_ref_id=deal_data.dealRefId)

    deal_data.payload = post_doc_payload

    custom_headers = post_doc_headers(SINGLE_DOC)

    post_status_code, post_resp, post_headers = deal_data.post_request(
        api_url, POST_DOCUMENT_ROUTE, cust_header=custom_headers
    )

    assert post_status_code == HTTPStatus.CREATED
    assert post_resp["dealRefId"] == deal_data.dealRefId
    assert "documentId" in post_resp
    assert_headers(resp_headers=post_headers)

    doc_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId,
        deal_component=DOCS_APP_COMPONENT,
        updated_timestamp=key_data_timestamp,
    )
    assert doc_timestamp > key_data_timestamp

    deal_data.payload = {}
    deal_data.documentId = post_resp["dealComponent"]

    get_status_code, get_resp, get_resp_headers = deal_data.get_request(
        url=api_url, route_url=GET_SINGLE_DOC_ROUTE
    )

    assert get_status_code == HTTPStatus.OK
    assert get_resp[0]["dealComponent"] == validate_deal_component_single_docs(
        post_doc_payload["documentType"], post_doc_payload["customerRole"]
    )
    assert "pages" not in get_resp[0]


@pytest.mark.smoke
@pytest.mark.functional
def test_post_docs_invalid_deal_ref(
    env,
    api_url,
    key_data_test_data_dtc_record_single_key,
    assert_headers,
    post_doc_headers,
    post_doc_payload,
    invalid_deal_ref_id_response,
):

    deal_data = ServiceAPI(env=env)

    deal_data.payload = post_doc_payload
    deal_data.dealRefId = deal_data.generate_random_id(ulid_id=True)

    custom_headers = post_doc_headers(SESSION_DOC)

    post_status_code, post_resp, post_headers = deal_data.post_request(
        api_url, POST_DOCUMENT_ROUTE, cust_header=custom_headers
    )

    assert post_status_code == HTTPStatus.BAD_REQUEST
    assert post_resp == invalid_deal_ref_id_response(deal_data.dealRefId)
    assert_headers(resp_headers=post_headers)


@pytest.mark.smoke
@pytest.mark.functional
def test_post_docs_missing_body_fields(
    env,
    api_url,
    key_data_test_data_dtc_record_single_key,
    assert_headers,
    post_doc_headers,
    post_doc_payload,
    get_deal_updated_timestamp,
    missing_body_fields_docs_resp,
):

    deal_data = ServiceAPI(env=env)

    deal_data.payload = key_data_test_data_dtc_record_single_key

    status_code, key_data_resp, headers = deal_data.post_request(
        api_url,
        KEY_DATA_ROUTER,
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {key_data_resp}"
        )
    get_deal_updated_timestamp(deal_ref_id=deal_data.dealRefId)
    deal_data.payload = post_doc_payload
    deal_data.payload.pop("documentType")

    custom_headers = post_doc_headers(SINGLE_DOC)

    post_status_code, post_resp, post_headers = deal_data.post_request(
        api_url, POST_DOCUMENT_ROUTE, cust_header=custom_headers
    )

    assert post_status_code == HTTPStatus.BAD_REQUEST
    assert post_resp == missing_body_fields_docs_resp(
        ["documentType", "customerRole", "uploadStatus"]
    )
    assert_headers(resp_headers=post_headers)


@pytest.mark.smoke
@pytest.mark.functional
def test_post_docs_duplicate_resource(
    env,
    api_url,
    key_data_test_data_dtc_record_single_key,
    assert_headers,
    post_doc_headers,
    post_doc_payload,
    validate_deal_component_single_docs,
    payload_signing_coordinates,
    get_deal_updated_timestamp,
    post_duplicate_document_resp,
):

    deal_data = ServiceAPI(env=env)

    deal_data.payload = key_data_test_data_dtc_record_single_key

    status_code, key_data_resp, headers = deal_data.post_request(
        api_url, KEY_DATA_ROUTER
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {key_data_resp}"
        )
    key_data_timestamp = get_deal_updated_timestamp(deal_ref_id=deal_data.dealRefId)
    deal_data.payload = post_doc_payload

    custom_headers = post_doc_headers(SINGLE_DOC)

    post_status_code, post_resp, post_headers = deal_data.post_request(
        api_url, POST_DOCUMENT_ROUTE, cust_header=custom_headers
    )

    assert post_status_code == HTTPStatus.CREATED
    assert_headers(resp_headers=post_headers)
    doc_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId,
        deal_component=DOCS_APP_COMPONENT,
        updated_timestamp=key_data_timestamp,
    )
    assert doc_timestamp > key_data_timestamp

    # Try to post the same document twice
    post_status_code, post_resp, post_headers = deal_data.post_request(
        api_url, POST_DOCUMENT_ROUTE, cust_header=custom_headers
    )

    assert post_status_code == HTTPStatus.BAD_REQUEST
    assert post_resp == post_duplicate_document_resp

    deal_data.payload = {}

    get_status_code, get_resp, get_resp_headers = deal_data.get_request(
        url=api_url, route_url=GET_DOCS_ROUTE
    )

    assert get_status_code == HTTPStatus.OK
    assert len(get_resp) == 1


@pytest.mark.prod
@pytest.mark.smoke
@pytest.mark.functional
def test_post_docs_invalid_customer_role(
    env,
    api_url,
    key_data_test_data_dtc_record_single_key,
    post_doc_headers,
    post_doc_payload,
    get_deal_updated_timestamp,
    invalid_customer_role_docs_resp,
):

    deal_data = ServiceAPI(env=env)

    deal_data.payload = key_data_test_data_dtc_record_single_key

    status_code, key_data_resp, headers = deal_data.post_request(
        api_url, KEY_DATA_ROUTER
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {key_data_resp}"
        )
    get_deal_updated_timestamp(deal_ref_id=deal_data.dealRefId)
    deal_data.payload = post_doc_payload
    deal_data.payload["customerRole"] = "Invalid"

    custom_headers = post_doc_headers(SESSION_DOC)

    post_status_code, post_resp, post_headers = deal_data.post_request(
        api_url, POST_DOCUMENT_ROUTE, cust_header=custom_headers
    )

    assert post_status_code == HTTPStatus.BAD_REQUEST
    assert post_resp == invalid_customer_role_docs_resp(
        list(DOCS_CUSTOMER_TYPES.keys())
    )


@pytest.mark.prod
@pytest.mark.smoke
@pytest.mark.functional
def test_post_session(
    env,
    api_url,
    key_data_test_data_dtc_record_single_key,
    assert_headers,
    post_doc_headers,
    post_doc_payload,
    get_deal_updated_timestamp,
    validate_deal_component_session_docs,
):

    deal_data = ServiceAPI(env=env)

    deal_data.payload = key_data_test_data_dtc_record_single_key

    status_code, key_data_resp, headers = deal_data.post_request(
        api_url, KEY_DATA_ROUTER
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {key_data_resp}"
        )
    key_data_timestamp = get_deal_updated_timestamp(deal_ref_id=deal_data.dealRefId)
    deal_data.payload = post_doc_payload

    custom_headers = post_doc_headers(SESSION_DOC)

    post_status_code, post_resp, post_headers = deal_data.post_request(
        api_url, POST_DOCUMENT_ROUTE, cust_header=custom_headers
    )

    assert post_status_code == HTTPStatus.CREATED
    assert post_resp["dealRefId"] == deal_data.dealRefId
    assert "documentId" in post_resp
    assert "sessionId" in post_resp
    assert_headers(resp_headers=post_headers)
    doc_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId,
        deal_component=DOCS_APP_COMPONENT,
        updated_timestamp=key_data_timestamp,
    )
    assert doc_timestamp > key_data_timestamp

    deal_data.payload = {}
    session_id = post_resp["sessionId"]

    deal_data.sessionId = f"DTC.DOCS.UPLOADS.{session_id}"

    get_status_code, get_resp, get_resp_headers = deal_data.get_request(
        url=api_url, route_url=GET_SESSION_ROUTE
    )

    assert get_status_code == HTTPStatus.OK
    assert len(get_resp) == 1
    assert "pages" in get_resp[0]
    assert len(get_resp[0]["pages"]) == int(custom_headers["pageCount"])

    validate_deal_component_session_docs(get_resp[0]["dealComponent"])

    deal_data.payload = {}
    deal_data.sessionId = None

    get_status_code, get_resp, get_resp_headers = deal_data.get_request(
        url=api_url, route_url=GET_DOCS_ROUTE
    )

    assert get_status_code == HTTPStatus.OK
    assert len(get_resp) == 2


@pytest.mark.prod
@pytest.mark.smoke
@pytest.mark.functional
def test_post_document_already_exists(
    env,
    api_url,
    key_data_test_data_dtc_record_single_key,
    assert_headers,
    post_doc_headers,
    post_doc_payload,
    get_deal_updated_timestamp,
    validate_deal_component_session_docs,
):

    deal_data = ServiceAPI(env=env)

    deal_data.payload = key_data_test_data_dtc_record_single_key

    status_code, key_data_resp, headers = deal_data.post_request(
        api_url,
        KEY_DATA_ROUTER,
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {key_data_resp}"
        )

    key_data_timestamp = get_deal_updated_timestamp(deal_ref_id=deal_data.dealRefId)
    deal_data.payload = post_doc_payload

    custom_headers = post_doc_headers(SINGLE_DOC)

    post_status_code, post_resp, post_headers = deal_data.post_request(
        api_url, POST_DOCUMENT_ROUTE, cust_header=custom_headers
    )

    assert post_status_code == HTTPStatus.CREATED
    assert post_resp["dealRefId"] == deal_data.dealRefId
    assert "documentId" in post_resp
    assert "sessionId" not in post_resp
    assert_headers(resp_headers=post_headers)
    doc_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId,
        deal_component=DOCS_APP_COMPONENT,
        updated_timestamp=key_data_timestamp,
    )
    assert doc_timestamp > key_data_timestamp

    custom_headers = post_doc_headers(SESSION_DOC)

    # Send same payload again, this should create a new session record
    post_status_code, post_resp, post_headers = deal_data.post_request(
        api_url, POST_DOCUMENT_ROUTE, cust_header=custom_headers
    )

    assert post_status_code == HTTPStatus.CREATED
    assert post_resp["dealRefId"] == deal_data.dealRefId
    assert "documentId" in post_resp
    assert "sessionId" in post_resp
    assert_headers(resp_headers=post_headers)

    deal_data.payload = {}
    session_id = post_resp["sessionId"]
    deal_data.sessionId = f"DTC.DOCS.UPLOADS.{session_id}"

    get_status_code, get_resp, get_resp_headers = deal_data.get_request(
        url=api_url, route_url=GET_SESSION_ROUTE
    )
    assert get_status_code == HTTPStatus.OK
    assert len(get_resp) == 1

    assert "pages" in get_resp[0]
    validate_deal_component_session_docs(get_resp[0]["dealComponent"])

    deal_data.payload = {}
    deal_data.sessionId = None

    get_status_code, get_resp, get_resp_headers = deal_data.get_request(
        url=api_url, route_url=GET_DOCS_ROUTE
    )

    assert get_status_code == HTTPStatus.OK
    assert len(get_resp) == 2


@pytest.mark.smoke
@pytest.mark.functional
def test_post_session_invalid_page_count(
    env,
    api_url,
    key_data_test_data_dtc_record_single_key,
    post_doc_headers,
    post_doc_payload,
    get_deal_updated_timestamp,
    invalid_page_count_docs_resp,
):

    deal_data = ServiceAPI(env=env)

    deal_data.payload = key_data_test_data_dtc_record_single_key

    status_code, key_data_resp, headers = deal_data.post_request(
        api_url, KEY_DATA_ROUTER
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {key_data_resp}"
        )
    get_deal_updated_timestamp(deal_ref_id=deal_data.dealRefId)
    deal_data.payload = post_doc_payload

    custom_headers = post_doc_headers(SESSION_DOC)
    custom_headers["pageCount"] = "five"

    post_status_code, post_resp, post_headers = deal_data.post_request(
        api_url, POST_DOCUMENT_ROUTE, cust_header=custom_headers
    )

    assert post_status_code == HTTPStatus.BAD_REQUEST
    assert post_resp == invalid_page_count_docs_resp
