# -*- coding: utf-8 -*-
from http import HTTPStatus

import pytest
from tests.functional.service_api import ServiceAPI
from tests.unit.docs.conftest import SESSION_DOC


GET_SINGLE_DOC_ROUTE = "get_single_document"
GET_SESSION_ROUTE = "get_session"
KEY_DATA_ROUTER = "key_data"
PATCH_DOCUMENT_ROUTE = "patch_document"
POST_DOCUMENT_ROUTE = "post_document"
PATCH_SESSION_ROUTE = "patch_session"
PATCH_SESSION_PAGE_ROUTE = "patch_session_page"

DOCS_FILE_NAME = [
    ("docs_single_document_insurance.json"),
    ("docs_single_document_drivers_license.json"),
    ("docs_single_document_w2.json"),
]

DOCS_SESSION_FILE_NAMES = [
    ("docs_single_session.json"),
]


@pytest.mark.prod
@pytest.mark.smoke
@pytest.mark.functional
@pytest.mark.parametrize("docs_file", DOCS_FILE_NAME)
def test_patch_document(
    api_url,
    docs_file,
    env,
    get_deal_updated_timestamp,
    key_data_test_data_dtc_record_single_key,
):
    docs_file = f"docs/{docs_file}"
    deal_data = ServiceAPI(env=env)

    deal_data.payload = key_data_test_data_dtc_record_single_key

    status_code, key_data_resp, headers = deal_data.post_request(
        api_url, KEY_DATA_ROUTER
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {key_data_resp}"
        )
    key_data_timestamp = get_deal_updated_timestamp(deal_ref_id=deal_data.dealRefId)
    deal_data.set_payload(docs_file)
    deal_data.payload["dealRefId"] = deal_data.dealRefId

    status_code, post_resp, headers = deal_data.post_request(
        api_url, POST_DOCUMENT_ROUTE
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {post_resp}"
        )

    doc_comp_id = deal_data.payload["dealComponent"]
    doc_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId,
        deal_component=doc_comp_id,
        updated_timestamp=key_data_timestamp,
    )
    assert doc_timestamp > key_data_timestamp

    inbound_customer_role = deal_data.payload["customerRole"]
    deal_data.payload = {}
    deal_data.payload = {"customerRole": "Unknown"}

    deal_data.documentId = doc_comp_id

    patch_status_code, patch_resp, resp_headers = deal_data.patch(
        url=api_url,
        route_url=PATCH_DOCUMENT_ROUTE,
        cust_status_code=HTTPStatus.NO_CONTENT,
    )
    assert patch_status_code == HTTPStatus.NO_CONTENT
    patch_doc_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId,
        deal_component=doc_comp_id,
        updated_timestamp=doc_timestamp,
    )
    assert patch_doc_timestamp > doc_timestamp

    deal_data.payload = {
        "documentId": "GEN.INSURANCECARD",
        "dealRefId": deal_data.dealRefId,
    }

    get_status_code, check_get_resp, get_resp_headers = deal_data.get_request(
        url=api_url, route_url=GET_SINGLE_DOC_ROUTE
    )

    assert get_status_code == HTTPStatus.OK
    assert check_get_resp[0]["customerRole"] != inbound_customer_role
    assert len(check_get_resp) == 1


@pytest.mark.prod
@pytest.mark.smoke
@pytest.mark.functional
@pytest.mark.parametrize("docs_file", DOCS_FILE_NAME)
def test_patch_document_invalid_deal_ref_id(
    api_url, docs_file, env, generate_random_id, invalid_deal_ref_id_response
):
    deal_data = ServiceAPI(env=env)
    deal_data.dealRefId = generate_random_id

    deal_data.payload = {"customerRole": "Unknown"}
    deal_data.documentId = generate_random_id

    patch_status_code, patch_resp, resp_headers = deal_data.patch(
        url=api_url,
        route_url=PATCH_DOCUMENT_ROUTE,
        cust_status_code=HTTPStatus.BAD_REQUEST,
    )

    assert patch_status_code == HTTPStatus.BAD_REQUEST
    assert patch_resp == invalid_deal_ref_id_response(deal_data.dealRefId)


@pytest.mark.prod
@pytest.mark.smoke
@pytest.mark.functional
@pytest.mark.parametrize("docs_file", DOCS_FILE_NAME)
def test_patch_document_empty_body(
    api_url, docs_file, env, generate_random_id, missing_payload_response
):
    deal_data = ServiceAPI(env=env)
    deal_data.payload = {}
    deal_data.documentId = generate_random_id
    deal_data.dealRefId = generate_random_id

    patch_status_code, patch_resp, resp_headers = deal_data.patch(
        url=api_url,
        route_url=PATCH_DOCUMENT_ROUTE,
        cust_status_code=HTTPStatus.BAD_REQUEST,
    )

    assert patch_status_code == HTTPStatus.BAD_REQUEST
    assert patch_resp == missing_payload_response


@pytest.mark.prod
@pytest.mark.smoke
@pytest.mark.functional
@pytest.mark.parametrize("docs_file", DOCS_SESSION_FILE_NAMES)
def test_patch_session_success(
    api_url,
    docs_file,
    env,
    get_deal_updated_timestamp,
    key_data_test_data_dtc_record_single_key,
):
    docs_file = f"docs/{docs_file}"
    deal_data = ServiceAPI(env=env)

    deal_data.payload = key_data_test_data_dtc_record_single_key

    status_code, key_data_resp, headers = deal_data.post_request(
        api_url, KEY_DATA_ROUTER
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {key_data_resp}"
        )
    key_data_timestamp = get_deal_updated_timestamp(deal_ref_id=deal_data.dealRefId)

    deal_data.set_payload(docs_file)
    deal_data.payload["dealRefId"] = deal_data.dealRefId

    status_code, post_resp, headers = deal_data.post_request(
        api_url, POST_DOCUMENT_ROUTE, cust_header={"pageCount": "2"}
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {post_resp}"
        )

    inbound_customer_role = deal_data.payload["customerRole"]
    session_id = post_resp["sessionId"]
    doc_comp_id = f"{deal_data.payload['dealComponent']}{session_id}"
    doc_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId,
        deal_component=doc_comp_id,
        updated_timestamp=key_data_timestamp,
    )
    assert doc_timestamp > key_data_timestamp

    deal_data.payload = {"customerRole": "Unknown"}
    deal_data.sessionId = f"DTC.DOCS.UPLOADS.{session_id}"

    deal_data.dealRefId = deal_data.dealRefId

    patch_status_code, patch_resp, resp_headers = deal_data.patch(
        url=api_url,
        route_url=PATCH_SESSION_ROUTE,
        cust_status_code=HTTPStatus.NO_CONTENT,
    )
    assert patch_status_code == HTTPStatus.NO_CONTENT
    update_doc_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId,
        deal_component=doc_comp_id,
        updated_timestamp=doc_timestamp,
    )
    assert update_doc_timestamp > doc_timestamp

    deal_data.payload = {}

    get_status_code, check_get_resp, get_resp_headers = deal_data.get_request(
        url=api_url, route_url=GET_SESSION_ROUTE
    )

    assert get_status_code == HTTPStatus.OK
    assert check_get_resp[0]["customerRole"] != inbound_customer_role
    assert len(check_get_resp) == 1


@pytest.mark.prod
@pytest.mark.smoke
@pytest.mark.functional
@pytest.mark.parametrize("docs_file", DOCS_SESSION_FILE_NAMES)
def test_patch_session_invalid_deal_ref_id(
    api_url, docs_file, env, generate_random_id, invalid_deal_ref_id_response
):
    deal_data = ServiceAPI(env=env)
    deal_data.dealRefId = generate_random_id
    deal_data.sessionId = generate_random_id

    deal_data.payload = {"customerRole": "Unknown"}

    patch_status_code, patch_resp, resp_headers = deal_data.patch(
        url=api_url,
        route_url=PATCH_SESSION_ROUTE,
        cust_status_code=HTTPStatus.BAD_REQUEST,
    )

    assert patch_status_code == HTTPStatus.BAD_REQUEST
    assert patch_resp == invalid_deal_ref_id_response(deal_data.dealRefId)


@pytest.mark.prod
@pytest.mark.smoke
@pytest.mark.functional
@pytest.mark.parametrize("docs_file", DOCS_SESSION_FILE_NAMES)
def test_patch_session_no_resources(
    api_url,
    docs_file,
    env,
    generate_random_id,
    get_deal_updated_timestamp,
    key_data_test_data_dtc_record_single_key,
    no_resources_found_response,
):
    deal_data = ServiceAPI(env=env)

    deal_data.payload = key_data_test_data_dtc_record_single_key
    status_code, key_data_resp, headers = deal_data.post_request(
        api_url, KEY_DATA_ROUTER
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {key_data_resp}"
        )
    get_deal_updated_timestamp(deal_ref_id=deal_data.dealRefId)
    session_id = generate_random_id

    deal_data.payload = {"customerRole": "Unknown"}
    deal_data.sessionId = session_id

    patch_status_code, patch_resp, resp_headers = deal_data.patch(
        url=api_url,
        route_url=PATCH_SESSION_ROUTE,
        cust_status_code=HTTPStatus.BAD_REQUEST,
    )

    assert patch_status_code == HTTPStatus.BAD_REQUEST
    assert patch_resp == no_resources_found_response(
        deal_data.dealRefId, field="sessionId", value=session_id
    )


@pytest.mark.prod
@pytest.mark.smoke
@pytest.mark.functional
def test_patch_session_page_success(
    api_url,
    assert_headers,
    env,
    get_deal_updated_timestamp,
    key_data_test_data_dtc_record_single_key,
    post_doc_headers,
    post_doc_payload,
):
    deal_data = ServiceAPI(env=env)

    deal_data.payload = key_data_test_data_dtc_record_single_key

    status_code, key_data_resp, headers = deal_data.post_request(
        api_url, KEY_DATA_ROUTER
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {key_data_resp}"
        )
    key_data_timestamp = get_deal_updated_timestamp(deal_ref_id=deal_data.dealRefId)
    custom_headers = post_doc_headers(SESSION_DOC)
    deal_data.payload = post_doc_payload

    post_status_code, post_resp, post_headers = deal_data.post_request(
        api_url, POST_DOCUMENT_ROUTE, cust_header=custom_headers
    )

    assert post_status_code == HTTPStatus.CREATED
    assert post_resp["dealRefId"] == deal_data.dealRefId
    assert "documentId" in post_resp
    assert_headers(resp_headers=post_headers)
    doc_comp_id = f"DTC.DOCS.UPLOADS.{post_resp['sessionId']}"
    doc_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId,
        deal_component=doc_comp_id,
        updated_timestamp=key_data_timestamp,
    )
    assert doc_timestamp > key_data_timestamp

    session_id = post_resp["sessionId"]

    # path params
    deal_data.sessionId = f"DTC.DOCS.UPLOADS.{session_id}"

    deal_data.pageId = "1"
    deal_data.payload = {"status": "Complete", "location": "/DOCS/file.jpg"}

    patch_status_code, patch_resp, resp_headers = deal_data.patch(
        url=api_url,
        route_url=PATCH_SESSION_PAGE_ROUTE,
        cust_status_code=HTTPStatus.NO_CONTENT,
    )
    assert patch_status_code == HTTPStatus.NO_CONTENT
    patch_doc_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId,
        deal_component=doc_comp_id,
        updated_timestamp=doc_timestamp,
    )
    assert patch_doc_timestamp > doc_timestamp

    deal_data.payload = {}

    get_status_code, check_get_resp, get_resp_headers = deal_data.get_request(
        url=api_url, route_url=GET_SESSION_ROUTE
    )

    assert get_status_code == HTTPStatus.OK
    assert check_get_resp[0]["pages"][deal_data.pageId]["status"] == "Complete"
    assert check_get_resp[0]["pages"][deal_data.pageId]["location"] == "/DOCS/file.jpg"
    assert len(check_get_resp) == 1
