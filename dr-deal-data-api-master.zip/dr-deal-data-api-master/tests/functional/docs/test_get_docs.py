# -*- coding: utf-8 -*-
from http import HTTPStatus

import pytest
from common.settings import GET_DOCS_FILTER_PARAMS
from tests.functional.service_api import ServiceAPI


GET_SINGLE_DOC_ROUTE = "get_single_document"
GET_DOCS_ROUTE = "get_documents"
POST_DOCS_ROUTE = "post_document"
GET_SESSION_ROUTE = "get_session"
KEY_DATA_ROUTER = "key_data"

DOCS_FILE_NAME = [
    ("docs_single_document_insurance.json"),
    ("docs_single_document_drivers_license.json"),
    ("docs_single_document_w2.json"),
]

DOCS_SESSION_FILE_NAMES = [
    ("docs_single_session.json"),
]


@pytest.mark.prod
@pytest.mark.smoke
@pytest.mark.functional
@pytest.mark.parametrize("docs_file", DOCS_FILE_NAME)
def test_get_single_document(
    env,
    api_url,
    docs_file,
    assert_headers,
    get_deal_updated_timestamp,
    key_data_test_data_dtc_record_single_key,
):
    docs_file = f"docs/{docs_file}"
    deal_data = ServiceAPI(env=env)

    deal_data.payload = key_data_test_data_dtc_record_single_key

    status_code, key_data_resp, headers = deal_data.post_request(
        api_url, KEY_DATA_ROUTER
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {key_data_resp}"
        )
    key_data_timestamp = get_deal_updated_timestamp(deal_ref_id=deal_data.dealRefId)

    deal_data.set_payload(docs_file)
    deal_data.payload["dealRefId"] = deal_data.dealRefId

    status_code, post_resp, headers = deal_data.post_request(api_url, POST_DOCS_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {post_resp}"
        )
    doc_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId,
        deal_component=deal_data.payload["dealComponent"],
        updated_timestamp=key_data_timestamp,
    )
    assert doc_timestamp > key_data_timestamp

    document_id = deal_data.payload["documentId"]
    deal_data.payload = {}
    deal_data.documentId = post_resp["dealComponent"]

    get_status_code, get_resp, get_resp_headers = deal_data.get_request(
        url=api_url, route_url=GET_SINGLE_DOC_ROUTE
    )
    body = get_resp[0]

    assert get_status_code == HTTPStatus.OK
    assert_headers(get_resp_headers)
    assert body["dealRefId"] == deal_data.dealRefId
    assert body["dealComponent"] == f"DTC.DOCS.{document_id}"


@pytest.mark.smoke
@pytest.mark.functional
@pytest.mark.parametrize("docs_file", DOCS_FILE_NAME)
def test_get_single_document_invalid_deal_ref(
    env,
    api_url,
    docs_file,
    key_data_test_data_dtc_record_single_key,
    invalid_deal_ref_id_response,
    get_deal_updated_timestamp,
    assert_headers,
):
    docs_file = f"docs/{docs_file}"
    deal_data = ServiceAPI(env=env)

    deal_data.payload = key_data_test_data_dtc_record_single_key

    status_code, key_data_resp, headers = deal_data.post_request(
        api_url, KEY_DATA_ROUTER
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {key_data_resp}"
        )
    key_data_timestamp = get_deal_updated_timestamp(deal_ref_id=deal_data.dealRefId)
    deal_ref_id = deal_data.generate_random_id(ulid_id=True)
    deal_data.set_payload(docs_file)
    deal_data.payload["dealRefId"] = deal_ref_id

    status_code, post_resp, headers = deal_data.post_request(api_url, POST_DOCS_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {post_resp}"
        )
    doc_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId,
        deal_component=deal_data.payload["dealComponent"],
        updated_timestamp=key_data_timestamp,
    )
    assert doc_timestamp > key_data_timestamp

    document_id = deal_data.payload["documentId"]

    deal_data.payload = {}
    deal_data.dealRefId = deal_ref_id
    deal_data.documentId = document_id

    get_status_code, get_resp, get_resp_headers = deal_data.get_request(
        url=api_url, route_url=GET_SINGLE_DOC_ROUTE
    )

    assert get_status_code == HTTPStatus.BAD_REQUEST
    assert_headers(get_resp_headers)
    assert get_resp == invalid_deal_ref_id_response(deal_ref_id)


@pytest.mark.smoke
@pytest.mark.functional
@pytest.mark.parametrize("docs_file", DOCS_FILE_NAME)
def test_get_single_document_invalid_document_id(
    env,
    api_url,
    docs_file,
    key_data_test_data_dtc_record_single_key,
    no_resources_found_response,
    get_deal_updated_timestamp,
    assert_headers,
):
    docs_file = f"docs/{docs_file}"
    deal_data = ServiceAPI(env=env)

    deal_data.payload = key_data_test_data_dtc_record_single_key

    status_code, key_data_resp, headers = deal_data.post_request(
        api_url, KEY_DATA_ROUTER
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {key_data_resp}"
        )
    key_data_timestamp = get_deal_updated_timestamp(deal_ref_id=deal_data.dealRefId)
    deal_data.set_payload(docs_file)
    deal_data.payload["dealRefId"] = deal_data.dealRefId

    status_code, post_resp, headers = deal_data.post_request(api_url, POST_DOCS_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {post_resp}"
        )

    doc_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId,
        deal_component=deal_data.payload["dealComponent"],
        updated_timestamp=key_data_timestamp,
    )
    assert doc_timestamp > key_data_timestamp

    deal_data.payload = {}
    deal_data.documentId = "INVALID_DOCUMENT_ID"

    get_status_code, get_resp, get_resp_headers = deal_data.get_request(
        url=api_url, route_url=GET_SINGLE_DOC_ROUTE
    )

    assert get_status_code == HTTPStatus.NOT_FOUND
    assert_headers(get_resp_headers)
    assert get_resp == no_resources_found_response(
        deal_data.dealRefId, field="documentId", value=deal_data.documentId
    )


@pytest.mark.prod
@pytest.mark.smoke
@pytest.mark.functional
def test_get_documents(
    env,
    api_url,
    assert_headers,
    get_deal_updated_timestamp,
    key_data_test_data_dtc_record_single_key,
):
    deal_data = ServiceAPI(env=env)

    deal_data.payload = key_data_test_data_dtc_record_single_key

    status_code, key_data_resp, headers = deal_data.post_request(
        api_url, KEY_DATA_ROUTER
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {key_data_resp}"
        )
    current_timestamp = get_deal_updated_timestamp(deal_ref_id=deal_data.dealRefId)
    for json_document in DOCS_FILE_NAME:
        docs_file = f"docs/{json_document}"
        deal_data.set_payload(docs_file)
        deal_data.payload["dealRefId"] = deal_data.dealRefId
        status_code, post_resp, headers = deal_data.post_request(
            api_url, POST_DOCS_ROUTE
        )

        if status_code != HTTPStatus.CREATED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {post_resp}"
            )
        doc_timestamp = get_deal_updated_timestamp(
            deal_ref_id=deal_data.dealRefId,
            deal_component=deal_data.payload["dealComponent"],
            updated_timestamp=current_timestamp,
        )
        assert doc_timestamp > current_timestamp
        current_timestamp = doc_timestamp

    deal_data.payload = {}

    get_status_code, get_resp, get_resp_headers = deal_data.get_request(
        url=api_url, route_url=GET_DOCS_ROUTE
    )

    assert get_status_code == HTTPStatus.OK
    assert_headers(get_resp_headers)
    assert len(get_resp) == 3
    for item in get_resp:
        assert item["dealRefId"] == deal_data.dealRefId
        assert item["dealComponent"].startswith("DTC.DOCS")


@pytest.mark.smoke
@pytest.mark.functional
def test_get_documents_query_params(
    env,
    api_url,
    assert_headers,
    get_deal_updated_timestamp,
    key_data_test_data_dtc_record_single_key,
):
    deal_data = ServiceAPI(env=env)

    deal_data.payload = key_data_test_data_dtc_record_single_key

    status_code, key_data_resp, headers = deal_data.post_request(
        api_url, KEY_DATA_ROUTER
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {key_data_resp}"
        )
    current_timestamp = get_deal_updated_timestamp(deal_ref_id=deal_data.dealRefId)
    for json_document in DOCS_FILE_NAME:
        docs_file = f"docs/{json_document}"
        deal_data.set_payload(docs_file)
        deal_data.payload["dealRefId"] = deal_data.dealRefId
        status_code, post_resp, headers = deal_data.post_request(
            api_url, POST_DOCS_ROUTE
        )

        if status_code != HTTPStatus.CREATED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {post_resp}"
            )
        doc_timestamp = get_deal_updated_timestamp(
            deal_ref_id=deal_data.dealRefId,
            deal_component=deal_data.payload["dealComponent"],
            updated_timestamp=current_timestamp,
        )
        assert doc_timestamp > current_timestamp
        current_timestamp = doc_timestamp
    deal_data.payload = {}
    query_params = "uploadStatus=Infected"

    get_status_code, get_resp, get_resp_headers = deal_data.get_request(
        url=api_url, route_url=GET_DOCS_ROUTE, query_param=query_params
    )
    body = get_resp[0]

    assert get_status_code == HTTPStatus.OK
    assert_headers(get_resp_headers)
    assert len(get_resp) == 1
    assert body["uploadStatus"] == "Infected"


@pytest.mark.smoke
@pytest.mark.functional
def test_get_documents_query_params_tags(
    env,
    api_url,
    assert_headers,
    get_deal_updated_timestamp,
    key_data_test_data_dtc_record_single_key,
):
    deal_data = ServiceAPI(env=env)

    deal_data.payload = key_data_test_data_dtc_record_single_key

    status_code, key_data_resp, headers = deal_data.post_request(
        api_url, KEY_DATA_ROUTER
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {key_data_resp}"
        )
    current_timestamp = get_deal_updated_timestamp(deal_ref_id=deal_data.dealRefId)
    for json_document in DOCS_FILE_NAME:
        docs_file = f"docs/{json_document}"
        deal_data.set_payload(docs_file)
        deal_data.payload["dealRefId"] = deal_data.dealRefId
        status_code, post_resp, headers = deal_data.post_request(
            api_url, POST_DOCS_ROUTE
        )

        if status_code != HTTPStatus.CREATED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {post_resp}"
            )
        doc_timestamp = get_deal_updated_timestamp(
            deal_ref_id=deal_data.dealRefId,
            deal_component=deal_data.payload["dealComponent"],
            updated_timestamp=current_timestamp,
        )
        assert doc_timestamp > current_timestamp
        current_timestamp = doc_timestamp

    deal_data.payload = {}
    query_params = "tags=AB"

    get_status_code, get_resp, get_resp_headers = deal_data.get_request(
        url=api_url, route_url=GET_DOCS_ROUTE, query_param=query_params
    )
    body = get_resp[0]

    assert get_status_code == HTTPStatus.OK
    assert_headers(get_resp_headers)
    assert len(get_resp) == 1
    assert body["documentId"] == "GEN.INSURANCECARD"


@pytest.mark.smoke
@pytest.mark.functional
def test_get_documents_invalid_query_params(
    env,
    api_url,
    assert_headers,
    get_deal_updated_timestamp,
    key_data_test_data_dtc_record_single_key,
    invalid_query_parameters_response,
):
    deal_data = ServiceAPI(env=env)

    deal_data.payload = key_data_test_data_dtc_record_single_key

    status_code, key_data_resp, headers = deal_data.post_request(
        api_url, KEY_DATA_ROUTER
    )
    current_timestamp = get_deal_updated_timestamp(deal_ref_id=deal_data.dealRefId)
    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {key_data_resp}"
        )

    for json_document in DOCS_FILE_NAME:
        docs_file = f"docs/{json_document}"
        deal_data.set_payload(docs_file)
        deal_data.payload["dealRefId"] = deal_data.dealRefId
        status_code, post_resp, headers = deal_data.post_request(
            api_url, POST_DOCS_ROUTE
        )

        if status_code != HTTPStatus.CREATED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {post_resp}"
            )
        doc_timestamp = get_deal_updated_timestamp(
            deal_ref_id=deal_data.dealRefId,
            deal_component=deal_data.payload["dealComponent"],
            updated_timestamp=current_timestamp,
        )
        assert doc_timestamp > current_timestamp
        current_timestamp = doc_timestamp

    deal_data.payload = {}
    query_params = "INVALID_QUERY_PARAM=Test"

    get_status_code, get_resp, get_resp_headers = deal_data.get_request(
        url=api_url, route_url=GET_DOCS_ROUTE, query_param=query_params
    )

    assert get_status_code == HTTPStatus.BAD_REQUEST
    assert_headers(get_resp_headers)
    assert get_resp == invalid_query_parameters_response(GET_DOCS_FILTER_PARAMS)


@pytest.mark.smoke
@pytest.mark.functional
def test_get_documents_invalid_deal_ref(
    env,
    api_url,
    invalid_deal_ref_id_response,
    assert_headers,
):
    deal_data = ServiceAPI(env=env)

    deal_data.dealRefId = deal_data.generate_random_id(ulid_id=True)

    get_status_code, get_resp, get_resp_headers = deal_data.get_request(
        url=api_url, route_url=GET_DOCS_ROUTE
    )

    assert get_status_code == HTTPStatus.BAD_REQUEST
    assert_headers(get_resp_headers)
    assert get_resp == invalid_deal_ref_id_response(deal_data.dealRefId)


@pytest.mark.smoke
@pytest.mark.functional
def test_get_documents_none_in_db(
    env,
    api_url,
    key_data_test_data_dtc_record_single_key,
    no_resources_found_response,
    assert_headers,
):
    deal_data = ServiceAPI(env=env)

    deal_data.payload = key_data_test_data_dtc_record_single_key

    status_code, key_data_resp, headers = deal_data.post_request(
        api_url, KEY_DATA_ROUTER
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {key_data_resp}"
        )

    deal_data.payload = {}

    get_status_code, get_resp, get_resp_headers = deal_data.get_request(
        url=api_url, route_url=GET_DOCS_ROUTE
    )

    assert get_status_code == HTTPStatus.NOT_FOUND
    assert_headers(get_resp_headers)
    assert get_resp == no_resources_found_response(deal_data.dealRefId)


@pytest.mark.prod
@pytest.mark.smoke
@pytest.mark.functional
@pytest.mark.parametrize("docs_file", DOCS_SESSION_FILE_NAMES)
def test_get_session(
    env,
    api_url,
    docs_file,
    get_deal_updated_timestamp,
    key_data_test_data_dtc_record_single_key,
    assert_headers,
):
    docs_file = f"docs/{docs_file}"
    deal_data = ServiceAPI(env=env)

    deal_data.payload = key_data_test_data_dtc_record_single_key

    status_code, key_data_resp, headers = deal_data.post_request(
        api_url, KEY_DATA_ROUTER
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {key_data_resp}"
        )
    key_data_timestamp = get_deal_updated_timestamp(deal_ref_id=deal_data.dealRefId)
    deal_data.set_payload(docs_file)
    deal_data.payload["dealRefId"] = deal_data.dealRefId

    status_code, post_resp, headers = deal_data.post_request(
        api_url, POST_DOCS_ROUTE, cust_header={"pageCount": "2"}
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {post_resp}"
        )

    session_id = post_resp["sessionId"]
    doc_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId,
        deal_component=f"{deal_data.payload['dealComponent']}{session_id}",
        updated_timestamp=key_data_timestamp,
    )
    assert doc_timestamp > key_data_timestamp

    deal_data.payload = {}
    deal_data.sessionId = f"DTC.DOCS.UPLOADS.{session_id}"

    get_status_code, get_resp, get_resp_headers = deal_data.get_request(
        url=api_url, route_url=GET_SESSION_ROUTE
    )
    body = get_resp[0]

    assert get_status_code == HTTPStatus.OK
    assert_headers(get_resp_headers)
    assert body["dealRefId"] == deal_data.dealRefId
    assert body["dealComponent"] == f"DTC.DOCS.UPLOADS.{session_id}"
    assert "1" in body["pages"] and "2" in body["pages"]


@pytest.mark.smoke
@pytest.mark.functional
@pytest.mark.parametrize("docs_file", DOCS_SESSION_FILE_NAMES)
def test_get_session_invalid_deal_ref(
    env,
    api_url,
    docs_file,
    key_data_test_data_dtc_record_single_key,
    get_deal_updated_timestamp,
    invalid_deal_ref_id_response,
    assert_headers,
):
    docs_file = f"docs/{docs_file}"
    deal_data = ServiceAPI(env=env)

    deal_data.payload = key_data_test_data_dtc_record_single_key

    status_code, key_data_resp, headers = deal_data.post_request(
        api_url, KEY_DATA_ROUTER
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {key_data_resp}"
        )
    key_data_timestamp = get_deal_updated_timestamp(deal_ref_id=deal_data.dealRefId)

    deal_data.set_payload(docs_file)
    deal_data.payload["dealRefId"] = deal_data.dealRefId

    status_code, post_resp, headers = deal_data.post_request(
        api_url, POST_DOCS_ROUTE, cust_header={"pageCount": "2"}
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {post_resp}"
        )

    session_id = post_resp["sessionId"]
    doc_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId,
        deal_component=f"{deal_data.payload['dealComponent']}{session_id}",
        updated_timestamp=key_data_timestamp,
    )
    assert doc_timestamp > key_data_timestamp

    invalid_deal_ref_id = deal_data.generate_random_id(ulid_id=True)
    deal_data.payload = {}
    deal_data.dealRefId = invalid_deal_ref_id
    deal_data.sessionId = session_id

    get_status_code, get_resp, get_resp_headers = deal_data.get_request(
        url=api_url, route_url=GET_SESSION_ROUTE
    )

    assert get_status_code == HTTPStatus.BAD_REQUEST
    assert_headers(get_resp_headers)
    assert get_resp == invalid_deal_ref_id_response(invalid_deal_ref_id)


@pytest.mark.smoke
@pytest.mark.functional
@pytest.mark.parametrize("docs_file", DOCS_SESSION_FILE_NAMES)
def test_get_session_invalid_session_id(
    env,
    api_url,
    docs_file,
    key_data_test_data_dtc_record_single_key,
    get_deal_updated_timestamp,
    no_resources_found_response,
    assert_headers,
):
    docs_file = f"docs/{docs_file}"
    deal_data = ServiceAPI(env=env)

    deal_data.payload = key_data_test_data_dtc_record_single_key

    status_code, key_data_resp, headers = deal_data.post_request(
        api_url, KEY_DATA_ROUTER
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {key_data_resp}"
        )
    key_data_timestamp = get_deal_updated_timestamp(deal_ref_id=deal_data.dealRefId)
    deal_data.set_payload(docs_file)
    deal_data.payload["dealRefId"] = deal_data.dealRefId

    status_code, post_resp, headers = deal_data.post_request(
        api_url, POST_DOCS_ROUTE, cust_header={"pageCount": "2"}
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {post_resp}"
        )
    session_id = post_resp["sessionId"]
    doc_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId,
        deal_component=f"{deal_data.payload['dealComponent']}{session_id}",
        updated_timestamp=key_data_timestamp,
    )
    assert doc_timestamp > key_data_timestamp

    deal_data.payload = {}
    deal_data.sessionId = "INVALID_SESSION_ID"

    get_status_code, get_resp, get_resp_headers = deal_data.get_request(
        url=api_url, route_url=GET_SESSION_ROUTE
    )

    assert get_status_code == HTTPStatus.NOT_FOUND
    assert_headers(get_resp_headers)
    assert get_resp == no_resources_found_response(
        deal_data.dealRefId, field="sessionId", value=deal_data.sessionId
    )
