# -*- coding: utf-8 -*-
from http import HTTPStatus

import pytest
from tests.functional.service_api import ServiceAPI


KEY_DATA_ROUTER = "key_data"
DELETE_DOCS_ROUTE = "delete_document"
POST_DOCUMENT_ROUTE = "post_document"
GET_SINGLE_DOC_ROUTE = "get_single_document"

DOCS_FILE_NAME = [
    ("docs_single_document_insurance.json"),
    ("docs_single_document_drivers_license.json"),
    ("docs_single_document_w2.json"),
]


@pytest.mark.prod
@pytest.mark.smoke
@pytest.mark.functional
@pytest.mark.parametrize("docs_file", DOCS_FILE_NAME)
def test_delete_successful(
    env,
    api_url,
    docs_file,
    assert_headers,
    get_deal_updated_timestamp,
    key_data_test_data_dtc_record_single_key,
):
    docs_file = f"docs/{docs_file}"
    deal_data = ServiceAPI(env=env)

    deal_data.payload = key_data_test_data_dtc_record_single_key

    status_code, key_data_resp, headers = deal_data.post_request(
        api_url, KEY_DATA_ROUTER
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {key_data_resp}"
        )

    key_data_timestamp = get_deal_updated_timestamp(deal_ref_id=deal_data.dealRefId)

    deal_data.set_payload(docs_file)
    deal_data.payload["dealRefId"] = deal_data.dealRefId

    status_code, post_resp, headers = deal_data.post_request(
        api_url, POST_DOCUMENT_ROUTE
    )
    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {post_resp}"
        )

    doc_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId,
        deal_component=deal_data.payload["dealComponent"],
        updated_timestamp=key_data_timestamp,
    )
    assert doc_timestamp > key_data_timestamp
    deal_data.documentId = post_resp["dealComponent"]

    deal_data.payload = {}
    get_status_code, get_resp, get_resp_headers = deal_data.get_request(
        url=api_url, route_url=GET_SINGLE_DOC_ROUTE
    )

    assert get_status_code == HTTPStatus.OK

    status_code, resp, resp_headers = deal_data.delete_request(
        url=api_url, route_url=DELETE_DOCS_ROUTE
    )

    assert status_code == HTTPStatus.NO_CONTENT
    assert_headers(resp_headers)

    get_status_code, get_resp, get_resp_headers = deal_data.get_request(
        url=api_url, route_url=GET_SINGLE_DOC_ROUTE
    )

    assert get_status_code == HTTPStatus.NOT_FOUND


@pytest.mark.smoke
@pytest.mark.functional
def test_delete_invalid_deal_ref_id(
    env,
    api_url,
    assert_headers,
    invalid_deal_ref_id_response,
):
    deal_data = ServiceAPI(env=env)
    deal_data.payload = {}
    deal_data.dealRefId = deal_data.generate_random_id(ulid_id=True)
    deal_data.documentId = "W2.APP"

    status_code, resp, resp_headers = deal_data.delete_request(
        url=api_url, route_url=DELETE_DOCS_ROUTE
    )

    assert status_code == HTTPStatus.BAD_REQUEST
    assert resp == invalid_deal_ref_id_response(deal_data.dealRefId)
    assert_headers(resp_headers)


@pytest.mark.smoke
@pytest.mark.functional
@pytest.mark.parametrize("docs_file", DOCS_FILE_NAME)
def test_delete_invalid_document_id(
    env,
    api_url,
    docs_file,
    assert_headers,
    no_resources_found_response,
    get_deal_updated_timestamp,
    key_data_test_data_dtc_record_single_key,
):
    docs_file = f"docs/{docs_file}"
    deal_data = ServiceAPI(env=env)

    deal_data.payload = key_data_test_data_dtc_record_single_key

    status_code, key_data_resp, headers = deal_data.post_request(
        api_url, KEY_DATA_ROUTER
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {key_data_resp}"
        )
    key_data_timestamp = get_deal_updated_timestamp(deal_ref_id=deal_data.dealRefId)

    deal_data.set_payload(docs_file)
    deal_data.payload["dealRefId"] = deal_data.dealRefId

    status_code, post_resp, headers = deal_data.post_request(
        api_url, POST_DOCUMENT_ROUTE
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {post_resp}"
        )

    doc_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId,
        deal_component=deal_data.payload["dealComponent"],
        updated_timestamp=key_data_timestamp,
    )
    assert doc_timestamp > key_data_timestamp

    deal_data.payload = {}
    deal_data.documentId = deal_data.generate_random_id(ulid_id=True)

    status_code, resp, resp_headers = deal_data.delete_request(
        url=api_url, route_url=DELETE_DOCS_ROUTE
    )

    assert status_code == HTTPStatus.BAD_REQUEST
    assert resp == no_resources_found_response(
        deal_data.dealRefId, "documentId", deal_data.documentId
    )
    assert_headers(resp_headers)


@pytest.mark.prod
@pytest.mark.smoke
@pytest.mark.functional
def test_delete_missing_path_params(
    env,
    api_url,
    assert_headers,
    missing_reference_ids_response,
):
    deal_data = ServiceAPI(env=env)

    deal_data.payload = {}
    deal_data.dealRefId = ""

    status_code, resp, resp_headers = deal_data.delete_request(
        url=api_url, route_url=DELETE_DOCS_ROUTE
    )

    assert status_code == HTTPStatus.BAD_REQUEST
    assert resp == missing_reference_ids_response(field_list=["dealRefId"])
    assert_headers(resp_headers)
