# -*- coding: utf-8 -*-
from http import HTTPStatus

import pytest
from common.settings import ErrorMsgs
from tests.functional.service_api import ServiceAPI


KEY_DATA_ROUTE = "key_data_get"


@pytest.mark.smoke
@pytest.mark.prod
@pytest.mark.functional
def test_post_credit_app_using_existing_lead_deal_ref_id_in_header(
    env,
    api_url,
    common_assert,
    random_data_class,
    get_response_data,
    verify_deal_component,
    validate_deal_data_keys,
    get_deal_updated_timestamp,
    get_deal_component_details,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
    query_dynamodb_with_deal_component,
    verify_get_response_against_posted_data,
):
    """
    This test case is to associate a credit application to an existing lead using delRefId
    Step1: Submit a lead to leads endpoint
    Stet2: Submit a credit app to credit app with dealRefId endpoint
    """
    json_file_name = "ind_retail_new_decision.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"leads/{json_file_name}",
    )
    # Posting a lead to leads POST endpoint
    status_code, lead_resp, resp_headers = deal_data.post_request(
        api_url,
        "leads",
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {lead_resp}"
        )

    # Saving first post payload for verification
    first_post_payload = deal_data.payload

    # Lead timestamp
    lead_timestamp = get_deal_updated_timestamp(deal_ref_id=deal_data.dealRefId)

    # Add creditAppId in header
    add_keys_header = {
        "X-Credit-Application-Reference-Id": deal_data.generate_random_id(True),
        "X-Lead-Reference-Number": deal_data.generate_random_id(),
        "X-Application-Reference-Number": deal_data.generate_random_id(),
        "X-Lead-Reference-Number-Internal": deal_data.generate_random_id(),
        "X-Application-Reference-Number-Internal": deal_data.generate_random_id(),
        "X-Deal-Jacket-ID": deal_data.generate_random_id(),
        "X-Dealer-Code": "6",
        "X-Deal-Reference-Number-UniFI": deal_data.generate_random_id(),
        "X-ABCD-ID": deal_data.generate_random_id(),
    }

    # Posting a credit app using the dealRefId
    json_file_name = "app_guar_references_cash_new.json"
    deal_data.set_payload(f"credit_app/{json_file_name}")
    # Update dealRefIdFD in payload
    deal_data.payload["dealRefIdFD"] = deal_data.generate_random_id(True)
    status_code, app_resp, resp_headers = deal_data.post_request(
        api_url,
        "credit_app_with_deal_ref",
        lead_resp.get("dealRefId"),
        cust_header=add_keys_header,
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {app_resp}"
        )

    app_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId, updated_timestamp=lead_timestamp
    )
    assert app_timestamp > lead_timestamp

    records, count = get_records_by_deal_ref_id(app_resp.get("dealRefId"))

    # Validation
    # assert count == 20
    db_resp = query_dynamodb_with_deal_component(deal_data.dealRefId, "DTC.DEAL")
    validate_deal_data_keys(app_resp, db_resp[0], add_keys_header)
    common_assert(records=records, resp_headers=resp_headers)

    # Verify that App and lead ids are generated and store in db
    assert get_response_data(records, "DEAL").get("creditAppId") == app_resp.get(
        "creditAppId"
    )
    assert get_response_data(records, "DEAL").get("leadRefId") == lead_resp.get(
        "leadRefId"
    )

    # Verify updated timestamp is greater than created timestamp
    assert get_response_data(records, "DEAL").get(
        "createdTimestamp"
    ) < get_response_data(records, "DEAL").get("updatedTimestamp")

    # Verify top level field
    assert deal_data.payload.get("financeMethod") == get_response_data(
        records, "DEAL"
    ).get("financeMethod")

    # Verify the lowest level object is updated
    cur_emp_add_payload = (
        deal_data.payload.get("applicant")
        .get("currentEmployment")
        .get("employerAddress")
    )
    cur_emp_add_resp = get_response_data(records, "APPLICANT").get(
        "currentEmployment_employerAddress"
    )
    verify_get_response_against_posted_data(cur_emp_add_payload, cur_emp_add_resp)

    # Verify data from the second post is saved in DB
    assert deal_data.payload.get("guarantor").get(
        "otherMonthlyIncome"
    ) == get_response_data(records, "GUARANTOR").get("otherMonthlyIncome")

    # Verify list items is saved in db from second post
    ref_payload = deal_data.payload.get("guarantor").get("references")
    ref_resp = deal_data.payload.get("guarantor").get("references")
    verify_get_response_against_posted_data(ref_payload, ref_resp, "firstName")

    # Verify data from first post that does not exist in the second post
    payload_deci_obj = first_post_payload.get("decisionSummary")
    resp_deci_obj = get_response_data(records, "DECISIONSUMMARY")
    verify_get_response_against_posted_data(payload_deci_obj, resp_deci_obj)

    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")
    verify_deal_component(records, deal_data.payload, "guarantor")
    verify_deal_component_protected(records, deal_data.payload, "guarantor")

    add_keys_header["X-Lead-Reference-Number"] = None
    deal_data.payload.update(add_keys_header)
    verify_deal_component(
        records, deal_data.payload, "deal", additional_header_keys=True
    )

    # Validate sourcePartnerDealerId is saved in DB
    for target in deal_data.payload["targetPlatforms"]:
        v2_record = get_deal_component_details(
            deal_data.dealRefId, deal_component=f"REF_IDS.{target['id']}"
        )
        assert (
            v2_record.get("sourcePartnerDealerId") == target["partyId"]
        ), f"partyId did not save in key-data as sourcePartnerDealerId for {target}"


@pytest.mark.prod
@pytest.mark.functional
def test_post_leads_using_existing_credit_app(
    env,
    api_url,
    common_assert,
    random_data_class,
    get_response_data,
    verify_deal_component,
    validate_deal_data_keys,
    get_deal_component_details,
    get_deal_updated_timestamp,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
    query_dynamodb_with_deal_component,
    verify_get_response_against_posted_data,
):
    """
    This test case is to associate a leads to an existing credit application using delRefId
    Step1: Submit a credit application to credit application endpoint
    Stet2: Submit a leads to leads with dealRefId endpoint
    """
    json_file_name = "joint_retail_certified.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, app_resp, resp_headers = deal_data.post_request(
        api_url,
        "credit_app",
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {app_resp}"
        )

    # Saving first post payload for verification
    first_post_payload = deal_data.payload
    app_timestamp = get_deal_updated_timestamp(deal_ref_id=deal_data.dealRefId)

    # Posting a lead using the dealRefId
    json_file_name = "ind_cash_new_decision_session.json"
    deal_data.set_payload(f"leads/{json_file_name}")
    # Update dealRefIdFD in payload
    deal_data.payload["dealRefIdFD"] = deal_data.generate_random_id(True)
    add_keys_header = {
        "X-Lead-Reference-Number": deal_data.generate_random_id(),
        "X-Application-Reference-Number": deal_data.generate_random_id(),
        "X-Lead-Reference-Number-Internal": deal_data.generate_random_id(),
        "X-Application-Reference-Number-Internal": deal_data.generate_random_id(),
        "X-Deal-Jacket-ID": deal_data.generate_random_id(),
        "X-Dealer-Code": "6",
        "X-Deal-Reference-Number-UniFI": deal_data.generate_random_id(),
        "X-ABCD-ID": deal_data.generate_random_id(),
    }
    status_code, lead_resp, resp_headers = deal_data.post_request(
        api_url,
        "leads_with_deal_ref",
        app_resp["dealRefId"],
        cust_header=add_keys_header,
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {lead_resp}"
        )

    lead_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId, updated_timestamp=app_timestamp
    )
    assert lead_timestamp > app_timestamp

    records, count = get_records_by_deal_ref_id(app_resp.get("dealRefId"))

    # Validation
    # assert count == 15
    db_resp = query_dynamodb_with_deal_component(deal_data.dealRefId, "DTC.DEAL")
    validate_deal_data_keys(app_resp, db_resp[0])
    common_assert(records=records, resp_headers=resp_headers)

    # Verify that App and lead ids are generated and store in db
    assert get_response_data(records, "DEAL").get("creditAppId") == app_resp.get(
        "creditAppId"
    )
    assert get_response_data(records, "DEAL").get("leadRefId") == lead_resp.get(
        "leadRefId"
    )

    # Verify updated timestamp is greater than created timestamp
    assert get_response_data(records, "DEAL").get(
        "createdTimestamp"
    ) < get_response_data(records, "DEAL").get("updatedTimestamp")

    # Verify top level field - 2nd post should override the 1st post value
    assert deal_data.payload.get("financeMethod") == get_response_data(
        records, "DEAL"
    ).get("financeMethod")

    # Verify the lowest level object is updated
    cur_emp_add_payload = (
        deal_data.payload.get("applicant")
        .get("currentEmployment")
        .get("employerAddress")
    )
    cur_emp_add_resp = get_response_data(records, "APPLICANT").get(
        "currentEmployment_employerAddress"
    )
    verify_get_response_against_posted_data(cur_emp_add_payload, cur_emp_add_resp)

    # # Verify coapp data from the first post is saved in DB. This data is missing in second post
    coapp_emp_add_payload = (
        first_post_payload.get("coApplicant")
        .get("currentEmployment")
        .get("employerAddress")
    )
    coapp_emp_add_resp = get_response_data(records, "COAPPLICANT").get(
        "currentEmployment_employerAddress"
    )
    verify_get_response_against_posted_data(coapp_emp_add_payload, coapp_emp_add_resp)

    # Verify list item from first post
    target_payload = deal_data.payload.get("targetPlatforms")
    resp_target = get_response_data(records, "DEAL").get("targetPlatforms")
    verify_get_response_against_posted_data(target_payload, resp_target, "id")

    # Verify vehicle data is update and saved in db
    payload_veh_obj = deal_data.payload.get("vehicle")
    resp_veh_obj = get_response_data(records, "VEHICLE")
    verify_get_response_against_posted_data(payload_veh_obj, resp_veh_obj)

    # Verify data from second post that does not exist in the first post - Session Info and Decision Summary
    payload_session_obj = deal_data.payload.get("sessionInfo")
    resp_session_obj = get_response_data(records, "SESSIONINFO")
    verify_get_response_against_posted_data(payload_session_obj, resp_session_obj)

    payload_deci_obj = deal_data.payload.get("decisionSummary")
    resp_dec_obj = get_response_data(records, "DECISIONSUMMARY")

    verify_get_response_against_posted_data(payload_deci_obj, resp_dec_obj)

    # Verify app and coapp first and last name
    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")
    verify_deal_component(records, first_post_payload, "coApplicant")
    verify_deal_component_protected(records, first_post_payload, "coApplicant")

    add_keys_header["X-Lead-Reference-Number"] = None
    deal_data.payload.update(add_keys_header)
    verify_deal_component(
        records, deal_data.payload, "deal", additional_header_keys=True
    )
    # Validate sourcePartnerDealerId is saved in DB
    deal_data.payload["targetPlatforms"].extend(first_post_payload["targetPlatforms"])
    for target in deal_data.payload["targetPlatforms"]:
        v2_record = get_deal_component_details(
            deal_data.dealRefId, deal_component=f"REF_IDS.{target['id']}"
        )
        assert (
            v2_record.get("sourcePartnerDealerId") == target["partyId"]
        ), f"partyId did not save in key-data as sourcePartnerDealerId for {target}"


@pytest.mark.functional
def test_post_duplicate_credit_apps(
    env, api_url, random_data_class, wait_with_no_retries
):
    """
    This test case is to post duplicate credit applications to credit app endpoint
    Step1: Submit a credit application to credit application endpoint
    Stet2: Submit another credit application to credit app with dealRefId endpoint
    The API should not allow the duplicate post to same endpoint
    """
    json_file_name = "ind_lease_new.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )

    # Posted initial credit app
    status_code, app_resp, resp_headers = deal_data.post_request(
        api_url,
        "credit_app",
    )

    # Validate the app was created
    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {app_resp}"
        )

    wait_with_no_retries()
    json_file_name = "ind_retail_used.json"
    deal_data.set_payload(f"credit_app/{json_file_name}")

    # Post another credit app using the dealRefId
    status_code, dup_app_resp, resp_headers = deal_data.post_request(
        api_url, "credit_app_with_deal_ref", app_resp.get("dealRefId")
    )

    # Validate that the second credit app isn't created and expected validation error message is returned
    assert status_code == HTTPStatus.BAD_REQUEST
    assert (
        dup_app_resp.get("message")
        == "You have tired to post to an endpoint for which the resource already exists."
    )


@pytest.mark.functional
def test_post_duplicate_leads(env, api_url, random_data_class, wait_with_no_retries):
    """
    This test case is to post duplicate leads to leads endpoint
    Step1: Submit a lead to leads endpoint
    Stet2: Submit another lead to leads with dealRefId endpoint
    The API should not allow the duplicate post to same endpoint
    """
    json_file_name = "leads_min_data.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"leads/{json_file_name}",
    )

    # Initial lead is created
    status_code, lead_resp, resp_headers = deal_data.post_request(
        api_url,
        "leads",
    )

    # Validate that the lead is created
    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {lead_resp}"
        )

    wait_with_no_retries()
    json_file_name = "ind_retail_new_decision.json"
    deal_data.set_payload(f"leads/{json_file_name}")

    # Post second lead using existing dealRefId
    status_code, dup_lead_resp, resp_headers = deal_data.post_request(
        api_url, "leads_with_deal_ref", lead_resp.get("dealRefId")
    )

    # Validate that the second lead isn't created and expected validation error message is returned
    assert status_code == HTTPStatus.BAD_REQUEST
    assert (
        dup_lead_resp.get("message")
        == "You have tired to post to an endpoint for which the resource already exists."
    )


@pytest.mark.functional
def test_post_credit_app_with_dealrefid_invalid_test_data(
    env, api_url, random_data_class, invalid_payload
):
    """
    This test case is validating that the credit app api returns proper error for posting with invalid json
    """
    json_file_name = "ind_retail_new_decision.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"leads/{json_file_name}",
    )
    status_code, leads_response, resp_headers = deal_data.post_request(
        api_url,
        "leads",
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {leads_response}"
        )

    deal_data = ServiceAPI(
        env=env, random_data_class=random_data_class, payload=invalid_payload
    )

    status_code, response, resp_headers = deal_data.post_request(
        api_url, "credit_app_with_deal_ref", leads_response.get("dealRefId")
    )
    assert resp_headers.get("X-CoxAuto-Correlation-Id") is not None
    assert status_code == HTTPStatus.BAD_REQUEST


@pytest.mark.functional
def test_post_leads_with_dealrefid_invalid_test_data(
    env, api_url, random_data_class, invalid_payload
):
    """
    This test case is validating that the leads api returns proper error for posting with invalid json
    """
    json_file_name = "joint_lease_new_chrome_ymmt_no_vin.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, app_resp, resp_headers = deal_data.post_request(
        api_url,
        "credit_app",
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {app_resp}"
        )

    deal_data = ServiceAPI(
        env=env, random_data_class=random_data_class, payload=invalid_payload
    )

    status_code, response, resp_headers = deal_data.post_request(
        api_url, "leads_with_deal_ref", app_resp.get("dealRefId")
    )
    assert resp_headers.get("X-CoxAuto-Correlation-Id") is not None
    assert status_code == HTTPStatus.BAD_REQUEST


@pytest.mark.smoke
@pytest.mark.prod
@pytest.mark.functional
def test_post_credit_bureau_using_existing_lead(
    env,
    api_url,
    get_response_data,
    random_data_class,
    verify_deal_component,
    get_deal_updated_timestamp,
    get_records_by_deal_ref_id,
    verify_list_of_given_fields,
    verify_credit_bureau_reports,
    verify_deal_component_protected,
    verify_get_response_against_posted_data,
):
    """
    This test case is to associate a credit bureau to an existing lead using delRefId
    Step1: Submit a lead to leads endpoint
    Stet2: Submit a credit bureau to credit bureau with dealRefId endpoint
    """
    json_file_name = "guar_balloon_demo_trades.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"leads/{json_file_name}",
    )
    # Posting a lead to leads POST endpoint
    status_code, lead_resp, resp_headers = deal_data.post_request(
        api_url,
        "leads",
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {lead_resp}"
        )

    # Saving first post payload for verification
    lead_payload = deal_data.payload

    lead_timestamp = get_deal_updated_timestamp(deal_ref_id=deal_data.dealRefId)

    # Posting a credit bureau using the dealRefId
    json_file_name = "app_cb_equ_exp_tru.json"
    deal_data.set_payload(f"credit_bureau/{json_file_name}")

    status_code, bureau_resp, resp_headers = deal_data.post_request(
        api_url, "credit_bureau_with_deal_ref", cb_post=True
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {bureau_resp}"
        )

    bureau_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId, updated_timestamp=lead_timestamp
    )
    assert bureau_timestamp > lead_timestamp

    records, count = get_records_by_deal_ref_id(lead_resp.get("dealRefId"))

    # Validation
    # assert count == 13
    assert resp_headers.get("X-CoxAuto-Correlation-Id") is not None

    # Verify that Bureau and lead ids are generated and store in db
    assert get_response_data(records, "DEAL").get("leadRefId") == lead_resp.get(
        "leadRefId"
    )

    # Verify updated timestamp is greater than created timestamp
    assert get_response_data(records, "DEAL").get(
        "createdTimestamp"
    ) < get_response_data(records, "DEAL").get("updatedTimestamp")

    # Verify top level field
    top_resp_data = get_response_data(records, "DEAL")

    fields_list = ["sourcePartnerId"]
    verify_list_of_given_fields(lead_payload, top_resp_data, fields_list)

    fields_list = ["financeMethod", "sourcePartnerDealerId"]
    verify_list_of_given_fields(deal_data.payload, top_resp_data, fields_list)

    # Verify the lowest level object from second post is updated
    cur_add_payload = deal_data.payload.get("applicant").get("address")
    cur_add_resp = get_response_data(records, "APPLICANT").get("address")
    verify_get_response_against_posted_data(cur_add_payload, cur_add_resp)

    # Lowest level object exist in first post, not in second post
    guar_emp_add_payload = (
        lead_payload.get("guarantor").get("currentEmployment").get("employerAddress")
    )
    guar_emp_add_resp = get_response_data(records, "GUARANTOR").get(
        "currentEmployment_employerAddress"
    )
    verify_get_response_against_posted_data(guar_emp_add_payload, guar_emp_add_resp)

    verify_deal_component(records, lead_payload, "financeSummary")

    # Verify Report Data
    app_report = deal_data.payload.get("applicant").get("reports")
    verify_credit_bureau_reports(
        app_report,
        records,
        "applicant",
        bureau_resp.get("creditBureauRefId"),
        "request",
    )

    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")
    verify_deal_component(records, lead_payload, "guarantor")
    verify_deal_component_protected(records, lead_payload, "guarantor")


@pytest.mark.functional
def test_post_credit_bureau_using_existing_credit_app(
    env,
    api_url,
    get_response_data,
    random_data_class,
    verify_deal_component,
    get_deal_updated_timestamp,
    get_records_by_deal_ref_id,
    verify_list_of_given_fields,
    verify_credit_bureau_reports,
    verify_deal_component_protected,
    verify_get_response_against_posted_data,
):
    """
    This test case is to associate a credit bureau to an existing credit app using delRefId
    Step1: Submit a credit app to credit app endpoint
    Stet2: Submit a credit bureau to credit bureau with dealRefId endpoint
    """
    json_file_name = "joint_retail_certified.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, app_resp, resp_headers = deal_data.post_request(
        api_url,
        "credit_app",
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {app_resp}"
        )

    # Saving first post payload for verification
    app_payload = deal_data.payload

    app_timestamp = get_deal_updated_timestamp(deal_ref_id=deal_data.dealRefId)

    # Posting a credit bureau using the dealRefId
    json_file_name = "app_cb_softpull_redflag_ofac.json"
    deal_data.set_payload(f"credit_bureau/{json_file_name}")

    status_code, bureau_resp, resp_headers = deal_data.post_request(
        api_url, "credit_bureau_with_deal_ref", cb_post=True
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {app_resp}"
        )

    bureau_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId, updated_timestamp=app_timestamp
    )
    assert bureau_timestamp > app_timestamp

    records, count = get_records_by_deal_ref_id(app_resp.get("dealRefId"))

    # Validation
    # assert count == 16
    assert resp_headers.get("X-CoxAuto-Correlation-Id") is not None

    # Verify that Bureau and App ids are generated and store in db
    assert app_resp.get("creditAppId") == get_response_data(records, "DEAL").get(
        "creditAppId"
    )
    # Out of scope until team figure out how to handle multiple creditBureauRefId
    # assert deal_data.cbRefId == get_response_data(records, "DEAL").get(
    #     "creditBureauRefId"
    # )

    # Verify updated timestamp is greater than created timestamp
    assert get_response_data(records, "DEAL").get(
        "createdTimestamp"
    ) < get_response_data(records, "DEAL").get("updatedTimestamp")

    # Verify top level field
    top_resp_data = get_response_data(records, "DEAL")
    # assert deal_data.payload.get("financeMethod") == top_resp_data.get("financeMethod")

    fields_list = [
        "financeMethod",
        "regulationBIndicator",
        "communityPropertyDisclosureIndicator",
        "comments",
    ]
    verify_list_of_given_fields(app_payload, top_resp_data, fields_list)

    fields_list = ["sourcePartnerId", "sourcePartnerDealerId"]
    verify_list_of_given_fields(deal_data.payload, top_resp_data, fields_list)

    # Verify Target Platforms
    target_payload = deal_data.payload.get("targetPlatforms")
    target_resp = get_response_data(records, "DEAL").get("targetPlatforms")
    verify_get_response_against_posted_data(target_payload, target_resp, "id")

    # Verify the lowest level object from second post is updated
    cur_add_payload = deal_data.payload.get("applicant").get("address")
    cur_add_resp = get_response_data(records, "APPLICANT").get("address")
    verify_get_response_against_posted_data(cur_add_payload, cur_add_resp)

    # Lowest level object exist in first post, not in second post
    coapp_emp_add_payload = (
        app_payload.get("coApplicant").get("currentEmployment").get("employerAddress")
    )
    coapp_emp_add_resp = get_response_data(records, "COAPPLICANT").get(
        "currentEmployment_employerAddress"
    )
    verify_get_response_against_posted_data(coapp_emp_add_payload, coapp_emp_add_resp)

    verify_deal_component(records, app_payload, "vehicle")
    verify_deal_component(records, app_payload, "financeSummary")

    # Verify Report Data
    app_report = deal_data.payload.get("applicant").get("reports")
    verify_credit_bureau_reports(
        app_report,
        records,
        "applicant",
        bureau_resp.get("creditBureauRefId"),
        "request",
    )

    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")
    verify_deal_component(records, app_payload, "coApplicant")
    verify_deal_component_protected(records, app_payload, "coApplicant")


@pytest.mark.smoke
@pytest.mark.functional
def test_post_credit_app_using_existing_credit_bureau(
    env,
    api_url,
    get_response_data,
    random_data_class,
    verify_deal_component,
    get_deal_updated_timestamp,
    validate_deal_data_keys,
    get_records_by_deal_ref_id,
    verify_list_of_given_fields,
    verify_credit_bureau_reports,
    verify_deal_component_protected,
    query_dynamodb_with_deal_component,
    verify_get_response_against_posted_data,
):
    """
    This test case is to associate a credit app to an existing credit bureau using delRefId
    Step1: Submit a credit bureau to credit bureau endpoint
    Stet2: Submit a credit app to credit bureau with dealRefId endpoint
    """
    json_file_name = "app_coapp_cb_exp_equ_tru_redflag_ofac.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_bureau/{json_file_name}",
    )
    status_code, bureau_resp, resp_headers = deal_data.post_request(
        api_url, "credit_bureau", cb_post=True
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {bureau_resp}"
        )

    # Saving first post payload for verification
    cb_payload = deal_data.payload

    bureau_timestamp = get_deal_updated_timestamp(deal_ref_id=deal_data.dealRefId)

    # Add empty creditAppId in header
    fs_header_value = {"X-Credit-Application-Reference-Id": ""}

    # Posting a credit app using the dealRefId
    json_file_name = "app_guar_references_cash_new.json"
    deal_data.set_payload(f"credit_app/{json_file_name}")

    status_code, app_resp, resp_headers = deal_data.post_request(
        api_url,
        "credit_app_with_deal_ref",
        bureau_resp.get("dealRefId"),
        cust_header=fs_header_value,
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {app_resp}"
        )

    app_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId, updated_timestamp=bureau_timestamp
    )
    assert app_timestamp > bureau_timestamp

    records, count = get_records_by_deal_ref_id(bureau_resp.get("dealRefId"))

    # Validation
    # assert count == 30
    db_resp = query_dynamodb_with_deal_component(deal_data.dealRefId, "DTC.DEAL")
    validate_deal_data_keys(app_resp, db_resp[0], fs_header_value)
    assert resp_headers.get("X-CoxAuto-Correlation-Id") is not None
    # Verify that Bureau and App ids are generated and store in db
    # Validation is skipped until team figure out how to handle multiple creditBureauRefId for a deal
    # assert bureau_resp.get("creditBureauRefId") == get_response_data(records, "DEAL").get("creditBureauRefId")
    assert app_resp.get("creditAppId") == get_response_data(records, "DEAL").get(
        "creditAppId"
    )
    # Out of scope until team figure out how to handle multiple creditBureauRefId
    # assert deal_data.cbRefId == get_response_data(records, "DEAL").get(
    #     "creditBureauRefId"
    # )

    # Verify top level fields
    top_resp_data = get_response_data(records, "DEAL")

    fields_list = [
        "financeMethod",
        "sourcePartnerId",
        "sourcePartnerDealerId",
        "comments",
        "communityPropertyDisclosureIndicator",
    ]
    verify_list_of_given_fields(deal_data.payload, top_resp_data, fields_list)

    # Verify Target Platforms
    target_payload = deal_data.payload.get("targetPlatforms")
    target_resp = get_response_data(records, "DEAL").get("targetPlatforms")
    verify_get_response_against_posted_data(target_payload, target_resp, "id")

    # Verify the lowest level object from second post is updated
    cur_add_payload = deal_data.payload.get("applicant").get("address")
    cur_add_resp = get_response_data(records, "APPLICANT").get("address")
    verify_get_response_against_posted_data(cur_add_payload, cur_add_resp)

    # Lowest level object exist in first post, not in second post
    coapp_emp_add_payload = cb_payload.get("coApplicant").get("address")
    coapp_emp_add_resp = get_response_data(records, "COAPPLICANT").get("address")
    verify_get_response_against_posted_data(coapp_emp_add_payload, coapp_emp_add_resp)

    # Verify data from sub-level list from second post
    app_ref_payload = deal_data.payload.get("applicant").get("references")
    app_ref_resp = get_response_data(records, "APPLICANT").get("references")
    verify_get_response_against_posted_data(app_ref_payload, app_ref_resp, "firstName")

    guar_ref_payload = deal_data.payload.get("guarantor").get("references")
    guar_ref_resp = get_response_data(records, "GUARANTOR").get("references")
    verify_get_response_against_posted_data(
        guar_ref_payload, guar_ref_resp, "firstName"
    )

    verify_deal_component(records, deal_data.payload, "tradeIns")
    verify_deal_component(records, deal_data.payload, "extraData")
    lender_ids = [
        lender.get("lenderId") for lender in deal_data.payload.get("lenderList")
    ]
    for lender_id in lender_ids:
        verify_deal_component(records, deal_data.payload, f"lenderList.{lender_id}")
    verify_deal_component(records, deal_data.payload, "vehicle")
    verify_deal_component(records, deal_data.payload, "financeSummary")

    # Verify Report Data for Applicant
    app_report = cb_payload.get("applicant").get("reports")
    verify_credit_bureau_reports(
        app_report,
        records,
        "applicant",
        bureau_resp.get("creditBureauRefId"),
        "request",
    )

    # Verify Report Data for Co-Applicant
    app_report = cb_payload.get("coApplicant").get("reports")
    verify_credit_bureau_reports(
        app_report,
        records,
        "coApplicant",
        bureau_resp.get("creditBureauRefId"),
        "request",
    )

    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")
    verify_deal_component(records, cb_payload, "coApplicant")
    verify_deal_component_protected(records, cb_payload, "coApplicant")
    verify_deal_component(records, deal_data.payload, "guarantor")
    verify_deal_component_protected(records, deal_data.payload, "guarantor")


@pytest.mark.functional
def test_post_leads_using_existing_credit_bureau(
    env,
    api_url,
    get_response_data,
    random_data_class,
    verify_deal_component,
    get_deal_component_details,
    get_records_by_deal_ref_id,
    verify_list_of_given_fields,
    verify_credit_bureau_reports,
    verify_deal_component_protected,
    verify_get_response_against_posted_data,
):
    """
    This test case is to associate a lead to an existing credit bureau using delRefId
    Step1: Submit a credit bureau to credit bureau endpoint
    Stet2: Submit a lead to leads with dealRefId endpoint
    """
    json_file_name = "coapp_cb_equ_redflag_ofac.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_bureau/{json_file_name}",
    )
    status_code, bureau_resp, resp_headers = deal_data.post_request(
        api_url, "credit_bureau", cb_post=True
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {bureau_resp}"
        )

    # Saving first post payload for verification
    cb_payload = deal_data.payload

    get_deal_component_details(
        deal_ref_id=deal_data.dealRefId, deal_component="DTC.DEAL"
    )

    # Posting a lead using the dealRefId
    deal_data.set_payload("leads/app_coapp_guar_spouse_balloon_cert.json")

    status_code, lead_resp, resp_headers = deal_data.post_request(
        api_url, "leads_with_deal_ref", bureau_resp.get("dealRefId")
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {lead_resp}"
        )

    get_deal_component_details(
        deal_ref_id=deal_data.dealRefId,
        deal_component="DTC.DEAL",
        additional_check_key="leadRefId",
        additional_check_value=lead_resp["leadRefId"],
    )
    records, count = get_records_by_deal_ref_id(bureau_resp.get("dealRefId"))

    # Validation
    assert resp_headers.get("X-CoxAuto-Correlation-Id") is not None

    # Verify that App and lead ids are generated and store in db
    # Saving creditBureauRefId is out of scope until team figure out how to handle multiple creditBureauRefId
    # assert bureau_resp.get("creditBureauRefId") == get_response_data(records, "DEAL").get("creditBureauRefId")
    assert lead_resp.get("leadRefId") == get_response_data(records, "DEAL").get(
        "leadRefId"
    )
    # Out of scope until team figure out how to handle multiple creditBureauRefId
    # assert deal_data.cbRefId == get_response_data(records, "DEAL").get(
    #     "creditBureauRefId"
    # )

    # Verify top level fields
    top_resp_data = get_response_data(records, "DEAL")

    fields_list = [
        "financeMethod",
        "sourcePartnerId",
        "comments",
        "regulationBIndicator",
    ]
    verify_list_of_given_fields(deal_data.payload, top_resp_data, fields_list)

    # Verify targetPlatforms
    target_payload = deal_data.payload.get("targetPlatforms")
    target_resp = get_response_data(records, "DEAL").get("targetPlatforms")
    verify_get_response_against_posted_data(target_payload, target_resp, "id")

    # Verify lowest level object from second post is updated
    cur_add_payload = deal_data.payload.get("coApplicant").get("address")
    cur_add_resp = get_response_data(records, "COAPPLICANT").get("address")
    verify_get_response_against_posted_data(cur_add_payload, cur_add_resp)

    # Verify data from sub-level list from second post
    coapp_spou_payload = deal_data.payload.get("coApplicant").get("spouse")
    coapp_spou_resp = get_response_data(records, "COAPPLICANT").get("spouse")
    fields_list = ["firstName", "lastName", "income", "otherMonthlyIncomeSource"]
    verify_list_of_given_fields(coapp_spou_payload, coapp_spou_resp, fields_list)

    coapp_spou_add_payload = (
        deal_data.payload.get("coApplicant").get("spouse").get("address")
    )
    coapp_spou_add_resp = get_response_data(records, "COAPPLICANT").get(
        "spouse_address"
    )
    verify_get_response_against_posted_data(coapp_spou_add_payload, coapp_spou_add_resp)

    # verify Guarantor Info
    cur_add_payload = deal_data.payload.get("guarantor").get("address")
    cur_add_resp = get_response_data(records, "GUARANTOR").get("address")
    verify_get_response_against_posted_data(cur_add_payload, cur_add_resp)

    guar_spou_add_payload = (
        deal_data.payload.get("guarantor").get("spouse").get("address")
    )
    guar_spou_add_resp = get_response_data(records, "GUARANTOR").get("spouse_address")
    verify_get_response_against_posted_data(guar_spou_add_payload, guar_spou_add_resp)

    # Verify data from the is lead saved to DB
    verify_deal_component(records, deal_data.payload, "vehicle")
    verify_deal_component(records, deal_data.payload, "tradeIns")
    verify_deal_component(records, deal_data.payload, "financeSummary")
    lender_ids = [
        lender.get("lenderId") for lender in deal_data.payload.get("lenderList")
    ]
    for lender_id in lender_ids:
        verify_deal_component(records, deal_data.payload, f"lenderList.{lender_id}")
    verify_deal_component(records, deal_data.payload, "sessionInfo")
    verify_deal_component(records, deal_data.payload, "extraData")

    # Verify Report Data for Co-Applicant
    app_report = cb_payload.get("coApplicant").get("reports")
    verify_credit_bureau_reports(
        app_report,
        records,
        "coApplicant",
        bureau_resp.get("creditBureauRefId"),
        "request",
    )

    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")
    verify_deal_component(records, deal_data.payload, "coApplicant")
    verify_deal_component_protected(records, deal_data.payload, "coApplicant")
    verify_deal_component(records, deal_data.payload, "guarantor")
    verify_deal_component_protected(records, deal_data.payload, "guarantor")


@pytest.mark.smoke
@pytest.mark.prod
@pytest.mark.functional
def test_post_credit_bureau_and_credit_app_using_existing_lead(
    env,
    api_url,
    get_response_data,
    random_data_class,
    verify_deal_component,
    get_deal_updated_timestamp,
    get_records_by_deal_ref_id,
    verify_list_of_given_fields,
    verify_credit_bureau_reports,
    verify_deal_component_protected,
    verify_get_response_against_posted_data,
):
    """
    This test case is to associate a credit bureau to an existing leads using delRefId
    Step1: Submit a lead to leads endpoint
    Stet2: Submit a Credit Bureau to Credit Bureau with dealRefId endpoint
    """
    json_file_name = "ind_retail_new_no_income.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"leads/{json_file_name}",
    )

    # Posting a lead to leads POST endpoint
    status_code, lead_resp, resp_headers = deal_data.post_request(
        api_url,
        "leads",
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {lead_resp}"
        )

    # Saving first post payload for verification
    lead_payload = deal_data.payload

    lead_timestamp = get_deal_updated_timestamp(deal_data.dealRefId)

    # Posting a credit bureau using the dealRefId
    json_file_name = "app_coapp_redflag.json"
    deal_data.set_payload(f"credit_bureau/{json_file_name}")
    # Update dealRefIdFD in payload
    # deal_data.payload["dealRefIdFD"] = deal_data.generate_random_id(True) -->> CB with dealRefId is not SUPPORTED
    status_code, bureau_resp, resp_headers = deal_data.post_request(
        api_url, "credit_bureau_with_deal_ref", cb_post=True
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {bureau_resp}"
        )

    bureau_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId, updated_timestamp=lead_timestamp
    )
    assert bureau_timestamp > lead_timestamp

    # Saving second post payload for verification
    cb_payload = deal_data.payload

    # Posting a credit app using the dealRefId
    json_file_name = "credit_app_max_data.json"
    deal_data.set_payload(f"credit_app/{json_file_name}")
    # Update dealRefIdFD in payload
    deal_data.payload["dealRefIdFD"] = deal_data.generate_random_id(True)
    status_code, app_resp, resp_headers = deal_data.post_request(
        api_url, "credit_app_with_deal_ref", lead_resp.get("dealRefId")
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {app_resp}"
        )

    app_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId, updated_timestamp=bureau_timestamp
    )
    assert app_timestamp > bureau_timestamp

    records, count = get_records_by_deal_ref_id(lead_resp.get("dealRefId"))

    # # Validation
    assert resp_headers.get("X-CoxAuto-Correlation-Id") is not None

    # Verify that Bureau, App and lead ids are generated and store in db
    assert lead_resp.get("leadRefId") == get_response_data(records, "DEAL").get(
        "leadRefId"
    )
    # Out of scope until team figure out how to handle multiple creditBureauRefId
    # assert deal_data.cbRefId == get_response_data(records, "DEAL").get(
    #     "creditBureauRefId"
    # )
    assert app_resp.get("creditAppId") == get_response_data(records, "DEAL").get(
        "creditAppId"
    )

    # Verify top level fields
    top_resp_data = get_response_data(records, "DEAL")

    fields_list = [
        "financeMethod",
        "sourcePartnerDealerId",
        "partnerSource",
        "comments",
        "regulationBIndicator",
    ]
    verify_list_of_given_fields(deal_data.payload, top_resp_data, fields_list)

    # Verify Target Platforms
    target_payload = deal_data.payload.get("targetPlatforms")
    target_resp = get_response_data(records, "DEAL").get("targetPlatforms")
    verify_get_response_against_posted_data(target_payload, target_resp, "id")

    # Data from first post not in second or third payloads
    verify_deal_component(records, lead_payload, "decisionSummary")

    # Verify data from second post is saved
    fields_list = ["sourcePartnerId"]
    top_resp = get_response_data(records, "DEAL")
    verify_list_of_given_fields(cb_payload, top_resp, fields_list)

    coapp_add_payload = deal_data.payload.get("coApplicant").get("address")
    coapp_add_resp = get_response_data(records, "COAPPLICANT").get("address")
    verify_get_response_against_posted_data(coapp_add_payload, coapp_add_resp)

    # Verify data from the third post
    fields_list = ["firstName", "lastName", "phone"]

    guar_top_payload = deal_data.payload.get("guarantor")
    guar_top_resp = get_response_data(records, "GUARANTOR")
    verify_list_of_given_fields(guar_top_payload, guar_top_resp, fields_list)

    guar_add_payload = (
        deal_data.payload.get("guarantor")
        .get("currentEmployment")
        .get("employerAddress")
    )
    guar_add_resp = get_response_data(records, "GUARANTOR").get(
        "currentEmployment_employerAddress"
    )
    verify_get_response_against_posted_data(guar_add_payload, guar_add_resp)

    # verify Driver Info
    fields_list = ["firstName", "lastName", "phone"]
    driver_top_payload = deal_data.payload.get("guarantor")
    driver_top_resp = get_response_data(records, "GUARANTOR")
    verify_list_of_given_fields(driver_top_payload, driver_top_resp, fields_list)

    driver_add_payload = (
        deal_data.payload.get("guarantor")
        .get("currentEmployment")
        .get("employerAddress")
    )
    driver_add_resp = get_response_data(records, "GUARANTOR").get(
        "currentEmployment_employerAddress"
    )
    verify_get_response_against_posted_data(driver_add_payload, driver_add_resp)

    # Verify data from the credit app saved to DB
    verify_deal_component(records, deal_data.payload, "vehicle")
    verify_deal_component(records, deal_data.payload, "tradeIns")
    verify_deal_component(records, deal_data.payload, "financeSummary")

    # Verify Report Data for Applicant
    app_report = cb_payload.get("applicant").get("reports")
    verify_credit_bureau_reports(
        app_report,
        records,
        "applicant",
        bureau_resp.get("creditBureauRefId"),
        "request",
    )

    # Verify Report Data for Co-Applicant
    app_report = cb_payload.get("coApplicant").get("reports")
    verify_credit_bureau_reports(
        app_report,
        records,
        "coApplicant",
        bureau_resp.get("creditBureauRefId"),
        "request",
    )

    verify_deal_component_protected(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, cb_payload, "coApplicant")
    verify_deal_component_protected(records, deal_data.payload, "guarantor")
    verify_deal_component_protected(records, deal_data.payload, "driver")

    # Verify leadRefId using key data get
    query_param = f"leadRefId={lead_resp.get('leadRefId')}"

    status_code, get_resp, resp_headers = deal_data.get_request(
        url=api_url, route_url="key_data_get", query_param=query_param
    )
    assert status_code == HTTPStatus.OK
    assert lead_resp.get("dealRefId") == get_resp[0]["dealRefId"]

    deal_resp = get_response_data(records, "DEAL")
    assert "dealRefIdFD" not in deal_resp


@pytest.mark.functional
def test_post_multiple_credit_bureaus_using_same_deal_ref_id(
    env,
    api_url,
    get_response_data,
    random_data_class,
    wait_with_no_retries,
    verify_deal_component,
    get_deal_updated_timestamp,
    get_records_by_deal_ref_id,
    verify_credit_bureau_reports,
    verify_deal_component_protected,
):
    """
    This test case is to post multiple credit bureaus using existing delRefId
    Step1: Submit a lead to leads endpoint
    Stet2: Submit multiple Credit Bureaus to Credit Bureau with dealRefId endpoint
    Each bureau should successfully save/updated in DynamoDb
    """
    json_file_name = "leads_min_data.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"leads/{json_file_name}",
    )
    # Posting a lead to leads POST endpoint
    status_code, lead_resp, resp_headers = deal_data.post_request(
        api_url,
        "leads",
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {lead_resp}"
        )

    lead_timestamp = get_deal_updated_timestamp(deal_ref_id=deal_data.dealRefId)

    # First credit bureau post using the dealRefId
    json_file_name = "app_redflag_ofac.json"
    deal_data.set_payload(f"credit_bureau/{json_file_name}")

    status_code, bureau_resp, resp_headers = deal_data.post_request(
        api_url, "credit_bureau_with_deal_ref", cb_post=True
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {bureau_resp}"
        )

    first_bureau_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId, updated_timestamp=lead_timestamp
    )
    assert first_bureau_timestamp > lead_timestamp

    first_cb_records, count = get_records_by_deal_ref_id(lead_resp.get("dealRefId"))

    # first credit bureau post
    first_cb_payload = deal_data.payload
    first_app_cb_id = deal_data.cbRefId

    # Validation
    # assert count == 8

    # Verify updated timestamp is greater than created timestamp
    assert get_response_data(first_cb_records, "DEAL").get(
        "createdTimestamp"
    ) < get_response_data(first_cb_records, "DEAL").get("updatedTimestamp")

    first_updated_time = get_response_data(first_cb_records, "DEAL").get(
        "updatedTimestamp"
    )

    # Second Credit Bureau Post
    json_file_name = "app_cb_equ_exp_tru.json"
    deal_data.set_payload(f"credit_bureau/{json_file_name}")

    status_code, bureau_resp, resp_headers = deal_data.post_request(
        api_url, "credit_bureau_with_deal_ref", cb_post=True
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {bureau_resp}"
        )

    second_bureau_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId, updated_timestamp=first_bureau_timestamp
    )
    assert second_bureau_timestamp > first_bureau_timestamp

    second_cb_records, count = get_records_by_deal_ref_id(lead_resp.get("dealRefId"))

    second_cb_payload = deal_data.payload
    second_app_cb_id = deal_data.cbRefId

    # Validation
    # assert count == 11

    # Verify updated timestamp is greater than first updated timestamp
    second_updated_time = get_response_data(second_cb_records, "DEAL").get(
        "updatedTimestamp"
    )
    assert first_updated_time < second_updated_time

    second_updated_time = get_response_data(second_cb_records, "DEAL").get(
        "updatedTimestamp"
    )

    # Third Credit Bureau Post
    json_file_name = "coapp_cb_softpull_equ_exp_tru_redflag_ofac.json"
    deal_data.set_payload(f"credit_bureau/{json_file_name}")

    status_code, bureau_resp, resp_headers = deal_data.post_request(
        api_url, "credit_bureau_with_deal_ref", cb_post=True
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {bureau_resp}"
        )

    third_bureau_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId, updated_timestamp=second_bureau_timestamp
    )
    assert third_bureau_timestamp > second_bureau_timestamp

    third_cb_records, count = get_records_by_deal_ref_id(lead_resp.get("dealRefId"))

    third_cb_payload = deal_data.payload
    third_app_cb_id = deal_data.cbRefId

    # Validation
    # assert count == 18

    # Verify updated timestamp is greater than first updated timestamp
    third_updated_time = get_response_data(third_cb_records, "DEAL").get(
        "updatedTimestamp"
    )
    assert second_updated_time < third_updated_time

    # Verify Report Data
    # first post report
    first_app_cb_report = first_cb_payload.get("applicant").get("reports")
    verify_credit_bureau_reports(
        first_app_cb_report, first_cb_records, "applicant", first_app_cb_id, "request"
    )

    # second post report
    second_app_cb_report = second_cb_payload.get("applicant").get("reports")
    verify_credit_bureau_reports(
        second_app_cb_report,
        second_cb_records,
        "applicant",
        second_app_cb_id,
        "request",
    )

    # third post report
    third_app_cb_report = third_cb_payload.get("coApplicant").get("reports")
    verify_credit_bureau_reports(
        third_app_cb_report, third_cb_records, "coApplicant", third_app_cb_id, "request"
    )

    verify_deal_component(third_cb_records, second_cb_payload, "applicant")
    verify_deal_component_protected(third_cb_records, second_cb_payload, "applicant")
    verify_deal_component(third_cb_records, third_cb_payload, "coApplicant")
    verify_deal_component_protected(third_cb_records, third_cb_payload, "coApplicant")


@pytest.mark.functional
def test_post_duplicate_credit_bureaus(
    env, api_url, random_data_class, wait_with_no_retries
):
    """
    This test case is to validate posting duplicate credit bureaus
    Step1: Submit a credit bureau to credit bureau endpoint
    Stet2: Submit a another Credit Bureaus to Credit Bureau with dealRefId endpoint
    proper validation message should displays
    """
    json_file_name = "app_redflag_ofac.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_bureau/{json_file_name}",
    )

    # Initial bureau is created
    status_code, bureau_resp, resp_headers = deal_data.post_request(
        api_url, "credit_bureau", cb_post=True
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {bureau_resp}"
        )
    wait_with_no_retries()
    json_file_name = "coapp_cb_equ_redflag_ofac.json"
    deal_data.set_payload(f"credit_bureau/{json_file_name}")

    # Post second bureau using existing dealRefId and creditBureauRefId
    status_code, dup_lead_resp, resp_headers = deal_data.post_request(
        api_url, "credit_bureau_with_deal_ref", cb_post=True, generate_id=False
    )

    # Validate that the second bureau isn't created and expected validation error message is returned
    assert status_code == HTTPStatus.BAD_REQUEST
    assert (
        dup_lead_resp.get("message")
        == "You have tired to post to an endpoint for which the resource already exists."
    )


@pytest.mark.functional
def test_post_credit_bureau_using_invalid_deal_ref_id(
    env, api_url, random_data_class, get_records_by_deal_ref_id
):
    """
    This test case is to validate proper error message is displayed for posting credit bureaus
    using invalid dealRefId
    Step1: Submit a credit bureau to credit bureau endpoint
    Stet2: Submit a another Credit Bureaus to Credit Bureau with invalid dealRefId
    proper validation message should displays
    """
    json_file_name = "leads_min_data.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"leads/{json_file_name}",
    )
    # Posting a lead to leads POST endpoint
    status_code, lead_resp, resp_headers = deal_data.post_request(
        api_url,
        "leads",
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {lead_resp}"
        )

    # Generate a new ID
    deal_data.dealRefId = deal_data.generate_random_id()

    json_file_name = "app_cb_softpull_redflag_ofac.json"
    deal_data.set_payload(f"credit_bureau/{json_file_name}")

    status_code, bureau_resp, resp_headers = deal_data.post_request(
        api_url, "credit_bureau_with_deal_ref", cb_post=True
    )

    # Validate proper error message is return for invalid dealRefId
    assert status_code == HTTPStatus.BAD_REQUEST
    assert bureau_resp.get("message") == ErrorMsgs.missing_deal_from_db.format(
        deal_ref_id=deal_data.dealRefId
    )


@pytest.mark.functional
def test_post_credit_bureau_with_dealrefid_invalid_test_data(
    env, api_url, random_data_class, invalid_payload
):
    """
    This test case is validate that the credit bureau api returns proper error for posting with invalid json
    """
    json_file_name = "leads_min_data.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"leads/{json_file_name}",
    )
    status_code, leads_response, resp_headers = deal_data.post_request(
        api_url,
        "leads",
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {leads_response}"
        )

    deal_data = ServiceAPI(
        env=env, random_data_class=random_data_class, payload=invalid_payload
    )

    status_code, response, resp_headers = deal_data.post_request(
        api_url, "credit_bureau_with_deal_ref", cb_post=True
    )
    assert resp_headers.get("X-CoxAuto-Correlation-Id") is not None
    assert status_code == HTTPStatus.BAD_REQUEST


@pytest.mark.prod
@pytest.mark.smoke
@pytest.mark.functional
def test_deal_with_deal_ref_id_credit_app_post_without_source_partner_dealer_id_for_non_dtc(
    env, api_url, random_data_class, get_deal_updated_timestamp
):
    """
    This test case is to associate a credit application to an existing lead using delRefId
    Validate partyId from 2nd post(CA) is NOT saved as sourcePartnerDealerId in key-data
    Saving sourcePartnerDealerId is supported for a new deal only
    Step1: Submit a lead to leads endpoint
    Stet2: Submit a credit app to credit app with dealRefId endpoint
    """
    json_file_name = "ind_retail_new_decision.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"leads/{json_file_name}",
    )
    # Update targetPlatforms to empty list
    deal_data.payload["targetPlatforms"] = []

    # Posting a lead to leads POST endpoint
    status_code, lead_resp, resp_headers = deal_data.post_request(
        api_url,
        "leads",
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {lead_resp}"
        )

    # Confirm Lead is saved in db successfully
    lead_timestamp = get_deal_updated_timestamp(deal_data.dealRefId)

    # Posting a credit app using the dealRefId
    json_file_name = "app_guar_references_cash_new.json"
    deal_data.set_payload(f"credit_app/{json_file_name}")
    # remove sourcePartnerDealerId from payload if present
    deal_data.payload.pop("sourcePartnerDealerId", None)

    status_code, app_resp, resp_headers = deal_data.post_request(
        api_url,
        "credit_app_with_deal_ref",
        lead_resp.get("dealRefId"),
    )
    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {app_resp}"
        )

    # Confirm app is saved in db successfully
    app_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId, updated_timestamp=lead_timestamp
    )
    assert app_timestamp > lead_timestamp

    # Get Key-Data
    query_param = f"dealRefId={deal_data.dealRefId}"
    status_code, get_resp, resp_headers = deal_data.get_request(
        url=api_url, route_url=KEY_DATA_ROUTE, query_param=query_param
    )
    # partyId from targetPlatforms
    assert get_resp[0].get("sourcePartnerDealerId") is None


@pytest.mark.smoke
@pytest.mark.functional
def test_deal_with_deal_ref_id_lead_post_without_source_partner_dealer_id_for_non_dtc(
    env,
    api_url,
    random_data_class,
    get_deal_updated_timestamp,
):
    """
    This test case is to associate a leads to an existing credit application using delRefId
    Validate partyId from 2nd post(lead) is NOT saved as sourcePartnerDealerId in key-data
    Saving sourcePartnerDealerId is supported for a new deal only
    Step1: Submit a credit application to credit application endpoint
    Stet2: Submit a leads to leads with dealRefId endpoint
    """
    json_file_name = "joint_retail_certified.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    # Update targetPlatforms to empty list
    deal_data.payload["targetPlatforms"] = []
    status_code, app_resp, resp_headers = deal_data.post_request(
        api_url,
        "credit_app",
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {app_resp}"
        )

    # Confirm Lead is saved in db successfully
    app_timestamp = get_deal_updated_timestamp(deal_data.dealRefId)

    # Posting a lead using the dealRefId
    json_file_name = "ind_cash_new_decision_session.json"
    deal_data.set_payload(f"leads/{json_file_name}")
    # remove sourcePartnerDealerId from payload if present
    deal_data.payload.pop("sourcePartnerDealerId", None)
    status_code, lead_resp, resp_headers = deal_data.post_request(
        api_url, "leads_with_deal_ref", app_resp["dealRefId"]
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {lead_resp}"
        )

    # Confirm app is saved in db successfully
    lead_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId, updated_timestamp=app_timestamp
    )
    assert lead_timestamp > app_timestamp

    # Get Key-Data
    query_param = f"dealRefId={deal_data.dealRefId}"
    status_code, get_resp, resp_headers = deal_data.get_request(
        url=api_url, route_url=KEY_DATA_ROUTE, query_param=query_param
    )
    # partyId from targetPlatforms
    assert get_resp[0].get("sourcePartnerDealerId") is None
