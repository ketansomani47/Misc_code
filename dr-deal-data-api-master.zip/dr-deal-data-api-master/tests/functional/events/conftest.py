# -*- coding: utf-8 -*-
import pytest
import ulid


@pytest.fixture
def update_sample_credit_app():
    def wrapper(payload, source_partner_id):
        payload.update(
            {
                "appRefIdFD": "5784459096",
                "lenderId": "AHC",
                "partnerCode": "508",
                "sourcePartnerDealerId": "12345_TEST",
                "sourcePartnerId": source_partner_id,
                "dealerCodeIDL": "105786",
                "dealJacketIdIDL": "9797163803",
                "dealerId": None,
            }
        )
        return payload

    return wrapper


@pytest.fixture()
def generate_decision_record():
    def decision_payload(lender_id):
        return {
            "approvalStatus": "Approved",
            "approvedAmount": "29088",
            "approvedRate": "5",
            "approvedTerm": "60",
            "customerMoneyFactor": "0.002",
            "downPayment": "4380",
            "financeMethod": "Retail",
            "lenderId": lender_id,
            "lenderMoneyFactor": "0.005",
            "lenderName": "American Honda Finance Corporation",
            "monthlyPayment": "458",
            "stipulations": [{"text": "test1"}, {"text": "test2"}],
            "tier": "Gold",
        }

    return decision_payload


@pytest.fixture
def sample_credit_app_decision_payload():
    def wrapper(deal_ref_id):
        return {
            "eventEntityId": "105786",
            "eventId": ulid.new().str,
            "eventIdentityId": "105786",
            "eventName": "Deal:CreditDecisionResponse",
            "eventSource": "AHC:decisions",
            "eventTime": "2021-11-09T10:32:28.781979Z",
            "eventTransactionId": deal_ref_id,
            "eventType": "AHC:decisions",
            "eventVersion": "1.0",
            "payload": {
                "approvalStatus": "Approved",
                "approvedAmount": 25191.24,
                "approvedRate": 1.9,
                "approvedTerm": 60,
                "customerMoneyFactor": None,
                "downPayment": 5880,
                "financeMethod": "Retail",
                "lenderId": "AHC",
                "lenderMoneyFactor": 1.9,
                "lenderName": "American Honda Finance Corporation",
                "monthlyPayment": 440,
                "stipulations": ["Rate Advance Term Limit to Approval"],
                "tier": "05",
                "lenderApplicationId": "AHF2525654",
                "rateVariance": 1.25,
            },
            "payloadSchema": "DealDecisionsSummary/v1.0",
            "payloadSchemaHref": "",
        }

    return wrapper


@pytest.fixture
def expected_credit_app_decision_events_framework():
    def wrapper(event_id, deal_ref_id):
        return {
            "eventVersion": "1.2",
            "eventId": event_id,
            "eventEntityId": "105786",
            "eventTransactionId": deal_ref_id,
            "eventName": "CreditDecisions:Approved",
            "eventType": "ideal:CreditDecisions",
            "eventSource": "ideal:Deals",
            "eventDetailHref": None,
            "payload": {
                "status": "Approved",
                "approvedAmount": "25191.24",
                "approvedRate": "1.9",
                "approvedTerm": 60,
                "lenderId": "AHC",
                "lenderName": "American Honda Finance Corporation",
                "tier": "05",
                "stipulations": [{"text": "Rate Advance Term Limit to Approval"}],
                "monthlyPayment": 440,
                "lenderMoneyFactor": "1.9",
                "customerMoneyFactor": None,
                "downPayment": 5880,
                "financeMethod": "Retail",
                "lenderApplicationId": "AHF2525654",
                "rateVariance": "1.25",
            },
            "eventKeyData": {
                "appRefIdFD": "5784459096",
                "dealRefIdDR": deal_ref_id,
                "lenderId": "AHC",
                "partnerCode": "508",
                "sourcePartnerDealerId": "12345_TEST",
                "sourcePartnerId": "DXR",
                "dealerCode": "105786",
                "dealJacketId": "9797163803",
                "dealerId": "105786",
            },
        }

    return wrapper
