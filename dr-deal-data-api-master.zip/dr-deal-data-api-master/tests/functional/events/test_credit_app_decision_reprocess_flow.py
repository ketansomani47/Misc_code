# -*- coding: utf-8 -*-
from http import HTTPStatus
from uuid import uuid4

import pytest
from tests.functional.service_api import ServiceAPI


API_ROUTE = "credit_app"
EVENTS_ROUTE = "events"


@pytest.mark.smoke
@pytest.mark.prod
@pytest.mark.functional
def test_reprocess_event_details(
    env,
    api_url,
    query_dynamodb,
    random_data_class,
    sample_credit_app_decision_payload,
    update_sample_credit_app,
    get_deal_component_details,
    wait_with_no_retries,
):
    deal_component = "AHC.DECISION"
    json_file_name = "ind_lease_cert_trade.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    # Set sourcePartnerId to DXR so all events should redirect to E.F.
    deal_data.payload = update_sample_credit_app(deal_data.payload, "DXR")

    # Add dealRefId & creditAppId in header
    fs_header_value = {
        "X-Deal-Reference-Id": deal_data.generate_random_id(True),
        "X-Credit-Application-Reference-Id": deal_data.generate_random_id(True),
    }

    # Post a Credit App
    status_code, response, resp_headers = deal_data.post_request(
        api_url, API_ROUTE, cust_header=fs_header_value
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )

    # Post a Events
    deal_data.payload = sample_credit_app_decision_payload(deal_data.dealRefId)
    deal_data.request_type = "events"
    headers = {"X-CoxAuto-Correlation-Id": f"{uuid4()}_TEST"}
    status_code, response, resp_headers = deal_data.post_request(
        api_url, EVENTS_ROUTE, cust_header=headers
    )

    if status_code != HTTPStatus.OK:
        raise Exception(
            f"Response code is: {response.status_code} and the response message is: {response}"
        )

    event_data = get_deal_component_details(deal_data.dealRefId, deal_component)

    # Decision Posted Timestamp
    app_posted_time = event_data.get("createdTimestamp")

    # Null out payload to reprocess a deal as it is not required for reprocessing
    deal_data.payload = None

    # Reprocess the failed app
    status_code, response, resp_headers = deal_data.patch(api_url, "event_reprocess")

    if status_code != HTTPStatus.NO_CONTENT:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )

    wait_with_no_retries()
    patch_event_data = get_deal_component_details(deal_data.dealRefId, deal_component)

    # App Reprocess Timestamp
    app_rep_time = patch_event_data.get("updatedTimestamp")

    assert app_rep_time == app_posted_time


@pytest.mark.smoke
@pytest.mark.prod
@pytest.mark.functional
def test_reprocess_event_details_with_bad_data(
    env, api_url, random_data_class, ca_event_payload
):
    deal_ref_id = ServiceAPI.generate_random_id()
    ca_event_payload["eventTransactionId"] = deal_ref_id

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        payload=ca_event_payload,
        request_type="event",
    )
    deal_data.creditAppId = "AHC.DECISION"
    deal_data.dealRefId = deal_ref_id

    status_code, response, resp_headers = deal_data.patch(
        api_url, "event_reprocess", cust_status_code=HTTPStatus.BAD_REQUEST
    )
    bad_request = HTTPStatus.BAD_REQUEST
    assert (
        status_code == bad_request
    ), f"Failed: Actual: {status_code}, Expected: {bad_request}"
