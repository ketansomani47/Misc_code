# -*- coding: utf-8 -*-
import json
from http import HTTPStatus

import pytest
from tests.functional.service_api import ServiceAPI


@pytest.mark.prod
@pytest.mark.functional
def test_credit_bureau_response_via_events_app(
    api_url, env, random_data_class, cb_event_payload
):
    json_file_name = "app_cb_equ_exp_tru.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_bureau/{json_file_name}",
    )

    # Saving post payload
    cb_payload = deal_data.payload
    deal_data = ServiceAPI(
        env=env, random_data_class=random_data_class, payload=cb_event_payload
    )
    deal_data.update_payload_with_bureau_key_data(cb_event_payload, cb_payload, True)

    status_code, response, resp_headers = deal_data.post_request(api_url, "events")

    # CB event payload
    cb_event_payload = json.loads(deal_data.payload)

    assert status_code == HTTPStatus.OK
    assert response.get("status") == "SUCCESS"

    get_response, headers = deal_data.get_decision_payload_from_virtual_endpoint(
        cb_event_payload.get("eventTransactionId")
    )
    if isinstance(get_response, list) and get_response.__len__() > 0:
        get_response = get_response[0]
    assert cb_event_payload == get_response


@pytest.mark.smoke
@pytest.mark.functional
def test_credit_bureau_response_via_events_app_coapp(
    api_url, env, random_data_class, cb_event_payload
):
    json_file_name = "app_coapp_cb_exp_equ_tru_redflag_ofac.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_bureau/{json_file_name}",
    )

    # Saving post payload
    cb_payload = deal_data.payload

    deal_data = ServiceAPI(
        env=env, random_data_class=random_data_class, payload=cb_event_payload
    )

    deal_data.update_payload_with_bureau_key_data(
        cb_event_payload, is_virtual=True, cb_payload=cb_payload
    )

    status_code, response, resp_headers = deal_data.post_request(api_url, "events")

    # CB event payload
    cb_event_payload = json.loads(deal_data.payload)

    assert status_code == HTTPStatus.OK
    assert response.get("status") == "SUCCESS"

    get_response, headers = deal_data.get_decision_payload_from_virtual_endpoint(
        cb_event_payload.get("eventTransactionId")
    )
    if isinstance(get_response, list) and get_response.__len__() > 0:
        get_response = get_response[0]
    assert cb_event_payload == get_response


@pytest.mark.functional
def test_credit_bureau_response_via_events_invalid_payload(
    api_url, env, random_data_class, invalid_payload
):

    deal_data = ServiceAPI(
        env=env, random_data_class=random_data_class, payload=invalid_payload
    )

    status_code, response, resp_headers = deal_data.post_request(api_url, "events")

    assert status_code == HTTPStatus.BAD_REQUEST
