# -*- coding: utf-8 -*-
from http import HTTPStatus
from uuid import uuid4

import pytest
from tests.functional.service_api import ServiceAPI


API_ROUTE = "credit_app"
EVENTS_ROUTE = "events"


@pytest.mark.smoke
@pytest.mark.prod
@pytest.mark.functional
def test_credit_app_decision_submission_to_events_framework(
    env,
    api_url,
    query_dynamodb,
    random_data_class,
    sample_credit_app_decision_payload,
    update_sample_credit_app,
    expected_credit_app_decision_events_framework,
):
    json_file_name = "ind_lease_cert_trade.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    # Set sourcePartnerId to non DVM so all events should redirect to events framework
    deal_data.payload = update_sample_credit_app(deal_data.payload, "DXR")

    # Add dealRefId & creditAppId in header
    fs_header_value = {
        "X-Deal-Reference-Id": deal_data.generate_random_id(True),
        "X-Credit-Application-Reference-Id": deal_data.generate_random_id(True),
    }

    # Post a Credit App
    status_code, response, resp_headers = deal_data.post_request(
        api_url, API_ROUTE, cust_header=fs_header_value
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )

    # Post to Events
    deal_data.payload = sample_credit_app_decision_payload(deal_data.dealRefId)
    deal_data.request_type = "events"
    headers = {"X-CoxAuto-Correlation-Id": f"{uuid4()}_TEST"}
    status_code, response, resp_headers = deal_data.post_request(
        api_url, EVENTS_ROUTE, cust_header=headers
    )

    if status_code != HTTPStatus.OK:
        raise Exception(
            f"Response code is: {response.status_code} and the response message is: {response}"
        )

    events_payload, headers = deal_data.get_decision_payload_from_virtual_endpoint(
        deal_data.dealRefId
    )
    response, count = query_dynamodb(deal_data.dealRefId)
    actual_deal_ref_id_from_deals = response[0].get("eventTransactionId")
    # assert count == 10
    assert actual_deal_ref_id_from_deals == deal_data.dealRefId
    assert "lenderApplicationId" in events_payload["payload"]
    assert (
        events_payload.items()
        >= expected_credit_app_decision_events_framework(
            event_id=deal_data.payload["eventId"], deal_ref_id=deal_data.dealRefId
        ).items()
    )
