# -*- coding: utf-8 -*-
import pytest
import secrets
from http import HTTPStatus
from common.settings import ErrorMsgs
from tests.functional.service_api import ServiceAPI

LEAD_ROUTE = "leads"
APP_ROUTE = "credit_app"
KEY_DATA_ROUTE = "key_data_get_v2"


@pytest.mark.functional
def test_leads_post_guar_balloon_demo_trades_deal_ref_id_in_header(
    env,
    api_url,
    common_assert,
    random_data_class,
    validate_v2_key_data,
    verify_deal_component,
    validate_deal_data_keys,
    get_records_by_deal_ref_id,
    get_deal_component_details,
    verify_deal_component_protected,
    query_dynamodb_with_deal_component,
):
    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file="leads/guar_balloon_demo_trades.json",
    )

    # Add dealRefId in header - same value would be use for leadRefId
    fs_header_value = {
        "X-Deal-Reference-Id": deal_data.generate_random_id(True),
        "X-Lead-Reference-Number": deal_data.generate_random_id(True),
    }

    # Post Lead with FS IDs
    status_code, response, resp_headers = deal_data.post_request(
        api_url, LEAD_ROUTE, cust_header=fs_header_value
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    get_deal_component_details(
        deal_ref_id=deal_data.dealRefId, deal_component="REF_IDS.DTC"
    )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == 8
    db_resp = query_dynamodb_with_deal_component(deal_data.dealRefId, "DTC.DEAL")
    validate_deal_data_keys(response, db_resp[0], fs_header_value)
    common_assert(records=records, resp_headers=resp_headers)

    verify_deal_component(records, deal_data.payload, "guarantor")
    verify_deal_component_protected(records, deal_data.payload, "guarantor")

    # Verify leadRefId for key data get
    query_param = f"leadRefId={response.get('leadRefId')}"
    status_code, get_resp, resp_headers = deal_data.get_request(
        url=api_url, route_url="key_data_get", query_param=query_param
    )
    assert status_code == HTTPStatus.OK
    assert response.get("dealRefId") == get_resp[0]["dealRefId"]
    assert "dealRefIdFD" in get_resp[0]

    #  Validate v2 key-data record for DTA
    v2_record = get_deal_component_details(
        response.get("dealRefId"), deal_component="REF_IDS.DTA"
    )
    validate_v2_key_data(
        posted_payload={**fs_header_value, **response},
        database_resp=v2_record,
        key_name="DTA",
    )
    #  For a lead, there is no app record


@pytest.mark.functional
@pytest.mark.prod
def test_leads_post_min_data(
    env,
    api_url,
    common_assert,
    random_data_class,
    verify_deal_component,
    validate_deal_data_keys,
    get_records_by_deal_ref_id,
    query_dynamodb_with_deal_component,
):
    json_file_name = "leads_min_data.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"leads/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, LEAD_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )

    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))

    # assert count == 5
    db_resp = query_dynamodb_with_deal_component(deal_data.dealRefId, "DTC.DEAL")
    validate_deal_data_keys(response, db_resp[0])
    common_assert(records=records, resp_headers=resp_headers)

    verify_deal_component(records, deal_data.payload, "applicant")


@pytest.mark.functional
@pytest.mark.prod
def test_leads_post_max_app_coapp_guarantor_driver_with_deal_ref_id_fd_in_payload(
    env,
    api_url,
    common_assert,
    random_data_class,
    verify_deal_component,
    validate_deal_data_keys,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
    query_dynamodb_with_deal_component,
):
    json_file_name = "max_app_coapp_guarantor_driver.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"leads/{json_file_name}",
    )
    deal_data.payload["dealRefIdFD"] = deal_data.generate_random_id(True)
    status_code, response, resp_headers = deal_data.post_request(api_url, LEAD_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )

    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))

    # assert count == 19
    db_resp = query_dynamodb_with_deal_component(deal_data.dealRefId, "DTC.DEAL")
    assert "dealRefIdFD" in db_resp[0]
    validate_deal_data_keys(response, db_resp[0])
    common_assert(records=records, resp_headers=resp_headers)

    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")
    verify_deal_component(records, deal_data.payload, "coApplicant")
    verify_deal_component_protected(records, deal_data.payload, "coApplicant")
    verify_deal_component(records, deal_data.payload, "guarantor")
    verify_deal_component_protected(records, deal_data.payload, "guarantor")


@pytest.mark.smoke
@pytest.mark.functional
def test_leads_post_retail_new_driver_with_pii(
    env,
    api_url,
    common_assert,
    random_data_class,
    verify_deal_component,
    validate_deal_data_keys,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
    query_dynamodb_with_deal_component,
):
    json_file_name = "retail_new_driver_with_pii.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"leads/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, LEAD_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )

    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))

    # assert count == 12
    db_resp = query_dynamodb_with_deal_component(deal_data.dealRefId, "DTC.DEAL")
    validate_deal_data_keys(response, db_resp[0])
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")
    verify_deal_component(records, deal_data.payload, "guarantor")
    verify_deal_component_protected(records, deal_data.payload, "guarantor")
    verify_deal_component(records, deal_data.payload, "driver")
    verify_deal_component_protected(records, deal_data.payload, "driver")


@pytest.mark.smoke
@pytest.mark.functional
def test_leads_post_app_coapp_retail_new_null_and_empty_string(
    env,
    api_url,
    common_assert,
    random_data_class,
    verify_deal_component,
    validate_deal_data_keys,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
    query_dynamodb_with_deal_component,
):
    json_file_name = "app_coapp_retail_new_null_and_empty_string.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"leads/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, LEAD_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )

    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))

    # assert count == 9
    db_resp = query_dynamodb_with_deal_component(deal_data.dealRefId, "DTC.DEAL")
    validate_deal_data_keys(response, db_resp[0])
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")
    verify_deal_component(records, deal_data.payload, "coApplicant")
    verify_deal_component_protected(records, deal_data.payload, "coApplicant")


@pytest.mark.functional
def test_leads_post_retail_new_coapp_random_node(
    env,
    api_url,
    common_assert,
    random_data_class,
    verify_deal_component,
    validate_deal_data_keys,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
    query_dynamodb_with_deal_component,
):
    json_file_name = "retail_new_coapp_random_node.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"leads/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, LEAD_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )

    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == 7
    db_resp = query_dynamodb_with_deal_component(deal_data.dealRefId, "DTC.DEAL")
    validate_deal_data_keys(response, db_resp[0])
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "coApplicant")
    verify_deal_component_protected(records, deal_data.payload, "coApplicant")


@pytest.mark.functional
def test_leads_post_ind_retail_new_decision(
    env,
    api_url,
    common_assert,
    random_data_class,
    verify_deal_component,
    validate_deal_data_keys,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
    query_dynamodb_with_deal_component,
):
    json_file_name = "ind_retail_new_decision.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"leads/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, LEAD_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )

    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == 8
    db_resp = query_dynamodb_with_deal_component(deal_data.dealRefId, "DTC.DEAL")
    validate_deal_data_keys(response, db_resp[0])
    common_assert(records=records, resp_headers=resp_headers)

    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")


@pytest.mark.functional
def test_leads_post_ind_lease_cert_trade_session(
    env,
    api_url,
    common_assert,
    random_data_class,
    verify_deal_component,
    validate_deal_data_keys,
    get_deal_component_details,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
    query_dynamodb_with_deal_component,
):
    json_file_name = "ind_lease_cert_trade_session.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"leads/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, LEAD_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )

    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == 9
    db_resp = query_dynamodb_with_deal_component(deal_data.dealRefId, "DTC.DEAL")
    validate_deal_data_keys(response, db_resp[0])
    common_assert(records=records, resp_headers=resp_headers)

    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")

    # Validate sourcePartnerDealerId is saved in DB
    for target in deal_data.payload["targetPlatforms"]:
        v2_record = get_deal_component_details(
            deal_data.dealRefId, deal_component=f"REF_IDS.{target['id']}"
        )
        assert (
            v2_record.get("sourcePartnerDealerId") == target["partyId"]
        ), f"partyId did not save in key-data as sourcePartnerDealerId for {target}"


@pytest.mark.smoke
@pytest.mark.functional
def test_leads_post_ind_cash_new_decision_session(
    env,
    api_url,
    common_assert,
    random_data_class,
    verify_deal_component,
    validate_deal_data_keys,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
    query_dynamodb_with_deal_component,
):
    json_file_name = "ind_cash_new_decision_session.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"leads/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, LEAD_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )

    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == 10
    db_resp = query_dynamodb_with_deal_component(deal_data.dealRefId, "DTC.DEAL")
    validate_deal_data_keys(response, db_resp[0])
    common_assert(records=records, resp_headers=resp_headers)

    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")


@pytest.mark.functional
def test_leads_post_app_coapp_guar_spouse_balloon_cert(
    env,
    api_url,
    common_assert,
    random_data_class,
    verify_deal_component,
    validate_deal_data_keys,
    get_deal_component_details,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
    query_dynamodb_with_deal_component,
):
    json_file_name = "app_coapp_guar_spouse_balloon_cert.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"leads/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, LEAD_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )

    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == 20
    db_resp = query_dynamodb_with_deal_component(deal_data.dealRefId, "DTC.DEAL")
    validate_deal_data_keys(response, db_resp[0])
    common_assert(records=records, resp_headers=resp_headers)

    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")
    verify_deal_component(records, deal_data.payload, "coApplicant")
    verify_deal_component_protected(records, deal_data.payload, "coApplicant")
    verify_deal_component(records, deal_data.payload, "guarantor")
    verify_deal_component_protected(records, deal_data.payload, "guarantor")

    # Validate sourcePartnerDealerId is saved in DB
    for target in deal_data.payload["targetPlatforms"]:
        v2_record = get_deal_component_details(
            deal_data.dealRefId, deal_component=f"REF_IDS.{target['id']}"
        )
        assert (
            v2_record.get("sourcePartnerDealerId") == target["partyId"]
        ), f"partyId did not save in key-data as sourcePartnerDealerId for {target}"


@pytest.mark.functional
def test_leads_post_ind_retail_new_no_income_empty_keys_in_header(
    env,
    api_url,
    common_assert,
    random_data_class,
    verify_deal_component,
    validate_deal_data_keys,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
    query_dynamodb_with_deal_component,
):
    json_file_name = "ind_retail_new_no_income.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"leads/{json_file_name}",
    )

    # Add dealRefId & creditAppId in header
    fs_header_value = {
        "X-Deal-Reference-Id": "",
        "X-Credit-Application-Reference-Id": "",
    }

    status_code, response, resp_headers = deal_data.post_request(
        api_url, LEAD_ROUTE, cust_header=fs_header_value
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )

    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == 8
    db_resp = query_dynamodb_with_deal_component(deal_data.dealRefId, "DTC.DEAL")
    validate_deal_data_keys(response, db_resp[0], fs_header_value)
    common_assert(records=records, resp_headers=resp_headers)

    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")

    # Key data GET after a lead post
    # Search query for key data - dealRefId
    query_param = f"dealRefId={response.get('dealRefId')}"

    status_code, get_resp, resp_headers = deal_data.get_request(
        url=api_url, route_url="key_data_get", query_param=query_param
    )
    assert status_code == HTTPStatus.OK


@pytest.mark.smoke
@pytest.mark.functional
def test_leads_invalid_deal_ref_id_in_header(env, api_url, random_data_class):
    json_file_name = "leads_min_data.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"leads/{json_file_name}",
    )

    # Add dealRefId
    # dealRefId is non-ulid
    fs_header_value = {"X-Deal-Reference-Id": deal_data.generate_random_id()}

    # Post a lead
    status_code, response, resp_headers = deal_data.post_request(
        api_url, LEAD_ROUTE, cust_header=fs_header_value
    )

    if status_code != HTTPStatus.BAD_REQUEST:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )

    posted_id_len = len(fs_header_value.get("X-Deal-Reference-Id"))
    assert (
        response.get("message")
        == f"Invalid ulid provided. Error Expects 26 characters for decoding; got {posted_id_len}"
    )


@pytest.mark.smoke
@pytest.mark.functional
def test_leads_post_with_invalid_test_data(
    api_url, env, random_data_class, invalid_payload
):
    deal_data = ServiceAPI(
        env=env, random_data_class=random_data_class, payload=invalid_payload
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, LEAD_ROUTE)
    assert resp_headers.get("X-CoxAuto-Correlation-Id") is not None
    assert status_code == HTTPStatus.BAD_REQUEST


@pytest.mark.functional
def test_leads_post_with_additional_key_data(
    env,
    api_url,
    random_data_class,
    verify_deal_component,
    get_records_by_deal_ref_id,
):
    payload = {"sourcePartnerId": "VIN", "sourcePartnerDealerId": "123456789"}

    deal_data = ServiceAPI(
        random_data_class=random_data_class, env=env, payload=payload
    )
    add_keys_header = {
        "X-Lead-Reference-Number": deal_data.generate_random_id(),
        "X-Application-Reference-Number": deal_data.generate_random_id(),
        "X-Lead-Reference-Number-Internal": deal_data.generate_random_id(),
        "X-Application-Reference-Number-Internal": deal_data.generate_random_id(),
        "X-Deal-Jacket-ID": deal_data.generate_random_id(),
        "X-Dealer-Code": "6",
        "X-Deal-Reference-Number-UniFI": deal_data.generate_random_id(),
        "X-ABCD-ID": deal_data.generate_random_id(),
    }

    status_code, response, resp_headers = deal_data.post_request(
        api_url, LEAD_ROUTE, cust_header=add_keys_header
    )

    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    payload.update(add_keys_header)
    verify_deal_component(records, payload, "deal", additional_header_keys=True)


@pytest.mark.functional
def test_lead_with_existing_deal_ref_id_in_header(
    env,
    api_url,
    random_data_class,
    get_records_by_deal_ref_id,
):
    """
    Test case is to validate that a validation error is returns when a lead is posted
    with existing deadRefId in header
    Step1: Create a lead using lead post endpoint
    Stet2: Post a credit app using post credit app endpoint and passing dealRefId from lead post to header
    Expected: credit app post with dealRefId should be use
    """
    lead_file = "leads/ind_cash_new_decision_session.json"
    ca_file = "credit_app/joint_retail_certified.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class, env=env, json_file=ca_file
    )

    status_code, app_resp, resp_headers = deal_data.post_request(api_url, APP_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {app_resp}"
        )

    # Post a lead using the dealRefId in header
    deal_data.set_payload(lead_file)
    add_keys_header = {
        "X-Deal-Reference-Id": deal_data.dealRefId,
    }
    status_code, lead_resp, resp_headers = deal_data.post_request(
        api_url, LEAD_ROUTE, cust_header=add_keys_header
    )

    if status_code != HTTPStatus.BAD_REQUEST:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {lead_resp}"
        )
    assert lead_resp["message"] == ErrorMsgs.deal_ref_id_already_exists.format(
        deal_ref_id=deal_data.dealRefId
    )


@pytest.mark.smoke
@pytest.mark.prod
@pytest.mark.functional
def test_lead_post_without_source_partner_dealer_id_for_non_dtc(
    env, api_url, random_data_class, get_deal_component_details
):
    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file="leads/retail_new_driver_with_pii.json",
    )
    # remove sourcePartnerDealerId from payload if present
    deal_data.payload.pop("sourcePartnerDealerId", None)
    deal_data.payload["targetPlatforms"][0]["partyId"] = None

    status_code, response, resp_headers = deal_data.post_request(
        api_url,
        LEAD_ROUTE,
    )
    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    # Conform deal is saved in db successfully
    get_deal_component_details(
        deal_ref_id=deal_data.dealRefId, deal_component="REF_IDS.IDL"
    )

    #  Get Key-Data
    query_param = f"dealRefId={deal_data.dealRefId}"
    status_code, get_resp, resp_headers = deal_data.get_request(
        url=api_url, route_url=KEY_DATA_ROUTE, query_param=query_param
    )

    idl_record = [item for item in get_resp if item["targetPlatformId"] == "IDL"]

    # partyId from targetPlatforms
    assert idl_record[0].get("sourcePartnerDealerId") is None


@pytest.mark.smoke
@pytest.mark.prod
@pytest.mark.functional
def test_lead_post_with_source_partner_dealer_id_in_payload(
    env, api_url, random_data_class, get_deal_component_details
):
    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file="leads/retail_new_driver_with_pii.json",
    )
    # Add sourcePartnerDealerId to the payload
    random = secrets.SystemRandom()
    party_id = str(random.getrandbits(52))
    deal_data.payload["targetPlatforms"][0]["partyId"] = party_id

    status_code, response, resp_headers = deal_data.post_request(api_url, LEAD_ROUTE)
    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )

    # Conform deal is saved in db successfully
    get_deal_component_details(
        deal_ref_id=deal_data.dealRefId, deal_component="REF_IDS.IDL"
    )

    #  Get Key-Data
    query_param = f"dealRefId={deal_data.dealRefId}"
    status_code, get_resp, resp_headers = deal_data.get_request(
        url=api_url, route_url=KEY_DATA_ROUTE, query_param=query_param
    )
    idl_record = [item for item in get_resp if item["targetPlatformId"] == "IDL"]
    # partyId from targetPlatforms
    assert idl_record[0].get("sourcePartnerDealerId") == party_id
