# -*- coding: utf-8 -*-

from http import HTTPStatus

import pytest
from common.settings import ErrorMsgs
from tests.functional.service_api import ServiceAPI


API_ROUTE = "leads"
CA_UPDATE_ROUTE = "ca_update"
LEAD_UPDATE_ROUTE = "leads_update"


@pytest.mark.functional
def test_leads_ind_retail_new_update_gurantor(
    env,
    api_url,
    common_assert,
    random_data_class,
    get_response_data,
    verify_deal_component,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
):
    json_file_name, _ = ("ind_retail_new.json", 10)

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == no_of_records_expected
    assert response.get("leadRefId") is not None
    common_assert(records=records, resp_headers=resp_headers)

    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")

    # Update header with empty X-Lead-Reference-Number --> dealRefIdFD
    cust_header = {"X-Lead-Reference-Number": ""}

    # Update Guarantor
    deal_data.set_payload("credit_app/credit_app_full_payload.json", "guarantor")
    status_code, response, resp_headers = deal_data.patch(
        api_url, LEAD_UPDATE_ROUTE, cust_header
    )

    if status_code != HTTPStatus.NO_CONTENT:
        raise Exception(
            f"Patch. Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(deal_data.dealRefId)
    # assert count == 12

    deal_resp = get_response_data(records, "DEAL")
    assert "dealRefIdFD" not in deal_resp

    common_assert(records=records, resp_headers=resp_headers)

    verify_deal_component(records, deal_data.payload, "guarantor")
    verify_deal_component_protected(records, deal_data.payload, "guarantor")


@pytest.mark.functional
def test_leads_ind_retail_new_update_driver(
    env,
    api_url,
    common_assert,
    random_data_class,
    get_response_data,
    verify_deal_component,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
):
    json_file_name, _ = ("ind_retail_new.json", 10)

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == no_of_records_expected
    assert response.get("leadRefId") is not None
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")

    # Update header with empty X-Application-Reference-Number --> appRefIdFD
    cust_header = {"X-Application-Reference-Number": ""}

    # Update Driver
    deal_data.set_payload("credit_app/credit_app_full_payload.json", "driver")
    status_code, response, resp_headers = deal_data.patch(
        api_url, LEAD_UPDATE_ROUTE, cust_header
    )

    if status_code != HTTPStatus.NO_CONTENT:
        raise Exception(
            f"Patch. Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(deal_data.dealRefId)
    # assert count == 10

    deal_resp = get_response_data(records, "DEAL")
    assert "appRefIdFD" not in deal_resp

    common_assert(records=records, resp_headers=resp_headers)

    verify_deal_component(records, deal_data.payload, "driver")


@pytest.mark.functional
def test_leads_ind_retail_new_update_applicant_with_deal_ref_id_in_header(
    env,
    api_url,
    common_assert,
    random_data_class,
    get_response_data,
    verify_deal_component,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
):
    json_file_name, _ = ("ind_retail_new.json", 10)

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == no_of_records_expected
    assert response.get("leadRefId") is not None
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")

    # Update header with empty X-Lead-Reference-Number --> dealRefIdFD
    cust_header = {"X-Lead-Reference-Number": deal_data.generate_random_id()}

    # Update Applicant
    deal_data.set_payload("credit_app/credit_app_full_payload.json", "applicant")
    status_code, response, resp_headers = deal_data.patch(
        api_url, LEAD_UPDATE_ROUTE, cust_header
    )

    if status_code != HTTPStatus.NO_CONTENT:
        raise Exception(
            f"Patch. Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(deal_data.dealRefId)
    # assert count == 10

    deal_resp = get_response_data(records, "DEAL")
    assert "dealRefIdFD" not in deal_resp

    common_assert(records=records, resp_headers=resp_headers)

    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")


@pytest.mark.smoke
@pytest.mark.functional
def test_leads_ind_retail_new_update_coapplicant_with_read_ref_id_fd_in_payload(
    env,
    api_url,
    common_assert,
    random_data_class,
    get_response_data,
    verify_deal_component,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
):
    json_file_name, _ = ("ind_retail_new.json", 10)

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == no_of_records_expected
    assert response.get("leadRefId") is not None
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")

    # Update header with empty X-Application-Reference-Number --> appRefIdFD
    cust_header = {"X-Application-Reference-Number": deal_data.generate_random_id()}

    # Update Co-Applicant
    deal_data.set_payload("credit_app/credit_app_full_payload.json", "coApplicant")
    # Update dealRefIdFD in payload
    deal_data.payload["dealRefIdFD"] = deal_data.generate_random_id(True)
    status_code, response, resp_headers = deal_data.patch(
        api_url, LEAD_UPDATE_ROUTE, cust_header
    )

    if status_code != HTTPStatus.NO_CONTENT:
        raise Exception(
            f"Patch. Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(deal_data.dealRefId)
    # assert count == 12

    deal_resp = get_response_data(records, "DEAL")
    assert cust_header["X-Application-Reference-Number"] == deal_resp.get("appRefIdFD")
    assert "dealRefIdFD" not in deal_resp
    common_assert(records=records, resp_headers=resp_headers)

    verify_deal_component(records, deal_data.payload, "coApplicant")
    verify_deal_component_protected(records, deal_data.payload, "coApplicant")


@pytest.mark.functional
def test_leads_ind_retail_new_update_tradein(
    env,
    api_url,
    common_assert,
    random_data_class,
    get_response_data,
    verify_deal_component,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
):
    json_file_name, _ = ("ind_retail_new.json", 10)

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == no_of_records_expected
    assert response.get("leadRefId") is not None
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")

    # Update TradeIns
    deal_data.set_payload("credit_app/credit_app_full_payload.json", "tradeIns")
    status_code, response, resp_headers = deal_data.patch(api_url, LEAD_UPDATE_ROUTE)

    if status_code != HTTPStatus.NO_CONTENT:
        raise Exception(
            f"Patch. Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(deal_data.dealRefId)
    # assert count == 10
    common_assert(records=records, resp_headers=resp_headers)

    verify_deal_component(records, deal_data.payload, "tradeIns")


@pytest.mark.smoke
@pytest.mark.functional
def test_leads_ind_retail_new_update_extradata(
    env,
    api_url,
    common_assert,
    random_data_class,
    verify_deal_component,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
):
    json_file_name, _ = ("ind_retail_new.json", 10)

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == no_of_records_expected
    assert response.get("leadRefId") is not None
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")

    # Update Extra Data
    deal_data.set_payload("credit_app/credit_app_full_payload.json", "extraData")
    status_code, response, resp_headers = deal_data.patch(api_url, LEAD_UPDATE_ROUTE)

    if status_code != HTTPStatus.NO_CONTENT:
        raise Exception(
            f"Patch. Response code is: {status_code} and the response message is: {response}"
        )

    records, count = get_records_by_deal_ref_id(deal_data.dealRefId)
    # assert count == 11
    common_assert(records=records, resp_headers=resp_headers)

    verify_deal_component(records, deal_data.payload, "extraData")


@pytest.mark.functional
def test_leads_ind_retail_new_update_vehicle(
    env,
    api_url,
    common_assert,
    random_data_class,
    verify_deal_component,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
):
    json_file_name, _ = ("ind_retail_new.json", 10)

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == no_of_records_expected
    assert response.get("leadRefId") is not None
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")

    # Update Vehicle
    deal_data.set_payload("credit_app/credit_app_full_payload.json", "vehicle")
    status_code, response, resp_headers = deal_data.patch(api_url, LEAD_UPDATE_ROUTE)

    if status_code != HTTPStatus.NO_CONTENT:
        raise Exception(
            f"Patch. Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(deal_data.dealRefId)
    # assert count == 10
    common_assert(records=records, resp_headers=resp_headers)

    verify_deal_component(records, deal_data.payload, "vehicle")


@pytest.mark.smoke
@pytest.mark.functional
def test_leads_ind_retail_new_update_null_applicant(
    env,
    api_url,
    common_assert,
    random_data_class,
    get_response_data,
    verify_deal_component,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
):
    json_file_name, _ = ("ind_retail_new.json", 10)

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == no_of_records_expected
    assert response.get("leadRefId") is not None
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")

    # Update applicant
    deal_data.set_payload("credit_app/credit_app_null_payload.json", "applicant")
    status_code, response, resp_headers = deal_data.patch(api_url, LEAD_UPDATE_ROUTE)

    if status_code != HTTPStatus.NO_CONTENT:
        raise Exception(
            f"Patch. Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(deal_data.dealRefId)
    # assert count == 8
    common_assert(records=records, resp_headers=resp_headers)


@pytest.mark.functional
def test_leads_ind_retail_new_update_null_gurantor(
    env,
    api_url,
    common_assert,
    random_data_class,
    get_response_data,
    verify_deal_component,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
):
    json_file_name, _ = ("ind_retail_new.json", 10)

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == no_of_records_expected
    assert response.get("leadRefId") is not None
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")

    # Update Guarantor
    deal_data.set_payload("credit_app/credit_app_null_payload.json", "guarantor")
    status_code, response, resp_headers = deal_data.patch(api_url, LEAD_UPDATE_ROUTE)

    if status_code != HTTPStatus.NO_CONTENT:
        raise Exception(
            f"Patch. Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(deal_data.dealRefId)
    # assert count == 10
    common_assert(records=records, resp_headers=resp_headers)


@pytest.mark.functional
def test_leads_ind_retail_new_update_null_driver(
    env,
    api_url,
    common_assert,
    random_data_class,
    get_response_data,
    verify_deal_component,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
):
    json_file_name, _ = ("ind_retail_new.json", 10)

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == no_of_records_expected
    assert response.get("leadRefId") is not None
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")

    # Update Driver
    deal_data.set_payload("credit_app/credit_app_null_payload.json", "driver")
    status_code, response, resp_headers = deal_data.patch(api_url, LEAD_UPDATE_ROUTE)

    if status_code != HTTPStatus.NO_CONTENT:
        raise Exception(
            f"Patch. Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(deal_data.dealRefId)
    # assert count == 8
    common_assert(records=records, resp_headers=resp_headers)


@pytest.mark.functional
def test_leads_ind_retail_new_update_null_coapplicant(
    env,
    api_url,
    common_assert,
    random_data_class,
    verify_deal_component,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
):
    json_file_name, _ = ("ind_retail_new.json", 10)

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == no_of_records_expected
    assert response.get("leadRefId") is not None
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")

    # Update Co-applicant
    deal_data.set_payload("credit_app/credit_app_null_payload.json", "coApplicant")
    status_code, response, resp_headers = deal_data.patch(api_url, LEAD_UPDATE_ROUTE)

    if status_code != HTTPStatus.NO_CONTENT:
        raise Exception(
            f"Patch. Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(deal_data.dealRefId)
    # assert count == 10
    common_assert(records=records, resp_headers=resp_headers)


@pytest.mark.functional
def test_leads_ind_retail_new_update_null_tradein(
    env,
    api_url,
    common_assert,
    random_data_class,
    verify_deal_component,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
):
    json_file_name, _ = ("ind_retail_new.json", 10)

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == no_of_records_expected
    assert response.get("leadRefId") is not None
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")

    # Update TradeIns
    deal_data.set_payload("credit_app/credit_app_null_payload.json", "tradeIns")
    status_code, response, resp_headers = deal_data.patch(api_url, LEAD_UPDATE_ROUTE)

    if status_code != HTTPStatus.NO_CONTENT:
        raise Exception(
            f"Patch. Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(deal_data.dealRefId)
    # assert count == 9
    common_assert(records=records, resp_headers=resp_headers)


@pytest.mark.functional
def test_leads_ind_retail_new_update_null_extradata(
    env,
    api_url,
    common_assert,
    random_data_class,
    verify_deal_component,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
):
    json_file_name, _ = ("ind_retail_new.json", 10)

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == no_of_records_expected
    assert response.get("leadRefId") is not None
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")

    # Update Extra Data
    deal_data.set_payload("credit_app/credit_app_null_payload.json", "extraData")
    status_code, response, resp_headers = deal_data.patch(api_url, LEAD_UPDATE_ROUTE)

    if status_code != HTTPStatus.NO_CONTENT:
        raise Exception(
            f"Patch. Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(deal_data.dealRefId)
    # assert count == 10
    common_assert(records=records, resp_headers=resp_headers)


@pytest.mark.functional
def test_leads_ind_retail_new_update_null_vehicle(
    env,
    api_url,
    common_assert,
    random_data_class,
    verify_deal_component,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
):
    json_file_name, _ = ("ind_retail_new.json", 10)

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == no_of_records_expected
    assert response.get("leadRefId") is not None
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")

    # Update Vehicle
    deal_data.set_payload("credit_app/credit_app_null_payload.json", "vehicle")
    status_code, update_resp, resp_headers = deal_data.patch(api_url, LEAD_UPDATE_ROUTE)

    if status_code != HTTPStatus.NO_CONTENT:
        raise Exception(
            f"Patch. Response code is: {status_code} and the response message is: {update_resp}"
        )
    records, count = get_records_by_deal_ref_id(deal_data.dealRefId)
    # assert count == 9
    common_assert(records=records, resp_headers=resp_headers)

    # Key data GET after a lead update
    # Search query for key data - dealRefId
    query_param = f"dealRefId={response.get('dealRefId')}"

    status_code, get_resp, resp_headers = deal_data.get_request(
        url=api_url, route_url="key_data_get", query_param=query_param
    )
    assert status_code == HTTPStatus.OK

    # Search query for key data - leadRefId
    query_param = f"leadRefId={response.get('leadRefId')}"

    status_code, get_resp, resp_headers = deal_data.get_request(
        url=api_url, route_url="key_data_get", query_param=query_param
    )
    assert status_code == HTTPStatus.OK
    assert response.get("dealRefId") == get_resp[0]["dealRefId"]


@pytest.mark.smoke
@pytest.mark.functional
def test_update_lead_using_invalid_lead_ref_id(
    env, api_url, random_data_class, get_records_by_deal_ref_id
):
    json_file_name = "leads_min_data.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"leads/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == 5
    assert response.get("leadRefId") is not None

    # Update CA ID to a random ID
    deal_data.leadRefId = deal_data.generate_random_id()

    # Update applicant
    deal_data.set_payload("credit_app/credit_app_full_payload.json", "applicant")
    status_code, response, resp_headers = deal_data.patch(
        api_url, LEAD_UPDATE_ROUTE, cust_status_code=HTTPStatus.BAD_REQUEST
    )

    assert status_code == HTTPStatus.BAD_REQUEST
    assert response.get(
        "message"
    ) == "The resource_id: {} does not match our records for dealRefId: {}".format(
        deal_data.leadRefId, deal_data.dealRefId
    )


@pytest.mark.functional
def test_update_leads_using_credit_app_ref_id(
    env, api_url, random_data_class, get_records_by_deal_ref_id
):
    json_file_name, _ = ("leads_min_data.json", 5)

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"leads/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == no_of_records_expected
    assert response.get("leadRefId") is not None

    # Update applicant
    deal_data.set_payload("credit_app/credit_app_full_payload.json", "applicant")
    status_code, response, resp_headers = deal_data.patch(
        api_url, CA_UPDATE_ROUTE, cust_status_code=HTTPStatus.BAD_REQUEST
    )

    assert status_code == HTTPStatus.BAD_REQUEST
    assert response.get("message") == ErrorMsgs.error_duplicate_resource
