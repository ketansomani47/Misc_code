# -*- coding: utf-8 -*-

from http import HTTPStatus

import pytest
from tests.functional.service_api import ServiceAPI


APP_ROUTE = "credit_app"
CONTRACT_ROUTE = "create_contract"
ca_json_file = "credit_app/app_min_data.json"


@pytest.mark.prod
@pytest.mark.smoke
@pytest.mark.functional
def test_full_deal_get_for_contract_individual_retail_cert_trade(
    env,
    api_url,
    common_assert,
    random_data_class,
    get_records_by_deal_ref_id,
    query_dynamodb_for_specified_key,
    verify_get_response_against_posted_data,
    verify_field_does_not_exist_in_get_response,
):
    contract_json_file = "contract/individual_retail_cert_trade.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class, env=env, json_file=ca_json_file
    )

    # Add dealRefId & creditAppId in header
    fs_header_value = {
        "X-Deal-Reference-Id": deal_data.generate_random_id(True),
        "X-Credit-Application-Reference-Id": deal_data.generate_random_id(True),
    }

    # Generate random IDs for unifi and finance service
    random_ids_dict = random_data_class.generate_random_unifi_and_finance_service_ids()
    # Update Credit App with FS & uniFI IDs
    deal_data.update_contract_payloads_with_ids("credit_app", random_ids_dict)

    # Post a Credit App
    status_code, app_resp, resp_headers = deal_data.post_request(
        api_url, APP_ROUTE, cust_header=fs_header_value
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {app_resp}"
        )

    records, count = get_records_by_deal_ref_id(app_resp.get("dealRefId"))
    assert count == 7

    # Posting Contract
    deal_data.set_payload(contract_json_file)
    deal_data.update_contract_payloads_with_ids("contract", random_ids_dict)
    deal_data.update_payload_with_random_data()
    status_code, con_resp, resp_headers = deal_data.post_request(
        api_url, CONTRACT_ROUTE, lender_id=random_ids_dict.get("lenderId")
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {con_resp}"
        )

    # Confirm Contract is saved successfully
    contract_ref_id = query_dynamodb_for_specified_key(
        app_resp.get("dealRefId"), "contractRefId"
    )
    assert con_resp["contractRefId"] == contract_ref_id

    records, count = get_records_by_deal_ref_id(app_resp.get("dealRefId"))

    assert count == 14

    status_code, get_resp, resp_headers = deal_data.get_request(
        url=api_url, route_url="deal_get"
    )

    assert status_code == HTTPStatus.OK

    # Validate Contract request and response payload except PII
    verify_get_response_against_posted_data(deal_data.payload, get_resp)

    # Validate unwanted fields are not present in GET response
    verify_field_does_not_exist_in_get_response(get_resp)

    common_assert(records=records, resp_headers=resp_headers)


@pytest.mark.functional
def test_full_deal_get_for_contract_individual_retail_new(
    env,
    api_url,
    common_assert,
    random_data_class,
    get_records_by_deal_ref_id,
    query_dynamodb_for_specified_key,
    verify_get_response_against_posted_data,
    verify_field_does_not_exist_in_get_response,
):
    contract_json_file = "contract/individual_retail_new.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class, env=env, json_file=ca_json_file
    )

    # Add dealRefId & creditAppId in header
    fs_header_value = {
        "X-Deal-Reference-Id": deal_data.generate_random_id(True),
        "X-Credit-Application-Reference-Id": deal_data.generate_random_id(True),
    }

    # Generate random IDs for unifi and finance service
    random_ids_dict = random_data_class.generate_random_unifi_and_finance_service_ids()
    # Update Credit App with FS & uniFI IDs
    deal_data.update_contract_payloads_with_ids("credit_app", random_ids_dict)

    # Post a Credit App
    status_code, app_resp, resp_headers = deal_data.post_request(
        api_url, APP_ROUTE, cust_header=fs_header_value
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {app_resp}"
        )

    records, count = get_records_by_deal_ref_id(app_resp.get("dealRefId"))
    assert count == 7

    # Posting Contract
    deal_data.set_payload(contract_json_file)
    deal_data.update_contract_payloads_with_ids("contract", random_ids_dict)
    deal_data.update_payload_with_random_data()
    status_code, con_resp, resp_headers = deal_data.post_request(
        api_url, CONTRACT_ROUTE, lender_id=random_ids_dict.get("lenderId")
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {con_resp}"
        )

    # Confirm Contract is saved successfully
    contract_ref_id = query_dynamodb_for_specified_key(
        app_resp.get("dealRefId"), "contractRefId"
    )
    assert con_resp["contractRefId"] == contract_ref_id

    records, count = get_records_by_deal_ref_id(app_resp.get("dealRefId"))
    assert count == 13

    status_code, get_resp, resp_headers = deal_data.get_request(
        url=api_url, route_url="deal_get"
    )

    assert status_code == HTTPStatus.OK

    # Validate Contract request and response payload except PII
    verify_get_response_against_posted_data(deal_data.payload, get_resp)

    # Validate unwanted fields are not present in GET response
    verify_field_does_not_exist_in_get_response(get_resp)

    common_assert(records=records, resp_headers=resp_headers)


@pytest.mark.smoke
@pytest.mark.functional
def test_full_deal_get_for_individual_retail_new_min_data(
    env,
    api_url,
    common_assert,
    random_data_class,
    get_records_by_deal_ref_id,
    query_dynamodb_for_specified_key,
    verify_get_response_against_posted_data,
    verify_field_does_not_exist_in_get_response,
):
    contract_json_file = "contract/individual_retail_new_min_data.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class, env=env, json_file=ca_json_file
    )

    # Add dealRefId & creditAppId in header
    fs_header_value = {
        "X-Deal-Reference-Id": deal_data.generate_random_id(True),
        "X-Credit-Application-Reference-Id": deal_data.generate_random_id(True),
    }

    # Generate random IDs for unifi and finance service
    random_ids_dict = random_data_class.generate_random_unifi_and_finance_service_ids()
    # Update Credit App with FS & uniFI IDs
    deal_data.update_contract_payloads_with_ids("credit_app", random_ids_dict)

    # Post a Credit App
    status_code, app_resp, resp_headers = deal_data.post_request(
        api_url, APP_ROUTE, cust_header=fs_header_value
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {app_resp}"
        )

    records, count = get_records_by_deal_ref_id(app_resp.get("dealRefId"))
    assert count == 7

    # Posting Contract
    deal_data.set_payload(contract_json_file)
    deal_data.update_contract_payloads_with_ids("contract", random_ids_dict)
    deal_data.update_payload_with_random_data()
    status_code, con_resp, resp_headers = deal_data.post_request(
        api_url, CONTRACT_ROUTE, lender_id=random_ids_dict.get("lenderId")
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {con_resp}"
        )

    # Confirm Contract is saved successfully
    contract_ref_id = query_dynamodb_for_specified_key(
        app_resp.get("dealRefId"), "contractRefId"
    )
    assert con_resp["contractRefId"] == contract_ref_id

    records, count = get_records_by_deal_ref_id(app_resp.get("dealRefId"))
    assert count == 10

    status_code, get_resp, resp_headers = deal_data.get_request(
        url=api_url, route_url="deal_get"
    )

    assert status_code == HTTPStatus.OK

    # Validate Contract request and response payload except PII
    verify_get_response_against_posted_data(deal_data.payload, get_resp)

    # Validate unwanted fields are not present in GET response
    verify_field_does_not_exist_in_get_response(get_resp)

    common_assert(records=records, resp_headers=resp_headers)


@pytest.mark.functional
def test_full_deal_get_for_contract_individual_retail_used_extradata(
    env,
    api_url,
    common_assert,
    random_data_class,
    get_records_by_deal_ref_id,
    query_dynamodb_for_specified_key,
    verify_get_response_against_posted_data,
    verify_field_does_not_exist_in_get_response,
):
    contract_json_file = "contract/individual_retail_used_extradata.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class, env=env, json_file=ca_json_file
    )

    # Add dealRefId & creditAppId in header
    fs_header_value = {
        "X-Deal-Reference-Id": deal_data.generate_random_id(True),
        "X-Credit-Application-Reference-Id": deal_data.generate_random_id(True),
    }

    # Generate random IDs for unifi and finance service
    random_ids_dict = random_data_class.generate_random_unifi_and_finance_service_ids()
    # Update Credit App with FS & uniFI IDs
    deal_data.update_contract_payloads_with_ids("credit_app", random_ids_dict)

    # Post a Credit App
    status_code, app_resp, resp_headers = deal_data.post_request(
        api_url, APP_ROUTE, cust_header=fs_header_value
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {app_resp}"
        )

    records, count = get_records_by_deal_ref_id(app_resp.get("dealRefId"))
    assert count == 7

    # Posting Contract
    deal_data.set_payload(contract_json_file)
    deal_data.update_contract_payloads_with_ids("contract", random_ids_dict)
    deal_data.update_payload_with_random_data()
    status_code, con_resp, resp_headers = deal_data.post_request(
        api_url, CONTRACT_ROUTE, lender_id=random_ids_dict.get("lenderId")
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {con_resp}"
        )

    # Confirm Contract is saved successfully
    contract_ref_id = query_dynamodb_for_specified_key(
        app_resp.get("dealRefId"), "contractRefId"
    )
    assert con_resp["contractRefId"] == contract_ref_id

    records, count = get_records_by_deal_ref_id(app_resp.get("dealRefId"))
    assert count == 14

    status_code, get_resp, resp_headers = deal_data.get_request(
        url=api_url, route_url="deal_get"
    )

    assert status_code == HTTPStatus.OK

    # Validate Contract request and response payload except PII
    verify_get_response_against_posted_data(deal_data.payload, get_resp)

    # Validate unwanted fields are not present in GET response
    verify_field_does_not_exist_in_get_response(get_resp)

    common_assert(records=records, resp_headers=resp_headers)


@pytest.mark.functional
def test_full_deal_get_for_contract_individual_retail_used_max_fees(
    env,
    api_url,
    common_assert,
    random_data_class,
    get_records_by_deal_ref_id,
    query_dynamodb_for_specified_key,
    verify_get_response_against_posted_data,
    verify_field_does_not_exist_in_get_response,
):
    contract_json_file = "contract/individual_retail_used_max_fees.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class, env=env, json_file=ca_json_file
    )

    # Add dealRefId & creditAppId in header
    fs_header_value = {
        "X-Deal-Reference-Id": deal_data.generate_random_id(True),
        "X-Credit-Application-Reference-Id": deal_data.generate_random_id(True),
    }

    # Generate random IDs for unifi and finance service
    random_ids_dict = random_data_class.generate_random_unifi_and_finance_service_ids()
    # Update Credit App with FS & uniFI IDs
    deal_data.update_contract_payloads_with_ids("credit_app", random_ids_dict)

    # Post a Credit App
    status_code, app_resp, resp_headers = deal_data.post_request(
        api_url, APP_ROUTE, cust_header=fs_header_value
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {app_resp}"
        )

    records, count = get_records_by_deal_ref_id(deal_ref_id=deal_data.dealRefId)
    assert count == 7

    # Posting Contract
    deal_data.set_payload(contract_json_file)
    deal_data.update_contract_payloads_with_ids("contract", random_ids_dict)
    deal_data.update_payload_with_random_data()
    status_code, con_resp, resp_headers = deal_data.post_request(
        api_url, CONTRACT_ROUTE, lender_id=random_ids_dict.get("lenderId")
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {con_resp}"
        )

    # Confirm Contract is saved successfully
    contract_ref_id = query_dynamodb_for_specified_key(
        app_resp.get("dealRefId"), "contractRefId"
    )
    assert con_resp["contractRefId"] == contract_ref_id

    records, count = get_records_by_deal_ref_id(app_resp.get("dealRefId"))
    assert count == 11

    status_code, get_resp, resp_headers = deal_data.get_request(
        url=api_url, route_url="deal_get"
    )

    assert status_code == HTTPStatus.OK

    # Validate Contract request and response payload except PII
    verify_get_response_against_posted_data(deal_data.payload, get_resp)

    # Validate unwanted fields are not present in GET response
    verify_field_does_not_exist_in_get_response(get_resp)

    common_assert(records=records, resp_headers=resp_headers)


@pytest.mark.functional
def test_full_deal_get_for_contract_individual_retail_used_max_products(
    env,
    api_url,
    common_assert,
    random_data_class,
    get_deal_updated_timestamp,
    get_records_by_deal_ref_id,
    query_dynamodb_for_specified_key,
    verify_get_response_against_posted_data,
    verify_field_does_not_exist_in_get_response,
):
    contract_json_file = "contract/individual_retail_used_max_products.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class, env=env, json_file=ca_json_file
    )

    # Add dealRefId & creditAppId in header
    fs_header_value = {
        "X-Deal-Reference-Id": deal_data.generate_random_id(True),
        "X-Credit-Application-Reference-Id": deal_data.generate_random_id(True),
    }

    # Generate random IDs for unifi and finance service
    random_ids_dict = random_data_class.generate_random_unifi_and_finance_service_ids()
    # Update Credit App with FS & uniFI IDs
    deal_data.update_contract_payloads_with_ids("credit_app", random_ids_dict)

    # Post a Credit App
    status_code, app_resp, resp_headers = deal_data.post_request(
        api_url, APP_ROUTE, cust_header=fs_header_value
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {app_resp}"
        )

    app_timestamp = get_deal_updated_timestamp(deal_ref_id=deal_data.dealRefId)

    # Posting Contract
    deal_data.set_payload(contract_json_file)
    deal_data.update_contract_payloads_with_ids("contract", random_ids_dict)
    deal_data.update_payload_with_random_data()
    status_code, con_resp, resp_headers = deal_data.post_request(
        api_url, CONTRACT_ROUTE, lender_id=random_ids_dict.get("lenderId")
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {con_resp}"
        )

    # Confirm Contract is saved successfully
    contract_ref_id = query_dynamodb_for_specified_key(
        app_resp.get("dealRefId"), "contractRefId"
    )
    assert con_resp["contractRefId"] == contract_ref_id

    contract_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId, updated_timestamp=app_timestamp
    )
    assert contract_timestamp > app_timestamp

    records, count = get_records_by_deal_ref_id(app_resp.get("dealRefId"))
    assert count == 11

    status_code, get_resp, resp_headers = deal_data.get_request(
        url=api_url, route_url="deal_get"
    )

    assert status_code == HTTPStatus.OK

    # Validate Contract request and response payload except PII
    verify_get_response_against_posted_data(deal_data.payload, get_resp)

    # Validate unwanted fields are not present in GET response
    verify_field_does_not_exist_in_get_response(get_resp)

    common_assert(records=records, resp_headers=resp_headers)


@pytest.mark.functional
def test_full_deal_get_for_contract_individual_retail_used_max_taxes(
    env,
    api_url,
    common_assert,
    random_data_class,
    get_records_by_deal_ref_id,
    query_dynamodb_for_specified_key,
    verify_get_response_against_posted_data,
    verify_field_does_not_exist_in_get_response,
):
    contract_json_file = "contract/individual_retail_used_max_taxes.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class, env=env, json_file=ca_json_file
    )

    # Add dealRefId & creditAppId in header
    fs_header_value = {
        "X-Deal-Reference-Id": deal_data.generate_random_id(True),
        "X-Credit-Application-Reference-Id": deal_data.generate_random_id(True),
    }

    # Generate random IDs for unifi and finance service
    random_ids_dict = random_data_class.generate_random_unifi_and_finance_service_ids()
    # Update Credit App with FS & uniFI IDs
    deal_data.update_contract_payloads_with_ids("credit_app", random_ids_dict)

    # Post a Credit App
    status_code, app_resp, resp_headers = deal_data.post_request(
        api_url, APP_ROUTE, cust_header=fs_header_value
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {app_resp}"
        )

    records, count = get_records_by_deal_ref_id(app_resp.get("dealRefId"))
    assert count == 7

    # Posting Contract
    deal_data.set_payload(contract_json_file)
    deal_data.update_contract_payloads_with_ids("contract", random_ids_dict)
    deal_data.update_payload_with_random_data()
    status_code, con_resp, resp_headers = deal_data.post_request(
        api_url, CONTRACT_ROUTE, lender_id=random_ids_dict.get("lenderId")
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {con_resp}"
        )

    # Confirm Contract is saved successfully
    contract_ref_id = query_dynamodb_for_specified_key(
        app_resp.get("dealRefId"), "contractRefId"
    )
    assert con_resp["contractRefId"] == contract_ref_id

    records, count = get_records_by_deal_ref_id(app_resp.get("dealRefId"))
    assert count == 11

    status_code, get_resp, resp_headers = deal_data.get_request(
        url=api_url, route_url="deal_get"
    )

    assert status_code == HTTPStatus.OK

    # Validate Contract request and response payload except PII
    verify_get_response_against_posted_data(deal_data.payload, get_resp)

    # Validate unwanted fields are not present in GET response
    verify_field_does_not_exist_in_get_response(get_resp)

    common_assert(records=records, resp_headers=resp_headers)


@pytest.mark.functional
def test_full_deal_get_for_contract_individual_retail_used_multiple_trades(
    env,
    api_url,
    common_assert,
    random_data_class,
    get_records_by_deal_ref_id,
    query_dynamodb_for_specified_key,
    verify_get_response_against_posted_data,
    verify_field_does_not_exist_in_get_response,
):
    contract_json_file = "contract/individual_retail_used_multiple_trades.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class, env=env, json_file=ca_json_file
    )

    # Add dealRefId & creditAppId in header
    fs_header_value = {
        "X-Deal-Reference-Id": deal_data.generate_random_id(True),
        "X-Credit-Application-Reference-Id": deal_data.generate_random_id(True),
    }

    # Generate random IDs for unifi and finance service
    random_ids_dict = random_data_class.generate_random_unifi_and_finance_service_ids()
    # Update Credit App with FS & uniFI IDs
    deal_data.update_contract_payloads_with_ids("credit_app", random_ids_dict)

    # Post a Credit App
    status_code, app_resp, resp_headers = deal_data.post_request(
        api_url, APP_ROUTE, cust_header=fs_header_value
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {app_resp}"
        )

    records, count = get_records_by_deal_ref_id(app_resp.get("dealRefId"))
    assert count == 7

    # Posting Contract
    deal_data.set_payload(contract_json_file)
    deal_data.update_contract_payloads_with_ids("contract", random_ids_dict)
    deal_data.update_payload_with_random_data()
    status_code, con_resp, resp_headers = deal_data.post_request(
        api_url, CONTRACT_ROUTE, lender_id=random_ids_dict.get("lenderId")
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {con_resp}"
        )

    # Confirm Contract is saved successfully
    contract_ref_id = query_dynamodb_for_specified_key(
        app_resp.get("dealRefId"), "contractRefId"
    )
    assert con_resp["contractRefId"] == contract_ref_id

    records, count = get_records_by_deal_ref_id(app_resp.get("dealRefId"))
    assert count == 14

    status_code, get_resp, resp_headers = deal_data.get_request(
        url=api_url, route_url="deal_get"
    )

    assert status_code == HTTPStatus.OK

    # Validate Contract request and response payload except PII
    verify_get_response_against_posted_data(deal_data.payload, get_resp)

    # Validate unwanted fields are not present in GET response
    verify_field_does_not_exist_in_get_response(get_resp)

    common_assert(records=records, resp_headers=resp_headers)


@pytest.mark.smoke
@pytest.mark.functional
def test_full_deal_get_for_contract_joint_all_required_fields_for_optional_nodes(
    env,
    api_url,
    common_assert,
    random_data_class,
    get_records_by_deal_ref_id,
    query_dynamodb_for_specified_key,
    verify_get_response_against_posted_data,
    verify_field_does_not_exist_in_get_response,
):
    contract_json_file = "contract/joint_all_required_fields_for_optional_nodes.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class, env=env, json_file=ca_json_file
    )

    # Add dealRefId & creditAppId in header
    fs_header_value = {
        "X-Deal-Reference-Id": deal_data.generate_random_id(True),
        "X-Credit-Application-Reference-Id": deal_data.generate_random_id(True),
    }

    # Generate random IDs for unifi and finance service
    random_ids_dict = random_data_class.generate_random_unifi_and_finance_service_ids()
    # Update Credit App with FS & uniFI IDs
    deal_data.update_contract_payloads_with_ids("credit_app", random_ids_dict)

    # Post a Credit App
    status_code, app_resp, resp_headers = deal_data.post_request(
        api_url, APP_ROUTE, cust_header=fs_header_value
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {app_resp}"
        )

    records, count = get_records_by_deal_ref_id(app_resp.get("dealRefId"))
    assert count == 7

    # Posting Contract
    deal_data.set_payload(contract_json_file)
    deal_data.update_contract_payloads_with_ids("contract", random_ids_dict)
    deal_data.update_payload_with_random_data()
    status_code, con_resp, resp_headers = deal_data.post_request(
        api_url, CONTRACT_ROUTE, lender_id=random_ids_dict.get("lenderId")
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {con_resp}"
        )

    # Confirm Contract is saved successfully
    contract_ref_id = query_dynamodb_for_specified_key(
        app_resp.get("dealRefId"), "contractRefId"
    )
    assert con_resp["contractRefId"] == contract_ref_id

    records, count = get_records_by_deal_ref_id(app_resp.get("dealRefId"))
    assert count == 17

    status_code, get_resp, resp_headers = deal_data.get_request(
        url=api_url, route_url="deal_get"
    )

    assert status_code == HTTPStatus.OK

    # Validate Contract request and response payload except PII
    verify_get_response_against_posted_data(deal_data.payload, get_resp)

    # Validate unwanted fields are not present in GET response
    verify_field_does_not_exist_in_get_response(get_resp)

    common_assert(records=records, resp_headers=resp_headers)


@pytest.mark.functional
def test_full_deal_get_for_contract_joint_retail_demo_spouse(
    env,
    api_url,
    common_assert,
    random_data_class,
    get_records_by_deal_ref_id,
    query_dynamodb_for_specified_key,
    verify_get_response_against_posted_data,
    verify_field_does_not_exist_in_get_response,
):
    contract_json_file = "contract/joint_retail_demo_spouse.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class, env=env, json_file=ca_json_file
    )

    # Add dealRefId & creditAppId in header
    fs_header_value = {
        "X-Deal-Reference-Id": deal_data.generate_random_id(True),
        "X-Credit-Application-Reference-Id": deal_data.generate_random_id(True),
    }

    # Generate random IDs for unifi and finance service
    random_ids_dict = random_data_class.generate_random_unifi_and_finance_service_ids()
    # Update Credit App with FS & uniFI IDs
    deal_data.update_contract_payloads_with_ids("credit_app", random_ids_dict)

    # Post a Credit App
    status_code, app_resp, resp_headers = deal_data.post_request(
        api_url, APP_ROUTE, cust_header=fs_header_value
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {app_resp}"
        )

    records, count = get_records_by_deal_ref_id(app_resp.get("dealRefId"))
    assert count == 7

    # Posting Contract
    deal_data.set_payload(contract_json_file)
    deal_data.update_contract_payloads_with_ids("contract", random_ids_dict)
    deal_data.update_payload_with_random_data()
    status_code, con_resp, resp_headers = deal_data.post_request(
        api_url, CONTRACT_ROUTE, lender_id=random_ids_dict.get("lenderId")
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {con_resp}"
        )

    # Confirm Contract is saved successfully
    contract_ref_id = query_dynamodb_for_specified_key(
        app_resp.get("dealRefId"), "contractRefId"
    )
    assert con_resp["contractRefId"] == contract_ref_id

    records, count = get_records_by_deal_ref_id(app_resp.get("dealRefId"))
    assert count == 15

    status_code, get_resp, resp_headers = deal_data.get_request(
        url=api_url, route_url="deal_get"
    )

    assert status_code == HTTPStatus.OK

    # Validate Contract request and response payload except PII
    verify_get_response_against_posted_data(deal_data.payload, get_resp)

    # Validate unwanted fields are not present in GET response
    verify_field_does_not_exist_in_get_response(get_resp)

    common_assert(records=records, resp_headers=resp_headers)


@pytest.mark.smoke
@pytest.mark.functional
def test_full_deal_get_for_contract_joint_retail_new_max_data_pre_add_pre_emp(
    env,
    api_url,
    common_assert,
    random_data_class,
    get_records_by_deal_ref_id,
    query_dynamodb_for_specified_key,
    verify_get_response_against_posted_data,
    verify_field_does_not_exist_in_get_response,
):
    contract_json_file = "contract/joint_retail_new_max_data_pre_add_pre_emp.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class, env=env, json_file=ca_json_file
    )

    # Add dealRefId & creditAppId in header
    fs_header_value = {
        "X-Deal-Reference-Id": deal_data.generate_random_id(True),
        "X-Credit-Application-Reference-Id": deal_data.generate_random_id(True),
    }

    # Generate random IDs for unifi and finance service
    random_ids_dict = random_data_class.generate_random_unifi_and_finance_service_ids()
    # Update Credit App with FS & uniFI IDs
    deal_data.update_contract_payloads_with_ids("credit_app", random_ids_dict)

    # Post a Credit App
    status_code, app_resp, resp_headers = deal_data.post_request(
        api_url, APP_ROUTE, cust_header=fs_header_value
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {app_resp}"
        )

    records, count = get_records_by_deal_ref_id(app_resp.get("dealRefId"))
    assert count == 7

    # Posting Contract
    deal_data.set_payload(contract_json_file)
    deal_data.update_contract_payloads_with_ids("contract", random_ids_dict)
    deal_data.update_payload_with_random_data()
    status_code, con_resp, resp_headers = deal_data.post_request(
        api_url, CONTRACT_ROUTE, lender_id=random_ids_dict.get("lenderId")
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {con_resp}"
        )

    # Confirm Contract is saved successfully
    contract_ref_id = query_dynamodb_for_specified_key(
        app_resp.get("dealRefId"), "contractRefId"
    )
    assert con_resp["contractRefId"] == contract_ref_id

    records, count = get_records_by_deal_ref_id(app_resp.get("dealRefId"))
    assert count == 17

    status_code, get_resp, resp_headers = deal_data.get_request(
        url=api_url, route_url="deal_get"
    )

    assert status_code == HTTPStatus.OK

    # Validate Contract request and response payload except PII
    verify_get_response_against_posted_data(deal_data.payload, get_resp)

    # Validate unwanted fields are not present in GET response
    verify_field_does_not_exist_in_get_response(get_resp)

    common_assert(records=records, resp_headers=resp_headers)


@pytest.mark.functional
def test_full_deal_get_for_contract_joint_retail_used(
    env,
    api_url,
    common_assert,
    random_data_class,
    get_records_by_deal_ref_id,
    query_dynamodb_for_specified_key,
    verify_get_response_against_posted_data,
    verify_field_does_not_exist_in_get_response,
):
    contract_json_file = "contract/joint_retail_used.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class, env=env, json_file=ca_json_file
    )

    # Add dealRefId & creditAppId in header
    fs_header_value = {
        "X-Deal-Reference-Id": deal_data.generate_random_id(True),
        "X-Credit-Application-Reference-Id": deal_data.generate_random_id(True),
    }

    # Generate random IDs for unifi and finance service
    random_ids_dict = random_data_class.generate_random_unifi_and_finance_service_ids()
    # Update Credit App with FS & uniFI IDs
    deal_data.update_contract_payloads_with_ids("credit_app", random_ids_dict)

    # Post a Credit App
    status_code, app_resp, resp_headers = deal_data.post_request(
        api_url, APP_ROUTE, cust_header=fs_header_value
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {app_resp}"
        )

    records, count = get_records_by_deal_ref_id(app_resp.get("dealRefId"))
    assert count == 7

    # Posting Contract
    deal_data.set_payload(contract_json_file)
    deal_data.update_contract_payloads_with_ids("contract", random_ids_dict)
    deal_data.update_payload_with_random_data()
    status_code, con_resp, resp_headers = deal_data.post_request(
        api_url, CONTRACT_ROUTE, lender_id=random_ids_dict.get("lenderId")
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {con_resp}"
        )

    # Confirm Contract is saved successfully
    contract_ref_id = query_dynamodb_for_specified_key(
        app_resp.get("dealRefId"), "contractRefId"
    )
    assert con_resp["contractRefId"] == contract_ref_id

    records, count = get_records_by_deal_ref_id(app_resp.get("dealRefId"))
    assert count == 15

    status_code, get_resp, resp_headers = deal_data.get_request(
        url=api_url, route_url="deal_get"
    )

    assert status_code == HTTPStatus.OK

    # Validate Contract request and response payload except PII
    verify_get_response_against_posted_data(deal_data.payload, get_resp)

    # Validate unwanted fields are not present in GET response
    verify_field_does_not_exist_in_get_response(get_resp)

    common_assert(records=records, resp_headers=resp_headers)
