# -*- coding: utf-8 -*-
from copy import deepcopy
from datetime import datetime
from http import HTTPStatus

import pytest
from common.settings import ErrorMsgs
from tests.functional.service_api import ServiceAPI


@pytest.mark.prod
@pytest.mark.functional
def test_full_deal_get_for_redflag_ofac_response_app(
    env,
    api_url,
    common_assert,
    cb_event_payload,
    random_data_class,
    get_deal_updated_timestamp,
    get_records_by_deal_ref_id,
    verify_get_response_against_posted_data,
    verify_field_does_not_exist_in_get_response,
):
    json_file_name = "app_redflag_ofac.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_bureau/{json_file_name}",
    )
    initial_timestamp = datetime.isoformat(datetime.now())
    # Post a credit bureau
    status_code, cb_resp, resp_headers = deal_data.post_request(
        url=api_url, route_url="credit_bureau", cb_post=True
    )
    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {cb_resp}"
        )
    bureau_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId, updated_timestamp=initial_timestamp
    )
    assert bureau_timestamp > initial_timestamp
    records, count = get_records_by_deal_ref_id(cb_resp.get("dealRefId"))

    # assert count == 7
    assert deal_data.cbRefId == cb_resp.get("creditBureauRefId")

    # Saving post payload
    cb_payload = deepcopy(deal_data.payload)

    # posting credit bureau response for equifax ofac
    deal_data.set_report_data("cb_resp_equ_ofac")
    ofac_resp, ofac_report = deal_data.append_report_data_to_payload(
        deal_data.payload, deal_data.cb_report, "applicant"
    )
    deal_data.update_payload_with_bureau_key_data(cb_event_payload, ofac_resp)

    status_code, bureau_resp, resp_headers = deal_data.post_request(
        api_url, "cb_response", cb_post=True
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {bureau_resp}"
        )
    cb_resp_comp = f"CB.RESP.EQUIFAX.OFAC.APPLICANT.{bureau_resp['creditBureauRefId']}"
    cb_resp_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId,
        deal_component=cb_resp_comp,
        updated_timestamp=bureau_timestamp,
    )
    assert cb_resp_timestamp > bureau_timestamp

    # saving a copy of cb payload for response post
    deal_data.payload = deepcopy(cb_payload)

    # posting credit bureau response for equifax redflag
    deal_data.set_report_data("cb_resp_equ_redflag")
    redflag_resp, redflag_report = deal_data.append_report_data_to_payload(
        deal_data.payload, deal_data.cb_report, "applicant"
    )
    deal_data.update_payload_with_bureau_key_data(cb_event_payload, redflag_resp)

    status_code, bureau_resp, resp_headers = deal_data.post_request(
        api_url, "cb_response", cb_post=True
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {bureau_resp}"
        )

    cb_resp_comp = (
        f"CB.RESP.EQUIFAX.REDFLAG.APPLICANT.{bureau_resp['creditBureauRefId']}"
    )
    equ_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId,
        deal_component=cb_resp_comp,
        updated_timestamp=cb_resp_timestamp,
    )
    assert equ_timestamp > cb_resp_timestamp

    records, count = get_records_by_deal_ref_id(cb_resp.get("dealRefId"))

    # assert count == 9

    # Update payload with responses reports
    deal_data.append_report_data_to_payload(
        cb_payload, redflag_report, "applicant", "update_report"
    )
    deal_data.append_report_data_to_payload(
        cb_payload, ofac_report, "applicant", "update_report"
    )

    status_code, get_resp, resp_headers = deal_data.get_request(
        url=api_url,
        route_url="deal_get",
    )

    assert status_code == HTTPStatus.OK

    assert len(cb_payload.get("applicant").get("reports")) == len(
        get_resp.get("applicant").get("reports")
    )

    assert cb_payload.get("coApplicant") is None

    # Validate Credit App request and response payload except PII
    verify_get_response_against_posted_data(cb_payload, get_resp)

    # Validate unwanted fields are not present in GET response
    verify_field_does_not_exist_in_get_response(get_resp)

    common_assert(records=records, resp_headers=resp_headers)


@pytest.mark.functional
def test_full_deal_get_for_credit_bureau_response_app_coapp(
    env,
    api_url,
    common_assert,
    cb_event_payload,
    random_data_class,
    wait_with_no_retries,
    get_deal_updated_timestamp,
    get_records_by_deal_ref_id,
    verify_get_response_against_posted_data,
    verify_field_does_not_exist_in_get_response,
):
    json_file_name = "app_coapp_cb_exp_equ_tru_redflag_ofac.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_bureau/{json_file_name}",
    )
    initial_timestamp = datetime.isoformat(datetime.now())
    # Post a credit bureau
    status_code, cb_resp, resp_headers = deal_data.post_request(
        url=api_url, route_url="credit_bureau", cb_post=True
    )
    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {cb_resp}"
        )
    cb_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId, updated_timestamp=initial_timestamp
    )
    assert cb_timestamp > initial_timestamp
    records, count = get_records_by_deal_ref_id(cb_resp.get("dealRefId"))

    # assert count == 17
    assert deal_data.cbRefId == cb_resp.get("creditBureauRefId")

    # Saving post payload
    cb_payload = deepcopy(deal_data.payload)

    # App cb equifax response
    deal_data.set_report_data("cb_resp_equifax")
    payload, app_equ_report = deal_data.append_report_data_to_payload(
        deal_data.payload, deal_data.cb_report, "applicant"
    )

    # App redflag transunion response
    deal_data.set_report_data("cb_resp_redflag")
    payload, app_redflag_report = deal_data.append_report_data_to_payload(
        deal_data.payload, deal_data.cb_report, "applicant", "append_report"
    )

    # Co-app redflag response
    deal_data.set_report_data("cb_resp_redflag_exp")
    payload, coapp_redflag_report = deal_data.append_report_data_to_payload(
        deal_data.payload, deal_data.cb_report, "coApplicant"
    )

    # Co-App ofac transunion response
    deal_data.set_report_data("cb_resp_ofac")
    payload, coapp_ofac_report = deal_data.append_report_data_to_payload(
        deal_data.payload, deal_data.cb_report, "coApplicant", "append_report"
    )

    deal_data.update_payload_with_bureau_key_data(cb_event_payload, deal_data.payload)

    # update payload with response data payload
    deal_data.append_report_data_to_payload(
        cb_payload, app_equ_report, "applicant", "update_report"
    )
    deal_data.append_report_data_to_payload(
        cb_payload, app_redflag_report, "applicant", "update_report"
    )
    deal_data.append_report_data_to_payload(
        cb_payload, coapp_redflag_report, "coApplicant", "update_report"
    )
    deal_data.append_report_data_to_payload(
        cb_payload, coapp_ofac_report, "coApplicant", "update_report"
    )

    status_code, resp, resp_headers = deal_data.post_request(
        api_url, "cb_response", cb_post=True
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {resp}"
        )
    cb_resp_comp = f"CB.RESP.TRANSUNION.REDFLAG.APPLICANT.{resp['creditBureauRefId']}"
    cb_resp_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId,
        deal_component=cb_resp_comp,
        updated_timestamp=cb_timestamp,
    )
    assert cb_resp_timestamp > cb_timestamp

    records, count = get_records_by_deal_ref_id(cb_resp.get("dealRefId"))

    # assert count == 21

    status_code, get_resp, resp_headers = deal_data.get_request(
        url=api_url, route_url="deal_get"
    )

    assert status_code == HTTPStatus.OK

    assert len(cb_payload.get("applicant").get("reports")) == len(
        get_resp.get("applicant").get("reports")
    )
    assert len(cb_payload.get("coApplicant").get("reports")) == len(
        get_resp.get("coApplicant").get("reports")
    )

    # Validate Credit App request and response payload except PII
    verify_get_response_against_posted_data(cb_payload, get_resp)

    # Validate unwanted fields are not present in GET response
    verify_field_does_not_exist_in_get_response(get_resp)

    common_assert(records=records, resp_headers=resp_headers)


@pytest.mark.smoke
@pytest.mark.functional
def test_full_deal_get_for_cb_softpull_redflag_ofac_response_coapp(
    env,
    api_url,
    common_assert,
    cb_event_payload,
    random_data_class,
    get_deal_updated_timestamp,
    get_records_by_deal_ref_id,
    verify_get_response_against_posted_data,
    verify_field_does_not_exist_in_get_response,
):
    json_file_name = "coapp_cb_softpull_equ_exp_tru_redflag_ofac.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_bureau/{json_file_name}",
    )
    initial_timestamp = datetime.isoformat(datetime.now())
    status_code, pull_resp, resp_headers = deal_data.post_request(
        url=api_url, route_url="credit_bureau", cb_post=True
    )
    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {pull_resp}"
        )
    cb_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId, updated_timestamp=initial_timestamp
    )
    assert cb_timestamp > initial_timestamp
    records, count = get_records_by_deal_ref_id(pull_resp.get("dealRefId"))

    # assert count == 10
    assert deal_data.cbRefId == pull_resp.get("creditBureauRefId")
    assert resp_headers.get("X-CoxAuto-Correlation-Id") is not None

    # App cb equifax response
    deal_data.set_report_data("cb_resp_softpull_transunion")
    deal_data.append_report_data_to_payload(
        deal_data.payload, deal_data.cb_report, "coApplicant", "update_report"
    )

    # posting softpull experian response
    deal_data.set_report_data("cb_resp_softpull_experian")
    deal_data.append_report_data_to_payload(
        deal_data.payload, deal_data.cb_report, "coApplicant", "update_report"
    )

    # posting cb equifax response
    deal_data.set_report_data("cb_resp_equifax")
    deal_data.append_report_data_to_payload(
        deal_data.payload, deal_data.cb_report, "coApplicant", "update_report"
    )

    # posting ofac equifax response
    deal_data.set_report_data("cb_resp_equ_ofac")
    deal_data.append_report_data_to_payload(
        deal_data.payload, deal_data.cb_report, "coApplicant", "update_report"
    )

    # posting redflag equifax response
    deal_data.set_report_data("cb_resp_equ_redflag")
    deal_data.append_report_data_to_payload(
        deal_data.payload, deal_data.cb_report, "coApplicant", "update_report"
    )

    # saving payload for validation
    cb_payload = deepcopy(deal_data.payload)

    deal_data.update_payload_with_bureau_key_data(cb_event_payload, deal_data.payload)

    status_code, resp, resp_headers = deal_data.post_request(
        api_url, "cb_response", cb_post=True
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {resp}"
        )
    cb_resp_comp = f"CB.RESP.EQUIFAX.REDFLAG.COAPPLICANT.{resp['creditBureauRefId']}"
    cb_resp_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId,
        deal_component=cb_resp_comp,
        updated_timestamp=cb_timestamp,
    )
    assert cb_resp_timestamp > cb_timestamp
    records, count = get_records_by_deal_ref_id(pull_resp.get("dealRefId"))

    # assert count == 15

    status_code, get_resp, resp_headers = deal_data.get_request(
        url=api_url, route_url="deal_get"
    )

    assert status_code == HTTPStatus.OK

    assert len(cb_payload.get("coApplicant").get("reports")) == len(
        get_resp.get("coApplicant").get("reports")
    )
    assert get_resp.get("applicant") is None

    # Validate Credit App request and response payload except PII
    verify_get_response_against_posted_data(cb_payload, get_resp)

    # Validate unwanted fields are not present in GET response
    verify_field_does_not_exist_in_get_response(get_resp)

    common_assert(records=records, resp_headers=resp_headers)


@pytest.mark.smoke
@pytest.mark.functional
def test_full_deal_get_for_for_multiple_cb_pulls(
    env,
    api_url,
    common_assert,
    cb_event_payload,
    random_data_class,
    wait_with_no_retries,
    get_deal_updated_timestamp,
    get_records_by_deal_ref_id,
    verify_get_response_against_posted_data,
    verify_field_does_not_exist_in_get_response,
):
    json_file_name = "app_cb_equ_exp_tru.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_bureau/{json_file_name}",
    )
    initial_timestamp = datetime.isoformat(datetime.now())
    status_code, pull_resp, resp_headers = deal_data.post_request(
        api_url, "credit_bureau", cb_post=True
    )
    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {pull_resp}"
        )
    cb_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId, updated_timestamp=initial_timestamp
    )
    assert cb_timestamp > initial_timestamp
    records, count = get_records_by_deal_ref_id(pull_resp.get("dealRefId"))

    # assert count == 8
    assert deal_data.cbRefId == pull_resp.get("creditBureauRefId")

    # Saving first posted payload
    cb_payload = deepcopy(deal_data.payload)

    # Posting Applicant response
    deal_data.set_report_data("cb_resp_transunion")
    app_payload, app_report = deal_data.append_report_data_to_payload(
        deal_data.payload, deal_data.cb_report, "applicant"
    )

    deal_data.update_payload_with_bureau_key_data(cb_event_payload, deal_data.payload)

    status_code, resp, resp_headers = deal_data.post_request(
        api_url, "cb_response", cb_post=True
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {resp}"
        )

    cb_resp_comp = (
        f"CB.RESP.TRANSUNION.CREDITBUREAU.APPLICANT.{resp['creditBureauRefId']}"
    )
    cb_resp_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId,
        deal_component=cb_resp_comp,
        updated_timestamp=cb_timestamp,
    )
    assert cb_resp_timestamp > cb_timestamp
    records, count = get_records_by_deal_ref_id(pull_resp.get("dealRefId"))

    # assert count == 9

    # updating cb_payload with response data
    deal_data.append_report_data_to_payload(
        cb_payload, app_report, "applicant", "update_report"
    )

    # Second credit bureau post using the dealRefId
    json_file_name = "coapp_cb_equ_redflag_ofac.json"
    deal_data.set_payload(f"credit_bureau/{json_file_name}")

    status_code, refid_resp, resp_headers = deal_data.post_request(
        api_url, "credit_bureau_with_deal_ref", cb_post=True
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {refid_resp}"
        )

    cb_resp_comp = (
        f"CB.PULL.TRANSUNION.OFAC.COAPPLICANT.{refid_resp['creditBureauRefId']}"
    )
    equ_resp_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId,
        deal_component=cb_resp_comp,
        updated_timestamp=cb_resp_timestamp,
    )
    assert equ_resp_timestamp > cb_resp_timestamp
    records, count = get_records_by_deal_ref_id(pull_resp.get("dealRefId"))

    # assert count == 14

    # Saving post payload for co-applicant
    coapp_payload = deepcopy(deal_data.payload)

    # posting coapp response
    deal_data.set_report_data("cb_resp_redflag_exp")
    payload, coapp_report = deal_data.append_report_data_to_payload(
        deal_data.payload, deal_data.cb_report, "coApplicant"
    )

    deal_data.update_payload_with_bureau_key_data(cb_event_payload, deal_data.payload)

    status_code, resp, resp_headers = deal_data.post_request(
        api_url, "cb_response", cb_post=True
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {resp}"
        )

    cb_resp_comp = f"CB.RESP.EXPERIAN.REDFLAG.COAPPLICANT.{resp['creditBureauRefId']}"
    equ_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId,
        deal_component=cb_resp_comp,
        updated_timestamp=equ_resp_timestamp,
    )
    assert equ_timestamp > equ_resp_timestamp
    records, count = get_records_by_deal_ref_id(pull_resp.get("dealRefId"))

    # assert count == 15

    # updating cb_payload with response data
    deal_data.append_report_data_to_payload(
        coapp_payload, coapp_report, "coApplicant", "update_report"
    )

    # Appending applicant to payload
    coapp_payload["applicant"] = cb_payload["applicant"]

    status_code, get_resp, resp_headers = deal_data.get_request(
        url=api_url,
        route_url="deal_get",
    )

    assert status_code == HTTPStatus.OK

    assert len(coapp_payload.get("applicant").get("reports")) == len(
        get_resp.get("applicant").get("reports")
    )
    assert len(coapp_payload.get("coApplicant").get("reports")) == len(
        get_resp.get("coApplicant").get("reports")
    )

    # Validate Credit App request and response payload except PII
    verify_get_response_against_posted_data(coapp_payload, get_resp)

    # Validate unwanted fields are not present in GET response
    verify_field_does_not_exist_in_get_response(get_resp)

    common_assert(records=records, resp_headers=resp_headers)


@pytest.mark.functional
def test_full_deal_get_for_redflag_ofac_app_coapp(
    env,
    api_url,
    common_assert,
    cb_event_payload,
    random_data_class,
    wait_with_no_retries,
    get_deal_updated_timestamp,
    get_records_by_deal_ref_id,
    verify_get_response_against_posted_data,
    verify_field_does_not_exist_in_get_response,
):
    json_file_name = "app_coapp_redflag.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_bureau/{json_file_name}",
    )
    initial_timestamp = datetime.isoformat(datetime.now())
    # Post a credit bureau
    status_code, cb_resp, resp_headers = deal_data.post_request(
        url=api_url, route_url="credit_bureau", cb_post=True
    )
    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {cb_resp}"
        )
    cb_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId, updated_timestamp=initial_timestamp
    )
    assert cb_timestamp > initial_timestamp
    records, count = get_records_by_deal_ref_id(cb_resp.get("dealRefId"))

    # assert count == 9
    assert deal_data.cbRefId == cb_resp.get("creditBureauRefId")

    # App response
    deal_data.set_report_data("cb_resp_equ_redflag")
    payload, app_report = deal_data.append_report_data_to_payload(
        deal_data.payload, deal_data.cb_report, "applicant"
    )

    # Co-App response
    deal_data.set_report_data("cb_resp_equ_ofac")
    payload, coapp_report = deal_data.append_report_data_to_payload(
        deal_data.payload, deal_data.cb_report, "coApplicant"
    )

    deal_data.update_payload_with_bureau_key_data(cb_event_payload, deal_data.payload)

    status_code, resp, resp_headers = deal_data.post_request(
        api_url, "cb_response", cb_post=True
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {resp}"
        )

    cb_resp_comp = f"CB.RESP.EQUIFAX.REDFLAG.APPLICANT.{resp['creditBureauRefId']}"
    cb_resp_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId,
        deal_component=cb_resp_comp,
        updated_timestamp=cb_timestamp,
    )
    assert cb_resp_timestamp > cb_timestamp
    records, count = get_records_by_deal_ref_id(cb_resp.get("dealRefId"))

    # assert count == 11

    status_code, get_resp, resp_headers = deal_data.get_request(
        url=api_url, route_url="deal_get"
    )

    assert status_code == HTTPStatus.OK

    assert len(payload.get("applicant").get("reports")) == len(
        get_resp.get("applicant").get("reports")
    )
    assert len(payload.get("coApplicant").get("reports")) == len(
        get_resp.get("coApplicant").get("reports")
    )

    # Validate Credit App request and response payload except PII
    verify_get_response_against_posted_data(payload, get_resp)

    # Validate unwanted fields are not present in GET response
    verify_field_does_not_exist_in_get_response(get_resp)

    common_assert(records=records, resp_headers=resp_headers)


@pytest.mark.functional
def test_full_deal_get_for_credit_bureau_without_cb_response(
    env,
    api_url,
    common_assert,
    random_data_class,
    get_deal_updated_timestamp,
    get_records_by_deal_ref_id,
    verify_get_response_against_posted_data,
    verify_field_does_not_exist_in_get_response,
):
    json_file_name = "app_coapp_cb_exp_equ_tru_redflag_ofac.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_bureau/{json_file_name}",
    )
    initial_timestamp = datetime.isoformat(datetime.now())
    # Post a credit bureau
    status_code, cb_resp, resp_headers = deal_data.post_request(
        url=api_url, route_url="credit_bureau", cb_post=True
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {cb_resp}"
        )
    cb_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId, updated_timestamp=initial_timestamp
    )
    assert cb_timestamp > initial_timestamp
    records, count = get_records_by_deal_ref_id(cb_resp.get("dealRefId"))

    # assert count == 17
    assert deal_data.cbRefId == cb_resp.get("creditBureauRefId")

    # Saving post payload
    cb_payload = deal_data.payload

    status_code, get_resp, resp_headers = deal_data.get_request(
        url=api_url, route_url="deal_get"
    )

    assert status_code == HTTPStatus.OK

    assert len(cb_payload.get("applicant").get("reports")) == len(
        get_resp.get("applicant").get("reports")
    )
    assert len(cb_payload.get("coApplicant").get("reports")) == len(
        get_resp.get("coApplicant").get("reports")
    )

    # Validate Credit App request and response payload except PII
    verify_get_response_against_posted_data(cb_payload, get_resp)

    # Validate unwanted fields are not present in GET response
    verify_field_does_not_exist_in_get_response(get_resp)

    common_assert(records=records, resp_headers=resp_headers)


@pytest.mark.functional
def test_full_deal_get_with_invalid_deal_ref_id(
    env, api_url, common_assert, random_data_class, get_records_by_deal_ref_id
):

    deal_data = ServiceAPI(random_data_class=random_data_class, env=env)

    # Generate a new ID
    deal_data.dealRefId = deal_data.generate_random_id()

    status_code, get_resp, resp_headers = deal_data.get_request(
        url=api_url,
        route_url="deal_get",
    )

    # Validate proper error message is return for invalid dealRefId
    assert status_code == HTTPStatus.BAD_REQUEST
    assert get_resp.get("message") == ErrorMsgs.missing_deal_from_db.format(
        deal_ref_id=deal_data.dealRefId
    )

    common_assert(resp_headers=resp_headers)
