# -*- coding: utf-8 -*-
from http import HTTPStatus

import pytest
from tests.functional.service_api import ServiceAPI


@pytest.mark.smoke
@pytest.mark.functional
def test_full_deal_get_for_lead_leads_min_data(
    env,
    api_url,
    common_assert,
    random_data_class,
    get_deal_component_details,
    get_records_by_deal_ref_id,
    verify_get_response_against_posted_data,
    verify_field_does_not_exist_in_get_response,
):
    json_file_name = "leads_min_data.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"leads/{json_file_name}",
    )

    # Post a credit
    status_code, lead_resp, resp_headers = deal_data.post_request(
        url=api_url, route_url="leads"
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {lead_resp}"
        )

    # Verify if data has been saved successfully in DB
    get_deal_component_details(
        deal_ref_id=deal_data.dealRefId, deal_component="DTC.APPLICANT"
    )

    status_code, get_resp, resp_headers = deal_data.get_request(
        api_url, route_url="deal_get"
    )
    assert status_code == HTTPStatus.OK

    # Validate Credit App request and response payload except PII
    verify_get_response_against_posted_data(deal_data.payload, get_resp)

    # Validate unwanted fields are not present in GET response
    assert get_resp["vehicle"].get("randomField") is None
    assert get_resp["vehicle"].get("randomNode") is None
    verify_field_does_not_exist_in_get_response(get_resp)

    records, _ = get_records_by_deal_ref_id(lead_resp.get("dealRefId"))
    common_assert(records=records, resp_headers=resp_headers)


@pytest.mark.functional
def test_full_deal_get_for_lead_leads_with_shopper_quote_payload(
    env,
    api_url,
    common_assert,
    random_data_class,
    get_deal_component_details,
    get_records_by_deal_ref_id,
    verify_get_response_against_posted_data,
    verify_field_does_not_exist_in_get_response,
):
    json_file_name = "leads_shopper_quote_data.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"leads/{json_file_name}",
    )
    # Post a credit
    status_code, lead_resp, resp_headers = deal_data.post_request(
        url=api_url, route_url="leads"
    )
    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {lead_resp}"
        )

    # Verify if data has been saved successfully in DB
    get_deal_component_details(
        deal_ref_id=deal_data.dealRefId, deal_component="DTC.APPLICANT"
    )

    status_code, get_resp, resp_headers = deal_data.get_request(
        api_url, route_url="deal_get"
    )

    assert status_code == HTTPStatus.OK

    # Validate Credit App request and response payload except PII
    verify_get_response_against_posted_data(deal_data.payload, get_resp)

    # Validate unwanted fields are not present in GET response
    verify_field_does_not_exist_in_get_response(get_resp)

    records, _ = get_records_by_deal_ref_id(lead_resp.get("dealRefId"))
    common_assert(records=records, resp_headers=resp_headers)

    json_file_name = "leads_shopper_quote_data.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"leads/{json_file_name}",
    )

    # Post 2nd lead
    status_code, lead_resp, resp_headers = deal_data.post_request(
        url=api_url, route_url="leads"
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {lead_resp}"
        )

    # Verify if data has been saved successfully in DB
    get_deal_component_details(
        deal_ref_id=deal_data.dealRefId,
        deal_component="DTC.APPLICANT",
        additional_check_key="firstName",
        additional_check_value=deal_data.payload["applicant"]["firstName"],
    )
    records, _ = get_records_by_deal_ref_id(lead_resp.get("dealRefId"))

    status_code, get_resp, resp_headers = deal_data.get_request(
        api_url, route_url="deal_get"
    )

    assert status_code == HTTPStatus.OK

    # Validate Credit App request and response payload except PII
    verify_get_response_against_posted_data(deal_data.payload, get_resp)

    # Validate unwanted fields are not present in GET response
    verify_field_does_not_exist_in_get_response(get_resp)

    common_assert(records=records, resp_headers=resp_headers)


@pytest.mark.functional
def test_full_deal_get_for_lead_app_coapp_guar_spouse_balloon_cert(
    env,
    api_url,
    common_assert,
    random_data_class,
    get_deal_component_details,
    get_records_by_deal_ref_id,
    verify_get_response_against_posted_data,
    verify_field_does_not_exist_in_get_response,
):
    json_file_name = "app_coapp_guar_spouse_balloon_cert.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"leads/{json_file_name}",
    )

    # Post a credit
    status_code, lead_resp, resp_headers = deal_data.post_request(
        url=api_url, route_url="leads"
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {lead_resp}"
        )
    # Verify if data has been saved successfully in DB
    get_deal_component_details(
        deal_ref_id=deal_data.dealRefId, deal_component="DTC.APPLICANT"
    )
    records, count = get_records_by_deal_ref_id(lead_resp.get("dealRefId"))

    status_code, get_resp, resp_headers = deal_data.get_request(
        api_url, route_url="deal_get"
    )

    assert status_code == HTTPStatus.OK

    # Validate Credit App request and response payload except PII
    verify_get_response_against_posted_data(deal_data.payload, get_resp)

    # Validate unwanted fields are not present in GET response
    # assert get_resp["coApplicant"]["currentEmployment"].get("randomNode") is None
    verify_field_does_not_exist_in_get_response(get_resp)

    common_assert(records=records, resp_headers=resp_headers)


@pytest.mark.functional
def test_full_deal_get_for_lead_ind_lease_cert_trade_session(
    env,
    api_url,
    common_assert,
    random_data_class,
    get_deal_component_details,
    get_records_by_deal_ref_id,
    verify_get_response_against_posted_data,
    verify_field_does_not_exist_in_get_response,
):
    json_file_name = "ind_lease_cert_trade_session.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"leads/{json_file_name}",
    )
    # Post a credit
    status_code, lead_resp, resp_headers = deal_data.post_request(
        url=api_url, route_url="leads"
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {lead_resp}"
        )
    # Verify if data has been saved successfully in DB
    get_deal_component_details(
        deal_ref_id=deal_data.dealRefId, deal_component="DTC.APPLICANT"
    )
    records, count = get_records_by_deal_ref_id(lead_resp.get("dealRefId"))

    status_code, get_resp, resp_headers = deal_data.get_request(
        api_url, route_url="deal_get"
    )

    assert status_code == HTTPStatus.OK

    # Validate Credit App request and response payload except PII
    verify_get_response_against_posted_data(deal_data.payload, get_resp)

    # Validate unwanted fields are not present in GET response
    verify_field_does_not_exist_in_get_response(get_resp)

    common_assert(records=records, resp_headers=resp_headers)


@pytest.mark.functional
def test_full_deal_get_for_lead_ind_retail_new_decision(
    env,
    api_url,
    common_assert,
    random_data_class,
    get_deal_component_details,
    get_records_by_deal_ref_id,
    verify_get_response_against_posted_data,
    verify_field_does_not_exist_in_get_response,
):
    json_file_name = "ind_retail_new_decision.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"leads/{json_file_name}",
    )
    # Post a credit
    status_code, lead_resp, resp_headers = deal_data.post_request(
        url=api_url, route_url="leads"
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {lead_resp}"
        )
    # Verify if data has been saved successfully in DB
    get_deal_component_details(
        deal_ref_id=deal_data.dealRefId, deal_component="DTC.APPLICANT"
    )
    records, count = get_records_by_deal_ref_id(lead_resp.get("dealRefId"))

    status_code, get_resp, resp_headers = deal_data.get_request(
        api_url, route_url="deal_get"
    )

    assert status_code == HTTPStatus.OK

    # Validate Credit App request and response payload except PII
    verify_get_response_against_posted_data(deal_data.payload, get_resp)

    # Validate unwanted fields are not present in GET response
    verify_field_does_not_exist_in_get_response(get_resp)

    common_assert(records=records, resp_headers=resp_headers)


@pytest.mark.smoke
@pytest.mark.prod
@pytest.mark.functional
def test_full_deal_get_for_lead_with_pii(
    env,
    api_url,
    common_assert,
    random_data_class,
    get_deal_component_details,
    verify_protected_fields,
    get_records_by_deal_ref_id,
    verify_get_response_against_posted_data,
    verify_field_does_not_exist_in_get_response,
):
    json_file_name = "max_app_coapp_guarantor_driver.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"leads/{json_file_name}",
    )
    # Post a lead
    status_code, lead_resp, resp_headers = deal_data.post_request(
        url=api_url, route_url="leads"
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {lead_resp}"
        )
    # Verify if data has been saved successfully in DB
    get_deal_component_details(
        deal_ref_id=deal_data.dealRefId, deal_component="DTC.APPLICANT"
    )
    records, count = get_records_by_deal_ref_id(lead_resp.get("dealRefId"))

    status_code, get_resp, resp_headers = deal_data.get_request(
        api_url, route_url="deal_get_with_pii"
    )

    assert status_code == HTTPStatus.OK

    # Validate Credit App request and response payload except PII
    verify_get_response_against_posted_data(deal_data.payload, get_resp)

    # Verify PII data on GET
    verify_protected_fields(deal_data.payload, get_resp, "applicant")
    verify_protected_fields(deal_data.payload, get_resp, "coApplicant")
    verify_protected_fields(deal_data.payload, get_resp, "guarantor")
    verify_protected_fields(deal_data.payload, get_resp, "driver")

    # Validate unwanted fields are not present in GET response
    assert get_resp["coApplicant"]["currentEmployment"].get("randomField") is None
    assert get_resp["coApplicant"]["currentEmployment"].get("randomNode") is None

    # Validate unwanted fields are not present in GET response
    verify_field_does_not_exist_in_get_response(get_resp)

    common_assert(records=records, resp_headers=resp_headers)


@pytest.mark.functional
def test_full_deal_get_for_lead_app_coapp_retail_new_null_and_empty_string(
    env,
    api_url,
    common_assert,
    random_data_class,
    get_deal_component_details,
    get_records_by_deal_ref_id,
    verify_get_response_against_posted_data,
    verify_field_does_not_exist_in_get_response,
):
    json_file_name = "app_coapp_retail_new_null_and_empty_string.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"leads/{json_file_name}",
    )
    # Post a Lead
    status_code, lead_resp, resp_headers = deal_data.post_request(
        url=api_url, route_url="leads"
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {lead_resp}"
        )
    # Verify if data has been saved successfully in DB
    get_deal_component_details(
        deal_ref_id=deal_data.dealRefId, deal_component="DTC.APPLICANT"
    )
    records, count = get_records_by_deal_ref_id(lead_resp.get("dealRefId"))

    status_code, get_resp, resp_headers = deal_data.get_request(
        url=api_url, route_url="deal_get"
    )

    assert status_code == HTTPStatus.OK

    # Validate Credit App request and response payload except PII
    verify_get_response_against_posted_data(deal_data.payload, get_resp)

    # Validate unwanted fields are not present in GET response
    verify_field_does_not_exist_in_get_response(get_resp)

    common_assert(records=records, resp_headers=resp_headers)
