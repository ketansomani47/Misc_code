# -*- coding: utf-8 -*-
from datetime import datetime
from http import HTTPStatus

import pytest
from common.settings import ErrorMsgs
from tests.functional.service_api import ServiceAPI


@pytest.mark.prod
@pytest.mark.functional
def test_full_deal_get_for_credit_app_ind_retail_new(
    env,
    api_url,
    common_assert,
    random_data_class,
    get_deal_updated_timestamp,
    get_records_by_deal_ref_id,
    verify_get_response_against_posted_data,
    verify_field_does_not_exist_in_get_response,
):
    json_file_name = "ind_retail_new.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )

    initial_timestamp = datetime.isoformat(datetime.now())
    # Post a credit
    status_code, app_resp, resp_headers = deal_data.post_request(
        url=api_url, route_url="credit_app"
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {app_resp}"
        )
    app_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId, updated_timestamp=initial_timestamp
    )
    assert app_timestamp > initial_timestamp
    records, count = get_records_by_deal_ref_id(app_resp.get("dealRefId"))

    status_code, get_resp, resp_headers = deal_data.get_request(
        url=api_url, route_url="deal_get"
    )

    assert status_code == HTTPStatus.OK

    # Validate Credit App request and response payload except PII
    verify_get_response_against_posted_data(deal_data.payload, get_resp)

    # Validate unwanted fields are not present in GET response
    assert get_resp["vehicle"].get("randomField") is None
    assert get_resp["vehicle"].get("randomNode") is None

    verify_field_does_not_exist_in_get_response(get_resp)

    common_assert(records=records, resp_headers=resp_headers)


@pytest.mark.functional
def test_full_deal_get_for_credit_app_ind_lease_cert_trade(
    env,
    api_url,
    common_assert,
    random_data_class,
    get_deal_updated_timestamp,
    get_records_by_deal_ref_id,
    verify_get_response_against_posted_data,
    verify_field_does_not_exist_in_get_response,
):
    json_file_name = "ind_lease_cert_trade.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    initial_timestamp = datetime.isoformat(datetime.now())
    # Post a credit
    status_code, app_resp, resp_headers = deal_data.post_request(
        url=api_url, route_url="credit_app"
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {app_resp}"
        )
    app_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId, updated_timestamp=initial_timestamp
    )
    assert app_timestamp > initial_timestamp
    records, count = get_records_by_deal_ref_id(app_resp.get("dealRefId"))

    status_code, get_resp, resp_headers = deal_data.get_request(
        api_url, route_url="deal_get"
    )

    assert status_code == HTTPStatus.OK

    # Validate Credit App request and response payload except PII
    verify_get_response_against_posted_data(deal_data.payload, get_resp)

    # Validate unwanted fields are not present in GET response
    assert get_resp["financeSummary"].get("randomField") is None
    assert get_resp["financeSummary"].get("randomNode") is None
    verify_field_does_not_exist_in_get_response(get_resp)

    common_assert(records=records, resp_headers=resp_headers)


@pytest.mark.functional
def test_full_deal_get_for_credit_app_joint_spouse_pii_finance_cert(
    env,
    api_url,
    common_assert,
    random_data_class,
    get_deal_updated_timestamp,
    get_records_by_deal_ref_id,
    verify_get_response_against_posted_data,
    verify_field_does_not_exist_in_get_response,
):
    json_file_name = "joint_spouse_pii_finance_cert.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    # Add randomNode to validate deal GET API
    initial_timestamp = datetime.isoformat(datetime.now())
    # Post a credit
    status_code, app_resp, resp_headers = deal_data.post_request(
        url=api_url, route_url="credit_app"
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {app_resp}"
        )
    lead_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId, updated_timestamp=initial_timestamp
    )
    assert lead_timestamp > initial_timestamp
    records, count = get_records_by_deal_ref_id(app_resp.get("dealRefId"))

    status_code, get_resp, resp_headers = deal_data.get_request(
        api_url, route_url="deal_get"
    )

    assert status_code == HTTPStatus.OK

    # Validate Credit App request and response payload except PII
    verify_get_response_against_posted_data(deal_data.payload, get_resp)

    # Validate unwanted fields are not present in GET response
    assert get_resp["applicant"].get("randomField") is None
    assert get_resp["applicant"]["address"].get("randomNode") is None
    verify_field_does_not_exist_in_get_response(get_resp)

    common_assert(records=records, resp_headers=resp_headers)


@pytest.mark.functional
def test_full_deal_get_for_credit_app_joint_retail_new_pre_add_pre_emp(
    env,
    api_url,
    common_assert,
    random_data_class,
    get_deal_updated_timestamp,
    get_records_by_deal_ref_id,
    verify_get_response_against_posted_data,
    verify_field_does_not_exist_in_get_response,
):
    json_file_name = "joint_retail_new_pre_add_pre_emp.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    initial_timestamp = datetime.isoformat(datetime.now())
    # Post a credit
    status_code, app_resp, resp_headers = deal_data.post_request(
        url=api_url, route_url="credit_app"
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {app_resp}"
        )
    app_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId, updated_timestamp=initial_timestamp
    )
    assert app_timestamp > initial_timestamp
    records, count = get_records_by_deal_ref_id(app_resp.get("dealRefId"))

    status_code, get_resp, resp_headers = deal_data.get_request(
        api_url, route_url="deal_get"
    )

    assert status_code == HTTPStatus.OK

    # Validate Credit App request and response payload except PII
    verify_get_response_against_posted_data(deal_data.payload, get_resp)

    # Validate unwanted fields are not present in GET response
    verify_field_does_not_exist_in_get_response(get_resp)

    common_assert(records=records, resp_headers=resp_headers)


@pytest.mark.smoke
@pytest.mark.functional
def test_full_deal_get_for_credit_app_joint_retail_new_null_and_empty_string(
    env,
    api_url,
    common_assert,
    random_data_class,
    get_deal_updated_timestamp,
    get_records_by_deal_ref_id,
    verify_get_response_against_posted_data,
    verify_field_does_not_exist_in_get_response,
):
    json_file_name = "joint_retail_new_null_and_empty_string.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    initial_timestamp = datetime.isoformat(datetime.now())
    # Post a credit
    status_code, app_resp, resp_headers = deal_data.post_request(
        url=api_url, route_url="credit_app"
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {app_resp}"
        )
    app_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId, updated_timestamp=initial_timestamp
    )
    assert app_timestamp > initial_timestamp
    records, count = get_records_by_deal_ref_id(app_resp.get("dealRefId"))

    status_code, get_resp, resp_headers = deal_data.get_request(
        api_url, route_url="deal_get"
    )

    assert status_code == HTTPStatus.OK

    # Validate Credit App request and response payload except PII
    verify_get_response_against_posted_data(deal_data.payload, get_resp)

    # Validate unwanted fields are not present in GET response
    verify_field_does_not_exist_in_get_response(get_resp)

    common_assert(records=records, resp_headers=resp_headers)


@pytest.mark.smoke
@pytest.mark.functional
def test_full_deal_get_for_credit_app_credit_app_full_payload(
    env,
    api_url,
    common_assert,
    random_data_class,
    get_deal_updated_timestamp,
    get_records_by_deal_ref_id,
    verify_get_response_against_posted_data,
    verify_field_does_not_exist_in_get_response,
):
    json_file_name = "credit_app_full_payload.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    initial_timestamp = datetime.isoformat(datetime.now())
    # Post a credit
    status_code, app_resp, resp_headers = deal_data.post_request(
        url=api_url, route_url="credit_app"
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {app_resp}"
        )
    app_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId, updated_timestamp=initial_timestamp
    )
    assert app_timestamp > initial_timestamp
    records, count = get_records_by_deal_ref_id(app_resp.get("dealRefId"))

    status_code, get_resp, resp_headers = deal_data.get_request(
        api_url, route_url="deal_get"
    )

    assert status_code == HTTPStatus.OK

    # Validate Credit App request and response payload except PII
    verify_get_response_against_posted_data(deal_data.payload, get_resp)

    # Validate unwanted fields are not present in GET response
    verify_field_does_not_exist_in_get_response(get_resp)

    common_assert(records=records, resp_headers=resp_headers)


@pytest.mark.functional
def test_full_deal_get_for_credit_app_pii(
    env,
    api_url,
    common_assert,
    random_data_class,
    get_deal_updated_timestamp,
    verify_protected_fields,
    get_records_by_deal_ref_id,
    verify_get_response_against_posted_data,
    verify_field_does_not_exist_in_get_response,
):
    json_file_name = "credit_app_max_data.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    initial_timestamp = datetime.isoformat(datetime.now())
    # Post a credit
    status_code, app_resp, resp_headers = deal_data.post_request(
        url=api_url, route_url="credit_app"
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {app_resp}"
        )
    app_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId, updated_timestamp=initial_timestamp
    )
    assert app_timestamp > initial_timestamp
    records, count = get_records_by_deal_ref_id(app_resp.get("dealRefId"))

    status_code, get_resp, resp_headers = deal_data.get_request(
        api_url, route_url="deal_get_with_pii"
    )

    assert status_code == HTTPStatus.OK

    # Validate Credit App request and response payload except PII
    verify_get_response_against_posted_data(deal_data.payload, get_resp)

    # # validate protected data
    verify_protected_fields(deal_data.payload, get_resp, "applicant")
    verify_protected_fields(deal_data.payload, get_resp, "coApplicant")
    verify_protected_fields(deal_data.payload, get_resp, "guarantor")
    verify_protected_fields(deal_data.payload, get_resp, "driver")

    # Validate unwanted fields are not present in GET response
    verify_field_does_not_exist_in_get_response(get_resp)

    common_assert(records=records, resp_headers=resp_headers)


@pytest.mark.smoke
@pytest.mark.functional
def test_full_deal_get_for_credit_app_with_invalid_deal_ref_id(
    env,
    api_url,
    common_assert,
    random_data_class,
    get_records_by_deal_ref_id,
    get_deal_updated_timestamp,
):
    json_file_name = "ind_retail_used.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    initial_timestamp = datetime.isoformat(datetime.now())
    # Posting a credit app to POST endpoint
    status_code, app_resp, resp_headers = deal_data.post_request(
        url=api_url, route_url="credit_app"
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {app_resp}"
        )
    app_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId, updated_timestamp=initial_timestamp
    )
    assert app_timestamp > initial_timestamp
    records, count = get_records_by_deal_ref_id(app_resp.get("dealRefId"))

    # Generate a new ID
    deal_data.dealRefId = deal_data.generate_random_id()

    status_code, get_resp, resp_headers = deal_data.get_request(
        url=api_url, route_url="deal_get"
    )

    # Validate proper error message is return for invalid dealRefId
    assert status_code == HTTPStatus.BAD_REQUEST
    assert get_resp.get("message") == ErrorMsgs.missing_deal_from_db.format(
        deal_ref_id=deal_data.dealRefId
    )

    common_assert(records=records, resp_headers=resp_headers)
