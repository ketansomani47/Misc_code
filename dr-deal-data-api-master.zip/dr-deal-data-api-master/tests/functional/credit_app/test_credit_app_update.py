# -*- coding: utf-8 -*-
import copy
from http import HTTPStatus

import pytest
from common.settings import ErrorMsgs
from tests.functional.service_api import ServiceAPI


API_ROUTE = "credit_app"
CA_UPDATE_ROUTE = "ca_update"
LEAD_UPDATE_ROUTE = "leads_update"


@pytest.mark.prod
@pytest.mark.smoke
@pytest.mark.functional
def test_credit_app_post_ind_retail_new_update_guarantor(
    env,
    api_url,
    common_assert,
    get_response_data,
    random_data_class,
    get_deal_component_details,
    verify_deal_component,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
):
    json_file_name, _ = ("ind_retail_new.json", 11)

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )

    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    assert response.get("creditAppId") is not None
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")

    # Update header with empty X-Lead-Reference-Number --> dealRefIdFD
    cust_header = {
        "X-Lead-Reference-Number": "",
        "X-Lead-Reference-Number-Internal": "",
        "X-Application-Reference-Number-Internal": "",
    }

    # Update guarantor
    deal_data.set_payload("credit_app/credit_app_full_payload.json", "guarantor")
    status_code, response, resp_headers = deal_data.patch(
        api_url, CA_UPDATE_ROUTE, cust_header=cust_header
    )

    if status_code != HTTPStatus.NO_CONTENT:
        raise Exception(
            f"Patch. Response code is: {status_code} and the response message is: {response}"
        )
    # Confirm requested in saved in DB
    get_deal_component_details(
        deal_ref_id=deal_data.dealRefId, deal_component="DTC.GUARANTOR"
    )
    records, count = get_records_by_deal_ref_id(deal_data.dealRefId)

    deal_resp = get_response_data(records, "DEAL")
    assert "dealRefIdFD" not in deal_resp
    assert "dealRefIdFDInt" not in deal_resp
    assert "appRefIdFDInt" not in deal_resp

    common_assert(records=records, resp_headers=resp_headers)

    verify_deal_component(records, deal_data.payload, "guarantor")
    verify_deal_component_protected(records, deal_data.payload, "guarantor")


@pytest.mark.smoke
@pytest.mark.functional
def test_credit_app_post_ind_retail_new_update_driver_eith_deal_ref_id_fd_in_payload(
    env,
    api_url,
    common_assert,
    get_response_data,
    random_data_class,
    verify_deal_component,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
):
    json_file_name, _ = ("ind_retail_new.json", 11)

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == no_of_records_expected
    assert response.get("creditAppId") is not None
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")

    # Update header with empty X-Application-Reference-Number --> appRefIdFD
    cust_header = {"X-Application-Reference-Number": ""}

    # Update driver
    deal_data.set_payload("credit_app/credit_app_full_payload.json", "driver")
    # Update payload with dealRefIdFD
    deal_data.payload["dealRefIdFD"] = deal_data.generate_random_id(True)
    status_code, response, resp_headers = deal_data.patch(
        api_url, CA_UPDATE_ROUTE, cust_header=cust_header
    )

    if status_code != HTTPStatus.NO_CONTENT:
        raise Exception(
            f"Patch. Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(deal_data.dealRefId)
    # assert count == 11

    deal_resp = get_response_data(records, "DEAL")
    assert "dealRefIdFD" not in deal_resp
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "driver")


@pytest.mark.prod
@pytest.mark.smoke
@pytest.mark.functional
def test_credit_app_post_ind_retail_new_update_applicant_with_deal_ref_id_fd_in_header(
    env,
    api_url,
    common_assert,
    get_response_data,
    random_data_class,
    verify_deal_component,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
):
    json_file_name, _ = ("ind_retail_new.json", 11)

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == no_of_records_expected
    assert response.get("creditAppId") is not None
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")

    # Update header with X-Lead-Reference-Number --> dealRefIdFD
    cust_header = {"X-Lead-Reference-Number": deal_data.generate_random_id()}

    # Update applicant
    deal_data.set_payload("credit_app/credit_app_full_payload.json", "applicant")
    status_code, response, resp_headers = deal_data.patch(
        api_url, CA_UPDATE_ROUTE, cust_header=cust_header
    )

    if status_code != HTTPStatus.NO_CONTENT:
        raise Exception(
            f"Patch. Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(deal_data.dealRefId)
    # assert count == 11

    deal_resp = get_response_data(records, "DEAL")
    assert "dealRefIdFD" not in deal_resp

    common_assert(records=records, resp_headers=resp_headers)

    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")


@pytest.mark.functional
def test_credit_app_post_ind_retail_new_update_coapplicant(
    env,
    api_url,
    common_assert,
    get_response_data,
    random_data_class,
    verify_deal_component,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
):
    json_file_name, _ = ("ind_retail_new.json", 11)

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == no_of_records_expected
    assert response.get("creditAppId") is not None
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")

    # Update header with empty X-Application-Reference-Number --> appRefIdFD
    cust_header = {"X-Application-Reference-Number": deal_data.generate_random_id()}

    # Update Co-applicant
    deal_data.set_payload("credit_app/credit_app_full_payload.json", "coApplicant")
    status_code, response, resp_headers = deal_data.patch(
        api_url, CA_UPDATE_ROUTE, cust_header=cust_header
    )

    if status_code != HTTPStatus.NO_CONTENT:
        raise Exception(
            f"Patch. Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(deal_data.dealRefId)
    # assert count == 13

    deal_resp = get_response_data(records, "DEAL")
    assert cust_header["X-Application-Reference-Number"] == deal_resp.get("appRefIdFD")

    common_assert(records=records, resp_headers=resp_headers)

    verify_deal_component(records, deal_data.payload, "coApplicant")
    verify_deal_component_protected(records, deal_data.payload, "coApplicant")


@pytest.mark.functional
def test_credit_app_post_ind_retail_new_update_tradein(
    env,
    api_url,
    common_assert,
    random_data_class,
    verify_deal_component,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
):
    json_file_name, _ = ("ind_retail_new.json", 11)

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == no_of_records_expected
    assert response.get("creditAppId") is not None
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")

    # Update tradeins
    deal_data.set_payload("credit_app/credit_app_full_payload.json", "tradeIns")
    status_code, response, resp_headers = deal_data.patch(api_url, CA_UPDATE_ROUTE)

    if status_code != HTTPStatus.NO_CONTENT:
        raise Exception(
            f"Patch. Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(deal_data.dealRefId)
    # assert count == 11
    common_assert(records=records, resp_headers=resp_headers)

    verify_deal_component(records, deal_data.payload, "tradeIns")


@pytest.mark.functional
def test_credit_app_post_ind_retail_new_update_extradata(
    env,
    api_url,
    common_assert,
    random_data_class,
    verify_deal_component,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
):
    json_file_name, _ = ("ind_retail_new.json", 11)

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == no_of_records_expected
    assert response.get("creditAppId") is not None
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")

    # Update extraData
    deal_data.set_payload("credit_app/credit_app_full_payload.json", "extraData")
    status_code, response, resp_headers = deal_data.patch(api_url, CA_UPDATE_ROUTE)

    if status_code != HTTPStatus.NO_CONTENT:
        raise Exception(
            f"Patch. Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(deal_data.dealRefId)
    # assert count == 12
    common_assert(records=records, resp_headers=resp_headers)

    verify_deal_component(records, deal_data.payload, "extraData")


@pytest.mark.smoke
@pytest.mark.functional
def test_credit_app_post_ind_retail_new_update_vehicle(
    env,
    api_url,
    common_assert,
    random_data_class,
    verify_deal_component,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
):
    json_file_name, _ = ("ind_retail_new.json", 11)

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == no_of_records_expected
    assert response.get("creditAppId") is not None
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")

    # Update Vehicle
    deal_data.set_payload("credit_app/credit_app_full_payload.json", "vehicle")
    status_code, response, resp_headers = deal_data.patch(api_url, CA_UPDATE_ROUTE)

    if status_code != HTTPStatus.NO_CONTENT:
        raise Exception(
            f"Patch. Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(deal_data.dealRefId)
    # assert count == 11
    common_assert(records=records, resp_headers=resp_headers)

    verify_deal_component(records, deal_data.payload, "vehicle")


@pytest.mark.functional
def test_credit_app_post_ind_retail_new_update_null_applicant(
    env,
    api_url,
    common_assert,
    random_data_class,
    verify_deal_component,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
):
    json_file_name, _ = ("ind_retail_new.json", 11)

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == no_of_records_expected
    assert response.get("creditAppId") is not None
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")

    # Update applicant
    deal_data.set_payload("credit_app/credit_app_null_payload.json", "applicant")
    status_code, response, resp_headers = deal_data.patch(api_url, CA_UPDATE_ROUTE)

    if status_code != HTTPStatus.NO_CONTENT:
        raise Exception(
            f"Patch. Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(deal_data.dealRefId)
    # assert count == 9
    common_assert(records=records, resp_headers=resp_headers)


@pytest.mark.smoke
@pytest.mark.functional
def test_credit_app_post_ind_retail_new_update_null_gurantor(
    env,
    api_url,
    common_assert,
    random_data_class,
    verify_deal_component,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
):
    json_file_name, _ = ("ind_retail_new.json", 11)

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == no_of_records_expected
    assert response.get("creditAppId") is not None
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")

    # Update Guarantor
    deal_data.set_payload("credit_app/credit_app_null_payload.json", "guarantor")
    status_code, response, resp_headers = deal_data.patch(api_url, CA_UPDATE_ROUTE)

    if status_code != HTTPStatus.NO_CONTENT:
        raise Exception(
            f"Patch. Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(deal_data.dealRefId)
    # assert count == 11
    common_assert(records=records, resp_headers=resp_headers)


@pytest.mark.functional
def test_credit_app_post_ind_retail_new_update_null_driver(
    env,
    api_url,
    common_assert,
    random_data_class,
    verify_deal_component,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
):
    json_file_name, _ = ("ind_retail_new.json", 11)

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == no_of_records_expected
    assert response.get("creditAppId") is not None
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")

    # Update driver
    deal_data.set_payload("credit_app/credit_app_null_payload.json", "driver")
    status_code, response, resp_headers = deal_data.patch(api_url, CA_UPDATE_ROUTE)

    if status_code != HTTPStatus.NO_CONTENT:
        raise Exception(
            f"Patch. Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(deal_data.dealRefId)
    # assert count == 9
    common_assert(records=records, resp_headers=resp_headers)


@pytest.mark.functional
def test_credit_app_post_ind_retail_new_update_null_coapplicant(
    env,
    api_url,
    common_assert,
    random_data_class,
    verify_deal_component,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
):
    json_file_name, _ = ("ind_retail_new.json", 11)

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == no_of_records_expected
    assert response.get("creditAppId") is not None
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")

    # Update Co-Applicant
    deal_data.set_payload("credit_app/credit_app_null_payload.json", "coApplicant")
    status_code, response, resp_headers = deal_data.patch(api_url, CA_UPDATE_ROUTE)

    if status_code != HTTPStatus.NO_CONTENT:
        raise Exception(
            f"Patch. Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(deal_data.dealRefId)
    # assert count == 11
    common_assert(records=records, resp_headers=resp_headers)


@pytest.mark.smoke
@pytest.mark.functional
def test_credit_app_post_ind_retail_new_update_null_tradein(
    env,
    api_url,
    common_assert,
    random_data_class,
    verify_deal_component,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
):
    json_file_name, _ = ("ind_retail_new.json", 11)

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == no_of_records_expected
    assert response.get("creditAppId") is not None
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")

    # Update TradeIns
    deal_data.set_payload("credit_app/credit_app_null_payload.json", "tradeIns")
    status_code, response, resp_headers = deal_data.patch(api_url, CA_UPDATE_ROUTE)

    if status_code != HTTPStatus.NO_CONTENT:
        raise Exception(
            f"Patch. Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(deal_data.dealRefId)
    # assert count == 10
    common_assert(records=records, resp_headers=resp_headers)


@pytest.mark.functional
def test_credit_app_post_ind_retail_new_update_null_extradata(
    env,
    api_url,
    common_assert,
    get_response_data,
    random_data_class,
    verify_deal_component,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
):
    json_file_name, _ = ("ind_retail_new.json", 11)

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == no_of_records_expected
    assert response.get("creditAppId") is not None
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")

    # Update header with empty X-Lead-Reference-Number --> dealRefIdFD
    cust_header = {"X-Lead-Reference-Number": ""}

    # Update Extra Data
    deal_data.set_payload("credit_app/credit_app_null_payload.json", "extraData")
    status_code, response, resp_headers = deal_data.patch(
        api_url, CA_UPDATE_ROUTE, cust_header=cust_header
    )

    if status_code != HTTPStatus.NO_CONTENT:
        raise Exception(
            f"Patch. Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(deal_data.dealRefId)
    # assert count == 11

    deal_resp = get_response_data(records, "DEAL")
    assert "dealRefIdFD" not in deal_resp

    common_assert(records=records, resp_headers=resp_headers)


@pytest.mark.functional
def test_credit_app_post_ind_retail_new_update_null_vehicle(
    env,
    api_url,
    common_assert,
    get_response_data,
    random_data_class,
    verify_deal_component,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
):
    json_file_name, _ = ("ind_retail_new.json", 11)

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == no_of_records_expected
    assert response.get("creditAppId") is not None
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")

    # Update header with empty X-Application-Reference-Number --> appRefIdFD
    cust_header = {"X-Application-Reference-Number": ""}

    # Update Vehicle
    deal_data.set_payload("credit_app/credit_app_null_payload.json", "vehicle")
    status_code, update_resp, resp_headers = deal_data.patch(
        api_url, CA_UPDATE_ROUTE, cust_header=cust_header
    )

    if status_code != HTTPStatus.NO_CONTENT:
        raise Exception(
            f"Patch. Response code is: {status_code} and the response message is: {update_resp}"
        )
    records, count = get_records_by_deal_ref_id(deal_data.dealRefId)
    # assert count == 10
    deal_resp = get_response_data(records, "DEAL")
    assert "appRefIdFD" not in deal_resp

    common_assert(records=records, resp_headers=resp_headers)

    # Key data GET after a credit app update
    # Search query for key data - dealRefId
    query_param = f"dealRefId={response.get('dealRefId')}"

    status_code, get_resp, resp_headers = deal_data.get_request(
        url=api_url, route_url="key_data_get", query_param=query_param
    )
    assert status_code == HTTPStatus.OK


@pytest.mark.functional
def test_credit_app_update_with_additional_key_data(
    env,
    api_url,
    random_data_class,
    verify_deal_component,
    get_records_by_deal_ref_id,
):
    json_file = "credit_app/app_min_data.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class, env=env, json_file=json_file
    )

    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)
    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )

    # Custom Header
    add_keys_header = {
        "X-Lead-Reference-Number": deal_data.generate_random_id(),
        "X-Application-Reference-Number": deal_data.generate_random_id(),
        "X-Lead-Reference-Number-Internal": deal_data.generate_random_id(),
        "X-Application-Reference-Number-Internal": deal_data.generate_random_id(),
        "X-Deal-Jacket-ID": deal_data.generate_random_id(),
        "X-Dealer-Code": "6",
        "X-Deal-Reference-Number-UniFI": deal_data.generate_random_id(),
        "X-ABCD-ID": deal_data.generate_random_id(),
    }

    # Update Extra Data
    deal_data.set_payload("credit_app/credit_app_null_payload.json", "extraData")
    status_code, response, resp_headers = deal_data.patch(
        api_url, CA_UPDATE_ROUTE, cust_header=add_keys_header
    )

    if status_code != HTTPStatus.NO_CONTENT:
        raise Exception(
            f"Patch. Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(deal_data.dealRefId)
    # assert count == 6

    add_keys_header["X-Lead-Reference-Number"] = None
    deal_data.payload.update(add_keys_header)
    verify_deal_component(
        records, deal_data.payload, "deal", additional_header_keys=True
    )


update_data = [
    "update_applicant_top_level",
    "update_applicant_add_emp",
    "update_applicant_pii",
    "update_co_applicant_add_emp",
    "update_co_applicant_pii",
    "update_vehicle",
    "update_trade_in",
]


@pytest.mark.smoke
@pytest.mark.functional
@pytest.mark.parametrize("test_data_node_name", update_data)
def test_credit_app_patch_with_existing_data(
    env,
    api_url,
    update_test_data,
    test_data_node_name,
    random_data_class,
    get_records_by_deal_ref_id,
    verify_get_response_against_posted_data,
):
    json_file_name = "joint_retail_certified.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )

    # posted payload
    original_payload = copy.deepcopy(deal_data.payload)

    deal_data.payload = update_test_data[test_data_node_name]
    status_code, response, resp_headers = deal_data.patch(api_url, CA_UPDATE_ROUTE)

    if status_code != HTTPStatus.NO_CONTENT:
        raise Exception(
            f"Patch. Response code is: {status_code} and the response message is: {response}"
        )

    #  full deal get
    status_code, get_resp, resp_headers = deal_data.get_request(
        url=api_url, route_url="deal_get", query_param="protected=true"
    )
    assert status_code == HTTPStatus.OK

    updated_payload = deal_data.merge_payloads_and_remove_pii(
        original_payload, deal_data.payload
    )
    verify_get_response_against_posted_data(updated_payload, get_resp)


update_data = [
    "update_applicant_top_level",
    "update_applicant_add_emp",
    "update_applicant_pii",
    "update_co_applicant_add_emp",
    "update_co_applicant_pii",
    "update_vehicle",
    "update_trade_in",
]


@pytest.mark.functional
@pytest.mark.parametrize("test_data_node_name", update_data)
def test_credit_app_patch_with_new_data(
    env,
    api_url,
    update_test_data,
    test_data_node_name,
    random_data_class,
    get_records_by_deal_ref_id,
    verify_get_response_against_posted_data,
):
    json_file_name = "app_min_data.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(
        api_url,
        API_ROUTE,
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )

    # posted payload
    original_payload = copy.deepcopy(deal_data.payload)

    deal_data.payload = update_test_data[test_data_node_name]
    status_code, response, resp_headers = deal_data.patch(api_url, CA_UPDATE_ROUTE)

    if status_code != HTTPStatus.NO_CONTENT:
        raise Exception(
            f"Patch. Response code is: {status_code} and the response message is: {response}"
        )

    #  full deal get
    status_code, get_resp, resp_headers = deal_data.get_request(
        url=api_url, route_url="deal_get", query_param="protected=true"
    )
    assert status_code == HTTPStatus.OK

    updated_payload = deal_data.merge_payloads_and_remove_pii(
        original_payload, deal_data.payload
    )
    verify_get_response_against_posted_data(updated_payload, get_resp)


remove_data = [
    ("remove_applicant_add_emp", ["applicant.address", "applicant.currentEmployment"]),
    ("remove_co_applicant", ["coApplicant"]),
    (
        "remove_co_applicant_pre_add_pre_emp_curr_emp_add",
        [
            "coApplicant.previousAddress",
            "coApplicant.currentEmployment.employerAddress",
            "coApplicant.previousEmployment",
        ],
    ),
    ("remove_trade_in", ["tradeIns"]),
    ("remove_vehicle", ["vehicle"]),
]


@pytest.mark.smoke
@pytest.mark.functional
@pytest.mark.xfail(
    reason="Pending clarification and design update for deal-data patch endpoint"
)
@pytest.mark.parametrize("test_data_node_name, delete_path", remove_data)
def test_credit_app_patch_remove_existing_data(
    env,
    api_url,
    delete_path,
    update_test_data,
    test_data_node_name,
    random_data_class,
    assert_deleted_value_from_deal,
    verify_get_response_against_posted_data,
):
    json_file_name = "joint_retail_certified.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(
        api_url,
        API_ROUTE,
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )

    # posted payload
    original_payload = copy.deepcopy(deal_data.payload)
    deal_data.payload = update_test_data[test_data_node_name]
    status_code, response, resp_headers = deal_data.patch(api_url, CA_UPDATE_ROUTE)

    if status_code != HTTPStatus.NO_CONTENT:
        raise Exception(
            f"Patch. Response code is: {status_code} and the response message is: {response}"
        )

    #  full deal get
    status_code, get_resp, resp_headers = deal_data.get_request(
        url=api_url, route_url="deal_get", query_param="protected=true"
    )
    assert status_code == HTTPStatus.OK
    updated_payload = deal_data.remove_key_from_json_obj(original_payload, delete_path)
    verify_get_response_against_posted_data(updated_payload, get_resp)
    assert_status = assert_deleted_value_from_deal(get_resp, delete_path)
    assert assert_status is True


@pytest.mark.functional
def test_update_credit_app_using_invalid_credit_app_id(
    env, api_url, random_data_class, get_records_by_deal_ref_id
):
    json_file_name, _ = ("ind_retail_new.json", 11)

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(
        api_url,
        API_ROUTE,
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == no_of_records_expected
    assert response.get("creditAppId") is not None

    # Update CA ID to a random ID
    deal_data.creditAppId = deal_data.generate_random_id()

    # Update applicant
    deal_data.set_payload("credit_app/credit_app_full_payload.json", "applicant")
    status_code, response, resp_headers = deal_data.patch(
        url=api_url,
        route_url=CA_UPDATE_ROUTE,
        cust_status_code=HTTPStatus.BAD_REQUEST,
    )

    assert status_code == HTTPStatus.BAD_REQUEST
    assert response.get("message") == ErrorMsgs.resource_id_mismatch.format(
        resource_id=deal_data.creditAppId, deal_ref_id=deal_data.dealRefId
    )


@pytest.mark.functional
def test_update_credit_app_using_lead_ref_id(
    env, api_url, random_data_class, get_records_by_deal_ref_id
):
    json_file_name, _ = ("ind_retail_new.json", 11)

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(
        api_url,
        API_ROUTE,
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == no_of_records_expected
    assert response.get("creditAppId") is not None

    # Update applicant
    deal_data.set_payload("credit_app/credit_app_full_payload.json", "applicant")
    status_code, response, resp_headers = deal_data.patch(
        url=api_url,
        route_url=LEAD_UPDATE_ROUTE,
        cust_status_code=HTTPStatus.BAD_REQUEST,
    )

    assert status_code == HTTPStatus.BAD_REQUEST
    assert response.get("message") == ErrorMsgs.error_duplicate_resource
