# -*- coding: utf-8 -*-
import os
from http import HTTPStatus

import pytest
from tests.functional.helper.helper_api import HelperApi


TEST_ENV = os.getenv("env")


class TestCopyCreditApp:
    @classmethod
    @pytest.fixture(autouse=True)
    def setup_credit_app(
        cls, env, api_url, random_data_class, get_deal_component_details
    ):
        cls.env = env
        cls.api_url = api_url
        cls.helper = HelperApi(
            env=env,
            api_url=api_url,
            random_data_class=random_data_class,
            get_deal_component_details=get_deal_component_details,
        )
        cls.helper.create_credit_app(app_file="credit_app/ind_retail_new.json")

    test_data_uat = [
        "app_min_data.json",
        "ind_retail_new.json",
        "ind_retail_used.json",
        "credit_app_max_data.json",
        "joint_spouse_pii_finance_cert.json",
        "joint_retail_new_null_and_empty_string.json",
    ]
    test_data_prod = [
        "app_min_data.json",
        "joint_retail_new_null_and_empty_string.json",
    ]

    test_data = test_data_prod if TEST_ENV == "prod" else test_data_uat

    @pytest.mark.prod
    @pytest.mark.smoke
    @pytest.mark.functional
    @pytest.mark.parametrize("app_file_name", test_data)
    def test_copy_credit_application(
        self, common_assert, app_file_name, get_records_by_deal_ref_id
    ):
        status_code, resp_body, resp_headers = self.helper.copy_credit_app(
            f"credit_app/{app_file_name}"
        )
        assert resp_body["dealRefId"] == self.helper.dealRefId

        records, count = get_records_by_deal_ref_id(self.helper.dealRefId)
        common_assert(records=records, resp_headers=resp_headers)

    @pytest.mark.prod
    @pytest.mark.smoke
    @pytest.mark.functional
    def test_copy_credit_application_without_app_id_in_header(
        self, common_assert, get_records_by_deal_ref_id
    ):
        app_file = "credit_app/ind_retail_new.json"
        status_code, resp_body, resp_headers = self.helper.copy_credit_app(
            app_file, expected_status=HTTPStatus.BAD_REQUEST, include_fs_headers=False
        )
        assert resp_body == {
            "message": "Required header is missing: X-Credit-Application-Reference-Id"
        }

        records, count = get_records_by_deal_ref_id(self.helper.dealRefId)
        common_assert(records=records, resp_headers=resp_headers)

    @pytest.mark.prod
    @pytest.mark.smoke
    @pytest.mark.functional
    def test_copy_multiple_credit_applications(
        self, common_assert, get_records_by_deal_ref_id, get_deal_component_details
    ):
        app_file = "credit_app/ind_retail_new.json"
        app_id_list = []
        for app in range(5):
            status_code, resp_body, resp_headers = self.helper.copy_credit_app(app_file)
            assert resp_body["dealRefId"] == self.helper.dealRefId
            app_id_list.append(resp_body["creditAppId"])

        records, count = get_records_by_deal_ref_id(self.helper.dealRefId)
        common_assert(records=records, resp_headers=resp_headers)

        #  Validate a record is created for each credit app
        for app_id in app_id_list:
            get_deal_component_details(
                deal_ref_id=self.helper.dealRefId,
                deal_component=f"REF_IDS.DTA.{app_id}",
            )

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_copy_credit_application_with_invalid_deal_ref_id(
        self, common_assert, get_records_by_deal_ref_id
    ):
        original_id = self.helper.dealRefId
        invalid_id = self.helper.generate_random_id(True)
        self.helper.dealRefId = invalid_id
        app_file = "credit_app/ind_retail_new.json"
        status_code, resp_body, resp_headers = self.helper.copy_credit_app(
            app_file, expected_status=HTTPStatus.BAD_REQUEST
        )
        assert resp_body == {"message": f"No deal found for {invalid_id}"}
        records, count = get_records_by_deal_ref_id(original_id)
        common_assert(records=records, resp_headers=resp_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_copy_credit_application_with_invalid_test_data(
        self, invalid_payload, common_assert
    ):
        self.helper.payload = invalid_payload
        status_code, resp_body, resp_headers = self.helper.copy_credit_app(
            expected_status=HTTPStatus.BAD_REQUEST
        )
        assert resp_headers.get("X-CoxAuto-Correlation-Id") is not None

    @pytest.mark.prod
    @pytest.mark.smoke
    @pytest.mark.functional
    def test_copy_credit_application_with_existing_credit_app_id(
        self, common_assert, get_records_by_deal_ref_id
    ):
        """
        As of now, deal-data would allow passing existing app id. This may change in the future
        """
        app_file = "credit_app/credit_app_full_payload.json"
        status_code, resp_body, resp_headers = self.helper.copy_credit_app(
            app_file, app_id=self.helper.creditAppId
        )
        assert resp_body["dealRefId"] == self.helper.dealRefId
        assert resp_body["creditAppId"] == self.helper.creditAppId

        records, count = get_records_by_deal_ref_id(self.helper.dealRefId)
        common_assert(records=records, resp_headers=resp_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_copy_credit_application_with_a_lead_no_existing_credit_app(
        self,
        env,
        api_url,
        common_assert,
        random_data_class,
        get_records_by_deal_ref_id,
        get_deal_component_details,
    ):
        helper = HelperApi(
            env=env,
            api_url=api_url,
            random_data_class=random_data_class,
            get_deal_component_details=get_deal_component_details,
        )
        helper.create_lead("leads/leads_min_data.json")
        app_file = "credit_app/ind_retail_new.json"
        status_code, resp_body, resp_headers = helper.copy_credit_app(
            app_file, expected_status=HTTPStatus.BAD_REQUEST
        )
        assert resp_body == {
            "message": "You have tired to post to an endpoint for which the resource doesn't exists."
        }

        records, count = get_records_by_deal_ref_id(self.helper.dealRefId)
        common_assert(records=records, resp_headers=resp_headers)
