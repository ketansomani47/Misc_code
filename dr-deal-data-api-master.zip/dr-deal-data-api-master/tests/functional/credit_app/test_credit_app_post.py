# -*- coding: utf-8 -*-
import secrets
from datetime import datetime
from http import HTTPStatus

import pytest
from common.settings import ErrorMsgs
from tests.functional.service_api import ServiceAPI


API_ROUTE = "credit_app"
KEY_DATA_ROUTE = "key_data_get"
LEAD_ROUTE = "leads"


@pytest.mark.smoke
@pytest.mark.functional
def test_credit_app_post_ind_lease_cert_trade_deal_ref_id_and_credit_app_id_in_header(
    env,
    api_url,
    common_assert,
    random_data_class,
    verify_deal_component,
    validate_v2_key_data,
    validate_deal_data_keys,
    get_deal_component_details,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
    query_dynamodb_with_deal_component,
):
    json_file_name = "ind_lease_cert_trade.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )

    # Add dealRefId & creditAppId in header
    fs_header_value = {
        "X-Deal-Reference-Id": deal_data.generate_random_id(True),
        "X-Credit-Application-Reference-Id": deal_data.generate_random_id(True),
    }

    # Post a Credit App
    status_code, response, resp_headers = deal_data.post_request(
        api_url, API_ROUTE, cust_header=fs_header_value
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    assert records != []
    db_resp = query_dynamodb_with_deal_component(deal_data.dealRefId, "DTC.DEAL")
    validate_deal_data_keys(response, db_resp[0], fs_header_value)
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")

    #  Validate v2 key-data record for DTA
    v2_record = get_deal_component_details(
        response.get("dealRefId"), deal_component="REF_IDS.DTA"
    )
    validate_v2_key_data(
        posted_payload={**fs_header_value, **response},
        database_resp=v2_record,
        key_name="DTA",
    )
    #  Validate v2 key-data credit app records
    v2_record = get_deal_component_details(
        response.get("dealRefId"),
        deal_component=f"REF_IDS.DTA.{response['creditAppId']}",
    )
    validate_v2_key_data(
        posted_payload={**fs_header_value, **response},
        database_resp=v2_record,
        key_name="DTA_APP",
    )


@pytest.mark.functional
def test_credit_app_post_ind_retail_new_deal_ref_id_in_header(
    env,
    api_url,
    common_assert,
    random_data_class,
    verify_deal_component,
    validate_deal_data_keys,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
    query_dynamodb_with_deal_component,
):
    json_file_name = "ind_retail_new.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )

    fs_header_value = {
        "X-Deal-Reference-Id": deal_data.generate_random_id(True),
        "dealXgDealId": deal_data.generate_random_id(True),
        "dealXgDealVersion": "v3",
    }

    # Post Credit App
    status_code, response, resp_headers = deal_data.post_request(
        api_url, API_ROUTE, cust_header=fs_header_value
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == 11
    db_resp = query_dynamodb_with_deal_component(deal_data.dealRefId, "DTC.DEAL")

    # Verify dealXG ref ids are not saved in DB
    assert "dealXgDealId" not in db_resp[0]
    assert "dealXgDealVersion" not in db_resp[0]

    validate_deal_data_keys(response, db_resp[0], fs_header_value)
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")


@pytest.mark.functional
def test_credit_app_post_ind_retail_new_no_income_credit_app_id_in_header(
    env,
    api_url,
    common_assert,
    random_data_class,
    verify_deal_component,
    validate_deal_data_keys,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
    query_dynamodb_with_deal_component,
):
    json_file_name = "ind_retail_new_no_income.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    # Add creditAppId only
    fs_header_value = {
        "X-Credit-Application-Reference-Id": deal_data.generate_random_id(True)
    }

    # Post Credit App
    status_code, response, resp_headers = deal_data.post_request(
        api_url, API_ROUTE, cust_header=fs_header_value
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )

    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))

    # assert count == 8
    db_resp = query_dynamodb_with_deal_component(deal_data.dealRefId, "DTC.DEAL")
    validate_deal_data_keys(response, db_resp[0], fs_header_value)
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")


@pytest.mark.functional
def test_credit_app_post_ind_retail_used_null_for_lists_empty_keys_in_header(
    env,
    api_url,
    common_assert,
    random_data_class,
    verify_deal_component,
    validate_deal_data_keys,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
    query_dynamodb_with_deal_component,
):
    json_file_name = "ind_retail_used_null_for_lists.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )

    # Add dealRefId & creditAppId in header
    fs_header_value = {
        "X-Deal-Reference-Id": "",
        "X-Credit-Application-Reference-Id": "",
        "X-Lead-Reference-Number-Internal": "",
        "X-Application-Reference-Number-Internal": "",
    }

    # Post a Credit App
    status_code, response, resp_headers = deal_data.post_request(
        api_url, API_ROUTE, cust_header=fs_header_value
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )

    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))

    # assert count == 8
    db_resp = query_dynamodb_with_deal_component(deal_data.dealRefId, "DTC.DEAL")
    validate_deal_data_keys(response, db_resp[0], fs_header_value)
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")

    assert "dealRefIdFD" not in db_resp[0]
    assert "dealRefIdFDInt" not in db_resp[0]
    assert "appRefIdFDInt" not in db_resp[0]


@pytest.mark.functional
def test_credit_app_post_joint_lease_new_chrome_ymmt_no_vin(
    env,
    api_url,
    common_assert,
    random_data_class,
    verify_deal_component,
    validate_deal_data_keys,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
    query_dynamodb_with_deal_component,
):
    json_file_name = "joint_lease_new_chrome_ymmt_no_vin.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )

    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))

    # assert count == 10
    db_resp = query_dynamodb_with_deal_component(deal_data.dealRefId, "DTC.DEAL")
    validate_deal_data_keys(response, db_resp[0])
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")
    verify_deal_component(records, deal_data.payload, "coApplicant")
    verify_deal_component_protected(records, deal_data.payload, "coApplicant")


@pytest.mark.functional
def test_credit_app_post_joint_retail_new_null_and_empty_string(
    env,
    api_url,
    common_assert,
    random_data_class,
    verify_deal_component,
    validate_deal_data_keys,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
    query_dynamodb_with_deal_component,
):
    json_file_name = "joint_retail_new_null_and_empty_string.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )

    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))

    # assert count == 10
    db_resp = query_dynamodb_with_deal_component(deal_data.dealRefId, "DTC.DEAL")
    validate_deal_data_keys(response, db_resp[0])
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")
    verify_deal_component(records, deal_data.payload, "coApplicant")
    verify_deal_component_protected(records, deal_data.payload, "coApplicant")


@pytest.mark.functional
def test_credit_app_post_joint_retail_new_pre_add_pre_emp(
    env,
    api_url,
    common_assert,
    random_data_class,
    verify_deal_component,
    validate_deal_data_keys,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
    query_dynamodb_with_deal_component,
):
    json_file_name = "joint_retail_new_pre_add_pre_emp.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )

    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == 10
    db_resp = query_dynamodb_with_deal_component(deal_data.dealRefId, "DTC.DEAL")
    validate_deal_data_keys(response, db_resp[0])
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")
    verify_deal_component(records, deal_data.payload, "coApplicant")
    verify_deal_component_protected(records, deal_data.payload, "coApplicant")


@pytest.mark.functional
@pytest.mark.prod
def test_credit_app_post_ind_lease_new(
    env,
    api_url,
    common_assert,
    random_data_class,
    verify_deal_component,
    validate_deal_data_keys,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
    query_dynamodb_with_deal_component,
):
    json_file_name = "ind_lease_new.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )

    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))

    # assert count == 9
    db_resp = query_dynamodb_with_deal_component(deal_data.dealRefId, "DTC.DEAL")
    validate_deal_data_keys(response, db_resp[0])
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")


@pytest.mark.functional
@pytest.mark.prod
def test_credit_app_post_ind_retail_used(
    env,
    api_url,
    common_assert,
    random_data_class,
    verify_deal_component,
    validate_deal_data_keys,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
    query_dynamodb_with_deal_component,
):
    json_file_name = "ind_retail_used.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )

    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == 8
    db_resp = query_dynamodb_with_deal_component(deal_data.dealRefId, "DTC.DEAL")
    validate_deal_data_keys(response, db_resp[0])
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")


@pytest.mark.functional
@pytest.mark.prod
def test_credit_app_post_joint_retail_certified(
    env,
    api_url,
    common_assert,
    random_data_class,
    verify_deal_component,
    validate_deal_data_keys,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
    query_dynamodb_with_deal_component,
):
    json_file_name = "joint_retail_certified.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )

    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))

    # assert count == 11
    db_resp = query_dynamodb_with_deal_component(deal_data.dealRefId, "DTC.DEAL")
    validate_deal_data_keys(response, db_resp[0])
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")
    verify_deal_component(records, deal_data.payload, "coApplicant")
    verify_deal_component_protected(records, deal_data.payload, "coApplicant")


@pytest.mark.functional
def test_credit_app_post_max_data(
    env,
    api_url,
    common_assert,
    random_data_class,
    verify_deal_component,
    validate_deal_data_keys,
    get_deal_component_details,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
    query_dynamodb_with_deal_component,
):
    json_file_name = "credit_app_max_data.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )

    fs_header_value = {
        "X-Deal-Reference-Id": deal_data.generate_random_id(True),
        "dealXgDealId": deal_data.generate_random_id(True),
        "dealXgDealVersion": "v3",
    }

    status_code, response, resp_headers = deal_data.post_request(
        api_url, API_ROUTE, cust_header=fs_header_value
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )

    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))

    # assert count == 22
    db_resp = query_dynamodb_with_deal_component(deal_data.dealRefId, "DTC.DEAL")
    validate_deal_data_keys(response, db_resp[0], fs_header_value)
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")
    verify_deal_component(records, deal_data.payload, "coApplicant")
    verify_deal_component_protected(records, deal_data.payload, "coApplicant")
    verify_deal_component(records, deal_data.payload, "guarantor")
    verify_deal_component_protected(records, deal_data.payload, "guarantor")
    verify_deal_component(records, deal_data.payload, "driver")

    # Validate sourcePartnerDealerId is saved in DB
    for target in deal_data.payload["targetPlatforms"]:
        v2_record = get_deal_component_details(
            deal_data.dealRefId, deal_component=f"REF_IDS.{target['id']}"
        )
        assert (
            v2_record.get("sourcePartnerDealerId") == target["partyId"]
        ), f"partyId did not save in key-data as sourcePartnerDealerId for {target}"


@pytest.mark.smoke
@pytest.mark.functional
def test_credit_app_post_guar_cash_new_driver_pii_multiple_trades(
    env,
    api_url,
    common_assert,
    random_data_class,
    verify_deal_component,
    validate_deal_data_keys,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
    query_dynamodb_with_deal_component,
):
    json_file_name = "guar_cash_new_driver_pii_multiple_trades.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )

    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))

    # assert count == 11
    db_resp = query_dynamodb_with_deal_component(deal_data.dealRefId, "DTC.DEAL")
    validate_deal_data_keys(response, db_resp[0])
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "guarantor")
    verify_deal_component_protected(records, deal_data.payload, "guarantor")
    verify_deal_component(records, deal_data.payload, "driver")
    verify_deal_component_protected(records, deal_data.payload, "driver")


@pytest.mark.functional
def test_credit_app_post_app_guar_references_cash_new(
    env,
    api_url,
    common_assert,
    random_data_class,
    verify_deal_component,
    validate_deal_data_keys,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
    query_dynamodb_with_deal_component,
):
    json_file_name = "app_guar_references_cash_new.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )

    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))

    # assert count == 18
    db_resp = query_dynamodb_with_deal_component(deal_data.dealRefId, "DTC.DEAL")
    validate_deal_data_keys(response, db_resp[0])
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")
    verify_deal_component(records, deal_data.payload, "guarantor")
    verify_deal_component_protected(records, deal_data.payload, "guarantor")


@pytest.mark.functional
def test_credit_app_post_joint_spouse_balloon_cert_with_deal_ref_id_fd_in_header(
    env,
    api_url,
    common_assert,
    random_data_class,
    verify_deal_component,
    validate_deal_data_keys,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
    query_dynamodb_with_deal_component,
):
    json_file_name = "joint_spouse_balloon_cert.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    # Add dealRefId & creditAppId in header
    fs_header_value = {
        "X-Lead-Reference-Number": deal_data.generate_random_id(True),
    }
    status_code, response, resp_headers = deal_data.post_request(
        api_url, API_ROUTE, cust_header=fs_header_value
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )

    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))

    # assert count == 20
    db_resp = query_dynamodb_with_deal_component(deal_data.dealRefId, "DTC.DEAL")
    assert "dealRefIdFD" in db_resp[0]
    validate_deal_data_keys(response, db_resp[0])
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")
    verify_deal_component(records, deal_data.payload, "coApplicant")
    verify_deal_component_protected(records, deal_data.payload, "coApplicant")
    verify_deal_component(records, deal_data.payload, "guarantor")
    verify_deal_component_protected(records, deal_data.payload, "guarantor")


@pytest.mark.smoke
@pytest.mark.functional
def test_credit_app_post_joint_spouse_pii_finance_cert_with_deal_ref_id_fd_in_payload(
    env,
    api_url,
    common_assert,
    random_data_class,
    verify_deal_component,
    validate_deal_data_keys,
    get_deal_component_details,
    get_records_by_deal_ref_id,
    verify_deal_component_protected,
    query_dynamodb_with_deal_component,
):
    json_file_name = "joint_spouse_pii_finance_cert.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )

    # Update payload with dealRefIdFD in payload
    deal_data.payload["dealRefIdFD"] = deal_data.generate_random_id(True)

    # Add dealRefId & creditAppId in header
    fs_header_value = {
        "X-Deal-Reference-Id": deal_data.generate_random_id(True),
        "X-Credit-Application-Reference-Id": deal_data.generate_random_id(True),
        "dealXgDealId": deal_data.generate_random_id(True),
        "dealXgDealVersion": "v3",
    }

    # Post a Credit App
    status_code, response, resp_headers = deal_data.post_request(
        api_url, API_ROUTE, cust_header=fs_header_value
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )

    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))

    # assert count == 16
    db_resp = query_dynamodb_with_deal_component(deal_data.dealRefId, "DTC.DEAL")
    assert "dealRefIdFD" in db_resp[0]

    # Verify dealXG ref ids are not saved in DB
    assert "dealXgDealId" not in db_resp[0]
    assert "dealXgDealVersion" not in db_resp[0]

    validate_deal_data_keys(response, db_resp[0], fs_header_value)
    common_assert(records=records, resp_headers=resp_headers)
    verify_deal_component(records, deal_data.payload, "applicant")
    verify_deal_component_protected(records, deal_data.payload, "applicant")
    verify_deal_component(records, deal_data.payload, "coApplicant")
    verify_deal_component_protected(records, deal_data.payload, "coApplicant")
    verify_deal_component(records, deal_data.payload, "guarantor")
    verify_deal_component_protected(records, deal_data.payload, "guarantor")

    # Validate sourcePartnerDealerId is saved in DB for key-data v2
    for target in deal_data.payload["targetPlatforms"]:
        v2_record = get_deal_component_details(
            deal_data.dealRefId, deal_component=f"REF_IDS.{target['id']}"
        )
        assert (
            v2_record.get("sourcePartnerDealerId") == target["partyId"]
        ), f"partyId did not save in key-data as sourcePartnerDealerId for {target}"

    # Key data v1 GET after a credit app post
    # Search query for key data - dealRefId
    query_param = f"dealRefId={response.get('dealRefId')}"

    status_code, get_resp, resp_headers = deal_data.get_request(
        url=api_url, route_url="key_data_get", query_param=query_param
    )
    if status_code != HTTPStatus.OK:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )


@pytest.mark.functional
def test_credit_app_post_with_additional_key_data(
    env,
    api_url,
    random_data_class,
    verify_deal_component,
    get_records_by_deal_ref_id,
):
    json_file = "credit_app/app_min_data.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class, env=env, json_file=json_file
    )
    add_keys_header = {
        "X-Lead-Reference-Number": deal_data.generate_random_id(),
        "X-Application-Reference-Number": deal_data.generate_random_id(),
        "X-Lead-Reference-Number-Internal": deal_data.generate_random_id(),
        "X-Application-Reference-Number-Internal": deal_data.generate_random_id(),
        "X-Deal-Jacket-ID": deal_data.generate_random_id(),
        "X-Dealer-Code": "6",
        "X-Deal-Reference-Number-UniFI": deal_data.generate_random_id(),
        "X-ABCD-ID": deal_data.generate_random_id(),
    }

    status_code, response, resp_headers = deal_data.post_request(
        api_url, API_ROUTE, cust_header=add_keys_header
    )
    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )

    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    deal_data.payload.update(add_keys_header)
    verify_deal_component(
        records, deal_data.payload, "deal", additional_header_keys=True
    )


@pytest.mark.smoke
@pytest.mark.functional
def test_credit_app_post_invalid_deal_ref_id_in_header(env, api_url, random_data_class):
    json_file_name = "ind_lease_cert_trade.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )

    # Add dealRefId & creditAppId in header
    # dealRefId is non-ulid
    fs_header_value = {
        "X-Deal-Reference-Id": deal_data.generate_random_id(),
        "X-Credit-Application-Reference-Id": deal_data.generate_random_id(True),
    }

    # Post a Credit App
    status_code, response, resp_headers = deal_data.post_request(
        api_url, API_ROUTE, cust_header=fs_header_value
    )

    if status_code != HTTPStatus.BAD_REQUEST:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )

    posted_id_len = len(fs_header_value.get("X-Deal-Reference-Id"))
    assert (
        response.get("message")
        == f"Invalid ulid provided. Error Expects 26 characters for decoding; got {posted_id_len}"
    )


@pytest.mark.smoke
@pytest.mark.functional
def test_credit_app_post_invalid_credit_app_id_in_header(
    env, api_url, random_data_class
):
    json_file_name = "ind_lease_cert_trade.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )

    # Add dealRefId & creditAppId in header
    # creditAppId is non-ulid
    fs_header_value = {
        "X-Deal-Reference-Id": deal_data.generate_random_id(True),
        "X-Credit-Application-Reference-Id": deal_data.generate_random_id(),
    }

    # Post a Credit App
    status_code, response, resp_headers = deal_data.post_request(
        api_url, API_ROUTE, cust_header=fs_header_value
    )

    if status_code != HTTPStatus.BAD_REQUEST:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    posted_id_len = len(fs_header_value.get("X-Credit-Application-Reference-Id"))
    assert (
        response.get("message")
        == f"Invalid ulid provided. Error Expects 26 characters for decoding; got {posted_id_len}"
    )


@pytest.mark.smoke
@pytest.mark.functional
def test_credit_app_post_with_invalid_test_data(
    api_url, env, random_data_class, invalid_payload
):
    deal_data = ServiceAPI(
        env=env, random_data_class=random_data_class, payload=invalid_payload
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)
    if status_code != HTTPStatus.BAD_REQUEST:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    assert resp_headers.get("X-CoxAuto-Correlation-Id") is not None


@pytest.mark.functional
def test_credit_app_with_existing_deal_ref_id_in_header(
    env,
    api_url,
    random_data_class,
):
    """
    Test case is to validate that a validation error is returns when credit app post
    endpoint is hit with existing deadRefId in header
    Step1: Create a lead using lead post endpoint
    Stet2: Post a credit app using post credit app endpoint and passing dealRefId from lead post to header
    Expected: credit app post with dealRefId should be use
    """
    lead_file = "leads/ind_cash_new_decision_session.json"
    ca_file = "credit_app/joint_retail_certified.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class, env=env, json_file=lead_file
    )

    status_code, app_resp, resp_headers = deal_data.post_request(api_url, LEAD_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {app_resp}"
        )

    # Post a credit app using the dealRefId in header
    deal_data.set_payload(ca_file)
    add_keys_header = {
        "X-Deal-Reference-Id": deal_data.dealRefId,
    }
    status_code, ca_resp, resp_headers = deal_data.post_request(
        api_url, API_ROUTE, cust_header=add_keys_header
    )

    if status_code != HTTPStatus.BAD_REQUEST:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {ca_file}"
        )

    assert ca_resp["message"] == ErrorMsgs.deal_ref_id_already_exists.format(
        deal_ref_id=deal_data.dealRefId
    )


@pytest.mark.smoke
@pytest.mark.prod
@pytest.mark.functional
def test_credit_app_post_without_source_partner_dealer_id_for_non_dtc(
    env,
    api_url,
    random_data_class,
    get_deal_updated_timestamp,
):
    json_file_name = "joint_spouse_balloon_cert.json"
    initial_timestamp = datetime.isoformat(datetime.now())
    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )

    # remove sourcePartnerDealerId from payload if present
    deal_data.payload.pop("sourcePartnerDealerId", None)

    # Add dealRefId & creditAppId in header
    fs_header_value = {
        "X-Deal-Reference-Id": deal_data.generate_random_id(True),
        "X-Credit-Application-Reference-Id": deal_data.generate_random_id(True),
    }
    status_code, response, resp_headers = deal_data.post_request(
        api_url, API_ROUTE, cust_header=fs_header_value
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )

    # Conform deal is saved in db successfully
    assert (
        get_deal_updated_timestamp(
            deal_ref_id=deal_data.dealRefId, updated_timestamp=initial_timestamp
        )
        > initial_timestamp
    )

    # Get Key-Data
    query_param = f"dealRefId={deal_data.dealRefId}"
    status_code, get_resp, resp_headers = deal_data.get_request(
        url=api_url, route_url=KEY_DATA_ROUTE, query_param=query_param
    )
    # partyId from targetPlatforms
    party_id = deal_data.payload["targetPlatforms"][0]["partyId"]
    assert get_resp[0].get("sourcePartnerDealerId") == party_id


@pytest.mark.smoke
@pytest.mark.prod
@pytest.mark.functional
def test_credit_app_post_with_source_partner_dealer_id_in_payload(
    env,
    api_url,
    random_data_class,
    get_deal_updated_timestamp,
):
    json_file_name = "joint_spouse_balloon_cert.json"
    initial_timestamp = datetime.isoformat(datetime.now())
    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )

    # Add sourcePartnerDealerId to the payload
    random = secrets.SystemRandom()
    source_dealer_id = str(random.getrandbits(26))
    deal_data.payload["sourcePartnerDealerId"] = source_dealer_id

    # Add dealRefId & creditAppId in header
    fs_header_value = {
        "X-Deal-Reference-Id": deal_data.generate_random_id(True),
        "X-Credit-Application-Reference-Id": deal_data.generate_random_id(True),
    }
    status_code, response, resp_headers = deal_data.post_request(
        api_url, API_ROUTE, cust_header=fs_header_value
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )

    # Conform deal is saved in db successfully
    assert (
        get_deal_updated_timestamp(
            deal_ref_id=deal_data.dealRefId, updated_timestamp=initial_timestamp
        )
        > initial_timestamp
    )

    # Get Key-Data
    query_param = f"dealRefId={deal_data.dealRefId}"
    status_code, get_resp, resp_headers = deal_data.get_request(
        url=api_url, route_url=KEY_DATA_ROUTE, query_param=query_param
    )
    # partyId from targetPlatforms
    assert get_resp[0].get("sourcePartnerDealerId") == source_dealer_id
