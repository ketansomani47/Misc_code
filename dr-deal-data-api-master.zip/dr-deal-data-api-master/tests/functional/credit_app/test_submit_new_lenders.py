# -*- coding: utf-8 -*-

from http import HTTPStatus

import pytest
from tests.functional.service_api import ServiceAPI


API_ROUTE = "credit_app"
LEAD_ROUTE = "leads"
LENDERS_SUBMIT = "submit_lenders"


@pytest.mark.prod
@pytest.mark.smoke
@pytest.mark.functional
def test_credit_app_lenders_new_lenders(
    env,
    api_url,
    random_data_class,
    verify_deal_component,
    get_deal_component_details,
    get_records_by_deal_ref_id,
):
    """
    Verify if record(s) is/are created in dynamodb when submitting one or multiple lenders
    """
    json_file = "credit_app/app_min_data.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class, env=env, json_file=json_file
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    # Confirm requested in saved in DB
    get_deal_component_details(
        deal_ref_id=deal_data.dealRefId, deal_component="DTC.APPLICANT"
    )

    deal_data.set_payload("credit_app/credit_app_lenderlist_payload.json")
    status_code, _, resp_headers = deal_data.patch(api_url, LENDERS_SUBMIT)

    if status_code != HTTPStatus.NO_CONTENT:
        raise Exception(
            f"Patch. Response code is: {status_code} and the response message is: {response}"
        )
    # Confirm requested in saved in DB
    get_deal_component_details(
        deal_ref_id=deal_data.dealRefId, deal_component="DTC.LENDERLIST.ABC"
    )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))

    lender_ids = [
        lender.get("lenderId") for lender in deal_data.payload.get("lenderList")
    ]
    for lender_id in lender_ids:
        verify_deal_component(records, deal_data.payload, f"lenderList.{lender_id}")


@pytest.mark.smoke
@pytest.mark.functional
def test_credit_app_lenders_submit_same_lender(
    env,
    api_url,
    random_data_class,
    get_deal_component_details_begins_with,
    verify_list_of_given_fields,
):
    """
    Verify that no record is created in dynamodb when submitting one lender that already exists
    """
    json_file = "credit_app/credit_app_max_data.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class, env=env, json_file=json_file
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    deal_ref_id = response.get("dealRefId")

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )

    lender_list_from_db = get_deal_component_details_begins_with(
        deal_ref_id, f"DTC.{'lenderList'.upper()}"
    )

    deal_data.set_payload(
        "credit_app/credit_app_lenderlist_repeated_lender_payload.json"
    )
    status_code, _, resp_headers = deal_data.patch(api_url, LENDERS_SUBMIT)

    if status_code != HTTPStatus.NO_CONTENT:
        raise Exception(
            f"Patch. Response code is: {status_code} and the response message is: {response}"
        )

    new_lender_list_from_db = get_deal_component_details_begins_with(
        deal_ref_id, f"DTC.{'lenderList'.upper()}"
    )

    lender_ids = [lender.get("lenderId") for lender in lender_list_from_db]
    new_lender_ids = [lender.get("lenderId") for lender in new_lender_list_from_db]

    # checking if lenders are the same (no creation happened)
    assert lender_ids == new_lender_ids


@pytest.mark.smoke
@pytest.mark.functional
def test_credit_app_lenders_bad_dealrefid(
    env,
    api_url,
    random_data_class,
    get_deal_component_details_begins_with,
    verify_list_of_given_fields,
):
    """
    Verify service is returning 400 response when passing bad dealRefId
    """
    json_file = "credit_app/credit_app_max_data.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class, env=env, json_file=json_file
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )

    # forcing bad dealRedId
    deal_data.dealRefId = deal_data.generate_random_id()

    deal_data.set_payload("credit_app/credit_app_lenderlist_payload.json")
    status_code, _, resp_headers = deal_data.patch(
        api_url, LENDERS_SUBMIT, cust_status_code=HTTPStatus.BAD_REQUEST
    )

    assert status_code == HTTPStatus.BAD_REQUEST


@pytest.mark.functional
def test_credit_app_lenders_bad_header(
    env,
    api_url,
    random_data_class,
    get_deal_component_details_begins_with,
    verify_list_of_given_fields,
):
    """
    Verify Service is returning 403 error when passing a bad header (x-origin-secret)
    """
    json_file = "credit_app/credit_app_max_data.json"
    deal_data = ServiceAPI(
        random_data_class=random_data_class, env=env, json_file=json_file
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )

    # creating bad header
    bad_header = {"x-origin-secret": ""}

    deal_data.set_payload("credit_app/credit_app_lenderlist_payload.json")
    status_code, _, resp_headers = deal_data.patch(
        api_url,
        LENDERS_SUBMIT,
        cust_header=bad_header,
        cust_status_code=HTTPStatus.FORBIDDEN,
    )

    assert status_code == HTTPStatus.FORBIDDEN
