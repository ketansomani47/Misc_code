# -*- coding: utf-8 -*-
import copy
from http import HTTPStatus

import pytest
from common.settings import ErrorMsgs
from tests.functional.service_api import ServiceAPI


API_ROUTE = "credit_app"
CA_UPDATE_DEAL = "deal_update"

update_data = [
    "update_applicant_top_level",
    "update_applicant_add_emp",
    "update_applicant_pii",
    "update_co_applicant_add_emp",
    "update_co_applicant_pii",
    "update_vehicle",
    "update_trade_in",
    "update_financeSummary",
]


@pytest.mark.prod
@pytest.mark.functional
@pytest.mark.parametrize("test_data_node_name", update_data)
def test_deal_update_with_new_data(
    env,
    api_url,
    update_test_data,
    test_data_node_name,
    random_data_class,
    get_deal_updated_timestamp,
    get_records_by_deal_ref_id,
    verify_get_response_against_posted_data,
):
    json_file_name = "app_min_data_honda.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(
        api_url,
        API_ROUTE,
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )

    # posted payload
    original_payload = copy.deepcopy(deal_data.payload)
    app_timestamp = get_deal_updated_timestamp(deal_data.dealRefId)

    deal_data.payload = update_test_data[test_data_node_name]
    deal_data.payload["sourcePartnerId"] = original_payload["sourcePartnerId"]
    deal_data.payload["targetPlatforms"] = original_payload["targetPlatforms"]
    status_code, response, resp_headers = deal_data.patch(
        api_url, CA_UPDATE_DEAL, lender_id="DT6"
    )

    if status_code != HTTPStatus.NO_CONTENT:
        raise Exception(
            f"Patch. Response code is: {status_code} and the response message is: {response}"
        )

    update_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId, updated_timestamp=app_timestamp
    )
    assert update_timestamp > app_timestamp

    #  full deal get
    status_code, get_resp, resp_headers = deal_data.get_request(
        url=api_url, route_url="deal_get", query_param="protected=true"
    )
    assert status_code == HTTPStatus.OK

    updated_payload = deal_data.merge_payloads_and_remove_pii(
        original_payload, deal_data.payload
    )
    verify_get_response_against_posted_data(updated_payload, get_resp)


@pytest.mark.smoke
@pytest.mark.functional
@pytest.mark.parametrize("test_data_node_name", update_data)
def test_deal_update_with_existing_data(
    env,
    api_url,
    update_test_data,
    test_data_node_name,
    random_data_class,
    get_deal_updated_timestamp,
    get_records_by_deal_ref_id,
    verify_get_response_against_posted_data,
):
    json_file_name = "joint_retail_certified.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )

    # posted payload
    original_payload = copy.deepcopy(deal_data.payload)
    app_timestamp = get_deal_updated_timestamp(deal_data.dealRefId)

    deal_data.payload = update_test_data[test_data_node_name]
    deal_data.payload["sourcePartnerId"] = original_payload["sourcePartnerId"]
    deal_data.payload["targetPlatforms"] = original_payload["targetPlatforms"]
    status_code, response, resp_headers = deal_data.patch(
        api_url, CA_UPDATE_DEAL, lender_id="DT6"
    )

    if status_code != HTTPStatus.NO_CONTENT:
        raise Exception(
            f"Patch. Response code is: {status_code} and the response message is: {response}"
        )
    update_timestamp = get_deal_updated_timestamp(
        deal_ref_id=deal_data.dealRefId, updated_timestamp=app_timestamp
    )
    assert update_timestamp > app_timestamp

    #  full deal get
    status_code, get_resp, resp_headers = deal_data.get_request(
        url=api_url, route_url="deal_get", query_param="protected=true"
    )
    assert status_code == HTTPStatus.OK

    updated_payload = deal_data.merge_payloads_and_remove_pii(
        original_payload, deal_data.payload
    )
    verify_get_response_against_posted_data(updated_payload, get_resp)


# Following are the Negative scenarios


@pytest.mark.functional
def test_update_credit_app_using_invalid_deal_ref_id(
    env, api_url, random_data_class, get_records_by_deal_ref_id
):
    json_file_name, _ = ("ind_retail_new.json", 11)

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(
        api_url,
        API_ROUTE,
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == no_of_records_expected
    assert response.get("creditAppId") is not None

    # Update Deal Ref ID to a random ID
    deal_data.dealRefId = deal_data.generate_random_id()

    # Update applicant
    deal_data.set_payload("credit_app/credit_app_full_payload.json", "applicant")
    status_code, response, resp_headers = deal_data.patch(
        url=api_url,
        route_url=CA_UPDATE_DEAL,
        cust_status_code=HTTPStatus.BAD_REQUEST,
        lender_id="DT6",
    )

    assert status_code == HTTPStatus.BAD_REQUEST
    assert response.get("message") == ErrorMsgs.missing_deal_from_db.format(
        deal_ref_id=deal_data.dealRefId
    )


@pytest.mark.functional
def test_update_deal_data_using_invalid_credit_app_id(
    env, api_url, random_data_class, get_records_by_deal_ref_id
):
    json_file_name, _ = ("ind_retail_new.json", 11)

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(
        api_url,
        API_ROUTE,
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == no_of_records_expected
    assert response.get("creditAppId") is not None

    # Update CA ID to a random ID
    deal_data.creditAppId = deal_data.generate_random_id()

    # Update applicant
    deal_data.set_payload("credit_app/credit_app_full_payload.json", "applicant")
    status_code, response, resp_headers = deal_data.patch(
        url=api_url,
        route_url=CA_UPDATE_DEAL,
        cust_status_code=HTTPStatus.BAD_REQUEST,
        lender_id="DT6",
    )

    assert status_code == HTTPStatus.BAD_REQUEST
    assert response.get("message") == ErrorMsgs.resource_id_mismatch.format(
        resource_id=deal_data.creditAppId, deal_ref_id=deal_data.dealRefId
    )


@pytest.mark.functional
def test_update_deal_data_using_empty_payload(
    env, api_url, random_data_class, get_records_by_deal_ref_id
):
    json_file_name, _ = ("ind_retail_new.json", 11)

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_app/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(
        api_url,
        API_ROUTE,
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == no_of_records_expected
    assert response.get("creditAppId") is not None

    # Update payload to None
    deal_data.payload = None

    status_code, response, resp_headers = deal_data.patch(
        url=api_url,
        route_url=CA_UPDATE_DEAL,
        cust_status_code=HTTPStatus.BAD_REQUEST,
        lender_id="DT6",
    )

    assert status_code == HTTPStatus.BAD_REQUEST
    assert response.get("message") == ErrorMsgs.missing_body_aws_event


@pytest.mark.prod
@pytest.mark.smoke
@pytest.mark.functional
def test_deal_data_update_with_additional_key_data(
    env,
    api_url,
    random_data_class,
    verify_deal_component,
    get_records_by_deal_ref_id,
):
    json_file = "credit_app/app_min_data.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class, env=env, json_file=json_file
    )

    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)
    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )

    # Custom Header
    add_keys_header = {
        "X-Lead-Reference-Number": deal_data.generate_random_id(),
        "X-Application-Reference-Number": deal_data.generate_random_id(),
        "X-Lead-Reference-Number-Internal": deal_data.generate_random_id(),
        "X-Application-Reference-Number-Internal": deal_data.generate_random_id(),
        "X-Deal-Jacket-ID": deal_data.generate_random_id(),
        "X-Dealer-Code": "6",
        "X-Deal-Reference-Number-UniFI": deal_data.generate_random_id(),
        "X-ABCD-ID": deal_data.generate_random_id(),
    }

    # Update Extra Data
    deal_data.set_payload("credit_app/credit_app_null_payload.json", "extraData")
    status_code, response, resp_headers = deal_data.patch(
        api_url, CA_UPDATE_DEAL, cust_header=add_keys_header, lender_id="DT6"
    )

    if status_code != HTTPStatus.NO_CONTENT:
        raise Exception(
            f"Patch. Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(deal_data.dealRefId)
    # assert count == 6

    add_keys_header["X-Lead-Reference-Number"] = None
    deal_data.payload.update(add_keys_header)
    verify_deal_component(
        records, deal_data.payload, "deal", additional_header_keys=True
    )
