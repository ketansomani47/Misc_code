# -*- coding: utf-8 -*-
from http import HTTPStatus

import pytest
from tests.functional.service_api import ServiceAPI


APP_POST_ROUTE = "credit_app"
POST_EVENT_ROUTE = "post_event"
GET_LENDER_ROUTE = "get_lender_ids"


class TestGetLenderId:
    @classmethod
    @pytest.fixture(autouse=True)
    def setup_method(cls, env, api_url, random_data_class, get_deal_updated_timestamp):
        cls.env = env
        cls.api_url = api_url
        cls.initial_timestamp = None
        cls.random_data_class = random_data_class
        cls.get_deal_updated_timestamp = get_deal_updated_timestamp
        cls.deal_data = ServiceAPI(random_data_class=random_data_class, env=env)

    def post_credit_app(self, app_file_name):
        self.deal_data.set_payload(file_name=app_file_name)
        # Add dealRefId & creditAppId in header
        fs_header_value = {
            "X-Deal-Reference-Id": self.deal_data.generate_random_id(True),
            "X-Credit-Application-Reference-Id": self.deal_data.generate_random_id(
                True
            ),
        }

        # Post a Credit App
        status_code, response, resp_headers = self.deal_data.post_request(
            self.api_url, APP_POST_ROUTE, cust_header=fs_header_value
        )
        self.deal_ref_id = response.get("dealRefId")
        if status_code != HTTPStatus.CREATED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {response}"
            )
        self.initial_timestamp = self.get_deal_updated_timestamp(
            deal_ref_id=self.deal_data.dealRefId
        )

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_credit_app_post_get_lender_ids_single_event_record(
        self,
        assert_headers,
        get_deal_updated_timestamp,
        get_deal_component_details,
        update_event_payload_random_data,
    ):
        """
        Post event records and get a single lender in response.
        """

        # Post Credit App
        self.post_credit_app("credit_app/ind_lease_cert_trade.json")
        app_timestamp = get_deal_updated_timestamp(deal_ref_id=self.deal_data.dealRefId)

        # Create Event using post API
        self.deal_data.set_payload("events/fs_internal_credit_decision_counter.json")
        update_event_payload_random_data(self.deal_data.payload, self.deal_ref_id, "fs")
        status_code, post_resp, headers = self.deal_data.post_request(
            self.api_url, POST_EVENT_ROUTE
        )
        if status_code != HTTPStatus.CREATED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {post_resp}"
            )
        assert post_resp == {
            "dealRefId": self.deal_ref_id,
            "eventId": self.deal_data.eventId,
        }
        event_timestamp = get_deal_updated_timestamp(
            deal_ref_id=self.deal_data.dealRefId,
            deal_component=f"DTC.EVENTS.{post_resp['eventId']}",
            updated_timestamp=app_timestamp,
        )
        assert event_timestamp > app_timestamp

        # get lender ids
        query_param = f"targetPlatformId={self.deal_data.payload['eventKeyData']['targetPlatform']}"
        status_code, resp_body, resp_headers = self.deal_data.get_request(
            url=self.api_url, route_url=GET_LENDER_ROUTE, query_param=query_param
        )

        if status_code != HTTPStatus.OK:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {resp_body}"
            )
        # validate the lender ids
        assert resp_body["lenderIds"] == [
            self.deal_data.payload["eventKeyData"]["lenderId"]
        ]
        assert_headers(resp_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_credit_app_post_get_lender_ids_single_idl_event_record(
        self,
        assert_headers,
        get_deal_updated_timestamp,
        get_deal_component_details,
        update_event_payload_random_data,
    ):
        """
        Post event records and get a single lender in response.
        """

        # Post Credit App
        self.post_credit_app("credit_app/ind_retail_new.json")
        app_timestamp = get_deal_updated_timestamp(deal_ref_id=self.deal_data.dealRefId)

        # Create Event using post API
        self.deal_data.set_payload("events/fs_internal_credit_decision_counter.json")
        update_event_payload_random_data(self.deal_data.payload, self.deal_ref_id, "fs")
        status_code, post_resp, headers = self.deal_data.post_request(
            self.api_url, POST_EVENT_ROUTE
        )
        if status_code != HTTPStatus.CREATED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {post_resp}"
            )
        assert post_resp == {
            "dealRefId": self.deal_ref_id,
            "eventId": self.deal_data.eventId,
        }
        event_timestamp = get_deal_updated_timestamp(
            deal_ref_id=self.deal_data.dealRefId,
            deal_component=f"DTC.EVENTS.{post_resp['eventId']}",
            updated_timestamp=app_timestamp,
        )
        assert event_timestamp > app_timestamp

        # get lender ids
        query_param = f"targetPlatformId={self.deal_data.payload['eventKeyData']['targetPlatform']}"
        status_code, resp_body, resp_headers = self.deal_data.get_request(
            url=self.api_url, route_url=GET_LENDER_ROUTE, query_param=query_param
        )

        if status_code != HTTPStatus.OK:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {resp_body}"
            )
        # validate the lender ids
        assert resp_body["lenderIds"] == [
            self.deal_data.payload["eventKeyData"]["lenderId"]
        ]
        assert_headers(resp_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_credit_app_post_get_lender_ids_multiple_event_record(
        self,
        assert_headers,
        get_lender_ids_valid_response,
        get_deal_component_details,
        update_event_payload_random_data,
    ):
        """
        Post multiple event records and get as many lenders in response.
        """
        # Post Credit App
        self.post_credit_app("credit_app/ind_lease_cert_trade.json")

        test_lender_id = ["BOA", "ALY", "DT6"]

        # Create 1St Event using post API
        self.deal_data.set_payload(
            file_name="events/fs_internal_credit_decision_counter.json"
        )
        for lender_id in test_lender_id:
            update_event_payload_random_data(
                payload=self.deal_data.payload,
                deal_ref_id=self.deal_ref_id,
                event_source="fs",
                lender_id=lender_id,
            )
            status_code, post_resp, headers = self.deal_data.post_request(
                self.api_url, POST_EVENT_ROUTE
            )
            if status_code != HTTPStatus.CREATED:
                raise Exception(
                    f"Response code is: {status_code} and the response message is: {post_resp}"
                )
            assert post_resp == {
                "dealRefId": self.deal_ref_id,
                "eventId": self.deal_data.eventId,
            }

            get_deal_component_details(
                self.deal_ref_id, f"DTC.EVENTS.{post_resp['eventId']}"
            )

        # get lender ids
        query_param = f"targetPlatformId={self.deal_data.payload['eventKeyData']['targetPlatform']}"
        status_code, resp_body, resp_headers = self.deal_data.get_request(
            url=self.api_url, route_url=GET_LENDER_ROUTE, query_param=query_param
        )

        if status_code != HTTPStatus.OK:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {resp_body}"
            )
        # validate the lender ids
        assert sorted(resp_body["lenderIds"]) == sorted(test_lender_id)
        assert_headers(resp_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    @pytest.mark.prod
    def test_credit_app_post_get_lender_ids_no_event_record(
        self,
        get_lender_ids_empty_response,
        assert_headers,
    ):
        """
        Post credit app with no event record. The lenderId in the response should be {"lenderIds": []}
        """
        # Post Credit App
        self.post_credit_app("credit_app/ind_lease_cert_trade.json")

        # get lender ids
        status_code, resp_body, resp_headers = self.deal_data.get_request(
            url=self.api_url, route_url=GET_LENDER_ROUTE
        )

        assert status_code == HTTPStatus.OK
        assert resp_body == get_lender_ids_empty_response
        assert_headers(resp_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    @pytest.mark.prod
    def test_credit_app_post_get_lender_ids_no_deal_ref_id(self, assert_headers):
        """
        Post credit app with no deal record. The response should be No Deal found for
        {dealRefId}
        """

        self.deal_data.dealRefId = self.deal_data.generate_random_id()

        # get lender ids without posting a deal
        status_code, resp_body, resp_headers = self.deal_data.get_request(
            url=self.api_url, route_url=GET_LENDER_ROUTE
        )
        assert status_code == HTTPStatus.BAD_REQUEST
        assert resp_body == {"message": f"No deal found for {self.deal_data.dealRefId}"}
        assert_headers(resp_headers)
