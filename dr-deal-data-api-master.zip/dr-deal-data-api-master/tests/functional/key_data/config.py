# -*- coding: utf-8 -*-
"""
Fields mapping per target platform and Fields allowed per target platform for POST API
Fields naming between what would be posted and get vs what would be save in DB.
GET would always return all DTA fields including fields that are not allows for posting:
                dealRefId, creditAppId, leadRefId""
"""
KEY_DATA_MAPPING = {
    "DTA": {
        "appRefIdFD": "appRefIdFD",
        "dealRefIdFD": "dealRefIdFD",
        "appRefIdFDInt": "appRefIdFDInt",
        "dealRefIdFDInt": "dealRefIdFDInt",
        "partnerCode": "partnerCode",
        "sourcePartnerId": "sourcePartnerId",
        "sourcePartnerDealerId": "sourcePartnerDealerId",
        "proxyPartnerId": "proxyPartnerId",
        "dealXgDealId": "dealXgDealId",
        "dealXgDealVersion": "dealXgDealVersion",
    },
    "DTC": {
        "dealJacketId": "dealJacketId",
        "dealRefIdFI": "dealRefIdFI",
        "dealIdFI": "dealIdFI",
        "dealerId": "dealerId",
        "dealerCode": "dealerCode",
        "documentMasterIndexIdFI": "documentMasterIndexIdFI",
        "commonOrgId": "commonOrgId",
    },
    "IDL": {
        "dealJacketId": "dealJacketIdIDL",
        "dealId": "dealIdIDL",
        "dealerCode": "dealerCodeIDL",
        "documentMasterIndexId": "documentMasterIndexIdIDL",
    },
    "R1J": {
        "dealJacketId": "dealJacketIdR1",
        "conversationId": "conversationIdR1",
        "creditAppIdR1": "creditAppIdR1",
    },
}

# Indexed fields for GET API v1
INDEXES_FIELDS_BY_TARGET = {
    "DTA": [
        "dealRefId",
        "creditAppId",
        "leadRefId",
        "appRefIdFD",
        "dealRefIdFD",
        "appRefIdFDInt",
        "dealRefIdFDInt",
    ],
    "DTC": ["dealJacketId", "dealRefIdFI"],
    "IDL": ["dealJacketId"],
    "R1J": ["creditAppIdR1"],
}

# Indexed fields for GET API v2
INDEXES_FIELDS_BY_TARGET_V2 = {
    "DTA": [
        "dealRefId",
        "creditAppId",
        "appRefIdFD",
        "dealRefIdFD",
        "appRefIdFDInt",
        "dealRefIdFDInt",
    ],
    "DTC": ["dealJacketId"],
    "IDL": ["dealJacketId"],
    "R1J": ["dealJacketId", "conversationId"],
}

# v2 Key-Data fields mapping by specific target and db record
KEY_DATA_V2_FIELDS_BY_RECORD = {
    "DTA": {
        "financeMethod": "financeMethod",
        "dealRefId": "dealRefId",
        "leadRefId": "leadRefId",
        "dealRefIdFD": "dealRefIdFD",
        "dealRefIdFDInt": "dealRefIdFDInt",
        "creditAppId": "creditAppId",
        "contractRefId": "contractRefId",
        "sourcePartnerId": "sourcePartnerId",
        "proxyPartnerId": "proxyPartnerId",
        "dealXgDealId": "dealXgDealId",
        "dealXgDealVersion": "dealXgDealVersion",
        "X-Lead-Reference-Number": "dealRefIdFD",
        "X-Lead-Reference-Number-Internal": "dealRefIdFDInt",
    },
    "DTA_APP": {
        "creditAppId": "creditAppId",
        "appRefIdFD": "appRefIdFD",
        "appRefIdFDInt": "appRefIdFDInt",
        "X-Application-Reference-Number": "appRefIdFD",
        "X-Application-Reference-Number-Internal": "appRefIdFDInt",
    },
    "DTC": {
        "dealJacketId": "dealJacketId",
        "dealerId": "dealerId",
        "dealerCode": "dealerCode",
        "documentMasterIndexId": "documentMasterIndexId",
        "sourcePartnerDealerId": "sourcePartnerDealerId",
        "X-Deal-Jacket-ID": "dealJacketId",
        "X-Dealer-Code": "dealerCode",
        "commonOrgId": "commonOrgId",
    },
    "DTC_APP": {"dealId": "dealId", "creditAppId": "creditAppId"},
    "IDL": {
        "dealJacketId": "dealJacketId",
        "dealerId": "dealerId",
        "dealerCode": "dealerCode",
        "documentMasterIndexId": "documentMasterIndexId",
        "sourcePartnerDealerId": "sourcePartnerDealerId",
        "X-Dealer-Code": "dealerCode",
        "X-Deal-Jacket-ID": "dealJacketId",
    },
    "IDL_APP": {"dealId": "dealId", "creditAppId": "creditAppId"},
    "R1J": {
        "dealJacketId": "dealJacketId",
        "sourcePartnerDealerId": "sourcePartnerDealerId",
    },
    "R1J_APP": {
        "conversationId": "conversationId",
        "creditAppIdR1": "creditAppIdR1",
        "creditAppId": "creditAppId",
    },
}

# v2 Key-Data fields mapping by specific target and db record
KEY_DATA_V2_GET_FIELDS_BY_RECORD = {
    "DTA": [
        "targetPlatformId",
        "proxyPartnerId",
        "dealXgDealId",
        "dealXgDealVersion",
        "financeMethod",
        "creditAppId",
        "dealRefId",
        "leadRefId",
        "contractRefId",
        "appRefIdFD",
        "dealRefIdFD",
        "appRefIdFDInt",
        "dealRefIdFDInt",
        "sourcePartnerId",
    ],
    "DTC": [
        "targetPlatformId",
        "creditAppId",
        "dealJacketId",
        "dealerCode",
        "documentMasterIndexId",
        "dealId",
        "sourcePartnerDealerId",
        "commonOrgId",
    ],  # creditAppId is not used as for DTC
    "IDL": [
        "targetPlatformId",
        "creditAppId",
        "dealJacketId",
        "dealerCode",
        "documentMasterIndexId",
        "dealId",
        "sourcePartnerDealerId",
    ],
    "R1J": [
        "targetPlatformId",
        "creditAppId",
        "dealJacketId",
        "conversationId",
        "creditAppIdR1",
        "sourcePartnerDealerId",
    ],
}

# v1 Key-Data Credit App key
CREDIT_APP_KEY_BY_TARGET = {
    "DTA": "creditAppId",
    "DTC": "dealIdFI",
    "IDL": "dealId",
    "R1J": "conversationId",
}
# v2 Key-Data Credit App key
CREDIT_APP_KEY_BY_TARGET_V2 = {
    "DTA": "creditAppId",
    "DTC": "dealId",
    "IDL": "dealId",
    "R1J": "conversationId",
}
