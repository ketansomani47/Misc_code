# -*- coding: utf-8 -*-
from http import HTTPStatus

import pytest
from tests.functional.key_data.config import CREDIT_APP_KEY_BY_TARGET
from tests.functional.service_api import ServiceAPI


KEY_DATA_POST_ROUTE = "key_data"


class TestKeyDataPost:
    @classmethod
    @pytest.fixture(autouse=True)
    def setup_method(cls, env, api_url, random_data_class):
        cls.env = env
        cls.api_url = api_url
        cls.deal_data = ServiceAPI(random_data_class=random_data_class, env=env)

    def post_request_based_on_route(
        self, expected_status=HTTPStatus.CREATED, cust_headers=None
    ):
        status_code, post_resp, resp_headers = self.deal_data.post_request(
            self.api_url, KEY_DATA_POST_ROUTE, cust_header=cust_headers
        )

        if status_code != expected_status:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {post_resp}"
            )

        return status_code, post_resp, resp_headers

    test_data = [
        "key_data_test_data_dta_record",
        "key_data_test_data_dtc_record",
        "key_data_test_data_default_record_dtc",
        "key_data_test_data_idl_record",
        "key_data_test_data_r1j_record",
    ]

    @pytest.mark.prod
    @pytest.mark.smoke
    @pytest.mark.functional
    @pytest.mark.parametrize("target_platforms_payloads", test_data)
    def test_key_data_post_for_all_target_platforms(
        self,
        common_assert,
        target_platforms_payloads,
        get_response_data,
        validate_v2_key_data,
        verify_given_dict_object,
        get_deal_component_details,
        key_data_test_data_dta_record,  # don't remove
        key_data_test_data_dtc_record,  # don't remove
        key_data_test_data_default_record_dtc,  # don't remove
        key_data_test_data_idl_record,  # don't remove
        key_data_test_data_r1j_record,  # don't remove
    ):
        self.deal_data.payload = eval(target_platforms_payloads)
        status_code, response, resp_headers = self.post_request_based_on_route()

        assert response.get("creditAppId") is None
        assert response.get("leadRefId") is None

        dtc_record = get_deal_component_details(
            response.get("dealRefId"), deal_component="DTC.DEAL"
        )
        common_assert(records=[dtc_record], resp_headers=resp_headers)

        # Validate v2 key-data record for Specific Target
        target_name = self.deal_data.payload.get("targetPlatformId", "DTC")
        target_key = f"REF_IDS.{target_name}"
        v2_record = get_deal_component_details(
            response.get("dealRefId"), deal_component=target_key
        )
        validate_v2_key_data(
            posted_payload=self.deal_data.payload,
            database_resp=v2_record,
            key_name=target_name,
        )

        # Validate v2 key-data record for Credit App
        ca_key = self.deal_data.payload.get(CREDIT_APP_KEY_BY_TARGET[target_name])
        if ca_key:
            v2_record = get_deal_component_details(
                response.get("dealRefId"), deal_component=f"{target_key}.{ca_key}"
            )
            validate_v2_key_data(
                posted_payload=self.deal_data.payload,
                database_resp=v2_record,
                key_name=f"{target_name}_APP",
            )

        # Validate v2 key-data record for DTA
        v2_record = get_deal_component_details(
            response.get("dealRefId"), deal_component="REF_IDS.DTA"
        )
        validate_v2_key_data(
            posted_payload=self.deal_data.payload,
            database_resp=v2_record,
            key_name="DTA",
        )

        # Update payload with DB key names and verify v1 key-data
        self.deal_data.update_key_data_fields_mapping()
        verify_given_dict_object(self.deal_data.payload, dtc_record)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_key_data_post_single_key(
        self,
        common_assert,
        get_response_data,
        validate_v2_key_data,
        verify_given_dict_object,
        get_deal_component_details,
        key_data_test_data_dtc_record_single_key,
    ):
        self.deal_data.payload = key_data_test_data_dtc_record_single_key
        status_code, response, resp_headers = self.post_request_based_on_route()

        assert response.get("creditAppId") is None
        assert response.get("leadRefId") is None

        record = get_deal_component_details(
            response.get("dealRefId"), deal_component="DTC.DEAL"
        )
        common_assert(records=[record], resp_headers=resp_headers)
        # Remove targetPlatforms from request payload as we do not save the value
        target_name = self.deal_data.payload.pop("targetPlatformId")
        verify_given_dict_object(self.deal_data.payload, record)

        #  Validate v2 key-data records
        v2_record = get_deal_component_details(
            response.get("dealRefId"), deal_component=f"REF_IDS.{target_name}"
        )
        validate_v2_key_data(
            posted_payload=self.deal_data.payload,
            database_resp=v2_record,
            key_name=target_name,
        )

        #  Validate v2 key-data record for DTA
        v2_record = get_deal_component_details(
            response.get("dealRefId"), deal_component="REF_IDS.DTA", zero_resp=True
        )

        assert v2_record is None

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_key_data_test_data_post_with_unsupported_key(
        self, invalid_key_data_test_data_dtc_record_with_unsupported_key
    ):
        self.deal_data.payload = (
            invalid_key_data_test_data_dtc_record_with_unsupported_key
        )
        status_code, response, resp_headers = self.post_request_based_on_route(
            HTTPStatus.BAD_REQUEST
        )
        assert response == {
            "message": "Given fields 'conversationId' is not supported for targetPlatformId DTC"
        }

    @pytest.mark.functional
    def test_key_data_post_random_id(self, invalid_key_data_test_data_dtc_random_key):
        self.deal_data.payload = invalid_key_data_test_data_dtc_random_key
        status_code, response, resp_headers = self.post_request_based_on_route(
            HTTPStatus.BAD_REQUEST
        )
        assert response == {"message": "Invalid request body"}

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_key_data_post_with_finance_method(
        self, invalid_key_data_test_data_for_finance_method
    ):
        self.deal_data.payload = invalid_key_data_test_data_for_finance_method
        status_code, response, resp_headers = self.post_request_based_on_route(
            HTTPStatus.BAD_REQUEST
        )
        assert response["message"] == "Invalid request body"

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_key_data_post_with_empty_body(
        self, invalid_key_data_test_data_empty_record
    ):
        self.deal_data.payload = invalid_key_data_test_data_empty_record
        status_code, response, resp_headers = self.post_request_based_on_route(
            HTTPStatus.BAD_REQUEST
        )
        assert response["message"] == "Invalid request body"

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_key_data_post_with_reference_keys(
        self, invalid_key_data_test_data_dta_record_with_reference_key
    ):
        self.deal_data.payload = (
            invalid_key_data_test_data_dta_record_with_reference_key
        )
        status_code, response, resp_headers = self.post_request_based_on_route(
            HTTPStatus.BAD_REQUEST
        )
        assert response == {"message": "Invalid request body"}

    @pytest.mark.smoke
    def test_key_data_post_with_old_removed_indexes(
        self, invalid_key_data_test_data_old_post_removed_keys
    ):

        for key, value in invalid_key_data_test_data_old_post_removed_keys.items():
            key_data_payload = {key: value}
            self.deal_data.payload = key_data_payload
            status_code, response, resp_headers = self.post_request_based_on_route(
                HTTPStatus.BAD_REQUEST
            )
            assert response == {"message": "Invalid request body"}

    @pytest.mark.functional
    def test_credit_app_post_with_invalid_test_data(self, invalid_payload):
        self.deal_data.payload = invalid_payload
        status_code, response, resp_headers = self.post_request_based_on_route(
            HTTPStatus.BAD_REQUEST
        )
        assert response == {"message": "Invalid request body"}

    @pytest.mark.functional
    def test_key_data_post_with_additional_key_data(
        self,
        key_data_test_data_dtc_record,
        verify_deal_component,
        validate_v2_key_data,
        get_deal_component_details,
        get_records_by_deal_ref_id,
    ):
        self.deal_data.payload = key_data_test_data_dtc_record
        add_keys_header = {
            "X-Lead-Reference-Number": self.deal_data.generate_random_id(),
            "X-Application-Reference-Number": self.deal_data.generate_random_id(),
            "X-Lead-Reference-Number-Internal": self.deal_data.generate_random_id(),
            "X-Application-Reference-Number-Internal": self.deal_data.generate_random_id(),
            "X-Deal-Reference-Number-UniFI": self.deal_data.generate_random_id(),
            "X-ABCD-ID": self.deal_data.generate_random_id(),
        }

        status_code, response, resp_headers = self.post_request_based_on_route(
            cust_headers=add_keys_header
        )

        records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
        self.deal_data.payload.update(add_keys_header)

        #  Validate v2 key-data DTC record
        v2_record = get_deal_component_details(
            response.get("dealRefId"), deal_component="REF_IDS.DTC"
        )
        validate_v2_key_data(
            posted_payload=self.deal_data.payload,
            database_resp=v2_record,
            key_name="DTC",
        )

        #  Validate v2 key-data DTC.{CreditApp} record
        v2_record = get_deal_component_details(
            response.get("dealRefId"),
            deal_component=f"REF_IDS.DTC.{self.deal_data.payload['dealIdFI']}",
        )
        validate_v2_key_data(
            posted_payload=self.deal_data.payload,
            database_resp=v2_record,
            key_name="DTC_APP",
        )

        #  Validate v2 key-data record for DTA
        v2_record = get_deal_component_details(
            response.get("dealRefId"), deal_component="REF_IDS.DTA"
        )
        validate_v2_key_data(
            posted_payload=self.deal_data.payload,
            database_resp=v2_record,
            key_name="DTA",
        )

        # Validate DTC.DEAL for v1 Key-Data
        verify_deal_component(
            records, add_keys_header, "deal", additional_header_keys=True
        )

    test_data = [
        "key_data_test_data_dtc_record",
        "key_data_test_data_default_record_dtc",
        "key_data_test_data_idl_record",
        "key_data_test_data_r1j_record",
    ]

    @pytest.mark.smoke
    @pytest.mark.functional
    @pytest.mark.parametrize("target_platforms_payloads", test_data)
    def test_key_data_post_dta_fields_allowed_for_all_target_platforms(
        self,
        target_platforms_payloads,
        get_response_data,
        validate_v2_key_data,
        verify_given_dict_object,
        get_deal_component_details,
        key_data_test_data_dta_record,  # don't remove
        key_data_test_data_dtc_record,  # don't remove
        key_data_test_data_default_record_dtc,  # don't remove
        key_data_test_data_idl_record,  # don't remove
        key_data_test_data_r1j_record,  # don't remove
    ):
        self.deal_data.payload = eval(target_platforms_payloads)
        payload_target = self.deal_data.payload.get("targetPlatformId", "DTC")
        self.deal_data.payload = {
            **key_data_test_data_dta_record,
            **self.deal_data.payload,
            "targetPlatformId": payload_target,
        }
        status_code, response, resp_headers = self.post_request_based_on_route()

        #  Validate v2 key-data records
        target_name = self.deal_data.payload.get("targetPlatformId", "DTC")
        target_key = f"REF_IDS.{target_name}"
        v2_record = get_deal_component_details(
            response.get("dealRefId"), deal_component=target_key
        )
        validate_v2_key_data(
            posted_payload=self.deal_data.payload,
            database_resp=v2_record,
            key_name=target_name,
        )

        #  Validate v2 key-data credit app records
        ca_key = self.deal_data.payload[CREDIT_APP_KEY_BY_TARGET[target_name]]
        v2_record = get_deal_component_details(
            response.get("dealRefId"), deal_component=f"{target_key}.{ca_key}"
        )
        validate_v2_key_data(
            posted_payload=self.deal_data.payload,
            database_resp=v2_record,
            key_name=f"{target_name}_APP",
        )

        #  Validate v2 key-data record for DTA
        v2_record = get_deal_component_details(
            response.get("dealRefId"), deal_component="REF_IDS.DTA"
        )
        validate_v2_key_data(
            posted_payload=self.deal_data.payload,
            database_resp=v2_record,
            key_name="DTA",
        )

        # Get DB Record
        dtc_record = get_deal_component_details(self.deal_data.dealRefId, "DTC.DEAL")
        # Update payload with DB key names and verify
        self.deal_data.update_key_data_fields_mapping()
        verify_given_dict_object(self.deal_data.payload, dtc_record)

    test_data = [
        "invalid_key_data_dtc_target_with_other_keys",
        "invalid_key_data_idl_target_with_other_keys",
        "invalid_key_data_r1j_target_with_other_keys",
    ]

    @pytest.mark.smoke
    @pytest.mark.functional
    @pytest.mark.parametrize("target_platforms_payloads", test_data)
    def test_key_data_post_other_target_platforms_are_not_allowed_except_dta(
        self,
        target_platforms_payloads,
        invalid_key_data_dtc_target_with_other_keys,  # don't remove
        invalid_key_data_idl_target_with_other_keys,  # don't remove
        invalid_key_data_r1j_target_with_other_keys,  # don't remove
    ):
        invalid_payload_list = eval(target_platforms_payloads)

        for payload in invalid_payload_list:
            error_fields = payload.pop("error_fields")
            self.deal_data.payload = payload

            status_code, response, resp_headers = self.post_request_based_on_route(
                HTTPStatus.BAD_REQUEST
            )
            target_platform = self.deal_data.payload.pop("targetPlatformId")

            assert response == {
                "message": f"Given fields '{error_fields}' is not supported for targetPlatformId {target_platform}"
            }
