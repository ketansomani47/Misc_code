# -*- coding: utf-8 -*-
import copy
import random
import string
import time
from http import HTTPStatus

import pytest
from tests.functional.key_data.config import INDEXES_FIELDS_BY_TARGET_V2
from tests.functional.service_api import ServiceAPI


APP_ROUTE = "credit_app"
LEAD_ROUTE = "leads"
KEY_DATA_UPDATE_ROUTE = "key_data_patch_v2"
KEY_DATA_GET_ROUTE = "key_data_get_v2"


class TestKeyDataPatch:
    @classmethod
    @pytest.fixture(autouse=True)
    def setup_method(cls, env, api_url, random_data_class, get_deal_component_details):
        cls.env = env
        cls.api_url = api_url
        cls.updated_timestamp = None
        cls.deal_data = ServiceAPI(random_data_class=random_data_class, env=env)
        cls.get_deal_component_details = get_deal_component_details

    def post_request_based_on_route(
        self,
        api_route=APP_ROUTE,
        expected_status=HTTPStatus.CREATED,
        cb_post=False,
        cust_headers=None,
    ):
        status_code, post_resp, resp_headers = self.deal_data.post_request(
            self.api_url,
            api_route,
            cb_post=cb_post,
            cust_header=cust_headers,
        )

        if status_code != expected_status:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {post_resp}"
            )

        record = self.get_deal_component_details(
            self.deal_data.dealRefId, deal_component="DTC.DEAL"
        )
        if not record:
            raise Exception(
                f"Deal is not created in DB for dealRefId: {self.deal_data.dealRefId}"
            )

        return post_resp, resp_headers

    def update_key_data(self, expected_status=HTTPStatus.NO_CONTENT, cust_header=None):
        status_code, patch_resp, resp_headers = self.deal_data.patch(
            url=self.api_url,
            route_url=KEY_DATA_UPDATE_ROUTE,
            cust_header=cust_header or {},
            cust_status_code=expected_status,
        )

        if status_code != expected_status:
            raise Exception(
                f"Patch. Response code is: {status_code} and the response message is: {patch_resp}"
            )

        return patch_resp, resp_headers

    def get_key_data_response(
        self, query_param, cust_header={}, expected_status_code=HTTPStatus.OK
    ):
        status_code, get_resp, resp_headers = self.deal_data.get_request(
            url=self.api_url,
            route_url=KEY_DATA_GET_ROUTE,
            query_param=query_param,
            cust_header=cust_header,
        )
        if status_code != expected_status_code:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {get_resp}"
            )
        return status_code, get_resp, resp_headers

    @staticmethod
    def filter_key_data_response(get_response, target_id, credit_app_id=None):
        for item in get_response:
            if credit_app_id:
                if (
                    target_id == item["targetPlatformId"]
                    and credit_app_id == item["creditAppId"]
                ):
                    return item
            else:
                if target_id == item["targetPlatformId"]:
                    return item

    all_targets_test_data = [
        ("key_data_test_data_dta_v2_record", "DTA", 1, ["DTA"]),
        ("key_data_test_data_dtc_v2_record", "DTC", 2, ["DTA", "DTC"]),
        ("key_data_test_data_idl_v2_record", "IDL", 2, ["DTA", "IDL"]),
        ("key_data_test_data_r1j_v2_record", "R1J", 2, ["DTA", "R1J"]),
    ]

    @pytest.mark.prod
    @pytest.mark.smoke
    @pytest.mark.functional
    @pytest.mark.parametrize(
        "target_platforms_payloads, key_data_target, expected_get_count, target_list",
        all_targets_test_data,
    )
    def test_key_data_get_with_all_target_platforms_credit_app_flow(
        self,
        target_list,
        common_assert,
        key_data_target,
        assert_headers,
        get_response_data,
        expected_get_count,
        target_platforms_payloads,
        verify_given_dict_object,
        get_deal_component_details,
        validate_v2_key_data_get_response,
        key_data_test_data_dta_v2_record,
        key_data_test_data_dtc_v2_record,
        key_data_test_data_idl_v2_record,
        key_data_test_data_r1j_v2_record,
    ):

        # Post a credit app
        self.deal_data.set_payload(file_name="credit_app/app_min_data.json")
        # Update random targetPlatforms based of key-data record
        random_party_id = "".join(
            random.choices(string.ascii_uppercase + string.digits, k=6)
        )
        self.deal_data.payload["targetPlatforms"] = [
            {"id": key_data_target, "partyId": random_party_id}
        ]
        app_resp, resp_headers = self.post_request_based_on_route(APP_ROUTE)

        # v2 Patch Key-Data Patch
        self.deal_data.payload = eval(target_platforms_payloads)
        self.deal_data.payload["creditAppId"] = app_resp["creditAppId"]
        patch_resp, resp_headers = self.update_key_data()

        # Add partyId as sourcePartnerDealerId in the payload for validation
        self.deal_data.payload["dealRefId"] = app_resp["dealRefId"]
        self.deal_data.payload[
            "sourcePartnerDealerId"
        ] = random_party_id  # partyId from credit app

        # Validate headers and TTL
        dtc_record = get_deal_component_details(
            deal_ref_id=app_resp.get("dealRefId"), deal_component="DTC.DEAL"
        )
        common_assert(records=[dtc_record], resp_headers=resp_headers)

        # Validate Key-Data v2 GET Response
        payload_target = self.deal_data.payload["targetPlatformId"]
        target_indexes = INDEXES_FIELDS_BY_TARGET_V2[payload_target]
        for index in target_indexes:
            if self.deal_data.payload.get(index):
                query_param = f"{index}={self.deal_data.payload[index]}&targetPlatformId={payload_target}"
                status_code, get_resp, resp_headers = self.get_key_data_response(
                    query_param
                )
                assert_headers(resp_headers=resp_headers)
                assert (
                    len(get_resp) == expected_get_count
                ), f"Expected {expected_get_count} records but received {len(get_resp)}"

                # Validate get response one at time record
                for target in target_list:
                    get_record = self.filter_key_data_response(
                        get_response=get_resp, target_id=target
                    )
                    self.deal_data.payload["targetPlatformId"] = target
                    validate_v2_key_data_get_response(
                        posted_payload=self.deal_data.payload,
                        get_response=get_record,
                        key_name=target,
                    )

    test_data = [
        (
            "key_data_test_data_dta_v2_record",
            "DTA",
            ["creditAppId", "financeMethod"],
            1,
            ["DTA"],
        ),
        (
            "key_data_test_data_dtc_v2_record",
            "DTC",
            ["creditAppId", "dealId"],
            2,
            ["DTA", "DTC"],
        ),
        (
            "key_data_test_data_idl_v2_record",
            "IDL",
            ["creditAppId", "dealId"],
            2,
            ["DTA", "IDL"],
        ),
        (
            "key_data_test_data_r1j_v2_record",
            "R1J",
            ["creditAppId", "conversationId", "creditAppIdR1"],
            2,
            ["DTA", "R1J"],
        ),
    ]

    @pytest.mark.smoke
    @pytest.mark.functional
    @pytest.mark.parametrize(
        "target_platforms_payloads, key_data_target, fields_to_remove, expected_get_count, target_list",
        test_data,
    )
    def test_key_data_get_with_all_target_platforms_lead_flow_without_ca_fields(
        self,
        target_list,
        common_assert,
        key_data_target,
        assert_headers,
        fields_to_remove,
        get_response_data,
        expected_get_count,
        target_platforms_payloads,
        verify_given_dict_object,
        get_deal_component_details,
        validate_v2_key_data_get_response,
        key_data_test_data_dta_v2_record,
        key_data_test_data_dtc_v2_record,
        key_data_test_data_idl_v2_record,
        key_data_test_data_r1j_v2_record,
    ):
        # Post a Lead
        self.deal_data.set_payload(file_name="leads/leads_min_data.json")
        # Update random targetPlatforms based of key-data record
        random_party_id = "".join(
            random.choices(string.ascii_uppercase + string.digits, k=6)
        )
        self.deal_data.payload["targetPlatforms"] = [
            {"id": key_data_target, "partyId": random_party_id}
        ]
        lead_resp, resp_headers = self.post_request_based_on_route(LEAD_ROUTE)

        # v2 Patch Key-Data Patch
        self.deal_data.payload = eval(target_platforms_payloads)
        for field in fields_to_remove:
            del self.deal_data.payload[field]
        patch_resp, resp_headers = self.update_key_data()

        # Validate headers and TTL
        dtc_record = get_deal_component_details(
            deal_ref_id=lead_resp.get("dealRefId"), deal_component="DTC.DEAL"
        )
        common_assert(records=[dtc_record], resp_headers=resp_headers)

        # Validate Key-Data v2 GET Response
        payload_target = self.deal_data.payload["targetPlatformId"]
        target_indexes = INDEXES_FIELDS_BY_TARGET_V2[payload_target]
        for index in target_indexes:
            if self.deal_data.payload.get(index):
                query_param = f"{index}={self.deal_data.payload[index]}&targetPlatformId={payload_target}"
                status_code, get_resp, resp_headers = self.get_key_data_response(
                    query_param
                )
                assert_headers(resp_headers=resp_headers)
                assert (
                    len(get_resp) == expected_get_count
                ), f"Expected {expected_get_count} records but received {len(get_resp)}"

                # Validate get response one at time record
                for target in target_list:
                    dta_record = self.filter_key_data_response(
                        get_response=get_resp, target_id=target
                    )
                    self.deal_data.payload["targetPlatformId"] = target
                    validate_v2_key_data_get_response(
                        posted_payload=self.deal_data.payload,
                        get_response=dta_record,
                        key_name=target,
                    )

    @pytest.mark.prod
    @pytest.mark.functional
    def test_key_data_get_single_target_patch(
        self,
        common_assert,
        assert_headers,
        get_response_data,
        validate_v2_key_data,
        verify_given_dict_object,
        get_deal_component_details,
        validate_v2_key_data_get_response,
        key_data_test_data_idl_v2_record,
    ):
        self.deal_data.set_payload(file_name="credit_app/app_min_data_honda.json")
        party_id = self.deal_data.payload["targetPlatforms"][0]["partyId"]
        app_resp, resp_headers = self.post_request_based_on_route(APP_ROUTE)

        # Patch with key-data
        self.deal_data.payload = key_data_test_data_idl_v2_record
        self.deal_data.payload["creditAppId"] = self.deal_data.creditAppId
        patch_resp, resp_headers = self.update_key_data()
        record = get_deal_component_details(
            deal_ref_id=app_resp.get("dealRefId"),
            deal_component=f"REF_IDS.{self.deal_data.payload['targetPlatformId']}",
        )
        common_assert(records=[record], resp_headers=resp_headers)

        # Add partyId as sourcePartnerDealerId for validation
        key_data_test_data_idl_v2_record["sourcePartnerDealerId"] = party_id

        key_data_test_data_idl_v2_record["dealRefId"] = app_resp["dealRefId"]
        query_param = f"dealJacketId={key_data_test_data_idl_v2_record['dealJacketId']}&targetPlatformId=IDL"
        status_code, get_resp, resp_headers = self.get_key_data_response(query_param)
        assert_headers(resp_headers=resp_headers)
        assert len(get_resp) == 2, f"Expected 2 records but received {len(get_resp)}"
        # Target Record
        resp_record = self.filter_key_data_response(
            get_response=get_resp, target_id="IDL"
        )
        validate_v2_key_data_get_response(
            posted_payload=key_data_test_data_idl_v2_record,
            get_response=resp_record,
            key_name="IDL",
        )
        # DTA Record
        resp_record = self.filter_key_data_response(
            get_response=get_resp, target_id="DTA"
        )
        key_data_test_data_idl_v2_record["targetPlatformId"] = "DTA"
        validate_v2_key_data_get_response(
            posted_payload=key_data_test_data_idl_v2_record,
            get_response=resp_record,
            key_name="DTA",
        )

    @pytest.mark.functional
    def test_key_data_get_dtc_r1j_patches(
        self,
        common_assert,
        assert_headers,
        get_response_data,
        validate_v2_key_data,
        verify_given_dict_object,
        get_deal_component_details,
        validate_v2_key_data_get_response,
        key_data_test_data_dtc_v2_record,
        key_data_test_data_r1j_v2_record,
    ):
        self.deal_data.set_payload(file_name="credit_app/ind_retail_new.json")
        dtc_party_id = "K34J5H3"
        r1j_party_id = "JH534G"
        targets_list = [
            {"id": "DTC", "partyId": dtc_party_id},
            {"id": "R1J", "partyId": r1j_party_id},
        ]
        self.deal_data.payload["targetPlatforms"] = targets_list
        app_resp, resp_headers = self.post_request_based_on_route(APP_ROUTE)

        # All target platforms
        key_data_target_payload = [
            key_data_test_data_dtc_v2_record,
            key_data_test_data_r1j_v2_record,
        ]

        # Patch Key-Data
        for patch_payload in key_data_target_payload:
            # Patch with key-data
            self.deal_data.payload = patch_payload
            self.deal_data.payload["creditAppId"] = self.deal_data.creditAppId
            patch_resp, resp_headers = self.update_key_data()
            record = get_deal_component_details(
                deal_ref_id=app_resp.get("dealRefId"),
                deal_component=f"REF_IDS.{self.deal_data.payload['targetPlatformId']}",
            )
            common_assert(records=[record], resp_headers=resp_headers)

        # Add partyId as sourcePartnerDealerId for validation
        key_data_test_data_dtc_v2_record["sourcePartnerDealerId"] = dtc_party_id
        key_data_test_data_r1j_v2_record["sourcePartnerDealerId"] = r1j_party_id

        # Validate get response one at time
        for target_payload in key_data_target_payload:
            payload_target = target_payload["targetPlatformId"]
            target_payload["dealRefId"] = app_resp["dealRefId"]
            query_param = f"dealJacketId={target_payload['dealJacketId']}&targetPlatformId={payload_target}"
            status_code, get_resp, resp_headers = self.get_key_data_response(
                query_param
            )
            assert_headers(resp_headers=resp_headers)
            assert (
                len(get_resp) == 2
            ), f"Expected 2 records but received {len(get_resp)}"
            # Target Record
            resp_record = self.filter_key_data_response(
                get_response=get_resp, target_id=payload_target
            )
            validate_v2_key_data_get_response(
                posted_payload=target_payload,
                get_response=resp_record,
                key_name=payload_target,
            )
            # DTA Record
            resp_record = self.filter_key_data_response(
                get_response=get_resp, target_id="DTA"
            )
            target_payload["targetPlatformId"] = "DTA"
            validate_v2_key_data_get_response(
                posted_payload=target_payload,
                get_response=resp_record,
                key_name="DTA",
            )

    @pytest.mark.prod
    @pytest.mark.functional
    def test_key_data_get_dtc_idl_patches(
        self,
        common_assert,
        assert_headers,
        get_response_data,
        validate_v2_key_data,
        verify_given_dict_object,
        get_deal_component_details,
        validate_v2_key_data_get_response,
        key_data_test_data_dtc_v2_record,
        key_data_test_data_idl_v2_record,
    ):
        self.deal_data.set_payload(file_name="credit_app/ind_retail_new.json")
        dtc_party_id = "K34J5H3"
        idl_party_id = "JH534G"
        targets_list = [
            {"id": "DTC", "partyId": dtc_party_id},
            {"id": "IDL", "partyId": idl_party_id},
        ]
        self.deal_data.payload["targetPlatforms"] = targets_list
        app_resp, resp_headers = self.post_request_based_on_route(APP_ROUTE)

        # All target platforms
        key_data_target_payload = [
            key_data_test_data_dtc_v2_record,
            key_data_test_data_idl_v2_record,
        ]

        # Patch Key-Data
        for patch_payload in key_data_target_payload:
            # Patch with key-data
            self.deal_data.payload = patch_payload
            self.deal_data.payload["creditAppId"] = self.deal_data.creditAppId
            patch_resp, resp_headers = self.update_key_data()
            record = get_deal_component_details(
                deal_ref_id=app_resp.get("dealRefId"),
                deal_component=f"REF_IDS.{self.deal_data.payload['targetPlatformId']}",
            )
            common_assert(records=[record], resp_headers=resp_headers)

        # Add partyId as sourcePartnerDealerId for validation
        key_data_test_data_dtc_v2_record["sourcePartnerDealerId"] = dtc_party_id
        key_data_test_data_idl_v2_record["sourcePartnerDealerId"] = idl_party_id

        # Validate get response one at time
        for target_payload in key_data_target_payload:
            payload_target = target_payload["targetPlatformId"]
            target_payload["dealRefId"] = app_resp["dealRefId"]
            query_param = f"dealJacketId={target_payload['dealJacketId']}&targetPlatformId={payload_target}"
            status_code, get_resp, resp_headers = self.get_key_data_response(
                query_param
            )
            assert_headers(resp_headers=resp_headers)
            assert (
                len(get_resp) == 2
            ), f"Expected 2 records but received {len(get_resp)}"
            # Target Record
            resp_record = self.filter_key_data_response(
                get_response=get_resp, target_id=payload_target
            )
            validate_v2_key_data_get_response(
                posted_payload=target_payload,
                get_response=resp_record,
                key_name=payload_target,
            )
            # DTA Record
            resp_record = self.filter_key_data_response(
                get_response=get_resp, target_id="DTA"
            )
            target_payload["targetPlatformId"] = "DTA"
            validate_v2_key_data_get_response(
                posted_payload=target_payload,
                get_response=resp_record,
                key_name="DTA",
            )

    @pytest.mark.functional
    def test_key_data_get_after_multiple_patches(
        self,
        common_assert,
        assert_headers,
        get_response_data,
        validate_v2_key_data,
        verify_given_dict_object,
        get_deal_component_details,
        validate_v2_key_data_get_response,
        key_data_test_data_dta_v2_record,
        key_data_test_data_dtc_v2_record,
        key_data_test_data_idl_v2_record,
        key_data_test_data_r1j_v2_record,
    ):
        self.deal_data.set_payload(file_name="credit_app/ind_retail_new.json")
        app_resp, resp_headers = self.post_request_based_on_route(APP_ROUTE)

        # All target platforms
        key_data_target_payload = [
            key_data_test_data_dta_v2_record,
            key_data_test_data_dtc_v2_record,
            key_data_test_data_idl_v2_record,
            key_data_test_data_r1j_v2_record,
        ]

        # Patch Key-Data
        for patch_payload in key_data_target_payload:
            # Patch with key-data
            self.deal_data.payload = patch_payload
            self.deal_data.payload["creditAppId"] = self.deal_data.creditAppId
            patch_resp, resp_headers = self.update_key_data()
            record = get_deal_component_details(
                deal_ref_id=app_resp.get("dealRefId"),
                deal_component=f"REF_IDS.{self.deal_data.payload['targetPlatformId']}",
            )
            common_assert(records=[record], resp_headers=resp_headers)

        # Validate get response one at time record
        for target_payload in key_data_target_payload:
            payload_target = target_payload["targetPlatformId"]
            get_index = "dealJacketId" if payload_target != "DTA" else "dealRefId"
            expected_count = 4 if payload_target == "DTA" else 2
            target_payload["dealRefId"] = app_resp["dealRefId"]
            query_param = f"{get_index}={target_payload[get_index]}&targetPlatformId={payload_target}"
            status_code, get_resp, resp_headers = self.get_key_data_response(
                query_param
            )
            assert_headers(resp_headers=resp_headers)
            assert (
                len(get_resp) == expected_count
            ), f"Expected {expected_count} records but received {len(get_resp)}"
            # Target Record
            resp_record = self.filter_key_data_response(
                get_response=get_resp, target_id=payload_target
            )
            validate_v2_key_data_get_response(
                posted_payload=target_payload,
                get_response=resp_record,
                key_name=payload_target,
            )
            # DTA Record
            resp_record = self.filter_key_data_response(
                get_response=get_resp, target_id="DTA"
            )
            target_payload["targetPlatformId"] = "DTA"
            validate_v2_key_data_get_response(
                posted_payload=target_payload,
                get_response=resp_record,
                key_name="DTA",
            )

    @pytest.mark.smoke
    @pytest.mark.functional
    @pytest.mark.parametrize(
        "target_platforms_payloads, key_data_target, expected_get_count, target_list",
        all_targets_test_data,
    )
    def test_key_data_get_no_result_found(
        self,
        target_list,
        assert_headers,
        key_data_target,
        get_response_data,
        expected_get_count,
        target_platforms_payloads,
        verify_given_dict_object,
        get_deal_component_details,
        validate_v2_key_data_get_response,
        key_data_test_data_dta_v2_record,
        key_data_test_data_dtc_v2_record,
        key_data_test_data_idl_v2_record,
        key_data_test_data_r1j_v2_record,
    ):
        # Post a credit app
        self.deal_data.set_payload(file_name="credit_app/app_min_data.json")
        # Update random targetPlatforms based of key-data record
        random_party_id = "".join(
            random.choices(string.ascii_uppercase + string.digits, k=6)
        )
        self.deal_data.payload["targetPlatforms"] = [
            {"id": key_data_target, "partyId": random_party_id}
        ]
        app_resp, resp_headers = self.post_request_based_on_route(APP_ROUTE)

        # Get key-data
        target_indexes = INDEXES_FIELDS_BY_TARGET_V2[key_data_target]
        for index in target_indexes:
            if self.deal_data.payload.get(index):
                query_param = f"{index}=123XYZ&targetPlatformId={key_data_target}"
                status_code, get_resp, resp_headers = self.get_key_data_response(
                    query_param, expected_status_code=HTTPStatus.NO_CONTENT
                )
                assert status_code == HTTPStatus.NO_CONTENT
                assert get_resp is None
                assert_headers(resp_headers=resp_headers)

    test_data = [
        ("key_data_test_data_dtc_v2_record", "DTC", ["IDL", "R1J"]),
        ("key_data_test_data_idl_v2_record", "IDL", ["DTC", "R1J"]),
        ("key_data_test_data_r1j_v2_record", "R1J", ["IDL", "DTC"]),
    ]

    @pytest.mark.prod
    @pytest.mark.smoke
    @pytest.mark.functional
    @pytest.mark.parametrize(
        "target_platforms_payloads, key_data_target, none_matching_targets", test_data
    )
    def test_key_data_get_with_none_matching_query_and_target(
        self,
        common_assert,
        assert_headers,
        key_data_target,
        get_response_data,
        none_matching_targets,
        target_platforms_payloads,
        verify_given_dict_object,
        get_deal_component_details,
        validate_v2_key_data_get_response,
        key_data_test_data_dta_v2_record,
        key_data_test_data_dtc_v2_record,
        key_data_test_data_idl_v2_record,
        key_data_test_data_r1j_v2_record,
    ):
        # Post a credit app
        self.deal_data.set_payload(file_name="credit_app/app_min_data.json")
        # Update random targetPlatforms based of key-data record
        random_party_id = "".join(
            random.choices(string.ascii_uppercase + string.digits, k=6)
        )
        self.deal_data.payload["targetPlatforms"] = [
            {"id": key_data_target, "partyId": random_party_id}
        ]
        app_resp, resp_headers = self.post_request_based_on_route(APP_ROUTE)

        # v2 Patch Key-Data Patch
        self.deal_data.payload = eval(target_platforms_payloads)
        self.deal_data.payload["creditAppId"] = app_resp["creditAppId"]
        patch_resp, resp_headers = self.update_key_data()

        # Validate headers and TTL
        dtc_record = get_deal_component_details(
            deal_ref_id=app_resp.get("dealRefId"), deal_component="DTC.DEAL"
        )
        common_assert(records=[dtc_record], resp_headers=resp_headers)

        # Confirm result found with correct target
        query_param = f"dealJacketId={self.deal_data.payload['dealJacketId']}&targetPlatformId={key_data_target}"
        status_code, get_resp, resp_headers = self.get_key_data_response(query_param)
        assert status_code == HTTPStatus.OK
        assert len(get_resp) == 2

        # Validate Key-Data v2 GET Response with none matching target
        for target in none_matching_targets:
            query_param = f"dealJacketId={self.deal_data.payload['dealJacketId']}&targetPlatformId={target}"
            status_code, get_resp, resp_headers = self.get_key_data_response(
                query_param, expected_status_code=HTTPStatus.NO_CONTENT
            )
            assert_headers(resp_headers=resp_headers)
            assert status_code == HTTPStatus.NO_CONTENT
            assert get_resp is None

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_key_data_get_with_invalid_target_id(
        self,
        assert_headers,
        get_response_data,
        verify_given_dict_object,
        get_deal_component_details,
        key_data_test_data_dta_v2_record,
    ):
        # Post a credit app
        self.deal_data.set_payload(file_name="credit_app/app_min_data.json")
        # Update random targetPlatforms based of key-data record
        random_target = "".join(random.choices(string.ascii_uppercase, k=3))
        app_resp, resp_headers = self.post_request_based_on_route(APP_ROUTE)

        query_param = (
            f"dealRefId={app_resp['dealRefId']}&targetPlatformId={random_target}"
        )
        status_code, get_resp, resp_headers = self.get_key_data_response(
            query_param, expected_status_code=HTTPStatus.BAD_REQUEST
        )
        assert (
            get_resp["message"]
            == f"Given target platform, {random_target} is not supported."
        )
        assert_headers(resp_headers=resp_headers)

    test_data = [
        ("DTA", ["dealJacketId", "conversationId"]),
        ("DTC", ["conversationId", "dealRefId"]),
        ("IDL", ["conversationId"]),
        ("R1J", ["creditAppId"]),
    ]

    @pytest.mark.smoke
    @pytest.mark.functional
    @pytest.mark.parametrize("target_id, invalid_fields_list", test_data)
    def test_key_data_get_with_invalid_fields_and_target(
        self,
        target_id,
        common_assert,
        get_response_data,
        invalid_fields_list,
    ):
        # Post a credit app
        self.deal_data.set_payload(file_name="credit_app/app_min_data.json")
        self.deal_data.payload["targetPlatforms"] = [
            {"id": target_id, "partyId": "1234"}
        ]
        app_resp, resp_headers = self.post_request_based_on_route(APP_ROUTE)

        for field in invalid_fields_list:
            query_param = f"{field}=122345678&targetPlatformId={target_id}"
            status_code, get_resp, resp_headers = self.get_key_data_response(
                query_param, expected_status_code=HTTPStatus.BAD_REQUEST
            )
            assert (
                get_resp["message"]
                == f"Given query param, {field} is not supported for targetPlatformId {target_id}"
            )

    test_data = [
        ("key_data_test_data_dtc_v2_record", "DTC", "dealId"),
        ("key_data_test_data_idl_v2_record", "IDL", "dealId"),
        ("key_data_test_data_r1j_v2_record", "R1J", "conversationId"),
    ]

    @pytest.mark.functional
    @pytest.mark.parametrize(
        "target_platforms_payloads, target_id, app_field_per_target", test_data
    )
    def test_key_data_get_with_multiple_credit_apps(
        self,
        target_id,
        common_assert,
        assert_headers,
        get_response_data,
        create_deal_record,
        app_field_per_target,
        target_platforms_payloads,
        verify_given_dict_object,
        get_deal_component_details,
        validate_v2_key_data_get_response,
        key_data_test_data_dtc_v2_record,
        key_data_test_data_idl_v2_record,
        key_data_test_data_r1j_v2_record,
    ):
        # Credit App Post
        self.deal_data.set_payload(file_name="credit_app/app_min_data_honda.json")
        random_party_id = "".join(
            random.choices(string.ascii_uppercase + string.digits, k=6)
        )
        self.deal_data.payload["targetPlatforms"] = [
            {"id": target_id, "partyId": random_party_id}
        ]
        app_resp, resp_headers = self.post_request_based_on_route(APP_ROUTE)

        # Patch with key-data - First CA Patch
        key_data_payload = eval(target_platforms_payloads)
        initial_key_data_payload = copy.deepcopy(key_data_payload)

        key_data_target = key_data_payload["targetPlatformId"]
        self.deal_data.payload = key_data_payload
        self.deal_data.payload["creditAppId"] = self.deal_data.creditAppId
        patch_resp, resp_headers = self.update_key_data()
        record = get_deal_component_details(
            deal_ref_id=app_resp.get("dealRefId"),
            deal_component=f"REF_IDS.{key_data_target}",
        )
        common_assert(records=[record], resp_headers=resp_headers)

        # Add partyId as sourcePartnerDealerId for validation
        self.deal_data.payload["sourcePartnerDealerId"] = random_party_id
        self.deal_data.payload["dealRefId"] = app_resp["dealRefId"]
        query_param = f"dealJacketId={self.deal_data.payload['dealJacketId']}&targetPlatformId={key_data_target}"
        status_code, get_resp, resp_headers = self.get_key_data_response(query_param)
        assert_headers(resp_headers=resp_headers)
        assert len(get_resp) == 2, f"Expected 2 records but received {len(get_resp)}"

        # Target Record
        resp_record = self.filter_key_data_response(
            get_response=get_resp, target_id=key_data_target
        )
        validate_v2_key_data_get_response(
            posted_payload=self.deal_data.payload,
            get_response=resp_record,
            key_name=key_data_target,
        )

        # DTA Record
        resp_record = self.filter_key_data_response(
            get_response=get_resp, target_id="DTA"
        )
        self.deal_data.payload["targetPlatformId"] = "DTA"
        validate_v2_key_data_get_response(
            posted_payload=self.deal_data.payload,
            get_response=resp_record,
            key_name="DTA",
        )

        # Create DTA Credit App Record in DB for second Credit App
        # This step is done manually until multiple credit apps are supported by FS
        new_dta_app_id = self.deal_data.generate_random_id(ulid_id=True)
        deal_comp = f"REF_IDS.DTA.{new_dta_app_id}"
        dta_ca_payload = {
            "dealRefId": self.deal_data.dealRefId,
            "dealComponent": deal_comp,
            "createdTimestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "creditAppId": new_dta_app_id,
            "updatedTimestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
        }
        create_deal_record(
            deal_ref_id=self.deal_data.dealRefId,
            deal_comp=deal_comp,
            record=dta_ca_payload,
        )
        self.deal_data.payload = {
            "targetPlatformId": "DTA",
            "creditAppId": new_dta_app_id,
            "financeMethod": random.choice(["Finance", "Lease", "Balloon", "Cash"]),
        }
        patch_resp, resp_headers = self.update_key_data()

        # Patch with key-data - Second CA Patch
        self.deal_data.payload = initial_key_data_payload
        self.deal_data.payload["creditAppId"] = new_dta_app_id  # New DTA CA ID
        self.deal_data.payload[app_field_per_target] = str(
            random.getrandbits(52)
        )  # New target CA ID
        patch_resp, resp_headers = self.update_key_data()
        record = get_deal_component_details(
            deal_ref_id=app_resp.get("dealRefId"),
            deal_component=f"REF_IDS.{key_data_target}.{self.deal_data.payload[app_field_per_target]}",
        )
        common_assert(records=[record], resp_headers=resp_headers)

        # Add partyId as sourcePartnerDealerId back to payload for validation
        self.deal_data.payload["sourcePartnerDealerId"] = random_party_id
        self.deal_data.payload["dealRefId"] = app_resp["dealRefId"]
        status_code, get_resp, resp_headers = self.get_key_data_response(query_param)
        assert_headers(resp_headers=resp_headers)
        assert len(get_resp) == 2, f"Expected 2 records but received {len(get_resp)}"

        # Target Record
        resp_record = self.filter_key_data_response(
            get_response=get_resp, target_id=key_data_target
        )
        validate_v2_key_data_get_response(
            posted_payload=self.deal_data.payload,
            get_response=resp_record,
            key_name=key_data_target,
        )
        # DTA Record
        resp_record = self.filter_key_data_response(
            get_response=get_resp, target_id="DTA"
        )
        self.deal_data.payload["targetPlatformId"] = "DTA"
        validate_v2_key_data_get_response(
            posted_payload=self.deal_data.payload,
            get_response=resp_record,
            key_name="DTA",
        )

    test_data = [
        ("key_data_test_data_dtc_v2_record", "DTC", "dealId"),
        ("key_data_test_data_idl_v2_record", "IDL", "dealId"),
        ("key_data_test_data_r1j_v2_record", "R1J", "conversationId"),
    ]

    @pytest.mark.prod
    @pytest.mark.functional
    @pytest.mark.parametrize(
        "target_platforms_payloads, target_id, app_field_per_target", test_data
    )
    def test_key_data_get_inactive_credit_apps(
        self,
        target_id,
        common_assert,
        assert_headers,
        get_response_data,
        create_deal_record,
        app_field_per_target,
        target_platforms_payloads,
        verify_given_dict_object,
        get_deal_component_details,
        validate_v2_key_data_get_response,
        key_data_test_data_dtc_v2_record,
        key_data_test_data_idl_v2_record,
        key_data_test_data_r1j_v2_record,
    ):
        # Credit App Post
        self.deal_data.set_payload(file_name="credit_app/app_min_data_honda.json")
        random_party_id = "".join(
            random.choices(string.ascii_uppercase + string.digits, k=6)
        )
        self.deal_data.payload["targetPlatforms"] = [
            {"id": target_id, "partyId": random_party_id}
        ]
        app_resp, resp_headers = self.post_request_based_on_route(APP_ROUTE)

        # Patch with key-data - First CA Patch
        key_data_payload = eval(target_platforms_payloads)
        initial_key_data_payload = copy.deepcopy(key_data_payload)

        key_data_target = key_data_payload["targetPlatformId"]
        self.deal_data.payload = key_data_payload
        self.deal_data.payload["creditAppId"] = self.deal_data.creditAppId
        patch_resp, resp_headers = self.update_key_data()
        record = get_deal_component_details(
            deal_ref_id=app_resp.get("dealRefId"),
            deal_component=f"REF_IDS.{key_data_target}",
        )
        common_assert(records=[record], resp_headers=resp_headers)

        # Create DTA Credit App Record in DB for second Credit App
        # This step is done manually until multiple credit apps are supported by FS
        new_dta_app_id = self.deal_data.generate_random_id(ulid_id=True)
        deal_comp = f"REF_IDS.DTA.{new_dta_app_id}"
        dta_ca_payload = {
            "dealRefId": self.deal_data.dealRefId,
            "dealComponent": deal_comp,
            "createdTimestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "creditAppId": new_dta_app_id,
            "updatedTimestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
        }
        create_deal_record(
            deal_ref_id=self.deal_data.dealRefId,
            deal_comp=deal_comp,
            record=dta_ca_payload,
        )
        self.deal_data.payload = {
            "targetPlatformId": "DTA",
            "creditAppId": new_dta_app_id,
            "financeMethod": random.choice(["Finance", "Lease", "Balloon", "Cash"]),
        }
        patch_resp, resp_headers = self.update_key_data()

        # Patch with key-data - Second CA Patch
        self.deal_data.payload = initial_key_data_payload
        self.deal_data.payload["creditAppId"] = new_dta_app_id  # New DTA CA ID
        self.deal_data.payload[app_field_per_target] = str(
            random.getrandbits(52)
        )  # New target CA ID
        patch_resp, resp_headers = self.update_key_data()
        record = get_deal_component_details(
            deal_ref_id=app_resp.get("dealRefId"),
            deal_component=f"REF_IDS.{key_data_target}.{self.deal_data.payload[app_field_per_target]}",
        )
        common_assert(records=[record], resp_headers=resp_headers)

        # Validate result with inactive credit app flag as False
        query_param = f"dealJacketId={self.deal_data.payload['dealJacketId']}&targetPlatformId={key_data_target}"
        cust_header = {"includeInactiveRefs": "false"}
        status_code, get_resp, resp_headers = self.get_key_data_response(
            query_param=query_param, cust_header=cust_header
        )
        assert_headers(resp_headers=resp_headers)
        assert len(get_resp) == 2, f"Expected 2 records but received {len(get_resp)}"

        # Validate result with inactive credit app flag as True
        cust_header = {"includeInactiveRefs": "true"}
        status_code, get_resp, resp_headers = self.get_key_data_response(
            query_param=query_param, cust_header=cust_header
        )
        assert_headers(resp_headers=resp_headers)
        assert len(get_resp) == 4, f"Expected 4 records but received {len(get_resp)}"
