# -*- coding: utf-8 -*-
import random
import string
from http import HTTPStatus

import pytest
from tests.functional.key_data.config import CREDIT_APP_KEY_BY_TARGET_V2
from tests.functional.service_api import ServiceAPI


APP_ROUTE = "credit_app"
LEAD_ROUTE = "leads"
KEY_DATA_UPDATE_ROUTE = "key_data_patch_v2"


class TestKeyDataPatch:
    @classmethod
    @pytest.fixture(autouse=True)
    def setup_method(cls, env, api_url, random_data_class, get_deal_component_details):
        cls.env = env
        cls.api_url = api_url
        cls.updated_timestamp = None
        cls.deal_data = ServiceAPI(random_data_class=random_data_class, env=env)
        cls.get_deal_component_details = get_deal_component_details

    def post_request_based_on_route(
        self,
        api_route=APP_ROUTE,
        expected_status=HTTPStatus.CREATED,
        cb_post=False,
        cust_headers=None,
    ):
        status_code, post_resp, resp_headers = self.deal_data.post_request(
            self.api_url,
            api_route,
            cb_post=cb_post,
            cust_header=cust_headers,
        )

        if status_code != expected_status:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {post_resp}"
            )

        record = self.get_deal_component_details(
            self.deal_data.dealRefId, deal_component="DTC.DEAL"
        )
        if not record:
            raise Exception(
                f"Deal is not created in DB for dealRefId: {self.deal_data.dealRefId}"
            )

        return post_resp, resp_headers

    def update_key_data(self, expected_status=HTTPStatus.NO_CONTENT, cust_header=None):
        status_code, patch_resp, resp_headers = self.deal_data.patch(
            url=self.api_url,
            route_url=KEY_DATA_UPDATE_ROUTE,
            cust_header=cust_header or {},
            cust_status_code=expected_status,
        )

        if status_code != expected_status:
            raise Exception(
                f"Patch. Response code is: {status_code} and the response message is: {patch_resp}"
            )

        return patch_resp, resp_headers

    all_targets_test_data = [
        "key_data_test_data_dta_v2_record",
        "key_data_test_data_dtc_v2_record",
        "key_data_test_data_idl_v2_record",
        "key_data_test_data_r1j_v2_record",
    ]

    @pytest.mark.prod
    @pytest.mark.smoke
    @pytest.mark.functional
    @pytest.mark.parametrize("target_platforms_payloads", all_targets_test_data)
    def test_key_data_update_with_all_target_platforms_credit_app_flow(
        self,
        common_assert,
        get_response_data,
        validate_v2_key_data,
        target_platforms_payloads,
        verify_given_dict_object,
        get_deal_component_details,
        key_data_test_data_dta_v2_record,
        key_data_test_data_dtc_v2_record,
        key_data_test_data_idl_v2_record,
        key_data_test_data_r1j_v2_record,
    ):

        key_data_payload = eval(target_platforms_payloads)
        # Post a credit app
        self.deal_data.set_payload(file_name="credit_app/app_min_data.json")
        # Update random targetPlatforms based of key-data record
        random_party_id = "".join(
            random.choices(string.ascii_uppercase + string.digits, k=6)
        )
        self.deal_data.payload["targetPlatforms"] = [
            {"id": key_data_payload["targetPlatformId"], "partyId": random_party_id}
        ]

        app_resp, resp_headers = self.post_request_based_on_route(APP_ROUTE)

        # v2 Patch Key-Data Patch
        self.deal_data.payload = key_data_payload
        self.deal_data.payload["creditAppId"] = app_resp["creditAppId"]
        patch_resp, resp_headers = self.update_key_data()

        # Add partyId as sourcePartnerDealerId in the payload for validation
        self.deal_data.payload["sourcePartnerDealerId"] = random_party_id

        # Validate headers and TTL
        dtc_record = get_deal_component_details(
            deal_ref_id=app_resp.get("dealRefId"), deal_component="DTC.DEAL"
        )
        common_assert(records=[dtc_record], resp_headers=resp_headers)

        # Validate v2 key-data record for DTA
        v2_record = get_deal_component_details(
            self.deal_data.dealRefId, deal_component="REF_IDS.DTA"
        )
        validate_v2_key_data(
            posted_payload=self.deal_data.payload,
            database_resp=v2_record,
            key_name="DTA",
        )

        # Validate v2 key-data record for DTA APP
        v2_record = get_deal_component_details(
            self.deal_data.dealRefId,
            deal_component=f"REF_IDS.DTA.{app_resp['creditAppId']}",
        )
        validate_v2_key_data(
            posted_payload=self.deal_data.payload,
            database_resp=v2_record,
            key_name="DTA_APP",
        )

        # Validate v2 key-data record for targetPlatform
        target_name = self.deal_data.payload["targetPlatformId"]
        target_key = f"REF_IDS.{target_name}"

        # Validate v2 key-data target record
        v2_record = get_deal_component_details(
            app_resp.get("dealRefId"), deal_component=target_key
        )
        validate_v2_key_data(
            posted_payload=self.deal_data.payload,
            database_resp=v2_record,
            key_name=target_name,
        )
        # Validate v2 key-data target record app
        ca_key = self.deal_data.payload[CREDIT_APP_KEY_BY_TARGET_V2[target_name]]
        v2_record = get_deal_component_details(
            app_resp["dealRefId"], deal_component=f"{target_key}.{ca_key}"
        )
        validate_v2_key_data(
            posted_payload=self.deal_data.payload,
            database_resp=v2_record,
            key_name=f"{target_name}_APP",
        )

    test_data = [
        ("key_data_test_data_dta_v2_record", ["creditAppId", "financeMethod"]),
        ("key_data_test_data_dtc_v2_record", ["creditAppId", "dealId"]),
        ("key_data_test_data_idl_v2_record", ["creditAppId", "dealId"]),
        (
            "key_data_test_data_r1j_v2_record",
            ["creditAppId", "conversationId", "creditAppIdR1"],
        ),
    ]

    @pytest.mark.smoke
    @pytest.mark.functional
    @pytest.mark.parametrize("target_platforms_payloads, fields_to_remove", test_data)
    def test_key_data_update_with_all_target_platforms_lead_flow_without_ca_fields(
        self,
        common_assert,
        fields_to_remove,
        get_response_data,
        validate_v2_key_data,
        target_platforms_payloads,
        verify_given_dict_object,
        get_deal_component_details,
        key_data_test_data_dta_v2_record,
        key_data_test_data_dtc_v2_record,
        key_data_test_data_idl_v2_record,
        key_data_test_data_r1j_v2_record,
    ):
        # Post a Lead
        self.deal_data.set_payload(file_name="leads/leads_min_data.json")
        lead_resp, resp_headers = self.post_request_based_on_route(LEAD_ROUTE)

        # v2 Patch Key-Data Patch
        self.deal_data.payload = eval(target_platforms_payloads)
        for field in fields_to_remove:
            del self.deal_data.payload[field]
        patch_resp, resp_headers = self.update_key_data()

        # Validate headers and TTL
        dtc_record = get_deal_component_details(
            deal_ref_id=lead_resp.get("dealRefId"), deal_component="DTC.DEAL"
        )
        common_assert(records=[dtc_record], resp_headers=resp_headers)

        # Validate v2 key-data record for DTA
        v2_record = get_deal_component_details(
            self.deal_data.dealRefId, deal_component="REF_IDS.DTA"
        )
        validate_v2_key_data(
            posted_payload=self.deal_data.payload,
            database_resp=v2_record,
            key_name="DTA",
        )

        # Validate v2 key-data record for targetPlatform
        target_name = self.deal_data.payload["targetPlatformId"]
        target_key = f"REF_IDS.{target_name}"

        # Validate v2 key-data target record
        v2_record = get_deal_component_details(
            lead_resp.get("dealRefId"), deal_component=target_key
        )
        validate_v2_key_data(
            posted_payload=self.deal_data.payload,
            database_resp=v2_record,
            key_name=target_name,
        )

    @pytest.mark.functional
    def test_key_data_update_multiple_patches(
        self,
        common_assert,
        get_response_data,
        validate_v2_key_data,
        verify_given_dict_object,
        get_deal_component_details,
        key_data_test_data_dta_v2_record,
        key_data_test_data_dtc_v2_record,
        key_data_test_data_idl_v2_record,
        key_data_test_data_r1j_v2_record,
    ):
        self.deal_data.set_payload(file_name="credit_app/ind_retail_new.json")
        app_resp, resp_headers = self.post_request_based_on_route(APP_ROUTE)
        # Patch Key-Data
        for patch_payload in [
            key_data_test_data_dta_v2_record,
            key_data_test_data_dtc_v2_record,
            key_data_test_data_idl_v2_record,
            key_data_test_data_r1j_v2_record,
        ]:
            # Patch with key-data
            self.deal_data.payload = patch_payload
            self.deal_data.payload["creditAppId"] = self.deal_data.creditAppId
            patch_resp, resp_headers = self.update_key_data()
            record = get_deal_component_details(
                deal_ref_id=app_resp.get("dealRefId"),
                deal_component=f"REF_IDS.{self.deal_data.payload['targetPlatformId']}",
            )
            common_assert(records=[record], resp_headers=resp_headers)

            # Validate v2 key-data record for Specific Target
            target_name = self.deal_data.payload["targetPlatformId"]
            target_key = f"REF_IDS.{target_name}"
            v2_record = get_deal_component_details(
                self.deal_data.dealRefId, deal_component=target_key
            )
            validate_v2_key_data(
                posted_payload=self.deal_data.payload,
                database_resp=v2_record,
                key_name=target_name,
            )

            # Validate v2 key-data record for Credit App
            ca_key = self.deal_data.payload.get(
                CREDIT_APP_KEY_BY_TARGET_V2[target_name]
            )
            v2_record = get_deal_component_details(
                self.deal_data.dealRefId, deal_component=f"{target_key}.{ca_key}"
            )
            validate_v2_key_data(
                posted_payload=self.deal_data.payload,
                database_resp=v2_record,
                key_name=f"{target_name}_APP",
            )

            # Validate v2 key-data record for DTA
            v2_record = get_deal_component_details(
                self.deal_data.dealRefId, deal_component="REF_IDS.DTA"
            )
            validate_v2_key_data(
                posted_payload=self.deal_data.payload,
                database_resp=v2_record,
                key_name="DTA",
            )

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_key_data_update_with_invalid_deal_ref_id(
        self,
        common_assert,
        get_response_data,
        validate_v2_key_data,
        verify_given_dict_object,
        get_deal_component_details,
        key_data_test_data_dtc_v2_record,
    ):
        # Post a credit app
        self.deal_data.set_payload(file_name="credit_app/app_min_data.json")
        app_resp, resp_headers = self.post_request_based_on_route(APP_ROUTE)

        self.deal_data.dealRefId = self.deal_data.generate_random_id()

        # v2 Patch Key-Data Patch
        self.deal_data.payload = key_data_test_data_dtc_v2_record
        patch_resp, resp_headers = self.update_key_data(
            expected_status=HTTPStatus.BAD_REQUEST
        )
        assert patch_resp["message"] == f"No deal found for {self.deal_data.dealRefId}"

        # Validate headers and TTL
        dtc_record = get_deal_component_details(
            deal_ref_id=app_resp.get("dealRefId"), deal_component="DTC.DEAL"
        )
        common_assert(records=[dtc_record], resp_headers=resp_headers)

    @pytest.mark.prod
    @pytest.mark.smoke
    @pytest.mark.functional
    @pytest.mark.parametrize("target_platforms_payloads", all_targets_test_data)
    def test_key_data_update_with_invalid_credit_app_id(
        self,
        common_assert,
        get_response_data,
        validate_v2_key_data,
        target_platforms_payloads,
        verify_given_dict_object,
        get_deal_component_details,
        key_data_test_data_dtc_v2_record,
        key_data_test_data_dta_v2_record,
        key_data_test_data_idl_v2_record,
        key_data_test_data_r1j_v2_record,
    ):
        # Post a credit app
        self.deal_data.set_payload(file_name="credit_app/app_min_data.json")
        app_resp, resp_headers = self.post_request_based_on_route(APP_ROUTE)

        # v2 Patch Key-Data Patch
        self.deal_data.payload = eval(target_platforms_payloads)
        patch_resp, resp_headers = self.update_key_data(
            expected_status=HTTPStatus.BAD_REQUEST
        )
        payload_app_id = self.deal_data.payload.get("creditAppId")
        assert (
            patch_resp["message"]
            == f"Provided creditAppId {payload_app_id} is not associated to dealRefId {self.deal_data.dealRefId}"
        )

        # Validate headers and TTL
        dtc_record = get_deal_component_details(
            deal_ref_id=app_resp.get("dealRefId"), deal_component="DTC.DEAL"
        )
        common_assert(records=[dtc_record], resp_headers=resp_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    @pytest.mark.parametrize("target_platforms_payloads", all_targets_test_data)
    def test_key_data_update_with_invalid_target_platforms(
        self,
        common_assert,
        get_response_data,
        validate_v2_key_data,
        target_platforms_payloads,
        verify_given_dict_object,
        get_deal_component_details,
        key_data_test_data_dtc_v2_record,
        key_data_test_data_dta_v2_record,
        key_data_test_data_idl_v2_record,
        key_data_test_data_r1j_v2_record,
    ):
        # Post a credit app
        self.deal_data.set_payload(file_name="credit_app/app_min_data.json")
        app_resp, resp_headers = self.post_request_based_on_route(APP_ROUTE)

        # v2 Patch Key-Data Patch
        self.deal_data.payload = eval(target_platforms_payloads)
        self.deal_data.payload["targetPlatformId"] = "XYZ"
        patch_resp, resp_headers = self.update_key_data(
            expected_status=HTTPStatus.BAD_REQUEST
        )
        assert patch_resp["message"] == "Given target platform, XYZ is not supported."

        # Validate headers and TTL
        dtc_record = get_deal_component_details(
            deal_ref_id=app_resp.get("dealRefId"), deal_component="DTC.DEAL"
        )
        common_assert(records=[dtc_record], resp_headers=resp_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    @pytest.mark.parametrize("target_platforms_payloads", all_targets_test_data)
    def test_key_data_update_with_dta_or_invalid_field(
        self,
        common_assert,
        get_response_data,
        validate_v2_key_data,
        target_platforms_payloads,
        verify_given_dict_object,
        get_deal_component_details,
        key_data_test_data_dta_v2_record,
        key_data_test_data_dtc_v2_record,
        key_data_test_data_idl_v2_record,
        key_data_test_data_r1j_v2_record,
    ):
        # Post a credit app
        self.deal_data.set_payload(file_name="credit_app/app_min_data.json")
        app_resp, resp_headers = self.post_request_based_on_route(APP_ROUTE)

        # v2 Patch Key-Data Patch
        self.deal_data.payload = eval(target_platforms_payloads)
        self.deal_data.payload["sourcePartnerDealerId"] = "XYZ"
        patch_resp, resp_headers = self.update_key_data(
            expected_status=HTTPStatus.BAD_REQUEST
        )
        payload_target = self.deal_data.payload["targetPlatformId"]
        assert (
            patch_resp["message"]
            == f"Given fields 'sourcePartnerDealerId' is not supported for targetPlatformId {payload_target}"
        )

        # Validate headers and TTL
        dtc_record = get_deal_component_details(
            deal_ref_id=app_resp.get("dealRefId"), deal_component="DTC.DEAL"
        )
        common_assert(records=[dtc_record], resp_headers=resp_headers)

    test_data = [
        ("key_data_test_data_dta_v2_record", "financeMethod", "creditAppId"),
        ("key_data_test_data_dta_v2_record", "creditAppId", "financeMethod"),
        ("key_data_test_data_dtc_v2_record", "creditAppId", "dealId"),
        ("key_data_test_data_dtc_v2_record", "dealId", "creditAppId"),
        ("key_data_test_data_idl_v2_record", "creditAppId", "dealId"),
        ("key_data_test_data_idl_v2_record", "dealId", "creditAppId"),
        ("key_data_test_data_r1j_v2_record", "creditAppId", "conversationId"),
        ("key_data_test_data_r1j_v2_record", "conversationId", "creditAppId"),
    ]

    @pytest.mark.smoke
    @pytest.mark.functional
    @pytest.mark.parametrize(
        "target_platforms_payloads, field_to_remove, secondary_field", test_data
    )
    def test_key_data_update_with_conditionally_required_fields(
        self,
        secondary_field,
        common_assert,
        field_to_remove,
        get_response_data,
        validate_v2_key_data,
        target_platforms_payloads,
        verify_given_dict_object,
        get_deal_component_details,
        key_data_test_data_dtc_v2_record,
        key_data_test_data_dta_v2_record,
        key_data_test_data_idl_v2_record,
        key_data_test_data_r1j_v2_record,
    ):
        # Post a credit app
        self.deal_data.set_payload(file_name="credit_app/app_min_data.json")
        app_resp, resp_headers = self.post_request_based_on_route(APP_ROUTE)

        # v2 Patch Key-Data Patch
        self.deal_data.payload = eval(target_platforms_payloads)
        self.deal_data.payload["creditAppId"] = app_resp["creditAppId"]
        del self.deal_data.payload[field_to_remove]
        patch_resp, resp_headers = self.update_key_data(
            expected_status=HTTPStatus.BAD_REQUEST
        )
        assert (
            patch_resp["message"]
            == f"'{field_to_remove}' and '{secondary_field}' are mutually conditional, if one is provided the other becomes mandatory"
        )

        # Validate headers and TTL
        dtc_record = get_deal_component_details(
            deal_ref_id=app_resp.get("dealRefId"), deal_component="DTC.DEAL"
        )
        common_assert(records=[dtc_record], resp_headers=resp_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_key_data_update_with_r1j_conversation_id_conditionally_required_fields(
        self,
        common_assert,
        get_response_data,
        validate_v2_key_data,
        verify_given_dict_object,
        get_deal_component_details,
        key_data_test_data_r1j_v2_record,
    ):
        # Post a credit app
        self.deal_data.set_payload(file_name="credit_app/app_min_data.json")
        app_resp, resp_headers = self.post_request_based_on_route(APP_ROUTE)

        # v2 Patch Key-Data Patch
        self.deal_data.payload = key_data_test_data_r1j_v2_record
        del self.deal_data.payload["creditAppId"]
        del self.deal_data.payload["conversationId"]
        patch_resp, resp_headers = self.update_key_data(
            expected_status=HTTPStatus.BAD_REQUEST
        )
        assert (
            patch_resp["message"]
            == "'conversationId' is required if 'creditAppIdR1' is provided"
        )

        # Validate headers and TTL
        dtc_record = get_deal_component_details(
            deal_ref_id=app_resp.get("dealRefId"), deal_component="DTC.DEAL"
        )
        common_assert(records=[dtc_record], resp_headers=resp_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    @pytest.mark.parametrize("target_platforms_payloads", all_targets_test_data)
    def test_key_data_update_with_no_target_platform(
        self,
        common_assert,
        get_response_data,
        validate_v2_key_data,
        target_platforms_payloads,
        verify_given_dict_object,
        get_deal_component_details,
        key_data_test_data_dta_v2_record,
        key_data_test_data_dtc_v2_record,
        key_data_test_data_idl_v2_record,
        key_data_test_data_r1j_v2_record,
    ):
        # Post a credit app
        self.deal_data.set_payload(file_name="credit_app/app_min_data.json")
        app_resp, resp_headers = self.post_request_based_on_route(APP_ROUTE)

        # v2 Patch Key-Data Patch
        self.deal_data.payload = eval(target_platforms_payloads)
        self.deal_data.payload["creditAppId"] = app_resp["creditAppId"]
        del self.deal_data.payload["targetPlatformId"]
        patch_resp, resp_headers = self.update_key_data(
            expected_status=HTTPStatus.BAD_REQUEST
        )
        assert patch_resp["message"] == "Missing 'targetPlatformId' in request payload"

        # Validate headers and TTL
        dtc_record = get_deal_component_details(
            deal_ref_id=app_resp.get("dealRefId"), deal_component="DTC.DEAL"
        )
        common_assert(records=[dtc_record], resp_headers=resp_headers)

    @pytest.mark.functional
    @pytest.mark.parametrize("target_platforms_payloads", all_targets_test_data)
    def test_key_data_update_with_empty_target_platform(
        self,
        common_assert,
        get_response_data,
        validate_v2_key_data,
        target_platforms_payloads,
        verify_given_dict_object,
        get_deal_component_details,
        key_data_test_data_dta_v2_record,
        key_data_test_data_dtc_v2_record,
        key_data_test_data_idl_v2_record,
        key_data_test_data_r1j_v2_record,
    ):
        # Post a credit app
        self.deal_data.set_payload(file_name="credit_app/app_min_data.json")
        app_resp, resp_headers = self.post_request_based_on_route(APP_ROUTE)

        # v2 Patch Key-Data Patch
        self.deal_data.payload = eval(target_platforms_payloads)
        self.deal_data.payload["creditAppId"] = app_resp["creditAppId"]
        self.deal_data.payload["targetPlatformId"] = ""
        patch_resp, resp_headers = self.update_key_data(
            expected_status=HTTPStatus.BAD_REQUEST
        )
        assert patch_resp["message"] == "Missing 'targetPlatformId' in request payload"

        # Validate headers and TTL
        dtc_record = get_deal_component_details(
            deal_ref_id=app_resp.get("dealRefId"), deal_component="DTC.DEAL"
        )
        common_assert(records=[dtc_record], resp_headers=resp_headers)

    test_data = [
        "key_data_test_data_dtc_v2_record",
        "key_data_test_data_idl_v2_record",
    ]

    @pytest.mark.functional
    @pytest.mark.parametrize("target_platforms_payloads", test_data)
    def test_key_data_update_additional_headers_keys(
        self,
        validate_v2_key_data,
        verify_deal_component,
        target_platforms_payloads,
        get_deal_component_details,
        get_records_by_deal_ref_id,
        key_data_test_data_dtc_v2_record,
        key_data_test_data_idl_v2_record,
    ):
        """
        for key-data v2, additional headers are NOT supported.
        These keys will be ignored and the payload would be saves in the as normal
        """
        # Post a credit app
        self.deal_data.set_payload(file_name="credit_app/app_min_data.json")
        del self.deal_data.payload[
            "targetPlatforms"
        ]  # remove targetPlatforms to reduce target platform record
        app_resp, resp_headers = self.post_request_based_on_route(APP_ROUTE)

        # v2 Patch Key-Data Patch
        self.deal_data.payload = eval(target_platforms_payloads)
        self.deal_data.payload["creditAppId"] = app_resp["creditAppId"]
        del self.deal_data.payload[
            "dealJacketId"
        ]  # remove from body to see if it is being saves from header
        del self.deal_data.payload[
            "dealerCode"
        ]  # remove from body to see if it is being saves from header
        add_keys_header = {
            "X-Deal-Jacket-ID": self.deal_data.generate_random_id(),
            "X-Dealer-Code": "65677",
        }
        patch_resp, resp_headers = self.update_key_data(cust_header=add_keys_header)

        # Validate v2 key-data record for DTA
        v2_record = get_deal_component_details(
            self.deal_data.dealRefId, deal_component="REF_IDS.DTA"
        )
        validate_v2_key_data(
            posted_payload=self.deal_data.payload,
            database_resp=v2_record,
            key_name="DTA",
        )

        # Validate v2 key-data record for DTA APP
        v2_record = get_deal_component_details(
            self.deal_data.dealRefId,
            deal_component=f"REF_IDS.DTA.{app_resp['creditAppId']}",
        )
        validate_v2_key_data(
            posted_payload=self.deal_data.payload,
            database_resp=v2_record,
            key_name="DTA_APP",
        )

        # Validate v2 key-data record for targetPlatform
        target_name = self.deal_data.payload["targetPlatformId"]
        target_key = f"REF_IDS.{target_name}"

        # Validate v2 key-data target record
        v2_record = get_deal_component_details(
            app_resp.get("dealRefId"), deal_component=target_key
        )
        assert (
            v2_record.get("dealJacketId") is None
        ), f"dealJacketId from header is saved in DB- {v2_record}"
        assert (
            v2_record.get("dealerCode") is None
        ), f"dealerCode from header is saved in DB- {v2_record}"
        validate_v2_key_data(
            posted_payload=self.deal_data.payload,
            database_resp=v2_record,
            key_name=target_name,
        )

        # Validate v2 key-data target record app
        ca_key = self.deal_data.payload[CREDIT_APP_KEY_BY_TARGET_V2[target_name]]
        v2_record = get_deal_component_details(
            app_resp["dealRefId"], deal_component=f"{target_key}.{ca_key}"
        )
        validate_v2_key_data(
            posted_payload=self.deal_data.payload,
            database_resp=v2_record,
            key_name=f"{target_name}_APP",
        )

    test_data = [
        "key_data_test_data_dtc_v2_record",
        "key_data_test_data_idl_v2_record",
        "key_data_test_data_r1j_v2_record",
    ]

    @pytest.mark.prod
    @pytest.mark.smoke
    @pytest.mark.functional
    @pytest.mark.parametrize("target_platforms_payloads", test_data)
    def test_key_data_update_fd_ref_ids_not_supported(
        self,
        common_assert,
        get_response_data,
        validate_v2_key_data,
        target_platforms_payloads,
        verify_given_dict_object,
        get_deal_component_details,
        key_data_test_data_dtc_v2_record,
        key_data_test_data_idl_v2_record,
        key_data_test_data_r1j_v2_record,
    ):
        # dealRefIdFD and dealRefIdInt are supported for DTA target

        key_data_payload = eval(target_platforms_payloads)
        # Post a credit app
        self.deal_data.set_payload(file_name="credit_app/app_min_data.json")
        # Update random targetPlatforms based of key-data record
        random_party_id = "".join(
            random.choices(string.ascii_uppercase + string.digits, k=6)
        )
        self.deal_data.payload["targetPlatforms"] = [
            {"id": key_data_payload["targetPlatformId"], "partyId": random_party_id}
        ]

        app_resp, resp_headers = self.post_request_based_on_route(APP_ROUTE)

        # v2 Patch Key-Data Patch
        self.deal_data.payload = key_data_payload
        self.deal_data.payload["creditAppId"] = app_resp["creditAppId"]
        # Add dealRefIdFD and dealRefIdInt for none DTA records
        self.deal_data.payload["dealRefIdFD"] = str(random.getrandbits(52))
        self.deal_data.payload["dealRefIdFDInt"] = str(random.getrandbits(52))
        patch_resp, resp_headers = self.update_key_data(
            expected_status=HTTPStatus.BAD_REQUEST
        )
        assert (
            patch_resp["message"]
            == f"Given fields 'dealRefIdFD, dealRefIdFDInt' is not supported for targetPlatformId {key_data_payload['targetPlatformId']}"
        )
