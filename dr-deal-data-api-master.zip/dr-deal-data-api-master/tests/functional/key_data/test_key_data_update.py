# -*- coding: utf-8 -*-
from http import HTTPStatus

import pytest
from common.settings import ErrorMsgs
from tests.functional.key_data.config import CREDIT_APP_KEY_BY_TARGET
from tests.functional.service_api import ServiceAPI


APP_ROUTE = "credit_app"
LEAD_ROUTE = "leads"
BUREAU_ROUTE = "credit_bureau"
KEY_DATA_POST_ROUTE = "key_data"
KEY_DATA_UPDATE_ROUTE = "key_data_patch"


class TestKeyDataPatch:
    @classmethod
    @pytest.fixture(autouse=True)
    def setup_method(cls, env, api_url, random_data_class, get_deal_component_details):
        cls.env = env
        cls.api_url = api_url
        cls.updated_timestamp = None
        cls.deal_data = ServiceAPI(random_data_class=random_data_class, env=env)
        cls.get_deal_component_details = get_deal_component_details

    def post_request_based_on_route(
        self,
        api_route=APP_ROUTE,
        expected_status=HTTPStatus.CREATED,
        cb_post=False,
        cust_headers=None,
    ):
        status_code, post_resp, resp_headers = self.deal_data.post_request(
            self.api_url,
            api_route,
            cb_post=cb_post,
            cust_header=cust_headers,
        )

        if status_code != expected_status:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {post_resp}"
            )

        record = self.get_deal_component_details(
            self.deal_data.dealRefId, deal_component="DTC.DEAL"
        )
        if not record:
            raise Exception(
                f"Deal is not created in DB for dealRefId: {self.deal_data.dealRefId}"
            )

        return post_resp, resp_headers

    def update_key_data(self, expected_status=HTTPStatus.NO_CONTENT, cust_header=None):
        status_code, patch_resp, resp_headers = self.deal_data.patch(
            url=self.api_url,
            route_url=KEY_DATA_UPDATE_ROUTE,
            cust_header=cust_header or {},
            cust_status_code=expected_status,
        )

        if status_code != expected_status:
            raise Exception(
                f"Patch. Response code is: {status_code} and the response message is: {patch_resp}"
            )

        return patch_resp, resp_headers

    @pytest.mark.prod
    @pytest.mark.smoke
    @pytest.mark.functional
    def test_key_data_update_with_single_key_credit_app(
        self,
        common_assert,
        get_response_data,
        validate_v2_key_data,
        verify_given_dict_object,
        get_deal_component_details,
        key_data_test_data_r1j_record,
    ):
        self.deal_data.set_payload(file_name="credit_app/ind_retail_new.json")
        app_resp, resp_headers = self.post_request_based_on_route(APP_ROUTE)

        # Patch Key-Data
        self.deal_data.payload = key_data_test_data_r1j_record
        patch_resp, resp_headers = self.update_key_data()

        # Validate v2 key-data record for R1J
        v2_record = get_deal_component_details(
            self.deal_data.dealRefId, deal_component="REF_IDS.R1J"
        )
        validate_v2_key_data(
            posted_payload=self.deal_data.payload,
            database_resp=v2_record,
            key_name="R1J",
        )
        # Validate v2 key-data record for R1J APP
        v2_record = get_deal_component_details(
            self.deal_data.dealRefId,
            deal_component=f"REF_IDS.R1J.{self.deal_data.payload['conversationId']}",
        )
        validate_v2_key_data(
            posted_payload=self.deal_data.payload,
            database_resp=v2_record,
            key_name="R1J_APP",
        )

        # Validate v2 key-data record for DTA
        v2_record = get_deal_component_details(
            self.deal_data.dealRefId, deal_component="REF_IDS.DTA"
        )
        validate_v2_key_data(
            posted_payload=self.deal_data.payload,
            database_resp=v2_record,
            key_name="DTA",
        )

        # Validate v2 key-data record for DTA APP
        payload_with_app = {
            **self.deal_data.payload,
            "creditAppId": app_resp["creditAppId"],
        }
        v2_record = get_deal_component_details(
            self.deal_data.dealRefId,
            deal_component=f"REF_IDS.DTA.{app_resp['creditAppId']}",
        )
        validate_v2_key_data(
            posted_payload=payload_with_app,
            database_resp=v2_record,
            key_name="DTA_APP",
        )

        # Validate headers and ket-data v1
        dtc_record = get_deal_component_details(
            deal_ref_id=app_resp.get("dealRefId"), deal_component="DTC.DEAL"
        )
        common_assert(records=[dtc_record], resp_headers=resp_headers)
        self.deal_data.update_key_data_fields_mapping()
        verify_given_dict_object(self.deal_data.payload, dtc_record)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_key_data_update_with_multiple_keys_leads(
        self,
        common_assert,
        validate_v2_key_data,
        get_response_data,
        verify_given_dict_object,
        get_deal_component_details,
        key_data_test_data_default_record_dtc,
    ):
        self.deal_data.set_payload(file_name="leads/ind_retail_new_decision.json")
        lead_resp, resp_headers = self.post_request_based_on_route(LEAD_ROUTE)

        # Patch Key-Data
        self.deal_data.payload = key_data_test_data_default_record_dtc
        patch_resp, resp_headers = self.update_key_data()
        record = get_deal_component_details(
            deal_ref_id=lead_resp.get("dealRefId"),
            deal_component="DTC.DEAL",
            additional_check_key="dealJacketId",
            additional_check_value=self.deal_data.payload["dealJacketId"],
        )

        # Validate v2 key-data record for DTA
        v2_record = get_deal_component_details(
            self.deal_data.dealRefId, deal_component="REF_IDS.DTA"
        )
        validate_v2_key_data(
            posted_payload=self.deal_data.payload,
            database_resp=v2_record,
            key_name="DTA",
        )
        # For a Lead Post, There is no DTA.creditApp record for key-data

        # Validate v2 key-data record for DTC
        v2_record = get_deal_component_details(
            self.deal_data.dealRefId, deal_component="REF_IDS.DTC"
        )
        validate_v2_key_data(
            posted_payload=self.deal_data.payload,
            database_resp=v2_record,
            key_name="DTC",
        )
        # Validate v2 key-data record for DTC APP
        v2_record = get_deal_component_details(
            self.deal_data.dealRefId,
            deal_component=f"REF_IDS.DTC.{self.deal_data.payload['dealIdFI']}",
        )
        validate_v2_key_data(
            posted_payload=self.deal_data.payload,
            database_resp=v2_record,
            key_name="DTC_APP",
        )

        # Validate
        common_assert(records=[record], resp_headers=resp_headers)
        self.deal_data.update_key_data_fields_mapping()
        verify_given_dict_object(self.deal_data.payload, record)

    @pytest.mark.prod
    @pytest.mark.smoke
    @pytest.mark.functional
    def test_key_data_update_with_existing_deal_ref_id_fd_lead_flow(
        self,
        common_assert,
        get_response_data,
        validate_v2_key_data,
        key_data_test_data_dta_record,
        get_deal_component_details,
        verify_given_dict_object,
    ):
        self.deal_data.set_payload(file_name="leads/ind_retail_new_decision.json")
        # Update header with X-Lead-Reference-Number --> dealRefIdFD
        cust_header = {"X-Lead-Reference-Number": self.deal_data.generate_random_id()}
        lead_resp, resp_headers = self.post_request_based_on_route(
            LEAD_ROUTE, cust_headers=cust_header
        )
        party_id = self.deal_data.payload["targetPlatforms"][0]["partyId"]
        # Patch Key-Data
        self.deal_data.payload = key_data_test_data_dta_record
        self.deal_data.payload.pop(
            "dealRefIdFD"
        )  # since this is being posted as X-Lead-Reference-Number
        patch_resp, resp_headers = self.update_key_data()
        record = get_deal_component_details(
            deal_ref_id=lead_resp.get("dealRefId"),
            deal_component="DTC.DEAL",
            additional_check_key="appRefIdFD",
            additional_check_value=self.deal_data.payload["appRefIdFD"],
        )
        self.deal_data.payload[
            "sourcePartnerDealerId"
        ] = party_id  # pass partyId as sourcePartnerDealerId
        # Validate v2 key-data record for DTA
        v2_record = get_deal_component_details(
            self.deal_data.dealRefId, deal_component="REF_IDS.DTA"
        )
        validate_v2_key_data(
            posted_payload={**cust_header, **self.deal_data.payload},
            database_resp=v2_record,
            key_name="DTA",
        )
        # For a Lead Post, there is no DTA.creditApp record for key-data

        # Validate v2 key-data record for DTA
        v2_record = get_deal_component_details(
            self.deal_data.dealRefId, deal_component="REF_IDS.DTC"
        )
        validate_v2_key_data(
            posted_payload={**self.deal_data.payload, **cust_header},
            database_resp=v2_record,
            key_name="DTC",
        )

        # Validate
        common_assert(records=[record], resp_headers=resp_headers)
        self.deal_data.update_key_data_fields_mapping()
        verify_given_dict_object(self.deal_data.payload, record)

    @pytest.mark.prod
    @pytest.mark.smoke
    @pytest.mark.functional
    def test_key_data_update_with_existing_deal_ref_id_fd_credit_app_flow(
        self,
        common_assert,
        get_response_data,
        validate_v2_key_data,
        get_deal_component_details,
        verify_given_dict_object,
        key_data_test_data_dta_record,
    ):
        self.deal_data.set_payload(file_name="credit_app/ind_retail_new.json")
        self.deal_data.payload["targetPlatforms"] = [
            {"id": "DTC", "partyId": "K56YK"},
            {"id": "R1J", "partyId": "K3J5H"},
        ]

        # Update header with X-Application-Reference-Number --> appRefIdFD
        cust_header = {
            "X-Application-Reference-Number": self.deal_data.generate_random_id()
        }
        app_resp, resp_headers = self.post_request_based_on_route(
            APP_ROUTE, cust_headers=cust_header
        )

        # Patch Key-Data
        self.deal_data.payload = key_data_test_data_dta_record
        patch_resp, resp_headers = self.update_key_data()
        record = get_deal_component_details(
            deal_ref_id=app_resp.get("dealRefId"),
            deal_component="DTC.DEAL",
            additional_check_key="appRefIdFD",
            additional_check_value=self.deal_data.payload["appRefIdFD"],
        )
        # Validate v2 key-data record for DTA
        v2_record = get_deal_component_details(
            self.deal_data.dealRefId, deal_component="REF_IDS.DTA"
        )
        validate_v2_key_data(
            posted_payload={**cust_header, **self.deal_data.payload},
            database_resp=v2_record,
            key_name="DTA",
        )

        # Validate v2 key-data record for DTA APP
        v2_record = get_deal_component_details(
            self.deal_data.dealRefId,
            deal_component=f"REF_IDS.DTA.{app_resp['creditAppId']}",
        )
        validate_v2_key_data(
            posted_payload={**cust_header, **app_resp},
            database_resp=v2_record,
            key_name="DTA_APP",
        )

        # Validate v2 key-data record for R1J
        v2_record = get_deal_component_details(
            self.deal_data.dealRefId, deal_component="REF_IDS.R1J"
        )
        self.deal_data.payload["sourcePartnerDealerId"] = "K3J5H"
        validate_v2_key_data(
            posted_payload=self.deal_data.payload,
            database_resp=v2_record,
            key_name="R1J",
        )
        # From Deal-Data with _SIMBRIDGE, a call to bridge is NOT made. Hence, no R1J key-data response for R1J CA

        # Validate
        common_assert(records=[record], resp_headers=resp_headers)
        self.deal_data.update_key_data_fields_mapping()
        verify_given_dict_object(self.deal_data.payload, record)

    @pytest.mark.functional
    def test_key_data_update_with_random_key_credit_app(
        self, invalid_key_data_test_data_dtc_random_key, generate_random_id
    ):
        self.deal_data.dealRefId = generate_random_id
        # Patch Key-Data
        self.deal_data.payload = invalid_key_data_test_data_dtc_random_key
        patch_resp, resp_headers = self.update_key_data(
            expected_status=HTTPStatus.BAD_REQUEST
        )
        assert patch_resp["message"] == "Invalid request body"

    @pytest.mark.functional
    def test_key_data_update_with_finance_method(
        self, invalid_key_data_test_data_for_finance_method, generate_random_id
    ):
        self.deal_data.dealRefId = generate_random_id
        # Patch Key-Data
        self.deal_data.payload = invalid_key_data_test_data_for_finance_method
        patch_resp, resp_headers = self.update_key_data(
            expected_status=HTTPStatus.BAD_REQUEST
        )
        assert patch_resp["message"] == "Invalid request body"

    @pytest.mark.functional
    def test_key_data_update_with_credit_bureau(
        self,
        common_assert,
        get_response_data,
        validate_v2_key_data,
        verify_given_dict_object,
        get_deal_component_details,
        key_data_test_data_idl_record,
    ):
        self.deal_data.set_payload(file_name="credit_bureau/app_cb_equ_exp_tru.json")
        bureau_resp, resp_headers = self.post_request_based_on_route(
            api_route=BUREAU_ROUTE, cb_post=True
        )
        # Need it for key-dat DTC validation
        bureau_party_id = self.deal_data.payload["targetPlatforms"][0]["partyId"]
        # Patch Key-Data
        self.deal_data.payload = key_data_test_data_idl_record
        patch_resp, resp_headers = self.update_key_data()
        record = get_deal_component_details(
            deal_ref_id=bureau_resp.get("dealRefId"),
            deal_component="DTC.DEAL",
            additional_check_key="dealJacketIdIDL",
            additional_check_value=self.deal_data.payload["dealJacketId"],
        )

        #  Validate v2 key-data records for DTA
        v2_record = get_deal_component_details(
            self.deal_data.dealRefId, deal_component="REF_IDS.DTA"
        )
        validate_v2_key_data(
            posted_payload=self.deal_data.payload,
            database_resp=v2_record,
            key_name="DTA",
        )
        #  Validate v2 key-data record for DTC
        v2_record = get_deal_component_details(
            self.deal_data.dealRefId, deal_component="REF_IDS.DTC"
        )
        validate_v2_key_data(
            posted_payload={"sourcePartnerDealerId": bureau_party_id},
            database_resp=v2_record,
            key_name="DTC",
        )
        #  Validate v2 key-data record for DTC
        v2_record = get_deal_component_details(
            self.deal_data.dealRefId,
            deal_component=f"REF_IDS.IDL.{self.deal_data.payload['dealId']}",
        )
        validate_v2_key_data(
            posted_payload=self.deal_data.payload,
            database_resp=v2_record,
            key_name="IDL_APP",
        )

        # Validate
        common_assert(records=[record], resp_headers=resp_headers)
        self.deal_data.update_key_data_fields_mapping()
        verify_given_dict_object(self.deal_data.payload, record)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_key_data_update_with_invalid_deal_ref_id(
        self,
        common_assert,
        key_data_test_data_dtc_record_single_key,
        generate_random_id,
    ):
        # Generate a new ID
        self.deal_data.dealRefId = generate_random_id

        # Patch Key-Data
        self.deal_data.payload = key_data_test_data_dtc_record_single_key
        patch_resp, resp_headers = self.update_key_data(
            expected_status=HTTPStatus.BAD_REQUEST
        )

        assert patch_resp.get("message") == ErrorMsgs.missing_deal_from_db.format(
            deal_ref_id=self.deal_data.dealRefId
        )

        # Validate
        common_assert(resp_headers=resp_headers)

    test_data = [
        ("key_data_test_data_dta_record", "appRefIdFD", "appRefIdFD"),
        ("key_data_test_data_dtc_record", "dealJacketId", "dealJacketId"),
        ("key_data_test_data_default_record_dtc", "dealJacketId", "dealJacketId"),
        ("key_data_test_data_idl_record", "dealJacketIdIDL", "dealJacketId"),
        ("key_data_test_data_r1j_record", "dealJacketIdR1", "dealJacketId"),
    ]

    @pytest.mark.functional
    @pytest.mark.parametrize(
        "target_platforms_payloads, db_field, payload_field", test_data
    )
    def test_key_data_update_all_target_platforms(
        self,
        common_assert,
        get_response_data,
        verify_given_dict_object,
        target_platforms_payloads,
        db_field,
        payload_field,
        validate_v2_key_data,
        get_deal_component_details,
        key_data_test_data_dta_record,  # don't remove
        key_data_test_data_dtc_record,  # don't remove
        key_data_test_data_default_record_dtc,  # don't remove
        key_data_test_data_idl_record,  # don't remove
        key_data_test_data_r1j_record,  # don't remove
    ):

        self.deal_data.set_payload(file_name="credit_app/ind_retail_new.json")
        app_resp, resp_headers = self.post_request_based_on_route()

        # Patch Key-Data
        self.deal_data.payload = eval(target_platforms_payloads)
        patch_resp, resp_headers = self.update_key_data()
        record = get_deal_component_details(
            deal_ref_id=app_resp.get("dealRefId"),
            deal_component="DTC.DEAL",
            additional_check_key=db_field,
            additional_check_value=self.deal_data.payload[payload_field],
        )
        target_name = self.deal_data.payload.get("targetPlatformId", "DTC")
        target_key = f"REF_IDS.{target_name}"
        # Validate v2 key-data record for DTA
        v2_record = get_deal_component_details(
            self.deal_data.dealRefId, deal_component="REF_IDS.DTA"
        )
        validate_v2_key_data(
            posted_payload=self.deal_data.payload,
            database_resp=v2_record,
            key_name="DTA",
        )

        # Validate v2 key-data record for DTA APP
        payload = (
            {"creditAppId": app_resp["creditAppId"]}
            if target_name == "DTA"
            else self.deal_data.payload
        )
        v2_record = get_deal_component_details(
            self.deal_data.dealRefId,
            deal_component=f"REF_IDS.DTA.{app_resp['creditAppId']}",
        )
        validate_v2_key_data(
            posted_payload=payload,
            database_resp=v2_record,
            key_name="DTA_APP",
        )

        # Validate v2 key-data record for specific target
        v2_record = get_deal_component_details(
            self.deal_data.dealRefId, deal_component=target_key
        )
        validate_v2_key_data(
            posted_payload=payload,
            database_resp=v2_record,
            key_name=target_name,
        )
        # Validate v2 key-data record for specific target app
        ca_key = payload[CREDIT_APP_KEY_BY_TARGET[target_name]]
        v2_record = get_deal_component_details(
            self.deal_data.dealRefId, deal_component=f"{target_key}.{ca_key}"
        )
        validate_v2_key_data(
            posted_payload=payload,
            database_resp=v2_record,
            key_name=f"{target_name}_APP",
        )

        # Validate
        common_assert(records=[record], resp_headers=resp_headers)
        self.deal_data.update_key_data_fields_mapping()
        verify_given_dict_object(self.deal_data.payload, record)

    @pytest.mark.functional
    def test_key_data_update_multiple_patches(
        self,
        common_assert,
        get_response_data,
        validate_v2_key_data,
        verify_given_dict_object,
        get_deal_component_details,
        key_data_test_data_dta_record,
        key_data_test_data_dtc_record,
        key_data_test_data_default_record_dtc,
        key_data_test_data_idl_record,
        key_data_test_data_r1j_record,
    ):
        self.deal_data.set_payload(file_name="credit_app/ind_retail_new.json")
        app_resp, resp_headers = self.post_request_based_on_route()

        posted_data_with_db_name = {}

        # Patch Key-Data
        for patch_payload in [
            (key_data_test_data_dta_record, "appRefIdFD", "appRefIdFD"),
            (key_data_test_data_dtc_record, "dealJacketId", "dealJacketId"),
            (key_data_test_data_default_record_dtc, "dealJacketId", "dealJacketId"),
            (key_data_test_data_idl_record, "dealJacketIdIDL", "dealJacketId"),
            (key_data_test_data_r1j_record, "dealJacketIdR1", "dealJacketId"),
        ]:
            # Patch with key-data
            self.deal_data.payload = patch_payload[0]
            patch_resp, resp_headers = self.update_key_data()
            record = get_deal_component_details(
                deal_ref_id=app_resp.get("dealRefId"),
                deal_component="DTC.DEAL",
                additional_check_key=patch_payload[1],
                additional_check_value=self.deal_data.payload[patch_payload[2]],
            )
            common_assert(records=[record], resp_headers=resp_headers)

            # Validate v2 key-data record for Specific Target
            target_name = self.deal_data.payload.get("targetPlatformId", "DTC")
            target_key = f"REF_IDS.{target_name}"
            v2_record = get_deal_component_details(
                self.deal_data.dealRefId, deal_component=target_key
            )
            validate_v2_key_data(
                posted_payload=self.deal_data.payload,
                database_resp=v2_record,
                key_name=target_name,
            )

            # Validate v2 key-data record for Credit App
            ca_key = self.deal_data.payload.get(CREDIT_APP_KEY_BY_TARGET[target_name])
            if ca_key:
                v2_record = get_deal_component_details(
                    self.deal_data.dealRefId, deal_component=f"{target_key}.{ca_key}"
                )
                validate_v2_key_data(
                    posted_payload=self.deal_data.payload,
                    database_resp=v2_record,
                    key_name=f"{target_name}_APP",
                )

            # Validate v2 key-data record for DTA
            v2_record = get_deal_component_details(
                self.deal_data.dealRefId, deal_component="REF_IDS.DTA"
            )
            validate_v2_key_data(
                posted_payload=self.deal_data.payload,
                database_resp=v2_record,
                key_name="DTA",
            )

            # Get DB field name and update to temp dict
            self.deal_data.update_key_data_fields_mapping()
            posted_data_with_db_name.update(self.deal_data.payload)

        # Validate
        verify_given_dict_object(posted_data_with_db_name, record)

    @pytest.mark.functional
    @pytest.mark.skip(reason="Flow is not support yet - US1087197")
    def test_key_data_update_with_additional_key_data(
        self,
        verify_deal_component,
        get_records_by_deal_ref_id,
        key_data_test_data_default_record_dtc,
        key_data_test_data_dtc_record_single_key,
    ):
        self.deal_data.payload = key_data_test_data_dtc_record_single_key

        response, resp_headers = self.post_request_based_on_route(
            api_route=KEY_DATA_POST_ROUTE
        )

        add_keys_header = {
            "X-Lead-Reference-Number": self.deal_data.generate_random_id(),
            "X-Application-Reference-Number": self.deal_data.generate_random_id(),
            "X-Lead-Reference-Number-Internal": self.deal_data.generate_random_id(),
            "X-Application-Reference-Number-Internal": self.deal_data.generate_random_id(),
            "X-Deal-Jacket-ID": self.deal_data.generate_random_id(),
            "X-Partner-ID": self.deal_data.generate_random_id(),
            "X-Partner-Dealer-ID": self.deal_data.generate_random_id(),
            "X-Dealer-Code": "65677",
            "X-Deal-Reference-Number-UniFI": self.deal_data.generate_random_id(),
            "X-ABCD-ID": self.deal_data.generate_random_id(),
        }

        # Patch Key-Data
        self.deal_data.payload = key_data_test_data_default_record_dtc
        self.update_key_data(cust_header=add_keys_header)
        records, count, status = get_records_by_deal_ref_id(response.get("dealRefId"))

        # Validate
        assert count == 2

        self.deal_data.payload.update(add_keys_header)
        verify_deal_component(
            records, self.deal_data.payload, "deal", additional_header_keys=True
        )

    @pytest.mark.functional
    def test_key_data_update_with_credit_app_id_on_credit_app(
        self, invalid_key_data_test_data_dta_record_with_reference_key
    ):
        """
        Tests if creditAppId be updated with a patch, a generic validation should prevent key data update with
        creditAppId
        """

        # Patch Key-Data
        self.deal_data.payload = (
            invalid_key_data_test_data_dta_record_with_reference_key
        )
        patch_resp, resp_headers = self.update_key_data(
            expected_status=HTTPStatus.BAD_REQUEST
        )
        assert patch_resp["message"] == "Invalid request body"

    @pytest.mark.functional
    def test_key_data_update_with_old_supported_keys(
        self,
        invalid_key_data_test_data_old_post_removed_keys,
    ):
        for key, value in invalid_key_data_test_data_old_post_removed_keys.items():
            key_data_payload = {key: value}

            # Patch Key-Data
            self.deal_data.payload = key_data_payload
            patch_resp, resp_headers = self.update_key_data(
                expected_status=HTTPStatus.BAD_REQUEST
            )
            assert patch_resp["message"] == "Invalid request body"

    @pytest.mark.prod
    @pytest.mark.smoke
    @pytest.mark.functional
    @pytest.mark.skip(reason="Flow is not support yet - US1087197")
    def test_key_data_update_with_existing_deal_ref_id_fd_in_db(
        self,
        key_data_test_data_default_record_dtc,
        key_data_test_data_dtc_record_single_key,
    ):
        """
        Validate error message is return for passing dealRefIdFD as part of key-data patch is the key already
        exist in db
        """
        self.deal_data.payload = key_data_test_data_dtc_record_single_key
        self.post_request_based_on_route(api_route=KEY_DATA_POST_ROUTE)

        # Patch key-data with dealRefIdFD
        self.deal_data.payload = key_data_test_data_default_record_dtc
        patch_resp, resp_headers = self.update_key_data(HTTPStatus.BAD_REQUEST)
        assert (
            patch_resp["message"]
            == f"'dealRefIdFD' already exists for resource dealRefId={self.deal_data.dealRefId}"
        )

    @pytest.mark.prod
    @pytest.mark.smoke
    @pytest.mark.functional
    @pytest.mark.skip(reason="Flow is not support yet - US1087197")
    def test_key_data_update_with_non_existing_deal_ref_id_fd_in_db(
        self,
        key_data_test_data_idl_record,
        key_data_test_data_dtc_record_single_key,
    ):
        """
        Validate NO error message is return for passing dealRefIdFD as part of key-data patch if key does NOT
        exist in db
        """
        self.deal_data.payload = key_data_test_data_dtc_record_single_key
        self.post_request_based_on_route(api_route=KEY_DATA_POST_ROUTE)

        # Patch key-data with dealRefIdFD
        self.deal_data.payload = key_data_test_data_idl_record
        self.update_key_data()

    test_data = [
        "key_data_test_data_dtc_record",
        "key_data_test_data_default_record_dtc",
        "key_data_test_data_idl_record",
        "key_data_test_data_r1j_record",
    ]

    @pytest.mark.smoke
    @pytest.mark.functional
    @pytest.mark.parametrize("target_platforms_payloads", test_data)
    def test_key_data_patch_dta_fields_allowed_for_all_target_platforms(
        self,
        validate_v2_key_data,
        target_platforms_payloads,
        verify_given_dict_object,
        get_deal_component_details,
        key_data_test_data_dtc_record_single_key,
        key_data_test_data_dta_record,  # don't remove
        key_data_test_data_dtc_record,  # don't remove
        key_data_test_data_default_record_dtc,  # don't remove
        key_data_test_data_idl_record,  # don't remove
        key_data_test_data_r1j_record,  # don't remove
    ):
        self.deal_data.payload = key_data_test_data_dtc_record_single_key
        response, resp_headers = self.post_request_based_on_route(
            api_route=KEY_DATA_POST_ROUTE
        )

        self.deal_data.payload = eval(target_platforms_payloads)
        payload_target = self.deal_data.payload.get("targetPlatformId", "DTC")
        self.deal_data.payload = {
            **key_data_test_data_dta_record,
            **self.deal_data.payload,
            "targetPlatformId": payload_target,
        }

        # Patch key-data with dealRefIdFD
        self.update_key_data()
        record = get_deal_component_details(
            deal_ref_id=response.get("dealRefId"),
            deal_component="DTC.DEAL",
            additional_check_key="dealRefIdFD",
            additional_check_value=self.deal_data.payload["dealRefIdFD"],
        )

        #  Validate v2 key-data records
        target_name = self.deal_data.payload.get("targetPlatformId", "DTC")
        target_key = f"REF_IDS.{target_name}"
        v2_record = get_deal_component_details(
            response.get("dealRefId"), deal_component=target_key
        )
        validate_v2_key_data(
            posted_payload=self.deal_data.payload,
            database_resp=v2_record,
            key_name=target_name,
        )

        #  Validate v2 key-data credit app records
        ca_key = self.deal_data.payload[CREDIT_APP_KEY_BY_TARGET[target_name]]
        v2_record = get_deal_component_details(
            response.get("dealRefId"), deal_component=f"{target_key}.{ca_key}"
        )
        validate_v2_key_data(
            posted_payload=self.deal_data.payload,
            database_resp=v2_record,
            key_name=f"{target_name}_APP",
        )

        #  Validate v2 key-data record for DTA
        v2_record = get_deal_component_details(
            response.get("dealRefId"), deal_component="REF_IDS.DTA"
        )
        validate_v2_key_data(
            posted_payload=self.deal_data.payload,
            database_resp=v2_record,
            key_name="DTA",
        )

        # Update payload with DB key names and verify
        self.deal_data.update_key_data_fields_mapping()
        verify_given_dict_object(self.deal_data.payload, record)
