# -*- coding: utf-8 -*-
import copy
import logging
from http import HTTPStatus

import pytest
from tests.functional.key_data.config import INDEXES_FIELDS_BY_TARGET
from tests.functional.service_api import ServiceAPI


APP_ROUTE = "credit_app"
LEAD_ROUTE = "leads"
KEY_DATA_POST_ROUTE = "key_data"
KEY_DATA_UPDATE_ROUTE = "key_data_patch"
KEY_DATA_GET_ROUTE = "key_data_get"
APP_WITH_REF_ID = "credit_app_with_deal_ref"

log = logging.getLogger(__name__)


class TestKeyDataGet:
    @classmethod
    @pytest.fixture(autouse=True)
    def setup_method(cls, env, api_url, random_data_class):
        cls.env = env
        cls.api_url = api_url
        cls.deal_data = ServiceAPI(random_data_class=random_data_class, env=env)

    def get_key_data_response(self, query_param, expected_status_code=HTTPStatus.OK):
        status_code, get_resp, resp_headers = self.deal_data.get_request(
            url=self.api_url,
            route_url=KEY_DATA_GET_ROUTE,
            query_param=query_param,
        )
        if status_code != expected_status_code:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {get_resp}"
            )
        return status_code, get_resp, resp_headers

    def post_request_based_on_route(self, api_route):
        status_code, post_resp, resp_headers = self.deal_data.post_request(
            self.api_url,
            api_route,
        )

        if status_code != HTTPStatus.CREATED:
            raise Exception(
                f"Response code is: {status_code} and the response message is: {post_resp}"
            )

        return status_code, post_resp, resp_headers

    @pytest.mark.prod
    @pytest.mark.functional
    def test_key_data_get_using_deal_jacket_id_for_credit_app(
        self,
        common_assert,
        get_deal_component_details,
    ):
        self.deal_data.set_payload("credit_app/ind_retail_new.json")
        # Update payload with a key field for get
        dj_id = self.deal_data.generate_random_id()
        self.deal_data.payload["dealJacketId"] = dj_id

        # Post a credit App
        self.post_request_based_on_route(APP_ROUTE)

        # Verify if data has been saved successfully in DB
        get_deal_component_details(
            deal_ref_id=self.deal_data.dealRefId,
            deal_component="DTC.DEAL",
            additional_check_key="dealJacketId",
            additional_check_value=dj_id,
        )

        # Search query for key data
        query_param = f"dealJacketId={dj_id}"
        status_code, get_resp, resp_headers = self.get_key_data_response(query_param)

        # Validation
        assert len(get_resp) == 1
        assert dj_id == get_resp[0]["dealJacketId"]
        assert self.deal_data.payload["financeMethod"] == get_resp[0]["financeMethod"]
        common_assert(resp_headers=resp_headers)

    @pytest.mark.prod
    @pytest.mark.functional
    def test_key_data_get_using_lead_ref_id(
        self, common_assert, get_deal_component_details
    ):
        self.deal_data.set_payload("leads/leads_min_data.json")
        # Post a lead
        self.post_request_based_on_route(LEAD_ROUTE)

        # Verify if data has been saved successfully in DB
        get_deal_component_details(
            deal_ref_id=self.deal_data.dealRefId,
            deal_component="DTC.DEAL",
            additional_check_key="leadRefId",
            additional_check_value=self.deal_data.leadRefId,
        )

        # Search query for key data
        query_param = f"leadRefId={self.deal_data.leadRefId}"
        status_code, get_resp, resp_headers = self.get_key_data_response(query_param)

        assert len(get_resp) == 1
        assert get_resp[0].get("leadRefId") == self.deal_data.leadRefId
        assert self.deal_data.payload["financeMethod"] == get_resp[0]["financeMethod"]
        common_assert(resp_headers=resp_headers)

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_key_data_get_for_multiple_matching_deals(self, common_assert):
        self.deal_data.set_payload("leads/leads_min_data.json")
        # Update payload with a key field for get
        dj_id = self.deal_data.generate_random_id()
        self.deal_data.payload["dealJacketId"] = dj_id

        # Post a lead
        self.post_request_based_on_route(LEAD_ROUTE)

        # Update payload
        json_file_name = "credit_app/app_min_data.json"
        self.deal_data.set_payload(json_file_name)

        # Update payload with a key field for get
        self.deal_data.payload["dealJacketId"] = dj_id

        # Post a credit app using same dj_id
        self.post_request_based_on_route(APP_ROUTE)

        # Search query for key data
        query_param = f"dealJacketId={dj_id}"
        status_code, get_resp, resp_headers = self.get_key_data_response(query_param)

        # Validation
        assert len(get_resp) == 2
        for resp in get_resp:
            assert dj_id == resp["dealJacketId"]
            assert self.deal_data.payload["financeMethod"] == resp["financeMethod"]
        common_assert(resp_headers=resp_headers)

    @pytest.mark.functional
    def test_key_data_get_from_after_a_key_data_post(
        self,
        key_data_test_data_r1j_record,
        verify_given_dict_object,
    ):
        self.deal_data.payload = key_data_test_data_r1j_record
        self.post_request_based_on_route(KEY_DATA_POST_ROUTE)

        # Search query for key data
        query_param = f"dealJacketId={self.deal_data.payload.get('dealJacketId')}&targetPlatformId=R1J"
        status_code, get_resp, resp_headers = self.get_key_data_response(query_param)

        assert get_resp[0].get("financeMethod") is None
        self.deal_data.payload.pop("targetPlatformId", None)
        verify_given_dict_object(self.deal_data.payload, get_resp[0])

    @pytest.mark.smoke
    @pytest.mark.functional
    @pytest.mark.xfail(reason="Flow is not support yet - US1087197")
    def test_key_data_get_from_after_a_key_data_patch(
        self,
        key_data_test_data_dtc_record,
        verify_given_dict_object,
        key_data_test_data_dtc_record_single_key,
    ):

        # Key Data POST
        self.deal_data.payload = key_data_test_data_dtc_record_single_key
        self.post_request_based_on_route(KEY_DATA_POST_ROUTE)

        # Key Data PATCH
        self.deal_data.payload = key_data_test_data_dtc_record
        self.deal_data.patch(self.api_url, KEY_DATA_UPDATE_ROUTE)

        # Search query for key data
        query_param = f"dealJacketId={self.deal_data.payload.get('dealJacketId')}"
        status_code, get_resp, resp_headers = self.get_key_data_response(query_param)

        assert get_resp[0].get("financeMethod") is None
        verify_given_dict_object(self.deal_data.payload, get_resp[0])

    test_data = [
        ("key_data_test_data_dta_record", "dealRefIdFD"),
        ("key_data_test_data_dtc_record", "dealJacketId"),
        ("key_data_test_data_default_record_dtc", "dealJacketId"),
        ("key_data_test_data_idl_record", "dealJacketId"),
        ("key_data_test_data_r1j_record", "dealJacketId"),
    ]

    @pytest.mark.smoke
    @pytest.mark.functional
    @pytest.mark.parametrize("key_data_patch_payload, patch_query_field", test_data)
    def test_key_data_get_using_indexed_fields_for_each_target(
        self,
        key_data_patch_payload,
        patch_query_field,
        validate_key_data_get,
        key_data_test_data_dta_record,
        key_data_test_data_dtc_record,
        key_data_test_data_default_record_dtc,
        key_data_test_data_idl_record,
        key_data_test_data_r1j_record,
    ):
        self.deal_data.set_payload("leads/leads_min_data.json")
        # Post a lead
        self.post_request_based_on_route(LEAD_ROUTE)

        # Verify lead created
        query_param = f"leadRefId={self.deal_data.leadRefId}"
        self.get_key_data_response(query_param)

        # Posting a credit app using the dealRefId
        self.deal_data.set_payload("credit_app/app_guar_references_cash_new.json")
        app_data = copy.deepcopy(self.deal_data.payload)
        self.post_request_based_on_route(APP_WITH_REF_ID)

        # Verify CA created
        query_param = f"creditAppId={self.deal_data.creditAppId}"
        self.get_key_data_response(query_param)

        # Patch with key-data
        self.deal_data.payload = eval(key_data_patch_payload)
        self.deal_data.patch(self.api_url, KEY_DATA_UPDATE_ROUTE)

        # Get Data GET with Index fields
        payload_target = self.deal_data.payload.get("targetPlatformId", "DTC")

        # Verify PATCH is successful
        query_param = f"{patch_query_field}={self.deal_data.payload[patch_query_field]}&targetPlatformId={payload_target}"
        self.get_key_data_response(query_param)

        # Adding dealRefId and leadRefId to payload
        self.deal_data.payload["dealRefId"] = self.deal_data.dealRefId
        self.deal_data.payload["leadRefId"] = self.deal_data.leadRefId
        self.deal_data.payload["creditAppId"] = self.deal_data.creditAppId

        for field in INDEXES_FIELDS_BY_TARGET[payload_target]:
            query_param = f"{field}={self.deal_data.payload.get(field)}&targetPlatformId={payload_target}"
            status_code, get_resp, resp_headers = self.get_key_data_response(
                query_param
            )

            assert len(get_resp) == 1
            self.deal_data.payload.pop("targetPlatformId", None)

            validate_key_data_get(self.deal_data.payload, get_resp[0])
            assert app_data["financeMethod"] == get_resp[0]["financeMethod"]

    @pytest.mark.functional
    def test_key_data_get_for_non_existing_data(self, common_assert):

        self.deal_data.set_payload(file_name="credit_app/ind_retail_used.json")
        # Update payload with a key field for get
        dj_id = self.deal_data.generate_random_id()
        self.deal_data.payload["dealJacketId"] = dj_id

        # Posting a credit app to POST endpoint
        self.post_request_based_on_route(APP_ROUTE)

        # Search query for key data
        query_param = f"dealJacketId={self.deal_data.generate_random_id()}"
        status_code, get_resp, resp_headers = self.get_key_data_response(query_param)

        # Validation
        assert get_resp == []
        common_assert(resp_headers=resp_headers)

    @pytest.mark.prod
    @pytest.mark.functional
    def test_key_data_get_for_proxy_partner(
        self,
        verify_given_dict_object,
        key_data_test_data_dta_proxy_partner,
    ):
        self.deal_data.payload = key_data_test_data_dta_proxy_partner
        self.post_request_based_on_route(KEY_DATA_POST_ROUTE)

        # Search query for key data
        query_param = f"dealRefId={self.deal_data.dealRefId}"
        status_code, get_resp, resp_headers = self.get_key_data_response(query_param)

        # Update dealRefId in the payload
        self.deal_data.payload["dealRefId"] = self.deal_data.dealRefId
        self.deal_data.payload.pop("targetPlatformId")
        verify_given_dict_object(self.deal_data.payload, get_resp[0])

    @pytest.mark.functional
    def test_key_data_get_with_single_query_and_target_platforms(
        self,
        key_data_test_data_idl_record,
        verify_given_dict_object,
    ):
        self.deal_data.payload = key_data_test_data_idl_record
        self.post_request_based_on_route(KEY_DATA_POST_ROUTE)

        # Search query for key data
        query_param = f"dealJacketId={self.deal_data.payload.get('dealJacketId')}&targetPlatformId=IDL"
        status_code, get_resp, resp_headers = self.get_key_data_response(query_param)

        assert get_resp[0].get("financeMethod") is None
        self.deal_data.payload.pop("targetPlatformId", None)
        verify_given_dict_object(self.deal_data.payload, get_resp[0])

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_key_data_get_default_to_dtc(
        self,
        key_data_test_data_dtc_record,
        verify_given_dict_object,
        key_data_test_data_dta_record,
        key_data_test_data_r1j_record,
        key_data_test_data_idl_record,
        key_data_test_data_dtc_record_single_key,
    ):
        # Key Data POST
        self.deal_data.payload = key_data_test_data_dtc_record_single_key
        self.post_request_based_on_route(KEY_DATA_POST_ROUTE)

        # DTA record must be posted first
        for key_data_patch_payload in [
            key_data_test_data_dta_record,
            key_data_test_data_dtc_record,
            key_data_test_data_r1j_record,
            key_data_test_data_idl_record,
        ]:

            # Key Data PATCH
            self.deal_data.payload = key_data_patch_payload
            self.deal_data.patch(self.api_url, KEY_DATA_UPDATE_ROUTE)

            # Search query for key data
            key_data_test_data_dta_record["dealRefId"] = self.deal_data.dealRefId
            payload_target = self.deal_data.payload.get("targetPlatformId", "DTC")
            get_key = INDEXES_FIELDS_BY_TARGET[payload_target][0]
            query_param = f"{get_key}={self.deal_data.payload[get_key]}&targetPlatformId={payload_target}"
            status_code, get_resp, resp_headers = self.get_key_data_response(
                query_param
            )

            self.deal_data.payload.pop("targetPlatformId", None)
            verify_given_dict_object(self.deal_data.payload, get_resp[0])

    @pytest.mark.functional
    def test_key_data_get_with_invalid_target_platforms(
        self,
    ):
        # Search query for key data
        invalid_target = "ABC"
        query_param = f"dealJacketId=12324343&targetPlatformId={invalid_target}"
        status_code, get_resp, resp_headers = self.get_key_data_response(
            query_param, HTTPStatus.BAD_REQUEST
        )

        assert get_resp == {
            "message": f"Given target platform, {invalid_target} is not supported."
        }

    @pytest.mark.functional
    def test_key_data_get_with_only_target_platforms(
        self,
    ):
        # Search query for key data
        query_param = "targetPlatformId=DTC"
        status_code, get_resp, resp_headers = self.get_key_data_response(
            query_param, HTTPStatus.BAD_REQUEST
        )

        assert get_resp == {"message": "No query string parameters provided"}

    @pytest.mark.functional
    def test_key_data_get_with_empty_index(
        self,
    ):
        # Search query for key data
        query_param = "dealRefId="
        status_code, get_resp, resp_headers = self.get_key_data_response(
            query_param, HTTPStatus.BAD_REQUEST
        )

        assert get_resp == {"message": "Query string value cannot be empty"}

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_key_data_get_from_with_multiple_queries(
        self,
    ):

        # Search query for key data
        query_param = "dealRefId=123456&dealJacketId=987654"
        status_code, get_resp, resp_headers = self.get_key_data_response(
            query_param, HTTPStatus.BAD_REQUEST
        )

        assert get_resp == {
            "message": "Only one query param along with a targetPlatformId is allowed"
        }

    @pytest.mark.smoke
    @pytest.mark.functional
    def test_key_data_get_from_with_multiple_queries_and_target_platforms(
        self,
    ):
        # Search query for key data
        query_param = "dealRefId=123456&dealJacketId=987654&targetPlatformId=R1J"
        status_code, get_resp, resp_headers = self.get_key_data_response(
            query_param, HTTPStatus.BAD_REQUEST
        )
        assert get_resp == {
            "message": "Only one query param along with a targetPlatformId is allowed"
        }

    @pytest.mark.functional
    def test_key_data_get_with_matching_deal_ref_id_and_none_matching_target_platforms(
        self,
        key_data_test_data_dtc_record,
        verify_given_dict_object,
    ):
        self.deal_data.payload = key_data_test_data_dtc_record
        self.post_request_based_on_route(KEY_DATA_POST_ROUTE)

        # Search query for key data
        query_param = f"dealJacketId={self.deal_data.payload.get('dealJacketId')}&targetPlatformId=R1J"
        status_code, get_resp, resp_headers = self.get_key_data_response(query_param)

        assert len(get_resp) == 0

    @pytest.mark.functional
    def test_key_data_get_for_unsupported_query_parameter(
        self, common_assert, get_records_by_deal_ref_id
    ):
        self.deal_data.set_payload(file_name="credit_app/ind_retail_new.json")
        # Post a credit App
        status_code, app_resp, resp_headers = self.post_request_based_on_route(
            APP_ROUTE
        )

        records, count = get_records_by_deal_ref_id(app_resp.get("dealRefId"))

        # Search query for key data
        query_param = f"unsupportedId={self.deal_data.creditAppId}"
        status_code, get_resp, resp_headers = self.get_key_data_response(
            query_param, HTTPStatus.BAD_REQUEST
        )

        # Validation
        assert (
            get_resp.get("message")
            == "Given query param, unsupportedId is not supported."
        )
        common_assert(records=records, resp_headers=resp_headers)
