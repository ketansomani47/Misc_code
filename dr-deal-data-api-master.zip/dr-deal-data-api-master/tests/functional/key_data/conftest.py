# -*- coding: utf-8 -*-
import logging
import secrets
import string

import pytest
from tests.functional.service_api import ServiceAPI as dealData


log = logging.getLogger(__name__)
random = secrets.SystemRandom()


@pytest.fixture()
def key_data_test_data_dta_record():
    """
    Key-Data payload for DTA record
    :return: payload
    """
    return {
        "targetPlatformId": "DTA",
        "appRefIdFD": dealData.generate_random_id(),
        "dealRefIdFD": dealData.generate_random_id(),
        "appRefIdFDInt": str(random.getrandbits(52)),
        "dealRefIdFDInt": str(random.getrandbits(52)),
        "partnerCode": "".join(
            random.choices(string.ascii_uppercase + string.digits, k=3)
        ),
        "sourcePartnerId": str(random.getrandbits(26)),
        "sourcePartnerDealerId": str(random.getrandbits(26)),
        "proxyPartnerId": "".join(
            random.choices(string.ascii_uppercase + string.digits, k=3)
        ),
        "dealXgDealId": "".join(
            random.choices(string.ascii_uppercase + string.digits, k=6)
        ),
        "dealXgDealVersion": "".join(
            random.choices(string.ascii_uppercase + string.digits, k=6)
        ),
    }


@pytest.fixture()
def key_data_test_data_dta_v2_record():
    """
    Key-Data payload for v2 key-data DTA record
    :return: payload
    """
    return {
        "targetPlatformId": "DTA",
        "creditAppId": str(random.getrandbits(52)),
        "dealRefIdFD": str(random.getrandbits(52)),
        "dealRefIdFDInt": str(random.getrandbits(52)),
        "proxyPartnerId": "".join(
            random.choices(string.ascii_uppercase + string.digits, k=3)
        ),
        "dealXgDealId": "".join(
            random.choices(string.ascii_uppercase + string.digits, k=6)
        ),
        "dealXgDealVersion": "".join(
            random.choices(string.ascii_uppercase + string.digits, k=6)
        ),
        "financeMethod": random.choice(["Finance", "Lease", "Balloon", "Cash"]),
    }


@pytest.fixture()
def key_data_test_data_dtc_v2_record():
    """
    Key-Data payload for v2 key-data DTC record
    :return: payload
    """
    return {
        "targetPlatformId": "DTC",
        "creditAppId": str(random.getrandbits(52)),
        "dealJacketId": str(random.getrandbits(52)),
        "dealId": str(random.getrandbits(52)),
        "dealerCode": str(random.getrandbits(24)),
        "documentMasterIndexId": str(random.getrandbits(52)),
        "commonOrgId": "".join(
            random.choices(string.ascii_uppercase + string.digits, k=6)
        ),
    }


@pytest.fixture()
def key_data_test_data_default_record_dtc():
    """
    Key-Data payload for default record. DTC is Default if no targetPlatformId key is provided
    :return: payload
    """
    return {
        "dealJacketId": str(random.getrandbits(52)),
        "dealRefIdFI": dealData.generate_random_id(),
        "dealIdFI": dealData.generate_random_id(),
        "dealerId": str(random.getrandbits(52)),
        "dealerCode": str(random.getrandbits(52)),
        "documentMasterIndexIdFI": dealData.generate_random_id(),
        "dealXgDealId": "".join(
            random.choices(string.ascii_uppercase + string.digits, k=6)
        ),
        "dealXgDealVersion": "".join(
            random.choices(string.ascii_uppercase + string.digits, k=6)
        ),
        "commonOrgId": "".join(
            random.choices(string.ascii_uppercase + string.digits, k=6)
        ),
    }


@pytest.fixture()
def key_data_test_data_idl_record():
    """
    Key-Data payload for Honda record
    :return: payload
    """
    return {
        "targetPlatformId": "IDL",
        "dealJacketId": str(random.getrandbits(52)),
        "dealerCode": str(random.getrandbits(52)),
        "dealId": str(random.getrandbits(52)),
        "documentMasterIndexId": dealData.generate_random_id(),
        "dealXgDealId": "".join(
            random.choices(string.ascii_uppercase + string.digits, k=6)
        ),
        "dealXgDealVersion": "".join(
            random.choices(string.ascii_uppercase + string.digits, k=6)
        ),
    }


@pytest.fixture()
def key_data_test_data_idl_v2_record():
    """
    Key-Data payload for v2 key-data Honda record
    :return: payload
    """
    return {
        "targetPlatformId": "IDL",
        "creditAppId": str(random.getrandbits(52)),
        "dealJacketId": str(random.getrandbits(52)),
        "dealId": str(random.getrandbits(52)),
        "dealerCode": str(random.getrandbits(52)),
        "documentMasterIndexId": dealData.generate_random_id(),
    }


@pytest.fixture()
def key_data_test_data_r1j_record():
    """
    Key-Data payload for RouteOne record
    :return: payload
    """
    return {
        "targetPlatformId": "R1J",
        "dealJacketId": dealData.generate_random_id(),
        "conversationId": dealData.generate_random_id(),
        "creditAppIdR1": dealData.generate_random_id(),
        "dealXgDealId": dealData.generate_random_id(),
    }


@pytest.fixture()
def key_data_test_data_r1j_v2_record():
    """
    Key-Data payload for v2 key-data RouteOne record
    :return: payload
    """
    return {
        "targetPlatformId": "R1J",
        "creditAppId": str(random.getrandbits(52)),
        "dealJacketId": str(random.getrandbits(52)),
        "conversationId": str(random.getrandbits(52)),
        "creditAppIdR1": str(random.getrandbits(52)),
    }


@pytest.fixture()
def key_data_test_data_dta_proxy_partner():
    """
    Key-Data payload for DTA record
    :return: payload
    """
    return {
        "targetPlatformId": "DTA",
        "proxyPartnerId": "".join(
            random.choices(string.ascii_uppercase + string.digits, k=3)
        ),
    }


@pytest.fixture()
def key_data_test_data_idl_deal_jacket_record():
    """
    Key-Data payload for IDL record
    :return: payload
    """
    return {
        "targetPlatformId": "IDL",
        "dealJacketId": str(random.getrandbits(52)),
    }


@pytest.fixture()
def invalid_key_data_test_data_dta_record_with_reference_key():
    """
    Invalid Key-Data payload for DTA record.
    Payload contains keys that are not allows to post.
    dealRefId & creditAppId are reference keys and they can not be posted/updated by key-data
    :return: payload
    """
    return {
        "targetPlatformId": "DTA",
        "dealRefId": dealData.generate_random_id(),
        "creditAppId": dealData.generate_random_id(),
        "leadRefId": dealData.generate_random_id(),
        "contractRefId": dealData.generate_random_id(),
        "dealRefIdFD": dealData.generate_random_id(),
        "appRefIdFDInt": str(random.getrandbits(52)),
        "dealRefIdFDInt": str(random.getrandbits(52)),
        "partnerCode": "".join(
            random.choices(string.ascii_uppercase + string.digits, k=3)
        ),
        "sourcePartnerId": str(random.getrandbits(52)),
        "sourcePartnerDealerId": str(random.getrandbits(52)),
        "proxyPartnerId": "".join(
            random.choices(string.ascii_uppercase + string.digits, k=3)
        ),
    }


@pytest.fixture()
def invalid_key_data_test_data_dtc_record_with_unsupported_key():
    """
    Invalid Key-Data payload for DTC record.
    Payload contains key that is not supported in the targetPlatforms
    :return: payload
    """
    return {
        "targetPlatformId": "DTC",
        "dealJacketId": str(random.getrandbits(52)),
        "dealRefIdFI": dealData.generate_random_id(),
        "dealIdFI": dealData.generate_random_id(),
        "dealerId": str(random.getrandbits(52)),
        "dealerCode": str(random.getrandbits(52)),
        "documentMasterIndexIdFI": dealData.generate_random_id(),
        "conversationId": dealData.generate_random_id(),
    }


@pytest.fixture()
def invalid_key_data_test_data_dtc_random_key():
    """
    Invalid Key-Data payload for DTC record.
    Payload contains a random key
    :return: payload
    """
    return {
        "targetPlatformId": "DTC",
        "randomKey": str(random.getrandbits(52)),
    }


@pytest.fixture()
def invalid_key_data_test_data_for_finance_method():
    """
    Invalid Key-Data payload for financeMethod key.
    Payload contains key financeMethod that is not supported
    :return: payload
    """
    return {"targetPlatformId": "DTA", "financeMethod": "Finance"}


@pytest.fixture()
def invalid_key_data_test_data_empty_record():
    """
    Invalid Key-Data payload for empty record
    :return: payload
    """
    return {}


@pytest.fixture()
def invalid_key_data_test_data_old_post_removed_keys():
    """
    Invalid Key-Data payload for DTC record. Post with only keys that are removed or unsupported.
    Recommendation is to post one field at a time
    :return: payload
    """
    return {
        "partnerId": str(random.getrandbits(52)),
        "partnerDealerId": str(random.getrandbits(52)),
    }


@pytest.fixture()
def validate_key_data_get():
    """
    Validate key data GET
    :return:
    """

    def wrapper(request, response):
        for key in request:
            assert request.get(key) == response.get(key)

    return wrapper


@pytest.fixture()
def invalid_key_data_dtc_target_with_other_keys():
    """
    Invalid Key-Data payload for DTC record.
    Payload contains keys for none DTC record
    :return: payload
    """
    return [
        {
            "targetPlatformId": "DTC",
            "dealId": str(random.getrandbits(52)),
            "documentMasterIndexId": dealData.generate_random_id(),
            "error_fields": "dealId, documentMasterIndexId",
        },
        {
            "targetPlatformId": "DTC",
            "conversationId": dealData.generate_random_id(),
            "creditAppIdR1": dealData.generate_random_id(),
            "error_fields": "conversationId, creditAppIdR1",
        },
    ]


@pytest.fixture()
def invalid_key_data_idl_target_with_other_keys():
    """
    Invalid Key-Data payload for IDL record.
    Payload contains keys for none IDL record
    :return: payload
    """
    return [
        {
            "targetPlatformId": "IDL",
            "dealRefIdFI": dealData.generate_random_id(),
            "dealIdFI": dealData.generate_random_id(),
            "dealerId": str(random.getrandbits(52)),
            "documentMasterIndexIdFI": dealData.generate_random_id(),
            "error_fields": "dealRefIdFI, dealIdFI, dealerId, documentMasterIndexIdFI",
        },
        {
            "targetPlatformId": "IDL",
            "conversationId": dealData.generate_random_id(),
            "creditAppIdR1": dealData.generate_random_id(),
            "error_fields": "conversationId, creditAppIdR1",
        },
    ]


@pytest.fixture()
def invalid_key_data_r1j_target_with_other_keys():
    """
    Invalid Key-Data payload for R1J record.
    Payload contains keys for none R1J record
    :return: payload
    """
    return [
        {
            "targetPlatformId": "R1J",
            "dealJacketId": str(random.getrandbits(52)),
            "dealRefIdFI": dealData.generate_random_id(),
            "dealIdFI": dealData.generate_random_id(),
            "dealerId": str(random.getrandbits(52)),
            "dealerCode": str(random.getrandbits(52)),
            "documentMasterIndexIdFI": dealData.generate_random_id(),
            "error_fields": "dealRefIdFI, dealIdFI, dealerId, dealerCode, documentMasterIndexIdFI",
        },
        {
            "targetPlatformId": "R1J",
            "dealJacketId": str(random.getrandbits(52)),
            "dealId": str(random.getrandbits(52)),
            "documentMasterIndexId": dealData.generate_random_id(),
            "error_fields": "dealId, documentMasterIndexId",
        },
    ]


def verify_deal_additional_key_data(payload, deal_component_record):
    field_mapper = {
        "dealRefIdFD": "X-Lead-Reference-Number",
        "appRefIdFD": "X-Application-Reference-Number",
        "dealRefIdFDInt": "X-Lead-Reference-Number-Internal",
        "appRefIdFDInt": "X-Application-Reference-Number-Internal",
        "dealJacketId": "X-Deal-Jacket-ID",
        "dealerCode": "X-Dealer-Code",
        "dealRefIdFI": "X-Deal-Reference-Number-UniFI",
    }
    for key in field_mapper.keys():
        if field_mapper[key] in payload:
            assert payload.get(field_mapper[key]) == deal_component_record.get(key)
