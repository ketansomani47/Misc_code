# -*- coding: utf-8 -*-
from http import HTTPStatus

import pytest
from tests.functional.service_api import ServiceAPI


API_ROUTE = "credit_app"


@pytest.mark.smoke
@pytest.mark.prod
@pytest.mark.functional
def test_snapshot_get_ind_retail_new(
    env, api_url, random_data_class, get_records_by_deal_ref_id, common_assert
):
    json_file_name = "ind_retail_new.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"{API_ROUTE}/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(api_url, API_ROUTE)

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )

    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == 11
    common_assert(records=records, resp_headers=resp_headers)
