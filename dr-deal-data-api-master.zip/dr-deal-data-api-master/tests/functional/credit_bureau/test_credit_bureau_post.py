# -*- coding: utf-8 -*-


from http import HTTPStatus

import pytest
from tests.functional.service_api import ServiceAPI


API_ROUTE = "credit_bureau"


@pytest.mark.smoke
@pytest.mark.prod
@pytest.mark.functional
def test_credit_bureau_post_app_cb_equ_exp_tru(
    env,
    api_url,
    common_assert,
    get_response_data,
    random_data_class,
    get_records_by_deal_ref_id,
    verify_list_of_given_fields,
    verify_credit_bureau_reports,
    verify_deal_component_protected,
):
    json_file_name = "app_cb_equ_exp_tru.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_bureau/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(
        api_url, API_ROUTE, cb_post=True
    )
    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))

    # assert count == 8
    assert deal_data.cbRefId == response.get("creditBureauRefId")
    common_assert(records=records, resp_headers=resp_headers)

    # Verify top level data
    fields_list = ["sourcePartnerId", "sourcePartnerDealerId"]
    resp_app = get_response_data(records, "DEAL")
    verify_list_of_given_fields(deal_data.payload, resp_app, fields_list)

    # Verify applicant's data
    fields_list = ["firstName", "lastName", "middleName", "phone"]
    requ_data = deal_data.payload.get("applicant")
    resp_app = get_response_data(records, "APPLICANT")
    verify_list_of_given_fields(requ_data, resp_app, fields_list)

    # Verify applicant's report's data
    app_report = deal_data.payload.get("applicant").get("reports")
    verify_credit_bureau_reports(
        app_report, records, "applicant", response.get("creditBureauRefId"), "request"
    )

    verify_deal_component_protected(records, deal_data.payload, "applicant")


@pytest.mark.functional
def test_credit_bureau_post_app_reports_dup_providers(
    env,
    api_url,
    common_assert,
    get_response_data,
    random_data_class,
    verify_deal_component,
    get_records_by_deal_ref_id,
    verify_list_of_given_fields,
    verify_credit_bureau_reports,
    verify_deal_component_protected,
):
    json_file_name = "app_reports_dup_providers.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_bureau/{json_file_name}",
    )
    add_keys_header = {
        "X-Lead-Reference-Number": deal_data.generate_random_id(),
        "X-Application-Reference-Number": deal_data.generate_random_id(),
        "X-Lead-Reference-Number-Internal": deal_data.generate_random_id(),
        "X-Application-Reference-Number-Internal": deal_data.generate_random_id(),
        "X-Deal-Jacket-ID": deal_data.generate_random_id(),
        "X-Dealer-Code": "6",
        "X-Deal-Reference-Number-UniFI": deal_data.generate_random_id(),
        "X-ABCD-ID": deal_data.generate_random_id(),
    }
    status_code, response, resp_headers = deal_data.post_request(
        api_url, API_ROUTE, cb_post=True, cust_header=add_keys_header
    )
    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))

    # assert count == 11
    assert deal_data.cbRefId == response.get("creditBureauRefId")
    common_assert(records=records, resp_headers=resp_headers)

    # Verify top level data
    fields_list = ["sourcePartnerId", "sourcePartnerDealerId"]
    resp_app = get_response_data(records, "DEAL")
    verify_list_of_given_fields(deal_data.payload, resp_app, fields_list)
    assert "dealRefIdFD" in resp_app

    # Verify applicant's data
    fields_list = ["firstName", "lastName", "middleName", "phone"]
    requ_data = deal_data.payload.get("applicant")
    resp_app = get_response_data(records, "APPLICANT")
    verify_list_of_given_fields(requ_data, resp_app, fields_list)

    # Verify applicant's report's data
    app_report = deal_data.payload.get("applicant").get("reports")
    verify_credit_bureau_reports(
        app_report, records, "applicant", response.get("creditBureauRefId"), "request"
    )

    verify_deal_component_protected(records, deal_data.payload, "applicant")
    deal_data.payload.update(add_keys_header)
    verify_deal_component(
        records, deal_data.payload, "deal", additional_header_keys=True
    )


@pytest.mark.functional
def test_credit_bureau_post_app_cb_softpull_redflag_ofac(
    env,
    api_url,
    common_assert,
    get_response_data,
    random_data_class,
    get_records_by_deal_ref_id,
    verify_list_of_given_fields,
    verify_credit_bureau_reports,
    verify_deal_component_protected,
):
    json_file_name = "app_cb_softpull_redflag_ofac.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_bureau/{json_file_name}",
    )
    # Update payload with dealRefIdFD
    deal_data.payload["dealRefIdFD"] = deal_data.generate_random_id(True)
    status_code, response, resp_headers = deal_data.post_request(
        api_url, API_ROUTE, cb_post=True
    )
    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == 10
    assert deal_data.cbRefId == response.get("creditBureauRefId")
    common_assert(records=records, resp_headers=resp_headers)

    # Verify top level data
    fields_list = ["sourcePartnerId", "sourcePartnerDealerId"]
    resp_app = get_response_data(records, "DEAL")
    verify_list_of_given_fields(deal_data.payload, resp_app, fields_list)
    assert "dealRefIdFD" in resp_app

    # Verify applicant's data
    fields_list = ["firstName", "lastName", "middleName", "phone"]
    requ_data = deal_data.payload.get("applicant")
    resp_app = get_response_data(records, "APPLICANT")
    verify_list_of_given_fields(requ_data, resp_app, fields_list)

    # Verify applicant's report's data
    app_report = deal_data.payload.get("applicant").get("reports")
    verify_credit_bureau_reports(
        app_report, records, "applicant", response.get("creditBureauRefId"), "request"
    )

    verify_deal_component_protected(records, deal_data.payload, "applicant")


@pytest.mark.functional
def test_credit_bureau_post_app_coapp_cb_exp(
    env,
    api_url,
    common_assert,
    get_response_data,
    random_data_class,
    get_records_by_deal_ref_id,
    verify_list_of_given_fields,
    verify_credit_bureau_reports,
    verify_deal_component_protected,
):
    json_file_name = "app_coapp_cb_exp.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_bureau/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(
        api_url, API_ROUTE, cb_post=True
    )
    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == 9
    assert deal_data.cbRefId == response.get("creditBureauRefId")
    common_assert(records=records, resp_headers=resp_headers)

    # Verify top level data
    fields_list = ["sourcePartnerId", "sourcePartnerDealerId"]
    resp_app = get_response_data(records, "DEAL")
    verify_list_of_given_fields(deal_data.payload, resp_app, fields_list)

    # Verify applicant's data
    fields_list = ["firstName", "lastName", "middleName", "phone", "consentGiven"]
    requ_data = deal_data.payload.get("applicant")
    resp_app = get_response_data(records, "APPLICANT")
    verify_list_of_given_fields(requ_data, resp_app, fields_list)

    # Verify applicant's report's data
    app_report = deal_data.payload.get("applicant").get("reports")
    verify_credit_bureau_reports(
        app_report, records, "applicant", response.get("creditBureauRefId"), "request"
    )

    verify_deal_component_protected(records, deal_data.payload, "applicant")

    # Verify Co-Applicant's data
    fields_list = ["firstName", "lastName", "middleName", "phone", "consentGiven"]
    requ_data = deal_data.payload.get("coApplicant")
    resp_app = get_response_data(records, "COAPPLICANT")
    verify_list_of_given_fields(requ_data, resp_app, fields_list)

    # Verify applicant's report's data
    coapp_report = deal_data.payload.get("coApplicant").get("reports")
    verify_credit_bureau_reports(
        coapp_report,
        records,
        "coApplicant",
        response.get("creditBureauRefId"),
        "request",
    )

    verify_deal_component_protected(records, deal_data.payload, "coApplicant")


@pytest.mark.smoke
@pytest.mark.functional
def test_credit_bureau_post_app_coapp_cb_exp_equ_tru_redflag_ofac(
    env,
    api_url,
    common_assert,
    get_response_data,
    random_data_class,
    get_records_by_deal_ref_id,
    verify_list_of_given_fields,
    verify_credit_bureau_reports,
    verify_deal_component_protected,
):
    json_file_name = "app_coapp_cb_exp_equ_tru_redflag_ofac.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_bureau/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(
        api_url, API_ROUTE, cb_post=True
    )
    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == 17
    assert deal_data.cbRefId == response.get("creditBureauRefId")
    common_assert(records=records, resp_headers=resp_headers)

    # Verify top level data
    fields_list = ["sourcePartnerId", "sourcePartnerDealerId"]
    resp_app = get_response_data(records, "DEAL")
    verify_list_of_given_fields(deal_data.payload, resp_app, fields_list)

    # Verify applicant's data
    fields_list = ["firstName", "lastName", "middleName", "phone", "consentGiven"]
    requ_data = deal_data.payload.get("applicant")
    resp_app = get_response_data(records, "APPLICANT")
    verify_list_of_given_fields(requ_data, resp_app, fields_list)

    # Verify applicant's report's data
    coapp_report = deal_data.payload.get("applicant").get("reports")
    verify_credit_bureau_reports(
        coapp_report, records, "applicant", response.get("creditBureauRefId"), "request"
    )

    verify_deal_component_protected(records, deal_data.payload, "applicant")

    # Verify Co-Applicant's data
    fields_list = ["firstName", "lastName", "middleName", "phone", "consentGiven"]
    requ_data = deal_data.payload.get("coApplicant")
    resp_app = get_response_data(records, "COAPPLICANT")
    verify_list_of_given_fields(requ_data, resp_app, fields_list)

    # Verify Co-applicant's report's data
    coapp_report = deal_data.payload.get("coApplicant").get("reports")
    verify_credit_bureau_reports(
        coapp_report,
        records,
        "coApplicant",
        response.get("creditBureauRefId"),
        "request",
    )

    verify_deal_component_protected(records, deal_data.payload, "coApplicant")


@pytest.mark.prod
@pytest.mark.functional
def test_credit_bureau_post_app_coapp_redflag(
    env,
    api_url,
    common_assert,
    get_response_data,
    random_data_class,
    get_records_by_deal_ref_id,
    verify_list_of_given_fields,
    verify_credit_bureau_reports,
    verify_deal_component_protected,
):
    json_file_name = "app_coapp_redflag.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_bureau/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(
        api_url, API_ROUTE, cb_post=True
    )
    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == 9
    assert deal_data.cbRefId == response.get("creditBureauRefId")
    common_assert(records=records, resp_headers=resp_headers)

    # Verify top level data
    fields_list = ["sourcePartnerId", "sourcePartnerDealerId"]
    resp_app = get_response_data(records, "DEAL")
    verify_list_of_given_fields(deal_data.payload, resp_app, fields_list)

    # Verify applicant's data
    fields_list = ["firstName", "lastName", "middleName", "phone", "consentGiven"]
    requ_data = deal_data.payload.get("applicant")
    resp_app = get_response_data(records, "APPLICANT")
    verify_list_of_given_fields(requ_data, resp_app, fields_list)

    # Verify applicant's report's data
    app_report = deal_data.payload.get("applicant").get("reports")
    verify_credit_bureau_reports(
        app_report, records, "applicant", response.get("creditBureauRefId"), "request"
    )

    verify_deal_component_protected(records, deal_data.payload, "applicant")

    # Verify Co-Applicant's data
    fields_list = ["firstName", "lastName", "middleName", "phone", "consentGiven"]
    requ_data = deal_data.payload.get("coApplicant")
    resp_app = get_response_data(records, "COAPPLICANT")
    verify_list_of_given_fields(requ_data, resp_app, fields_list)

    # Verify applicant's report's data
    coapp_report = deal_data.payload.get("coApplicant").get("reports")
    verify_credit_bureau_reports(
        coapp_report,
        records,
        "coApplicant",
        response.get("creditBureauRefId"),
        "request",
    )

    verify_deal_component_protected(records, deal_data.payload, "coApplicant")


@pytest.mark.functional
def test_credit_bureau_post_app_redflag_ofac(
    env,
    api_url,
    common_assert,
    get_response_data,
    random_data_class,
    get_records_by_deal_ref_id,
    verify_list_of_given_fields,
    verify_credit_bureau_reports,
    verify_deal_component_protected,
):
    json_file_name = "app_redflag_ofac.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_bureau/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(
        api_url, API_ROUTE, cb_post=True
    )
    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == 7
    assert deal_data.cbRefId == response.get("creditBureauRefId")
    common_assert(records=records, resp_headers=resp_headers)

    # Verify top level data
    fields_list = ["sourcePartnerId", "sourcePartnerDealerId"]
    resp_app = get_response_data(records, "DEAL")
    verify_list_of_given_fields(deal_data.payload, resp_app, fields_list)

    # Verify applicant's data
    fields_list = ["firstName", "lastName", "middleName", "phone"]
    requ_data = deal_data.payload.get("applicant")
    resp_app = get_response_data(records, "APPLICANT")
    verify_list_of_given_fields(requ_data, resp_app, fields_list)

    # Verify applicant's report's data
    app_report = deal_data.payload.get("applicant").get("reports")
    verify_credit_bureau_reports(
        app_report, records, "applicant", response.get("creditBureauRefId"), "request"
    )

    verify_deal_component_protected(records, deal_data.payload, "applicant")


@pytest.mark.functional
def test_credit_bureau_post_app_softpull_ofac(
    env,
    api_url,
    common_assert,
    get_response_data,
    random_data_class,
    get_records_by_deal_ref_id,
    verify_list_of_given_fields,
    verify_credit_bureau_reports,
    verify_deal_component_protected,
):
    json_file_name = "app_softpull_ofac.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_bureau/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(
        api_url, API_ROUTE, cb_post=True
    )
    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == 8
    assert deal_data.cbRefId == response.get("creditBureauRefId")
    common_assert(records=records, resp_headers=resp_headers)

    # Verify top level data
    fields_list = ["sourcePartnerId", "sourcePartnerDealerId"]
    resp_app = get_response_data(records, "DEAL")
    verify_list_of_given_fields(deal_data.payload, resp_app, fields_list)

    # Verify applicant's data
    fields_list = ["firstName", "lastName", "middleName", "phone"]
    requ_data = deal_data.payload.get("applicant")
    resp_app = get_response_data(records, "APPLICANT")
    verify_list_of_given_fields(requ_data, resp_app, fields_list)

    # Verify applicant's report's data
    app_report = deal_data.payload.get("applicant").get("reports")
    verify_credit_bureau_reports(
        app_report, records, "applicant", response.get("creditBureauRefId"), "request"
    )

    verify_deal_component_protected(records, deal_data.payload, "applicant")


@pytest.mark.smoke
@pytest.mark.functional
def test_credit_bureau_post_coapp_cb_equ_redflag_ofac(
    env,
    api_url,
    common_assert,
    get_response_data,
    random_data_class,
    get_records_by_deal_ref_id,
    verify_list_of_given_fields,
    verify_credit_bureau_reports,
    verify_deal_component_protected,
):
    json_file_name = "coapp_cb_equ_redflag_ofac.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_bureau/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(
        api_url, API_ROUTE, cb_post=True
    )
    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == 8
    assert deal_data.cbRefId == response.get("creditBureauRefId")
    common_assert(records=records, resp_headers=resp_headers)

    # Verify top level data
    fields_list = ["sourcePartnerId", "sourcePartnerDealerId"]
    resp_app = get_response_data(records, "DEAL")
    verify_list_of_given_fields(deal_data.payload, resp_app, fields_list)

    # Verify Co-Applicant's data
    fields_list = ["firstName", "lastName", "middleName", "phone"]
    requ_data = deal_data.payload.get("coApplicant")
    resp_app = get_response_data(records, "COAPPLICANT")
    verify_list_of_given_fields(requ_data, resp_app, fields_list)

    # Verify Co-applicant's report's data
    coapp_report = deal_data.payload.get("coApplicant").get("reports")
    verify_credit_bureau_reports(
        coapp_report,
        records,
        "coApplicant",
        response.get("creditBureauRefId"),
        "request",
    )

    verify_deal_component_protected(records, deal_data.payload, "coApplicant")


@pytest.mark.functional
def test_credit_bureau_post_coapp_softpull_equ_exp_tru_redflag_ofac(
    env,
    api_url,
    common_assert,
    get_response_data,
    random_data_class,
    get_records_by_deal_ref_id,
    verify_list_of_given_fields,
    verify_credit_bureau_reports,
    verify_deal_component_protected,
):
    json_file_name = "coapp_cb_softpull_equ_exp_tru_redflag_ofac.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_bureau/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(
        api_url, API_ROUTE, cb_post=True
    )
    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {response}"
        )
    records, count = get_records_by_deal_ref_id(response.get("dealRefId"))
    # assert count == 10
    assert deal_data.cbRefId == response.get("creditBureauRefId")
    common_assert(records=records, resp_headers=resp_headers)

    # Verify top level data
    fields_list = ["sourcePartnerId", "sourcePartnerDealerId"]
    resp_app = get_response_data(records, "DEAL")
    verify_list_of_given_fields(deal_data.payload, resp_app, fields_list)

    # Verify Co-applicant's data
    fields_list = ["firstName", "lastName", "middleName", "phone"]
    requ_data = deal_data.payload.get("coApplicant")
    resp_app = get_response_data(records, "COAPPLICANT")
    verify_list_of_given_fields(requ_data, resp_app, fields_list)

    # Verify Co-applicant's report's data
    coapp_report = deal_data.payload.get("coApplicant").get("reports")
    verify_credit_bureau_reports(
        coapp_report,
        records,
        "coApplicant",
        response.get("creditBureauRefId"),
        "request",
    )

    verify_deal_component_protected(records, deal_data.payload, "coApplicant")

    # Key data GET after a credit bureau post
    # Search query for key data - dealRefId
    query_param = f"dealRefId={response.get('dealRefId')}"

    status_code, get_resp, resp_headers = deal_data.get_request(
        url=api_url, route_url="key_data_get", query_param=query_param
    )
    assert status_code == HTTPStatus.OK


@pytest.mark.functional
def test_credit_bureau_post_without_cb_ref_id(env, api_url, random_data_class):
    json_file_name = "app_cb_equ_exp_tru.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_bureau/{json_file_name}",
    )
    status_code, response, resp_headers = deal_data.post_request(
        api_url,
        API_ROUTE,
    )
    assert resp_headers.get("X-CoxAuto-Correlation-Id") is not None
    assert status_code == HTTPStatus.BAD_REQUEST
    assert response["message"] == "No Credit-Bureau-Reference-Id header provided"


@pytest.mark.smoke
@pytest.mark.functional
def test_credit_bureau_post_with_invalid_test_data(
    api_url, env, random_data_class, invalid_payload
):
    deal_data = ServiceAPI(
        env=env, random_data_class=random_data_class, payload=invalid_payload
    )
    status_code, response, resp_headers = deal_data.post_request(
        api_url, API_ROUTE, cb_post=True
    )
    assert resp_headers.get("X-CoxAuto-Correlation-Id") is not None
    assert status_code == HTTPStatus.BAD_REQUEST
