# -*- coding: utf-8 -*-
import json
from http import HTTPStatus

import pytest
from tests.functional.service_api import ServiceAPI


@pytest.mark.prod
@pytest.mark.functional
def test_credit_bureau_response_for_applicant_bureau_ofac_redflag_with_deal_ref_id_fd_in_header(
    env,
    api_url,
    common_assert,
    cb_event_payload,
    random_data_class,
    get_response_data,
    wait_with_no_retries,
    get_records_by_deal_ref_id,
    verify_credit_bureau_reports,
):
    json_file_name = "app_cb_equ_exp_tru.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_bureau/{json_file_name}",
    )
    status_code, pull_resp, resp_headers = deal_data.post_request(
        api_url, "credit_bureau", cb_post=True
    )
    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {pull_resp}"
        )

    records, count = get_records_by_deal_ref_id(pull_resp.get("dealRefId"))
    # assert count == 8
    assert deal_data.cbRefId == pull_resp.get("creditBureauRefId")
    common_assert(records=records, resp_headers=resp_headers)

    # Saving post payload
    cb_payload = deal_data.payload

    # posting equ response
    deal_data.set_report_data("cb_resp_equifax")
    cb_resp_payload, reports = deal_data.append_report_data_to_payload(
        cb_payload, deal_data.cb_report, "applicant"
    )

    deal_data.update_payload_with_bureau_key_data(cb_event_payload, cb_resp_payload)
    add_header = {"X-Lead-Reference-Number": deal_data.generate_random_id()}
    status_code, equ_resp, resp_headers = deal_data.post_request(
        api_url, "cb_response", cb_post=True, cust_header=add_header
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {pull_resp}"
        )

    assert pull_resp.get("dealRefId") == equ_resp.get("dealRefId")
    assert pull_resp.get("creditBureauRefId") == equ_resp.get("creditBureauRefId")

    records, count = get_records_by_deal_ref_id(pull_resp.get("dealRefId"))

    # assert count == 9
    assert deal_data.cbRefId == equ_resp.get("creditBureauRefId")
    common_assert(records=records, resp_headers=resp_headers)

    # Verify equifax report's data
    verify_credit_bureau_reports(
        deal_data.cb_report,
        records,
        "applicant",
        pull_resp.get("creditBureauRefId"),
        "response",
    )

    # posting ofac response
    deal_data.set_report_data("cb_resp_ofac")
    cb_resp_payload, reports = deal_data.append_report_data_to_payload(
        cb_payload, deal_data.cb_report, "applicant"
    )

    deal_data.update_payload_with_bureau_key_data(cb_event_payload, cb_resp_payload)
    add_header = {"X-Lead-Reference-Number": deal_data.generate_random_id()}
    status_code, ofac_resp, resp_headers = deal_data.post_request(
        api_url, "cb_response", cb_post=True, cust_header=add_header
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {pull_resp}"
        )

    assert pull_resp.get("dealRefId") == ofac_resp.get("dealRefId")
    assert pull_resp.get("creditBureauRefId") == ofac_resp.get("creditBureauRefId")

    wait_with_no_retries()
    records, count = get_records_by_deal_ref_id(pull_resp.get("dealRefId"))
    # assert count == 10
    assert deal_data.cbRefId == equ_resp.get("creditBureauRefId")
    common_assert(records=records, resp_headers=resp_headers)

    # Verify OFAC report's data
    verify_credit_bureau_reports(
        deal_data.cb_report,
        records,
        "applicant",
        pull_resp.get("creditBureauRefId"),
        "response",
    )

    # posting redflag response
    deal_data.set_report_data("cb_resp_redflag")
    cb_resp_payload, report = deal_data.append_report_data_to_payload(
        cb_payload, deal_data.cb_report, "applicant"
    )

    deal_data.update_payload_with_bureau_key_data(cb_event_payload, cb_resp_payload)
    add_header = {"X-Lead-Reference-Number": deal_data.generate_random_id()}
    status_code, redflag_resp, resp_headers = deal_data.post_request(
        api_url, "cb_response", cb_post=True, cust_header=add_header
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {pull_resp}"
        )

    assert pull_resp.get("dealRefId") == redflag_resp.get("dealRefId")
    assert pull_resp.get("creditBureauRefId") == redflag_resp.get("creditBureauRefId")

    wait_with_no_retries()
    records, count = get_records_by_deal_ref_id(pull_resp.get("dealRefId"))
    # assert count == 11
    assert deal_data.cbRefId == redflag_resp.get("creditBureauRefId")
    common_assert(records=records, resp_headers=resp_headers)

    # Verify OFAC report's data
    verify_credit_bureau_reports(
        deal_data.cb_report,
        records,
        "applicant",
        pull_resp.get("creditBureauRefId"),
        "response",
    )

    deal_resp = get_response_data(records, "DEAL")
    assert "dealRefIdFD" not in deal_resp


@pytest.mark.functional
def test_credit_bureau_response_for_coapplicant_softpull_ofac(
    env,
    api_url,
    common_assert,
    cb_event_payload,
    random_data_class,
    get_response_data,
    wait_with_no_retries,
    get_records_by_deal_ref_id,
    verify_credit_bureau_reports,
):
    json_file_name = "coapp_cb_softpull_equ_exp_tru_redflag_ofac.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_bureau/{json_file_name}",
    )
    status_code, pull_resp, resp_headers = deal_data.post_request(
        api_url, "credit_bureau", cb_post=True
    )
    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {pull_resp}"
        )

    records, count = get_records_by_deal_ref_id(pull_resp.get("dealRefId"))

    # assert count == 10
    assert deal_data.cbRefId == pull_resp.get("creditBureauRefId")
    common_assert(records=records, resp_headers=resp_headers)

    # Saving post payload
    cb_payload = deal_data.payload

    # posting ofac response
    deal_data.set_report_data("cb_resp_softpull")
    cb_resp_payload, report = deal_data.append_report_data_to_payload(
        cb_payload, deal_data.cb_report, "coApplicant"
    )

    deal_data.update_payload_with_bureau_key_data(cb_event_payload, cb_resp_payload)
    # Update dealRefIdFD in payload
    deal_data.payload = json.loads(deal_data.payload)
    deal_data.payload["dealRefIdFD"] = deal_data.generate_random_id(True)
    status_code, equ_resp, resp_headers = deal_data.post_request(
        api_url, "cb_response", cb_post=True
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {pull_resp}"
        )

    assert pull_resp.get("dealRefId") == equ_resp.get("dealRefId")
    assert pull_resp.get("creditBureauRefId") == equ_resp.get("creditBureauRefId")

    records, count = get_records_by_deal_ref_id(pull_resp.get("dealRefId"))
    # assert count == 11
    assert deal_data.cbRefId == equ_resp.get("creditBureauRefId")
    common_assert(records=records, resp_headers=resp_headers)

    # Verify SoftPull report's data
    verify_credit_bureau_reports(
        deal_data.cb_report,
        records,
        "coApplicant",
        pull_resp.get("creditBureauRefId"),
        "response",
    )

    # posting ofac response
    deal_data.set_report_data("cb_resp_ofac")
    cb_resp_payload, report = deal_data.append_report_data_to_payload(
        cb_payload, deal_data.cb_report, "coApplicant"
    )

    deal_data.update_payload_with_bureau_key_data(cb_event_payload, cb_resp_payload)
    # Update dealRefIdFD in payload
    deal_data.payload = json.loads(deal_data.payload)
    deal_data.payload["dealRefIdFD"] = deal_data.generate_random_id(True)
    status_code, ofac_resp, resp_headers = deal_data.post_request(
        api_url, "cb_response", cb_post=True
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {pull_resp}"
        )

    assert pull_resp.get("dealRefId") == ofac_resp.get("dealRefId")
    assert pull_resp.get("creditBureauRefId") == ofac_resp.get("creditBureauRefId")

    wait_with_no_retries()
    records, count = get_records_by_deal_ref_id(pull_resp.get("dealRefId"))
    # assert count == 12
    assert deal_data.cbRefId == equ_resp.get("creditBureauRefId")
    common_assert(records=records, resp_headers=resp_headers)
    # Verify OFAC report's data
    verify_credit_bureau_reports(
        deal_data.cb_report,
        records,
        "coApplicant",
        pull_resp.get("creditBureauRefId"),
        "response",
    )

    deal_resp = get_response_data(records, "DEAL")
    assert "dealRefIdFD" not in deal_resp


@pytest.mark.smoke
@pytest.mark.functional
def test_credit_bureau_response_for_applicant_coapplicant(
    api_url,
    env,
    random_data_class,
    cb_event_payload,
    get_records_by_deal_ref_id,
    verify_credit_bureau_reports,
    common_assert,
):
    json_file_name = "app_coapp_cb_exp_equ_tru_redflag_ofac.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_bureau/{json_file_name}",
    )
    status_code, pull_resp, resp_headers = deal_data.post_request(
        api_url, "credit_bureau", cb_post=True
    )
    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {pull_resp}"
        )

    records, count = get_records_by_deal_ref_id(pull_resp.get("dealRefId"))

    # assert count == 17
    assert deal_data.cbRefId == pull_resp.get("creditBureauRefId")
    common_assert(records=records, resp_headers=resp_headers)

    # Saving post payload
    cb_payload = deal_data.payload

    # update report for applicant
    deal_data.set_report_data("cb_resp_experian")
    app_resp_payload, report = deal_data.append_report_data_to_payload(
        cb_payload, deal_data.cb_report, "applicant"
    )

    # app report
    app_report = deal_data.cb_report

    # update report for Co-applicant
    deal_data.set_report_data("cb_resp_redflag")
    cb_resp_payload, report = deal_data.append_report_data_to_payload(
        app_resp_payload, deal_data.cb_report, "coApplicant"
    )

    deal_data.update_payload_with_bureau_key_data(cb_event_payload, cb_resp_payload)

    status_code, equ_resp, resp_headers = deal_data.post_request(
        api_url, "cb_response", cb_post=True
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {pull_resp}"
        )

    assert pull_resp.get("dealRefId") == equ_resp.get("dealRefId")
    assert pull_resp.get("creditBureauRefId") == equ_resp.get("creditBureauRefId")

    records, count = get_records_by_deal_ref_id(pull_resp.get("dealRefId"))
    # assert count == 19
    assert deal_data.cbRefId == equ_resp.get("creditBureauRefId")
    common_assert(records=records, resp_headers=resp_headers)

    # Verify report's data
    verify_credit_bureau_reports(
        app_report, records, "applicant", pull_resp.get("creditBureauRefId"), "response"
    )
    verify_credit_bureau_reports(
        deal_data.cb_report,
        records,
        "coApplicant",
        pull_resp.get("creditBureauRefId"),
        "response",
    )


@pytest.mark.smoke
@pytest.mark.functional
def test_credit_bureau_response_multiple_responses_at_once(
    env,
    api_url,
    common_assert,
    cb_event_payload,
    random_data_class,
    get_records_by_deal_ref_id,
    verify_credit_bureau_reports,
):
    json_file_name = "app_coapp_cb_exp_equ_tru_redflag_ofac.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_bureau/{json_file_name}",
    )
    status_code, pull_resp, resp_headers = deal_data.post_request(
        api_url, "credit_bureau", cb_post=True
    )
    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {pull_resp}"
        )

    records, count = get_records_by_deal_ref_id(pull_resp.get("dealRefId"))

    # assert count == 17
    assert deal_data.cbRefId == pull_resp.get("creditBureauRefId")
    common_assert(records=records, resp_headers=resp_headers)

    # Saving post payload
    cb_payload = deal_data.payload

    # posting responses for Applicant and Co-Applicant
    deal_data.set_report_data("cb_resp_multiple")
    app_resp_payload, report = deal_data.append_report_data_to_payload(
        cb_payload, deal_data.cb_report, "applicant"
    )

    # app report
    app_report = deal_data.cb_report

    cb_resp_payload, report = deal_data.append_report_data_to_payload(
        app_resp_payload, deal_data.cb_report, "coApplicant"
    )

    deal_data.update_payload_with_bureau_key_data(cb_event_payload, cb_resp_payload)

    status_code, equ_resp, resp_headers = deal_data.post_request(
        api_url, "cb_response", cb_post=True
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {pull_resp}"
        )

    assert pull_resp.get("dealRefId") == equ_resp.get("dealRefId")
    assert pull_resp.get("creditBureauRefId") == equ_resp.get("creditBureauRefId")

    records, count = get_records_by_deal_ref_id(pull_resp.get("dealRefId"))
    # assert count == 27
    assert deal_data.cbRefId == equ_resp.get("creditBureauRefId")
    common_assert(records=records, resp_headers=resp_headers)

    # Verify SoftPull report's data
    verify_credit_bureau_reports(
        app_report, records, "applicant", pull_resp.get("creditBureauRefId"), "response"
    )

    # Verify OFAC report's data
    verify_credit_bureau_reports(
        deal_data.cb_report,
        records,
        "coApplicant",
        pull_resp.get("creditBureauRefId"),
        "response",
    )


@pytest.mark.functional
def test_credit_bureau_response_duplicate_responses(
    env,
    api_url,
    common_assert,
    cb_event_payload,
    random_data_class,
    get_records_by_deal_ref_id,
    verify_credit_bureau_reports,
):
    json_file_name = "app_coapp_cb_exp_equ_tru_redflag_ofac.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_bureau/{json_file_name}",
    )
    status_code, pull_resp, resp_headers = deal_data.post_request(
        api_url, "credit_bureau", cb_post=True
    )
    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {pull_resp}"
        )

    records, count = get_records_by_deal_ref_id(pull_resp.get("dealRefId"))

    # assert count == 17
    assert deal_data.cbRefId == pull_resp.get("creditBureauRefId")
    common_assert(records=records, resp_headers=resp_headers)

    # Saving post payload
    cb_payload = deal_data.payload

    # posting responses for Applicant and Co-Applicant
    deal_data.set_report_data("reports_dup_providers")
    app_resp_payload, report = deal_data.append_report_data_to_payload(
        cb_payload, deal_data.cb_report, "applicant"
    )

    # app report
    app_report = deal_data.cb_report

    cb_resp_payload, report = deal_data.append_report_data_to_payload(
        app_resp_payload, deal_data.cb_report, "coApplicant"
    )

    deal_data.update_payload_with_bureau_key_data(cb_event_payload, cb_resp_payload)

    status_code, equ_resp, resp_headers = deal_data.post_request(
        api_url, "cb_response", cb_post=True
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {pull_resp}"
        )

    assert pull_resp.get("dealRefId") == equ_resp.get("dealRefId")
    assert pull_resp.get("creditBureauRefId") == equ_resp.get("creditBureauRefId")

    records, count = get_records_by_deal_ref_id(pull_resp.get("dealRefId"))
    # assert count == 23
    assert deal_data.cbRefId == equ_resp.get("creditBureauRefId")

    # Verify SoftPull report's data
    verify_credit_bureau_reports(
        app_report, records, "applicant", pull_resp.get("creditBureauRefId"), "response"
    )

    # Verify OFAC report's data
    verify_credit_bureau_reports(
        deal_data.cb_report,
        records,
        "coApplicant",
        pull_resp.get("creditBureauRefId"),
        "response",
    )


@pytest.mark.functional
def test_credit_bureau_response_with_additional_customer_and_report_than_pull(
    env,
    api_url,
    common_assert,
    cb_event_payload,
    get_response_data,
    random_data_class,
    get_records_by_deal_ref_id,
    verify_credit_bureau_reports,
):
    json_file_name = "app_cb_equ_exp_tru.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_bureau/{json_file_name}",
    )
    status_code, pull_resp, resp_headers = deal_data.post_request(
        api_url, "credit_bureau", cb_post=True
    )
    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {pull_resp}"
        )

    records, count = get_records_by_deal_ref_id(pull_resp.get("dealRefId"))

    # assert count == 8
    common_assert(records=records, resp_headers=resp_headers)

    # update payload with coapp
    json_file_name = "app_coapp_cb_exp.json"
    deal_data.set_payload(f"credit_bureau/{json_file_name}")

    # joint payload
    joint_payload = deal_data.payload

    # posting responses for Applicant and Co-Applicant
    deal_data.set_report_data("cb_resp_equifax")

    app_resp_payload, report = deal_data.append_report_data_to_payload(
        joint_payload, deal_data.cb_report, "applicant"
    )
    # app report
    app_report = deal_data.cb_report

    coapp_resp_payload, report = deal_data.append_report_data_to_payload(
        app_resp_payload, deal_data.cb_report, "coApplicant"
    )

    deal_data.update_payload_with_bureau_key_data(cb_event_payload, coapp_resp_payload)

    status_code, cb_resp, resp_headers = deal_data.post_request(
        api_url, "cb_response", cb_post=True
    )

    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {pull_resp}"
        )

    assert pull_resp.get("dealRefId") == cb_resp.get("dealRefId")
    assert pull_resp.get("creditBureauRefId") == cb_resp.get("creditBureauRefId")

    records, count = get_records_by_deal_ref_id(pull_resp.get("dealRefId"))

    # assert count == 10
    assert deal_data.cbRefId == cb_resp.get("creditBureauRefId")
    common_assert(records=records, resp_headers=resp_headers)

    # Verify applicant report's data
    verify_credit_bureau_reports(
        app_report, records, "applicant", pull_resp.get("creditBureauRefId"), "response"
    )

    # Verify co-applicant report's data
    verify_credit_bureau_reports(
        deal_data.cb_report,
        records,
        "coApplicant",
        pull_resp.get("creditBureauRefId"),
        "response",
    )

    # Verify co-applicant data from response is not saved in database
    assert get_response_data(records, "COAPPLICANT") is None

    # Key data GET after a credit bureau response
    # Search query for key data - dealRefId
    query_param = f"dealRefId={pull_resp.get('dealRefId')}"

    status_code, get_resp, resp_headers = deal_data.get_request(
        url=api_url, route_url="key_data_get", query_param=query_param
    )
    assert status_code == HTTPStatus.OK


@pytest.mark.smoke
@pytest.mark.functional
def test_credit_bureau_response_invalid_cb_ref_id(
    env,
    api_url,
    cb_event_payload,
    random_data_class,
    get_records_by_deal_ref_id,
):
    json_file_name = "app_coapp_cb_exp_equ_tru_redflag_ofac.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_bureau/{json_file_name}",
    )
    status_code, pull_resp, resp_headers = deal_data.post_request(
        api_url, "credit_bureau", cb_post=True
    )
    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {pull_resp}"
        )

    records, count = get_records_by_deal_ref_id(pull_resp.get("dealRefId"))

    # assert count == 17
    assert deal_data.cbRefId == pull_resp.get("creditBureauRefId")
    assert resp_headers.get("X-CoxAuto-Correlation-Id") is not None

    # Saving post payload
    cb_payload = deal_data.payload

    # posting responses for Applicant and Co-Applicant
    deal_data.set_report_data("reports_dup_providers")
    app_resp_payload, reports = deal_data.append_report_data_to_payload(
        cb_payload, deal_data.cb_report, "applicant"
    )

    cb_resp_payload, reports = deal_data.append_report_data_to_payload(
        app_resp_payload, deal_data.cb_report, "coApplicant"
    )

    deal_data.update_payload_with_bureau_key_data(cb_event_payload, cb_resp_payload)

    # invalid cbRefId
    payload = json.loads(deal_data.payload)
    payload["eventTransactionId"] = deal_data.generate_random_id()
    deal_data.payload = json.dumps(payload)

    status_code, resp_body, resp_headers = deal_data.post_request(
        api_url, "cb_response", cb_post=True
    )

    assert status_code == HTTPStatus.BAD_REQUEST
    assert (
        resp_body.get("message")
        == "You have tired to post to an endpoint for which the resource doesn't exists."
    )


@pytest.mark.functional
def test_credit_bureau_response_invalid_payload(
    api_url, env, random_data_class, invalid_payload
):
    json_file_name = "app_coapp_cb_exp_equ_tru_redflag_ofac.json"

    deal_data = ServiceAPI(
        random_data_class=random_data_class,
        env=env,
        json_file=f"credit_bureau/{json_file_name}",
    )
    status_code, pull_resp, resp_headers = deal_data.post_request(
        api_url, "credit_bureau", cb_post=True
    )
    if status_code != HTTPStatus.CREATED:
        raise Exception(
            f"Response code is: {status_code} and the response message is: {pull_resp}"
        )

    deal_data = ServiceAPI(
        env=env, random_data_class=random_data_class, payload=invalid_payload
    )

    status_code, response, resp_headers = deal_data.post_request(
        api_url,
        "cb_response",
    )

    assert status_code == HTTPStatus.BAD_REQUEST
