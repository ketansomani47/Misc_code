# -*- coding: utf-8 -*-
import copy
from decimal import Decimal

import pytest
from boto3.dynamodb.conditions import Key
from common import healthchecks
from common.settings import PayloadType as pt


@pytest.fixture(autouse=True)
def patch_registry(monkeypatch):
    class MockHealthCheckRegistry:
        QUEUE_LIST = [
            healthchecks.Env.DEAL_DATA_QUEUE,
            healthchecks.Env.DEAL_DATA_DLQ,
        ]
        API_LIST = [
            {"route": "deals/HCdealRefId/credit-apps", "method": "post"},
        ]
        DB_LIST = [healthchecks.DealDataParameters().db_name]
        LAMBDA_LIST = []
        S3_LIST = [healthchecks.Env.SNAPSHOT_BUCKET]
        APIG_RESOURCES = ()

        @property
        def db_list(self):
            return ["deals"]

    monkeypatch.setattr(healthchecks, "HealthCheckRegistry", MockHealthCheckRegistry)


@pytest.fixture()
def query_item(deals_table):
    def wrapper(deal_ref_id):
        records = deals_table.query(
            KeyConditionExpression=Key("dealRefId").eq(deal_ref_id)
        )
        return records.get("Items", [])

    return wrapper


@pytest.fixture()
def payload_type():
    return pt.CREDIT_APP_POST


@pytest.fixture()
def multiple_target_platform_app(credit_app_full_payload):
    credit_app_full_payload["targetPlatforms"] = [
        {"id": "DTC", "partyId": "123987"},
        {"id": "R1J", "partyId": "123987"},
    ]
    return credit_app_full_payload


@pytest.fixture()
def non_registered_target_platform_app(credit_app_full_payload):
    credit_app_full_payload["targetPlatforms"] = [
        {"id": "DLT", "partyId": "123987"},
        {"id": "RT2", "partyId": "123987"},
    ]
    return credit_app_full_payload


@pytest.fixture()
def registered_target_platform_app(credit_app_full_payload):
    credit_app_full_payload["targetPlatforms"] = [{"id": "DTC", "partyId": "123987"}]
    return credit_app_full_payload


@pytest.fixture()
def target_platform_with_test_app(credit_app_full_payload):
    credit_app_full_payload["targetPlatforms"] = [
        {"id": "DLT_TEST", "partyId": "123987"},
        {"id": "RT2", "partyId": "123987"},
    ]
    return credit_app_full_payload


@pytest.fixture()
def mock_send_payload_to_queue_raise_exception(monkeypatch, mock_dr_utils):
    def send_payload_raise_exceptiom(*args, **kwargs):
        if kwargs["queue"] not in ["DealDataDLQ", "DealDataStatusQueue"]:
            raise Exception("Test Routing Exception")

    mock_dr_utils.send_payload_to_queue = send_payload_raise_exceptiom


@pytest.fixture()
def expected_health_check_payload_operational():
    return {
        "service": "dr_deal_data_api",
        "region": healthchecks.Env.AWS_REGION,
        "version": healthchecks.Env.VERSION,
        "service_status": "Operational",
        "healthchecks": {
            healthchecks.Env.DEAL_DATA_QUEUE: "Operational",
            healthchecks.Env.DEAL_DATA_DLQ: "Operational",
            healthchecks.DealDataParameters().db_name: "Operational",
            "deals/HCdealRefId/credit-apps method-post": "Operational",
            healthchecks.Env.SNAPSHOT_BUCKET: "Operational",
        },
    }


@pytest.fixture()
def expected_health_check_payload_down():
    return {
        "service": "dr_deal_data_api",
        "region": healthchecks.Env.AWS_REGION,
        "version": healthchecks.Env.VERSION,
        "service_status": "Down",
        "healthchecks": {
            healthchecks.Env.DEAL_DATA_QUEUE: "Down",
            healthchecks.Env.DEAL_DATA_DLQ: "Down",
            healthchecks.DealDataParameters().db_name: "Down",
            "deals/HCdealRefId/credit-apps method-post": "Down",
            healthchecks.Env.SNAPSHOT_BUCKET: "Down",
        },
    }


@pytest.fixture()
def expected_health_check_payload_for_deployment():
    return {
        "service": "dr_deal_data_api",
        "region": healthchecks.Env.AWS_REGION,
        "service_status": "Down",
        "version": "v1.0",
        "message": "Stack deployment in progress",
    }


# Shopper Quote Payload
@pytest.fixture()
def shopper_business():
    return {
        "businessName": "ABC Roofing Co.",
        "postalCode": 28429,
        "emailAddress": "hazel-testco@q.com",
        "businessPhoneNo": "209-415-2923",
    }


@pytest.fixture()
def shopper_individual():
    return {
        "firstName": "John",
        "lastName": "Doe",
        "middleInitial": "M",
        "suffix": "JR",
        "emailAddress": "hazel-testco@q.com",
        "cellPhone": "336-968-4645",
        "postalCode": 28429,
        "selfReportedCreditScore": 740,
    }


@pytest.fixture()
def financeStructure_selectedProgram():
    return {
        "lenderName": "GMF",
        "branchName": "California",
        "term": 36,
        "programType": "Enhanced",
        "programName": "ST",
        "dealType": "Lease",
        "regionalId": 5656,
        "residualProgram": "CERT",
        "rateProgram": "NoSD",
        "creditTierDescription": "Platinum",
        "creditTier": 1,
    }


@pytest.fixture()
def shopper_incentives():
    return {
        "selectedIncentiveId": 63563555,
        "sourceIncentiveId": 543453,
        "source": "VCS",
        "name": "Bonus Plus",
        "amount": 1000,
        "incentiveType": "Customer-Cash",
        "programType": "Standard",
        "programId": "G52345235",
        "moneyFactor": 0.00345,
        "category": "College Grad",
        "startDate": "2017-07-22",
        "endDate": "2017-06-24",
        "startTerm": 24,
        "endTerm": 60,
        "exclusions": [56778],
    }


@pytest.fixture()
def shopper_finance_structure(shopper_incentives):
    shopper_incentives = copy.deepcopy(shopper_incentives)
    shopper_incentives["moneyFactor"] = Decimal("0.00345")
    return {
        "dealType": "Lease",
        "term": 36,
        "cashDown": 5000,
        "sellingPrice": 34889,
        "contractDate": "2017-08-16",
        "daysToFirstPayment": 30,
        "annualMiles": 15000,
        "incentives": [shopper_incentives],
    }


@pytest.fixture()
def shopper_tradeVehicles():
    return [
        {
            "vehicleType": "Auto",
            "certifiedUsed": True,
            "vin": "WAUCFAFH2DN018228",
            "chromeYear": 2017,
            "chromeMake": "Honda",
            "chromeMakeId": 21,
            "chromeModel": "Accord",
            "chromeModelId": 19405,
            "chromeStyle": '4WD Crew Cab 143.5" SLE',
            "chromeStyleId": 380391,
            "chromeOptions": [{"id": 1048, "name": "Dual Air Condioning"}],
            "otherYear": 2017,
            "otherMake": "Honda",
            "otherModel": "Pilot",
            "otherTrim": "EX",
            "otherOptions": ["Dual Air Condioning"],
            "odometerMileage": 15400,
            "msrp": 69248,
            "interiorColor": "Gray",
            "exteriorColor": "Silver",
            "transmissionType": "Manual",
            "engineType": "3.7L V6",
            "monthlyPayment": 672,
            "payoffAmount": 12050,
            "vehicleKBBCondition": "Very Good",
        }
    ]


@pytest.fixture()
def shopper_products():
    return [
        {
            "dealProductId": 45234545,
            "productCategoryCode": "VSC",
            "dealerProductId": 67474567,
            "price": 831,
            "recommendCapitalized": True,
            "providerCode": "APC",
            "providerName": "EasyCare",
            "term": 36,
            "miles": 100000,
            "deductible": 1000,
            "plan": "Power Care",
            "program": "EasyCare Silver TC/SC/PC/PW N/U/M 2015:2926",
            "coverage": "Add On",
            "serviceIntervalAndTireRotation": "4/5000",
            "providerRateLevel": '{  "Levels": {"Level": {"QuoteId": "0","LevelType": "Program","Id": "0","Code": "10003","Desc": "EasyCare Silver TC/SC/PC/PW N/U/M 2015:2926","Levels": {"Level": {"QuoteId": "0","LevelType": "Coverage","Code": "A","Desc": "Add On","Levels": {"Level": {"QuoteId": "0","LevelType": "Plan","Id": "8","Code": "PowerCare","Desc": "PowerCare","Name": "PowerCare","RateInfo": {"RateBook": "1","ContractNoPrefix": "EST1D","PDFFormNo": "A1032926","Rates": {"Rate": {"RateId": "403","RetailRate": "2500","DealerCost": "867.00","TermMileage": {"TermId": "3675","Term": "36", "Mileage":"        },"Deductible": {"DeductId": "3","DeductAmt": "100.00", "DeductType": "V","DeductCode": "0","ReducedAmount": "0" },"MaxRetailRate": "0","MinRetailRate": "0", "RegulatedRuleId": "0","VehicleClass": "0007","ExpirationDate": "2008-01-01T00:00:00-05:00","ExpirationMileage": "0","RatePlanCode": "ECO_61_VSC_POW_36_75000_A_2735595","Options": {"Option": {"OptionId": "1","OptionDesc": "Rental Upgrade","OptionName": "RNT","RetailRate": "35","NetRate": "35","IsSelected": "false","isSurcharge": "false"} }, "OverRemit": "0" } } } } } } } } } } anotherKey": "anotherValue" }',
            "options": [
                {
                    "optionCode": "TS1",
                    "optionDescription": "Tire Surcharge",
                    "optionPrice": 120,
                    "isSurcharge": True,
                    "isSelected": True,
                }
            ],
        }
    ]


@pytest.fixture()
def shopper_buyVehicle():
    return {
        "vehicleType": "Auto",
        "certifiedUsed": True,
        "vin": "WAUCFAFH2DN018228",
        "chromeYear": 2017,
        "chromeMake": "Honda",
        "chromeMakeId": 21,
        "chromeModel": "Accord",
        "chromeModelId": 19405,
        "chromeStyle": '4WD Crew Cab 143.5" SLE',
        "chromeStyleId": 380391,
        "chromeOptions": [{"id": 1048, "name": "Dual Air Condioning"}],
        "otherYear": 2017,
        "otherMake": "Honda",
        "otherModel": "Pilot",
        "otherTrim": "EX",
        "otherOptions": ["Dual Air Condioning"],
        "odometerMileage": 15400,
        "msrp": 69248,
        "interiorColor": "Gray",
        "exteriorColor": "Silver",
        "transmissionType": "Manual",
        "engineType": "3.7L V6",
        "vehicleCondition": "Used",
    }


@pytest.fixture()
def shopper_quote_payload(shopper_tradeVehicles, shopper_products, shopper_buyVehicle):
    return {
        "partnerId": "MMD",
        "partnerDealerId": 123456789,
        "buyVehicle": shopper_buyVehicle,
        "tradeVehicles": shopper_tradeVehicles,
        "products": shopper_products,
        "onlineQuote": {
            "dealType": "Lease",
            "paymentAmount": Decimal("455.61"),
            "term": 60,
            "zipCodeUsed": 2414,
            "feesCapped": True,
            "taxesCapped": True,
            "cashDown": 2000,
            "rebateAmount": 800,
            "salesTax": Decimal("877.33"),
            "fees": Decimal("124.99"),
            "netTrade": Decimal("-500"),
            "dueAtSigning": Decimal("866.92"),
            "lenderName": "Wells Fargo",
            "branchName": "WEST",
            "creditTier": "Gold",
            "apr": Decimal("6.25"),
            "moneyFactor": Decimal("0.00344"),
            "securityDeposit": Decimal("0.00344"),
            "residualDollar": 23556,
            "balloonPayment": 23556,
        },
        "comments": "Test Credit App Comment",
    }


@pytest.fixture()
def expected_shopper_quote_payload(
    shopper_quote_payload,
    shopper_business,
    shopper_individual,
    financeStructure_selectedProgram,
    shopper_finance_structure,
    dr_ulid,
    time_stamp,
    dr_ttl,
):
    shopper_quote_payload.update(
        {
            "shopper": {"customerType": "Individual"},
            "financeStructure": shopper_finance_structure,
            "shopper_business": shopper_business,
            "financeStructure_selectedProgram": financeStructure_selectedProgram,
            "shopper_individual": shopper_individual,
            "dealComponent": "DTC.SHOPPERQUOTEPAYLOAD",
            "ttl": dr_ttl,
            "createdTimestamp": time_stamp,
            "updatedTimestamp": time_stamp,
            "dealRefId": dr_ulid,
        }
    )
    return shopper_quote_payload


@pytest.fixture()
def shopper_quote_full_payload(
    shopper_finance_structure,
    financeStructure_selectedProgram,
    shopper_incentives,
    shopper_business,
    shopper_individual,
    shopper_buyVehicle,
    shopper_tradeVehicles,
    shopper_products,
):
    shopper_finance_structure = copy.deepcopy(shopper_finance_structure)
    shopper_finance_structure["selectedProgram"] = financeStructure_selectedProgram
    shopper_finance_structure["incentives"] = [shopper_incentives]
    return {
        "partnerId": "MMD",
        "partnerDealerId": 123456789,
        "shopper": {
            "customerType": "Individual",
            "business": shopper_business,
            "individual": shopper_individual,
        },
        "buyVehicle": shopper_buyVehicle,
        "tradeVehicles": shopper_tradeVehicles,
        "products": shopper_products,
        "onlineQuote": {
            "dealType": "Lease",
            "paymentAmount": 455.61,
            "term": 60,
            "zipCodeUsed": 2414,
            "feesCapped": True,
            "taxesCapped": True,
            "cashDown": 2000,
            "rebateAmount": 800,
            "salesTax": 877.33,
            "fees": 124.99,
            "netTrade": -500,
            "dueAtSigning": 866.92,
            "lenderName": "Wells Fargo",
            "branchName": "WEST",
            "creditTier": "Gold",
            "apr": 6.25,
            "moneyFactor": 0.00344,
            "securityDeposit": 0.00344,
            "residualDollar": 23556,
            "balloonPayment": 23556,
        },
        "financeStructure": shopper_finance_structure,
        "comments": "Test Credit App Comment",
    }


@pytest.fixture()
def lead_shopper_quote_payload(credit_app_full_payload, shopper_quote_full_payload):
    credit_app_full_payload["shopperQuotePayload"] = shopper_quote_full_payload
    return credit_app_full_payload


@pytest.fixture()
def lead_partial_payload_with_shopper_quote(
    credit_app_partial_payload, shopper_quote_full_payload
):
    credit_app_partial_payload["shopperQuotePayload"] = shopper_quote_full_payload
    return credit_app_partial_payload
