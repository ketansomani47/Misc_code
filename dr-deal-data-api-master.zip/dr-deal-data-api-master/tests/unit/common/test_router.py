# -*- coding: utf-8 -*-
import json

import pytest
from common import router


class TestRoute:
    def test_multiple_target_platforms(
        self, sqs, patch_env, multiple_target_platform_app, payload_type
    ):
        resp = router.route(
            body=json.dumps(multiple_target_platform_app),
            correlation_id="",
            payload_type=payload_type,
            deal_ref_id=multiple_target_platform_app.get("dealRefId"),
        )
        assert resp is True

    def test_no_queue_found(
        self, sqs, target_platform_with_test_app, payload_type, mock_dr_utils
    ):

        with pytest.raises(mock_dr_utils.exceptions.NoQueueFound):
            router.route(
                body=json.dumps(target_platform_with_test_app),
                correlation_id="",
                payload_type=payload_type,
                deal_ref_id=target_platform_with_test_app.get("dealRefId"),
            )
