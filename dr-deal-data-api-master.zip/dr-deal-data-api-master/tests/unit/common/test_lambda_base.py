# -*- coding: utf-8 -*-
import pytest
from common import lambda_base


def test_get_handler_not_implmented():
    lb = lambda_base.LambdaBase()
    handler = lb.get_handler()

    with pytest.raises(NotImplementedError):
        handler(None, None)


def test_is_handler_decorator(lambda_context):
    class Klass(lambda_base.LambdaBase):
        pass

        @lambda_base.LambdaBase.is_handler
        def handle(self, event, context):
            return True

    obj = Klass()
    logger = obj.init_logger(context=lambda_context)

    assert logger._context.get("functionArn") == lambda_context.invoked_function_arn
