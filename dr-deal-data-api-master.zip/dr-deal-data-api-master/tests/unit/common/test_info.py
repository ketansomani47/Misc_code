# -*- coding: utf-8 -*-
import json
from http import HTTPStatus

from common import info


def test_info_api(expected_info_response):
    resp = info.get({}, {})
    assert resp["statusCode"] == HTTPStatus.OK
    assert resp["body"] == json.dumps(expected_info_response)
