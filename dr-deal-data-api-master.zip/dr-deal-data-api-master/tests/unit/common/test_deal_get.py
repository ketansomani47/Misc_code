# -*- coding: utf-8 -*-
import json
from http import HTTPStatus

from common import deal, deal_consumer
from common.settings import (
    HEALTHCHECK_HEADER_FIELD,
    HEALTHCHECK_HEADER_VALUE,
    ErrorMsgs,
    PayloadType as pt,
)
from utils.db_helper import DynamoDbHelper


def test_full_deal_get_payload(
    lambda_context,
    dynamodb,
    credit_app_full_payload,
    get_sqs_event,
    monkeypatch,
    db_query_items,
):
    deal_ref_id = credit_app_full_payload.get("dealRefId")
    credit_app_full_payload["applicant"]["aws:updatedTime"] = "aws_key"

    event = get_sqs_event(credit_app_full_payload, pt.CREDIT_APP_POST)
    monkeypatch.setattr(DynamoDbHelper, "query_items", db_query_items)

    # First create a deal
    response = deal_consumer.handler(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.CREATED

    # Next we retrieve the deal
    event = get_sqs_event(credit_app_full_payload, pt.CREDIT_APP_POST)
    event["path"] = "/v1/deals/dealRefId/"
    event.pop("Records")
    event["pathParameters"] = {"dealRefId": deal_ref_id}
    event["queryStringParameters"] = {"protected": "true"}

    response = deal.deal_get(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.OK
    body = json.loads(response["body"])

    # check for basic get data
    assert body["targetPlatforms"] == credit_app_full_payload["targetPlatforms"]
    assert body["financeMethod"] == credit_app_full_payload["financeMethod"]

    # check basic applicant get data
    assert (
        body["applicant"]["firstName"]
        == credit_app_full_payload["applicant"]["firstName"]
    )
    assert (
        body["applicant"]["lastName"]
        == credit_app_full_payload["applicant"]["lastName"]
    )
    assert (
        body["applicant"]["address"] == credit_app_full_payload["applicant"]["address"]
    )

    assert body["applicant"]["ssn"] == "788999009"

    # check basic co-applicant get data
    assert (
        body["coApplicant"]["firstName"]
        == credit_app_full_payload["coApplicant"]["firstName"]
    )
    assert (
        body["coApplicant"]["lastName"]
        == credit_app_full_payload["coApplicant"]["lastName"]
    )

    # check for financeSummary get data

    assert (
        body["financeSummary"].items()
        <= credit_app_full_payload["financeSummary"].items()
    )

    # check for tradeIns get data
    assert body["tradeIns"] == credit_app_full_payload["tradeIns"]

    # check for vehicle get data
    assert body["vehicle"] == credit_app_full_payload["vehicle"]


def test_full_deal_get_with_leads_shopper_quote_payload(
    lambda_context,
    dynamodb,
    lead_shopper_quote_payload,
    shopper_quote_full_payload,
    get_sqs_event,
    monkeypatch,
    db_query_items,
):
    deal_ref_id = lead_shopper_quote_payload.get("dealRefId")
    lead_shopper_quote_payload["applicant"]["aws:updatedTime"] = "aws_key"

    event = get_sqs_event(lead_shopper_quote_payload, pt.LEAD_POST)
    monkeypatch.setattr(DynamoDbHelper, "query_items", db_query_items)

    # First create a LEAD
    response = deal_consumer.handler(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.CREATED

    # Next we retrieve the lead
    event = get_sqs_event(lead_shopper_quote_payload, pt.LEAD_POST)
    event["path"] = "/v1/deals/dealRefId/"
    event.pop("Records")
    event["pathParameters"] = {"dealRefId": deal_ref_id}
    event["queryStringParameters"] = {"protected": "true"}

    response = deal.deal_get(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.OK
    body = json.loads(response["body"])
    assert "shopperQuotePayload" in body
    assert body["shopperQuotePayload"] == shopper_quote_full_payload


def test_full_deal_get_with_cb_pull_payload(
    dynamodb,
    monkeypatch,
    db_query_items,
    credit_bureau_full_payload,
    get_sqs_event_credit_bureau,
    lambda_context,
):
    cb_body = credit_bureau_full_payload.get("body")
    deal_ref_id = cb_body.get("dealRefId")
    event = get_sqs_event_credit_bureau(cb_body, pt.CREDIT_BUREAU_PULL)
    monkeypatch.setattr(DynamoDbHelper, "query_items", db_query_items)

    response = deal_consumer.handler(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.CREATED

    event["path"] = "/v1/deals/dealRefId/"
    event.pop("Records")
    event["pathParameters"] = {"dealRefId": deal_ref_id}
    event["queryStringParameters"] = {"protected": "true"}

    response = deal.deal_get(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.OK
    body = json.loads(response["body"])

    # check applicant report get data
    assert sorted(
        body["applicant"]["reports"], key=lambda i: (i["provider"], i["type"])
    ) == sorted(
        cb_body["applicant"]["reports"], key=lambda i: (i["provider"], i["type"])
    )


def test_full_deal_get_with_cb_response_payload(
    dynamodb,
    monkeypatch,
    db_query_items,
    cb_applicant_response,
    credit_bureau_full_payload,
    get_sqs_event_credit_bureau,
    lambda_context,
):
    cb_body = credit_bureau_full_payload.get("body")
    event = get_sqs_event_credit_bureau(cb_body, pt.CREDIT_BUREAU_PULL)
    monkeypatch.setattr(DynamoDbHelper, "query_items", db_query_items)

    response = deal_consumer.handler(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.CREATED

    cb_response_body = credit_bureau_full_payload.get("body")
    cb_response_body["applicant"] = cb_applicant_response
    deal_ref_id = cb_response_body.get("dealRefId")
    event = get_sqs_event_credit_bureau(cb_response_body, pt.CREDIT_BUREAU_RESPONSE)

    response = deal_consumer.handler(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.CREATED

    event["path"] = "/v1/deals/dealRefId/"
    event.pop("Records")
    event["pathParameters"] = {"dealRefId": deal_ref_id}
    event["queryStringParameters"] = {"protected": "true"}

    response = deal.deal_get(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.OK
    body = json.loads(response["body"])

    # check applicant report get data
    assert sorted(
        body["applicant"]["reports"], key=lambda i: (i["provider"], i["type"])
    ) == sorted(
        cb_body["applicant"]["reports"], key=lambda i: (i["provider"], i["type"])
    )


def test_full_deal_get_payload_with_additional_data_in_db_not_in_schema(
    lambda_context,
    dynamodb,
    credit_app_full_payload,
    get_sqs_event,
    monkeypatch,
    db_query_items,
):
    deal_ref_id = credit_app_full_payload.get("dealRefId")
    credit_app_full_payload["applicant"]["aws:updatedTime"] = "aws_key"
    credit_app_full_payload["applicant"]["address"]["randomNode"] = {"test": "test"}
    credit_app_full_payload["vehicle"]["curdWeight"] = {
        "unitOfMeasure": "pounds",
        "value": "10",
    }

    event = get_sqs_event(credit_app_full_payload, pt.CREDIT_APP_POST)
    monkeypatch.setattr(DynamoDbHelper, "query_items", db_query_items)

    # First create a deal
    response = deal_consumer.handler(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.CREATED

    # Next we retrieve the deal
    event = get_sqs_event(credit_app_full_payload, pt.CREDIT_APP_POST)
    event["path"] = "/v1/deals/dealRefId/"
    event.pop("Records")
    event["pathParameters"] = {"dealRefId": deal_ref_id}
    event["queryStringParameters"] = {"protected": "true"}

    response = deal.deal_get(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.OK
    body = json.loads(response["body"])
    assert "curdWeight" not in body["vehicle"]
    assert "randomNode" not in body["applicant"]["address"]


def test_full_deal_get_no_deal_ref_id(lambda_context):
    """
    Test to verify api return 400 if required parameters are missing
    """

    event = {"path": "/v1/deals/dealRefId/"}
    response = deal.deal_get(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST

    body = json.loads(response["body"])
    assert body["message"] == ErrorMsgs.deal_ref_id_not_provided


def test_full_deal_get_no_deal_ref_id_in_db(dynamodb, lambda_context):
    """
    Test to verify if no dealRefId found in db returns 404
    """
    event = {"path": "/v1/deals/dealRefId", "pathParameters": {"dealRefId": 1234}}
    response = deal.deal_get(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST

    body = json.loads(response["body"])
    assert body["message"] == ErrorMsgs.missing_deal_from_db.format(deal_ref_id="1234")


def test_full_deal_get_version_failed(
    dynamodb,
    credit_app_full_payload,
    get_sqs_event,
    monkeypatch,
    db_query_items,
    lambda_context,
):
    """
    Test to verify api return 400 if api version doesn't match
    """
    deal_ref_id = credit_app_full_payload.get("dealRefId")
    credit_app_full_payload["applicant"]["protected"] = "bad_encryption"
    event = get_sqs_event(credit_app_full_payload, pt.CREDIT_APP_POST)
    monkeypatch.setattr(DynamoDbHelper, "query_items", db_query_items)
    response = deal_consumer.handler(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.CREATED

    event["path"] = "/v2/deals/dealRefId/"
    event.pop("Records")
    event["pathParameters"] = {"dealRefId": deal_ref_id}
    response = deal.deal_get(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST

    body = json.loads(response["body"])
    assert body["message"] == ErrorMsgs.api_version_mismatch.format(
        stored_api_version=1, request_api_version=2
    )


def test_full_deal_get_exception(
    dynamodb,
    credit_app_full_payload,
    get_api_gateway_event,
    monkeypatch,
    db_query_items,
    return_exception,
    lambda_context,
):
    """
    Test to verify api return 500 for general exceptions
    """
    deal_ref_id = credit_app_full_payload.get("dealRefId")
    event = get_api_gateway_event(credit_app_full_payload)
    monkeypatch.setattr(DynamoDbHelper, "query_items", db_query_items)
    monkeypatch.setattr(deal, "ExistingDealValidator", return_exception)

    event["pathParameters"] = {"dealRefId": deal_ref_id}
    event["queryStringParameters"] = {"protected": "true"}

    response = deal.deal_get(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.INTERNAL_SERVER_ERROR


def test_get_health_check(lambda_context):
    event = {
        "headers": {HEALTHCHECK_HEADER_FIELD: HEALTHCHECK_HEADER_VALUE},
        "path": "/v1/deals/dealRefId/",
    }

    response = deal.deal_get(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps("Operational")


def test_transform_back_lender_list_payload(
    partial_db_record_lender, transformed_lender_list_payload, lender_list_payload
):
    """
    Test transformation-back-to-original for lenderList to keep original flow.
    """
    lender_list_data = deal.transform_back_lender_list_payload(
        partial_db_record_lender, transformed_lender_list_payload
    )

    assert lender_list_data["lenderList"] == lender_list_payload["lenderList"]
