# -*- coding: utf-8 -*-
import pytest
from common.validators import ExistingDealValidator
from utils.exceptions import BadRequestError


class TestValidators:
    def test_validate_body_with_invalid_payload(self):
        invalid_body_types = ["", None, {}, "5"]
        deal_ref_id = "12345667880_TEST"

        for i in invalid_body_types:
            print(f"invalid body: {i}")
            event = {"body": i}
            validator = ExistingDealValidator(event, deal_ref_id)
            with pytest.raises(BadRequestError):
                validator.validate_body()
