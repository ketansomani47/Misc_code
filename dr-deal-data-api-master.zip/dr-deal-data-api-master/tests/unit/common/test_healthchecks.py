# -*- coding: utf-8 -*-
import json
from http import HTTPStatus

import requests
from common import healthchecks


class TestHealthChecks:
    def test_database_health_check_expected_value(
        self, dynamodb, expected_healthcheck_record
    ):
        deals_table = dynamodb.Table(healthchecks.DealDataParameters().db_name)
        deals_table.put_item(Item=expected_healthcheck_record)
        resp = healthchecks.HealthCheck(
            healthchecks.Env.URL, healthchecks.Env.KEY, healthchecks.Env.API_NAME
        ).check_database(healthchecks.DealDataParameters().db_name)
        assert resp is True

    def test_database_health_check_unexpected_value(
        self, dynamodb, unexpected_healthcheck_record
    ):
        deals_table = dynamodb.Table(healthchecks.DealDataParameters().db_name)
        deals_table.put_item(Item=unexpected_healthcheck_record)
        resp = healthchecks.HealthCheck(
            healthchecks.Env.URL, healthchecks.Env.KEY, healthchecks.Env.API_NAME
        ).check_database(healthchecks.DealDataParameters().db_name)
        assert resp is False

    def test_check_queues(self, sqs):
        queues = [
            healthchecks.Env.DEAL_DATA_DLQ,
            healthchecks.Env.DEAL_DATA_QUEUE,
        ]

        for queue in queues:
            res = healthchecks.HealthCheck(
                healthchecks.Env.URL, healthchecks.Env.KEY, healthchecks.Env.API_NAME
            ).check_queue(queue)
            assert res is True

    def test_check_api_success(self, monkeypatch, mock_post):
        monkeypatch.setattr(requests, "post", mock_post(HTTPStatus.CREATED))
        api_list = [{"route": "deals/HCdealRefId/credit-apps", "method": "post"}]

        for endpoint in api_list:
            res = healthchecks.HealthCheck(
                healthchecks.Env.URL, healthchecks.Env.KEY, healthchecks.Env.API_NAME
            ).check_api(endpoint)
            assert res is True

    def test_check_api_fail(self, monkeypatch, mock_post):
        monkeypatch.setattr(requests, "post", mock_post(HTTPStatus.NOT_FOUND))
        api_list = [
            {"route": "deals/HCdealRefId/credit-apps", "method": "post"},
        ]

        for endpoint in api_list:
            res = healthchecks.HealthCheck(
                healthchecks.Env.URL, healthchecks.Env.KEY, healthchecks.Env.API_NAME
            ).check_api(endpoint)
            assert res is False

    def test_check_apig_success(self, monkeypatch, boto3_apig_client, mock_post):
        monkeypatch.setattr(healthchecks.boto3, "client", boto3_apig_client)
        monkeypatch.setattr(requests, "post", mock_post(HTTPStatus.CREATED))
        apig_resources = ("/",)

        for endpoint in apig_resources:
            res = healthchecks.HealthCheck(
                healthchecks.Env.URL, healthchecks.Env.KEY, healthchecks.Env.API_NAME
            ).check_apig_resource(endpoint)
            assert res is True

    def test_check_apig_fail(self, monkeypatch, mock_post):
        monkeypatch.setattr(requests, "post", mock_post(HTTPStatus.NOT_FOUND))
        apig_resources = ("/",)
        for endpoint in apig_resources:
            res = healthchecks.HealthCheck(
                healthchecks.Env.URL, healthchecks.Env.KEY, healthchecks.Env.API_NAME
            ).check_apig_resource(endpoint)
            assert res is False

    def test_check_queues_not_found(self, sqs):
        queues = ["nonexistent-queue"]

        for queue in queues:
            res = healthchecks.HealthCheck(
                healthchecks.Env.URL, healthchecks.Env.KEY, healthchecks.Env.API_NAME
            ).check_queue(queue)
            assert res is False

    def test_check_status(
        self,
        sqs,
        dynamodb,
        expected_health_check_payload_operational,
        expected_healthcheck_record,
        monkeypatch,
        mock_post,
        lambda_context,
        get_api_gateway_event,
        boto3_s3_client,
    ):
        monkeypatch.setattr(requests, "post", mock_post(HTTPStatus.CREATED))

        deals_table = dynamodb.Table(healthchecks.DealDataParameters().db_name)
        deals_table.put_item(Item=expected_healthcheck_record)
        res = healthchecks.check_status(get_api_gateway_event(body={}), lambda_context)

        json_res = json.loads(res["body"])

        assert json_res == expected_health_check_payload_operational

    def test_check_status_failure(
        self, expected_health_check_payload_down, lambda_context, get_api_gateway_event
    ):
        res = healthchecks.check_status(get_api_gateway_event(body={}), lambda_context)

        json_res = json.loads(res["body"])
        assert json_res == expected_health_check_payload_down

    def test_check_status_for_deployment(
        self,
        monkeypatch,
        expected_health_check_payload_for_deployment,
        lambda_context,
        get_api_gateway_event,
    ):
        monkeypatch.setattr(healthchecks.Env, "DEPLOY_STATUS", lambda x: "Deploying")
        res = healthchecks.check_status(get_api_gateway_event(body={}), lambda_context)

        json_res = json.loads(res["body"])
        assert json_res == expected_health_check_payload_for_deployment

    def test_check_lambda(self, monkeypatch, boto3_client):
        monkeypatch.setattr(healthchecks.boto3, "client", boto3_client)
        response = healthchecks.HealthCheck(
            healthchecks.Env.URL, healthchecks.Env.KEY, healthchecks.Env.API_NAME
        ).check_lambda("NoEventSourceLambda")
        assert response is False

        response = healthchecks.HealthCheck(
            healthchecks.Env.URL, healthchecks.Env.KEY, healthchecks.Env.API_NAME
        ).check_lambda("StateDisabledLambda")
        assert response is False

        response = healthchecks.HealthCheck(
            healthchecks.Env.URL, healthchecks.Env.KEY, healthchecks.Env.API_NAME
        ).check_lambda("TestLambda")
        assert response

    def test_check_s3(self, monkeypatch, boto3_client):
        monkeypatch.setattr(healthchecks.boto3, "client", boto3_client)
        response = healthchecks.HealthCheck(
            healthchecks.Env.URL, healthchecks.Env.KEY, healthchecks.Env.API_NAME
        ).check_s3("NosuchBucket")

        assert response is False
