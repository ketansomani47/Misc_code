# -*- coding: utf-8 -*-
import json
from http import HTTPStatus

import pytest
import schemas
from boto3.dynamodb.conditions import Key
from common import deal_consumer, router
from common.settings import PayloadType as pt
from dynamodb_json import json_util
from moto import mock_aws
from utils.db_helper import DynamoDbHelper


class TestCreditAppPost:
    def test_credit_app_post_full_payload(
        self,
        lambda_context,
        dynamodb,
        credit_app_full_payload,
        expected_applicant,
        expected_vehicle_data,
        expected_tradein_data,
        expected_finance_summary_data,
        get_sqs_event,
    ):
        """
        Test to verifies full payload with applicant, vehicle, tradeIn and finance summary is persisted
        """
        deal_ref_id = credit_app_full_payload.get("dealRefId")
        event = get_sqs_event(credit_app_full_payload, pt.CREDIT_APP_POST)

        response = deal_consumer.handler(event, lambda_context)

        assert response["statusCode"] == HTTPStatus.CREATED

        deals_table = dynamodb.Table(deal_consumer.DealDataParameters().db_name)

        key_expression = Key("dealRefId").eq(deal_ref_id)
        query_results = deals_table.query(KeyConditionExpression=key_expression).get(
            "Items", []
        )

        assert len(query_results) == 16

        key_expression = Key("dealRefId").eq(deal_ref_id) & Key("dealComponent").eq(
            "DTC.APPLICANT"
        )
        query_results = deals_table.query(KeyConditionExpression=key_expression).get(
            "Items", []
        )

        applicant_data = query_results[0]
        assert expected_applicant == applicant_data

        key_expression = Key("dealRefId").eq(deal_ref_id) & Key("dealComponent").eq(
            "DTC.VEHICLE"
        )
        query_results = deals_table.query(KeyConditionExpression=key_expression).get(
            "Items", []
        )

        vehicle_data = query_results[0]
        assert expected_vehicle_data == vehicle_data

        key_expression = Key("dealRefId").eq(deal_ref_id) & Key(
            "dealComponent"
        ).begins_with("DTC.TRADEINS")
        query_results = deals_table.query(KeyConditionExpression=key_expression).get(
            "Items", []
        )

        tradein_data = query_results[0]
        assert expected_tradein_data == tradein_data

        key_expression = Key("dealRefId").eq(deal_ref_id) & Key(
            "dealComponent"
        ).begins_with("DTC.FINANCESUMMARY")
        query_results = deals_table.query(KeyConditionExpression=key_expression).get(
            "Items", []
        )

        finance_summary_data = query_results[0]
        assert expected_finance_summary_data == finance_summary_data

    def test_credit_app_post_partial_payload(
        self,
        lambda_context,
        credit_app_partial_payload,
        expected_applicant,
        dynamodb,
        decimal_encoder,
        get_sqs_event,
    ):
        """
        To verify partial payload only with applicant is persisted
        """
        deal_ref_id = credit_app_partial_payload.get("dealRefId")
        event = get_sqs_event(credit_app_partial_payload, pt.CREDIT_APP_POST)

        response = deal_consumer.handler(event, lambda_context)

        assert response["statusCode"] == HTTPStatus.CREATED

        deals_table = dynamodb.Table(deal_consumer.DealDataParameters().db_name)
        key_expression = Key("dealRefId").eq(deal_ref_id)
        query_results = deals_table.query(KeyConditionExpression=key_expression).get(
            "Items", []
        )
        assert len(query_results) == 6

        key_expression = Key("dealRefId").eq(deal_ref_id) & Key("dealComponent").eq(
            "DTC.APPLICANT"
        )
        query_results = deals_table.query(KeyConditionExpression=key_expression).get(
            "Items", []
        )

        applicant_data = query_results[0]
        assert expected_applicant == applicant_data

        key_expression = Key("dealRefId").eq(deal_ref_id) & Key("dealComponent").eq(
            "DTC.VEHICLE"
        )

        query_results = deals_table.query(KeyConditionExpression=key_expression).get(
            "Items", []
        )
        assert len(query_results) == 0

    def test_credit_app_post_partial_payload_null_tradeins(
        self,
        lambda_context,
        credit_app_partial_payload,
        dynamodb,
        decimal_encoder,
        get_sqs_event,
    ):
        deal_ref_id = credit_app_partial_payload.get("dealRefId")
        credit_app_partial_payload["tradeIns"] = None
        event = get_sqs_event(credit_app_partial_payload, pt.CREDIT_APP_POST)
        response = deal_consumer.handler(event, lambda_context)

        assert response["statusCode"] == HTTPStatus.CREATED

        deals_table = dynamodb.Table(deal_consumer.DealDataParameters().db_name)
        key_expression = Key("dealRefId").eq(deal_ref_id)
        query_results = deals_table.query(KeyConditionExpression=key_expression).get(
            "Items", []
        )

        assert len(query_results) == 6

    def test_multiple_target_platforms_fail(
        self,
        sqs,
        multiple_target_platform_app,
        mock_send_payload_to_queue_raise_exception,
        dynamodb,
        decimal_encoder,
        get_sqs_event,
        mock_dr_utils,
        lambda_context,
    ):
        queue_url = sqs.get_queue_url(QueueName=router.Env.ROUTE_ONE_QUEUE)
        sqs.delete_queue(QueueUrl=queue_url.get("QueueUrl"))
        event = get_sqs_event(multiple_target_platform_app, pt.CREDIT_APP_POST)
        with pytest.raises(Exception) as error:
            deal_consumer.handler(event, lambda_context)
        assert "Test Routing Exception" in str(error)

    def test_non_registered_target_platform(
        self,
        sqs,
        non_registered_target_platform_app,
        dynamodb,
        decimal_encoder,
        get_sqs_event,
        lambda_context,
        mock_dr_utils,
    ):
        event = get_sqs_event(non_registered_target_platform_app, pt.CREDIT_APP_POST)
        response = deal_consumer.handler(event, lambda_context)
        assert response["statusCode"] == HTTPStatus.BAD_REQUEST
        assert (
            json.loads(response["body"])["error"]
            == f"No queue found for given targetPlatforms: {non_registered_target_platform_app['targetPlatforms']}"
        )

    def test_registered_target_platform_app(
        self,
        sqs,
        registered_target_platform_app,
        dynamodb,
        decimal_encoder,
        get_sqs_event,
        lambda_context,
        mock_dr_utils,
    ):
        event = get_sqs_event(registered_target_platform_app, pt.CREDIT_APP_POST)
        response = deal_consumer.handler(event, lambda_context)
        assert response["statusCode"] == HTTPStatus.CREATED
        assert response["body"] == "Queue message processed successfully"

    def test_credit_app_db_exception(
        self,
        lambda_context,
        credit_app_partial_payload,
        dynamodb,
        sqs,
        decimal_encoder,
        get_sqs_event,
        monkeypatch,
        boto3_resource_table_delete_item_error,
    ):
        """
        To verify partial payload only with applicant is persisted
        """
        monkeypatch.setattr(
            deal_consumer.boto3, "resource", boto3_resource_table_delete_item_error
        )

        event = get_sqs_event(credit_app_partial_payload, pt.CREDIT_APP_POST)

        with pytest.raises(Exception) as error:
            deal_consumer.handler(event, lambda_context)
        assert "dynamoDB Test Exception" in str(error)

    @mock_aws()
    def test_credit_app_post_without_deal_ref_id(
        self, credit_app_partial_payload, decimal_encoder, lambda_context
    ):
        """
        Test verifies payload without deal ref id should raise Exception
        """
        credit_app_partial_payload.pop("dealRefId")
        event = {
            "Records": [
                {"body": json.dumps(credit_app_partial_payload, cls=decimal_encoder)}
            ]
        }
        with pytest.raises(Exception) as error:
            deal_consumer.handler(event, lambda_context)
        assert "dealRefId is None or not present" in str(error)

    def test_add_deal_component(self, vehicle, applicant):
        """
        Test verifies vehicle and financesummary records should be updated with dealComponent
        """
        assert "dealComponent" not in vehicle
        assert "dealComponent" not in applicant

        deal_consumer.add_deal_component(vehicle, "vehicle", "")
        deal_consumer.add_deal_component(
            applicant, "applicant", "01DT7V02BFFYP1B0D9Y60CDPCD"
        )

        assert "dealComponent" in vehicle
        assert "dealComponent" in applicant

    def test_empty_body_raises_exception(self, lambda_context):
        """
        Test verifies without payload should raise Exception
        """
        event = {"Records": [{"body": {}}]}
        with pytest.raises(Exception) as error:
            deal_consumer.handler(event, lambda_context)
        assert "dealRefId is None or not present" in str(error)

    def test_bad_json_body_raises_json_decoder_exception(
        self, lambda_context, get_sqs_event
    ):
        """
        Test verifies with some string as payload should raise Json decoder error
        """
        event = get_sqs_event("", pt.CREDIT_APP_POST)
        event["Records"][0]["body"] = "bad json"

        with pytest.raises(Exception):
            deal_consumer.handler(event, lambda_context)

    def assert_shopper_quote_payload(
        self, deal_ref_id, deals_table, expected_shopper_quote_payload
    ):
        key_expression = Key("dealRefId").eq(deal_ref_id) & Key("dealComponent").eq(
            "DTC.SHOPPERQUOTEPAYLOAD"
        )
        query_results = deals_table.query(KeyConditionExpression=key_expression).get(
            "Items", []
        )

        result = query_results[0]
        assert expected_shopper_quote_payload == result

    def test_lead_post_with_full_payload_and_shopper_quote_payload(
        self,
        lambda_context,
        dynamodb,
        lead_shopper_quote_payload,
        expected_shopper_quote_payload,
        get_sqs_event,
    ):
        deal_ref_id = lead_shopper_quote_payload.get("dealRefId")
        event = get_sqs_event(lead_shopper_quote_payload, pt.LEAD_POST)

        response = deal_consumer.handler(event, lambda_context)

        assert response["statusCode"] == HTTPStatus.CREATED

        deals_table = dynamodb.Table(deal_consumer.DealDataParameters().db_name)

        key_expression = Key("dealRefId").eq(deal_ref_id)
        query_results = deals_table.query(KeyConditionExpression=key_expression).get(
            "Items", []
        )
        assert len(query_results) == 17
        self.assert_shopper_quote_payload(
            deal_ref_id, deals_table, expected_shopper_quote_payload
        )

    # Ref. DEP: Currently shopper quote payload partially mapped with LEADS.
    # Same reason shopperQuotePayload comes into a picture.
    def test_lead_post_with_partial_payload_and_shopper_quote_payload(
        self,
        lead_partial_payload_with_shopper_quote,
        lambda_context,
        dynamodb,
        get_sqs_event,
        expected_shopper_quote_payload,
    ):
        deal_ref_id = lead_partial_payload_with_shopper_quote.get("dealRefId")
        event = get_sqs_event(lead_partial_payload_with_shopper_quote, pt.LEAD_POST)

        response = deal_consumer.handler(event, lambda_context)

        assert response["statusCode"] == HTTPStatus.CREATED

        deals_table = dynamodb.Table(deal_consumer.DealDataParameters().db_name)
        key_expression = Key("dealRefId").eq(deal_ref_id)
        query_results = deals_table.query(KeyConditionExpression=key_expression).get(
            "Items", []
        )
        assert len(query_results) == 7
        self.assert_shopper_quote_payload(
            deal_ref_id, deals_table, expected_shopper_quote_payload
        )


class TestDealUpdate:
    def test_credit_app_update_full_payload(
        self,
        dynamodb,
        credit_app_full_payload,
        expected_updated_applicant_data,
        expected_updated_vehicle_data,
        expected_updated_finance_data,
        expected_updated_tradein_data,
        get_sqs_event,
        update_deal_data,
        boto3_client,
        monkeypatch,
        lambda_context,
        update_body_with_key_data,
    ):
        """
        Verify credit app UPDATE with full payload with applicant, vehicle, tradeIn and finance summary
        """
        # CREDIT APP CREATE
        monkeypatch.setattr(deal_consumer.boto3, "client", boto3_client)
        credit_app_full_payload["dealRefIdFD"] = ""
        event = get_sqs_event(credit_app_full_payload, pt.CREDIT_APP_POST)

        response = deal_consumer.handler(event, lambda_context)

        assert response["statusCode"] == HTTPStatus.CREATED

        # CREDIT APP UPDATE
        deal_ref_id = credit_app_full_payload.get("dealRefId")

        credit_app_full_payload = update_deal_data(credit_app_full_payload)
        credit_app_full_payload = update_body_with_key_data(credit_app_full_payload)
        update_event = get_sqs_event(credit_app_full_payload, pt.CREDIT_APP_UPDATE)
        response = deal_consumer.handler(update_event, lambda_context)

        assert response["statusCode"] == HTTPStatus.CREATED

        deals_table = dynamodb.Table(deal_consumer.DealDataParameters().db_name)
        key_expression = Key("dealRefId").eq(deal_ref_id)
        query_results = deals_table.query(KeyConditionExpression=key_expression).get(
            "Items", []
        )
        assert len(query_results) == 16

        key_expression = Key("dealRefId").eq(deal_ref_id) & Key("dealComponent").eq(
            "DTC.DEAL"
        )

        query_results = deals_table.query(KeyConditionExpression=key_expression).get(
            "Items", []
        )
        deal_data = json_util.loads(query_results[0])

        assert "dealRefIdFD" not in deal_data

        key_expression = Key("dealRefId").eq(deal_ref_id) & Key("dealComponent").eq(
            "DTC.APPLICANT"
        )

        query_results = deals_table.query(KeyConditionExpression=key_expression).get(
            "Items", []
        )
        applicant_data = json_util.loads(query_results[0])
        assert applicant_data == json_util.loads(expected_updated_applicant_data)

        key_expression = Key("dealRefId").eq(deal_ref_id) & Key("dealComponent").eq(
            "DTC.VEHICLE"
        )
        query_results = deals_table.query(KeyConditionExpression=key_expression).get(
            "Items", []
        )

        vehicle_data = query_results[0]
        assert json_util.loads(expected_updated_vehicle_data) == json_util.loads(
            vehicle_data
        )

        key_expression = Key("dealRefId").eq(deal_ref_id) & Key(
            "dealComponent"
        ).begins_with("DTC.TRADEINS")
        query_results = deals_table.query(KeyConditionExpression=key_expression).get(
            "Items", []
        )

        tradein_data = query_results[0]
        assert json_util.loads(expected_updated_tradein_data) == json_util.loads(
            tradein_data
        )

        key_expression = Key("dealRefId").eq(deal_ref_id) & Key(
            "dealComponent"
        ).begins_with("DTC.FINANCESUMMARY")
        query_results = deals_table.query(KeyConditionExpression=key_expression).get(
            "Items", []
        )

        finance_summary_data = query_results[0]
        assert json_util.loads(expected_updated_finance_data) == json_util.loads(
            finance_summary_data
        )

    def test_deal_update_for_honda(
        self,
        dynamodb,
        credit_app_full_payload,
        deal_update_payload,
        expected_updated_applicant_data,
        expected_updated_vehicle_data,
        expected_updated_finance_data,
        expected_updated_tradein_data,
        get_sqs_event,
        update_deal_data,
        boto3_client,
        monkeypatch,
        lambda_context,
        update_body_with_key_data,
    ):
        """
        Verify Deal UPDATE with  payload having applicant, vehicle, tradeIn and finance summary
        """
        # CREDIT APP CREATE
        monkeypatch.setattr(deal_consumer.boto3, "client", boto3_client)
        credit_app_full_payload["dealRefIdFD"] = ""
        credit_app_full_payload["targetPlatforms"] = [
            {"id": "IDL", "partyId": "123987"}
        ]
        event = get_sqs_event(credit_app_full_payload, pt.CREDIT_APP_POST)
        response = deal_consumer.handler(event, lambda_context)
        assert response["statusCode"] == HTTPStatus.CREATED

        # DEAL UPDATE
        deal_ref_id = credit_app_full_payload.get("dealRefId")
        deal_update_payload = update_deal_data(deal_update_payload)
        deal_update_payload = update_body_with_key_data(deal_update_payload)
        update_event = get_sqs_event(deal_update_payload, pt.DEAL_UPDATE)
        response = deal_consumer.handler(update_event, lambda_context)
        assert response["statusCode"] == HTTPStatus.CREATED

        deals_table = dynamodb.Table(deal_consumer.DealDataParameters().db_name)
        key_expression = Key("dealRefId").eq(deal_ref_id)
        query_results = deals_table.query(KeyConditionExpression=key_expression).get(
            "Items", []
        )
        assert len(query_results) == 16
        key_expression = Key("dealRefId").eq(deal_ref_id) & Key("dealComponent").eq(
            "DTC.DEAL"
        )
        query_results = deals_table.query(KeyConditionExpression=key_expression).get(
            "Items", []
        )
        deal_data = json_util.loads(query_results[0])
        assert "dealRefIdFD" not in deal_data

        key_expression = Key("dealRefId").eq(deal_ref_id) & Key("dealComponent").eq(
            "DTC.APPLICANT"
        )
        query_results = deals_table.query(KeyConditionExpression=key_expression).get(
            "Items", []
        )
        applicant_data = json_util.loads(query_results[0])
        assert applicant_data == json_util.loads(expected_updated_applicant_data)
        key_expression = Key("dealRefId").eq(deal_ref_id) & Key("dealComponent").eq(
            "DTC.VEHICLE"
        )
        query_results = deals_table.query(KeyConditionExpression=key_expression).get(
            "Items", []
        )
        vehicle_data = query_results[0]
        assert json_util.loads(expected_updated_vehicle_data) == json_util.loads(
            vehicle_data
        )
        key_expression = Key("dealRefId").eq(deal_ref_id) & Key(
            "dealComponent"
        ).begins_with("DTC.TRADEINS")
        query_results = deals_table.query(KeyConditionExpression=key_expression).get(
            "Items", []
        )

        tradein_data = query_results[0]
        assert json_util.loads(expected_updated_tradein_data) == json_util.loads(
            tradein_data
        )

        key_expression = Key("dealRefId").eq(deal_ref_id) & Key(
            "dealComponent"
        ).begins_with("DTC.FINANCESUMMARY")
        query_results = deals_table.query(KeyConditionExpression=key_expression).get(
            "Items", []
        )

        finance_summary_data = query_results[0]
        assert json_util.loads(expected_updated_finance_data) == json_util.loads(
            finance_summary_data
        )

    def test_transform_lender_list_payload(self, lender_list_payload):
        """
        Test proper lenderList fields are present
        """
        d_consumer = deal_consumer.DealConsumerLambda()
        lender_list_data = d_consumer.transform_lender_list_payload(lender_list_payload)

        expected_result = {
            "sourcePartnerId": "DTS",
            "targetPlatforms": [{"id": "DTC", "partyId": "1001000"}],
            "lenderList.BOA": {"lenderId": "BOA", "lenderName": "Bank of America"},
            "lenderList.CMB": {"lenderId": "CMB", "lenderName": "Chase Bank"},
        }

        assert expected_result == lender_list_data


def test_credit_app_patch(
    lambda_context,
    dynamodb,
    credit_app_full_payload,
    get_sqs_event,
    boto3_client,
    monkeypatch,
):
    event = get_sqs_event(credit_app_full_payload, pt.CREDIT_APP_PATCH)
    monkeypatch.setattr(deal_consumer.boto3, "client", boto3_client)

    response = deal_consumer.handler(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.CREATED


def test_credit_app_patch_no_query_items(
    lambda_context,
    dynamodb,
    credit_app_full_payload,
    get_sqs_event,
    boto3_client,
    monkeypatch,
    mock_query_items_empty,
):
    event = get_sqs_event(credit_app_full_payload, pt.CREDIT_APP_PATCH)
    monkeypatch.setattr(deal_consumer.boto3, "client", boto3_client)
    response = deal_consumer.handler(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.CREATED

    update_event = get_sqs_event(credit_app_full_payload, pt.CREDIT_APP_PATCH)
    monkeypatch.setattr(DynamoDbHelper, "query_items", mock_query_items_empty)
    with pytest.raises(Exception) as error:
        deal_consumer.handler(update_event, lambda_context)
    assert "Error retrieving  protected information from dynamoDB" in str(error)


def test_deal_consumer_handler_missing_body(
    sqs,
    non_registered_target_platform_app,
    dynamodb,
    decimal_encoder,
    get_sqs_event,
    lambda_context,
):
    event = get_sqs_event("", pt.CREDIT_APP_POST)
    event["Records"][0]["body"] = ""

    with pytest.raises(Exception) as error:
        deal_consumer.handler(event, lambda_context)
    assert "No record or body found in AWS event payload" in str(error)


def test_credit_app_patch_db_exception(
    lambda_context,
    credit_app_full_payload,
    dynamodb,
    sqs,
    decimal_encoder,
    get_sqs_event,
    monkeypatch,
    boto3_resource_table_delete_item_error,
):
    """
    To verify partial payload only with applicant is persisted
    """
    monkeypatch.setattr(
        deal_consumer.boto3, "resource", boto3_resource_table_delete_item_error
    )
    event = get_sqs_event(credit_app_full_payload, pt.CREDIT_APP_PATCH)
    with pytest.raises(Exception) as error:
        deal_consumer.handler(event, lambda_context)
    assert "dynamoDB Test Exception" in str(error)


def test_delete_dynamodb_records(
    lambda_context,
    dynamodb,
    credit_app_full_payload,
    get_sqs_event,
    boto3_client,
    monkeypatch,
):
    data = json.loads(json.dumps(credit_app_full_payload))
    data["applicant"] = None

    expected = json.loads(json.dumps(credit_app_full_payload))
    expected.pop("applicant")

    schema = json.loads(json.dumps(schemas.v1.CA.schema))
    deal_ref_id = credit_app_full_payload.get("dealRefId")
    monkeypatch.setattr(deal_consumer.boto3, "client", boto3_client)
    monkeypatch.setattr(deal_consumer.boto3, "client", boto3_client)

    actual, failed_items = deal_consumer.delete_dynamodb_records(
        data, deal_ref_id, schema, "deals"
    )

    assert actual == expected


def test_delete_dynamodb_records_failed_items(
    lambda_context,
    dynamodb,
    credit_app_full_payload,
    get_sqs_event,
    boto3_resource_table_delete_item_error,
    monkeypatch,
):
    data = json.loads(json.dumps(credit_app_full_payload))
    data["ERROR_TRIGGER"] = None
    data["applicant"] = None

    expected_data = json.loads(json.dumps(credit_app_full_payload))
    expected_data["ERROR_TRIGGER"] = None
    expected_data.pop("applicant")
    expected_failed_items = {"ERROR_TRIGGER": {"protected": None}}

    schema = json.loads(json.dumps(schemas.v1.CA.schema))
    schema["ERROR_TRIGGER"] = {"protected": {}}

    deal_ref_id = credit_app_full_payload.get("dealRefId")
    monkeypatch.setattr(
        deal_consumer.boto3, "resource", boto3_resource_table_delete_item_error
    )

    actual_data, actual_failed_items = deal_consumer.delete_dynamodb_records(
        data, deal_ref_id, schema, "deals"
    )

    assert actual_data == expected_data
    assert actual_failed_items == expected_failed_items


def test_key_data_post_payload(
    lambda_context, dynamodb, key_data_payload, get_sqs_event, dr_ulid
):
    """
    Test to verifies full payload with applicant, vehicle, tradeIn and finance summary is persisted
    """
    deal_ref_id = dr_ulid
    event = get_sqs_event(key_data_payload, pt.KEY_DATA_POST)
    response = deal_consumer.handler(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.CREATED

    deals_table = dynamodb.Table(deal_consumer.DealDataParameters().db_name)

    key_expression = Key("dealRefId").eq(deal_ref_id)
    query_results = deals_table.query(KeyConditionExpression=key_expression).get(
        "Items", []
    )
    assert len(query_results) == 3

    key_expression = Key("dealRefId").eq(deal_ref_id) & Key("dealComponent").eq(
        "DTC.DEAL"
    )
    query_results = deals_table.query(KeyConditionExpression=key_expression).get(
        "Items", []
    )

    assert query_results[0]["dealRefId"] == deal_ref_id
    assert query_results[0]["dealJacketId"] == key_data_payload["dealJacketId"]
    assert query_results[0]["dealerCode"] == key_data_payload["dealerCode"]


def test_prepare_deal_data_for_routing(credit_app_full_payload):
    """
    Test deal-data is properly populated per each lender in the lenderList.
    """
    d_consumer = deal_consumer.DealConsumerLambda()
    apps_data = d_consumer.prepare_deal_data_for_routing(credit_app_full_payload)

    assert len(apps_data) == 0


class TestCaMultipleDealPut:
    def test_credit_app_put_full_payload(
        self,
        lambda_context,
        dynamodb,
        ca_put_payload,
        credit_app_full_payload,
        get_sqs_event,
        dr_ulid_new,
    ):
        ca_post_data = credit_app_full_payload

        ca_post_data["targetPlatforms"][0]["id"] = "DTC"
        event = get_sqs_event(ca_post_data, pt.CREDIT_APP_POST)

        response = deal_consumer.handler(event, lambda_context)

        assert response["statusCode"] == HTTPStatus.CREATED

        data = ca_put_payload
        deal_ref_id = data.get("dealRefId")

        event = get_sqs_event(data, pt.CREDIT_APP_PUT)

        response = deal_consumer.handler(event, lambda_context)

        assert response["statusCode"] == HTTPStatus.CREATED

        deals_table = dynamodb.Table(deal_consumer.DealDataParameters().db_name)

        key_expression = Key("dealRefId").eq(deal_ref_id)

        query_results = deals_table.query(KeyConditionExpression=key_expression).get(
            "Items", []
        )

        assert len(query_results) == 18
