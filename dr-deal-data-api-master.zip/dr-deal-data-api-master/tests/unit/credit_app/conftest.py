# -*- coding: utf-8 -*-
import pytest
from common import settings
from utils.db_helper import DynamoDbHelper


@pytest.fixture(autouse=True)
def mock_dynamodb_helper(monkeypatch, mock_query_pk_filter):
    monkeypatch.setattr(DynamoDbHelper, "query_pk_filter", mock_query_pk_filter)


@pytest.fixture()
def mock_dynamodb_helper_empty(monkeypatch, db_query_empty):
    monkeypatch.setattr(DynamoDbHelper, "query_pk_filter", db_query_empty)


@pytest.fixture()
def get_api_gateway_event_ca_new_deal(get_api_gateway_event):
    def api_gateway_event(body):
        additional_header = {
            settings.DEAL_XG_ID_HEADER_KEY: "1234",
            settings.DEAL_XG_VERSION_HEADER_KEY: "v3",
        }
        event = get_api_gateway_event(body, additional_header)
        event["path"] = "/v1/deals/credit-apps"
        event["requestContext"] = {"operationName": "ca_new_deal"}
        return event

    return api_gateway_event


@pytest.fixture()
def get_api_gateway_event_ca_existing_deal(get_api_gateway_event):
    def api_gateway_event(body):
        additional_header = {
            settings.DEAL_XG_ID_HEADER_KEY: "1234",
            settings.DEAL_XG_VERSION_HEADER_KEY: "v3",
        }
        event = get_api_gateway_event(body, additional_header)
        event["path"] = "/v1/deals/dealRefId/credit-apps"
        event["pathParameters"] = {"dealRefId": "0000000000AAABBBCCDDEEFFGG"}
        event["requestContext"] = {"operationName": "ca_existing_deal"}
        return event

    return api_gateway_event


@pytest.fixture()
def get_api_gateway_event_ca_update(get_api_gateway_event):
    def api_gateway_event(body):
        event = get_api_gateway_event(body)
        event["path"] = "/v1/deals/dealRefId/credit-apps/creditAppId"
        event["pathParameters"] = {
            "dealRefId": "0000000000AAABBBCCDDEEFFGG",
            "creditAppId": "0000000000AAABBBCCDDEEFFGG",
        }
        event["requestContext"] = {"operationName": "ca_update"}
        return event

    return api_gateway_event


@pytest.fixture()
def get_api_gateway_event_ca_healthcheck(get_api_gateway_event):
    event = get_api_gateway_event("")
    event["headers"] = {
        settings.HEALTHCHECK_HEADER_FIELD: settings.HEALTHCHECK_HEADER_VALUE
    }
    event["path"] = "/v1/deals/dealRefId/credit-apps"
    event["requestContext"] = {"operationName": "ca_existing_deal"}
    return event


@pytest.fixture()
def get_api_gateway_event_ca_new_deal_dealrefid_given(
    get_api_gateway_event, credit_app_full_payload, dr_ulid_new
):
    event = get_api_gateway_event(credit_app_full_payload)
    event["headers"] = {settings.DEAL_REF_ID_HEADER_KEY: dr_ulid_new}
    event["path"] = "/v1/deals/credit-apps"
    event["requestContext"] = {"operationName": "ca_new_deal"}
    return event


@pytest.fixture()
def get_api_gateway_event_ca_reprocess_existing_deal(get_api_gateway_event):
    def api_gateway_event(body):

        event = get_api_gateway_event(body)
        event["path"] = "/v1/deals/dealRefId/credit-apps/creditAppId"
        event["pathParameters"] = {
            "dealRefId": "0000000000AAABBBCCDDEEFFGG",
            "creditAppId": "0000000000AAABBBCCDDEEFFGG",
        }
        return event

    return api_gateway_event


@pytest.fixture()
def get_api_gateway_event_multiple_ca_deal(get_api_gateway_event, dr_ulid_new):
    def api_gateway_event(body):
        event = get_api_gateway_event(body)
        event["path"] = "/v1/deals/{dealRefId}/credit-apps"
        event["pathParameters"] = {
            "dealRefId": dr_ulid_new,
        }
        return event

    return api_gateway_event


@pytest.fixture()
def get_api_gateway_event_ca_put_handler(get_api_gateway_event, dr_ulid_new):
    def api_gateway_event(body):
        additional_header = {
            settings.CREDIT_APP_ID_HEADER_KEY: dr_ulid_new,
        }
        event = get_api_gateway_event(body, additional_header)
        event["path"] = "/v1/deals/{dealRefId}/credit-apps"
        event["pathParameters"] = {
            "dealRefId": dr_ulid_new,
        }
        event["requestContext"] = {"operationName": "ca_put_handler"}
        return event

    return api_gateway_event
