# -*- coding: utf-8 -*-

import json
from http import HTTPStatus

from common import deal_consumer
from common.settings import ErrorMsgs, PayloadType as pt
from credit_app import get
from utils.db_helper import DynamoDbHelper


def test_full_ca_get_payload(
    lambda_context,
    dynamodb,
    credit_app_full_payload,
    get_sqs_event,
    monkeypatch,
    db_query_items,
):
    deal_ref_id = credit_app_full_payload.get("dealRefId")
    credit_app_id = credit_app_full_payload.get("creditAppId")
    credit_app_full_payload["applicant"]["aws:updatedTime"] = "aws_key"
    credit_app_full_payload["applicant"]["ssn"] = "788999009"

    event = get_sqs_event(credit_app_full_payload, pt.CREDIT_APP_POST)
    monkeypatch.setattr(DynamoDbHelper, "query_items", db_query_items)

    # First create a deal
    response = deal_consumer.handler(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.CREATED

    # Next we retrieve the deal
    event = get_sqs_event(credit_app_full_payload, pt.CREDIT_APP_POST)
    event["path"] = "/v1/deals/dealRefId/credit-apps/creditAppId/"
    event.pop("Records")
    event["pathParameters"] = {"dealRefId": deal_ref_id, "creditAppId": credit_app_id}

    response = get.credit_app_get(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.OK
    body = json.loads(response["body"])

    # check for basic get data
    assert body["targetPlatforms"] == credit_app_full_payload["targetPlatforms"]
    assert body["financeMethod"] == credit_app_full_payload["financeMethod"]

    # check basic applicant get data
    assert (
        body["applicant"]["firstName"]
        == credit_app_full_payload["applicant"]["firstName"]
    )
    assert (
        body["applicant"]["lastName"]
        == credit_app_full_payload["applicant"]["lastName"]
    )

    credit_app_full_payload["applicant"]["address"].pop("county")
    assert (
        body["applicant"]["address"] == credit_app_full_payload["applicant"]["address"]
    )

    assert body["applicant"]["ssn"] == "788999009"

    # check basic co-applicant get data
    assert (
        body["coApplicant"]["firstName"]
        == credit_app_full_payload["coApplicant"]["firstName"]
    )
    assert (
        body["coApplicant"]["lastName"]
        == credit_app_full_payload["coApplicant"]["lastName"]
    )

    # check for financeSummary get data
    assert (
        body["financeSummary"].items()
        <= credit_app_full_payload["financeSummary"].items()
    )

    # check for tradeIns get data
    assert body["tradeIns"][0].items() <= credit_app_full_payload["tradeIns"][0].items()

    # check for vehicle get data
    assert body["vehicle"].items() <= credit_app_full_payload["vehicle"].items()


def test_minimal_ca_get_payload(
    lambda_context,
    dynamodb,
    credit_app_partial_payload,
    get_sqs_event,
    monkeypatch,
    db_query_items,
):
    deal_ref_id = credit_app_partial_payload.get("dealRefId")
    credit_app_partial_payload.pop("customerType")
    credit_app_partial_payload["applicant"].pop("previousAddress")
    credit_app_partial_payload["applicant"].pop("previousEmployment")
    credit_app_partial_payload["applicant"].pop("spouse")
    credit_app_partial_payload["applicant"].pop("references")

    credit_app_id = credit_app_partial_payload.get("creditAppId")
    credit_app_partial_payload["applicant"]["aws:updatedTime"] = "aws_key"
    credit_app_partial_payload["applicant"]["ssn"] = "788999009"

    event = get_sqs_event(credit_app_partial_payload, pt.CREDIT_APP_POST)
    monkeypatch.setattr(DynamoDbHelper, "query_items", db_query_items)

    # First create a deal
    response = deal_consumer.handler(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.CREATED

    # Next we retrieve the deal
    event = get_sqs_event(credit_app_partial_payload, pt.CREDIT_APP_POST)
    event["path"] = "/v1/deals/dealRefId/credit-apps/creditAppId/"
    event.pop("Records")
    event["pathParameters"] = {"dealRefId": deal_ref_id, "creditAppId": credit_app_id}

    response = get.credit_app_get(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.OK
    body = json.loads(response["body"])

    # check for basic get data
    assert body["targetPlatforms"] == credit_app_partial_payload["targetPlatforms"]
    assert body["financeMethod"] == credit_app_partial_payload["financeMethod"]

    # check basic applicant get data
    assert (
        body["applicant"]["firstName"]
        == credit_app_partial_payload["applicant"]["firstName"]
    )
    assert (
        body["applicant"]["lastName"]
        == credit_app_partial_payload["applicant"]["lastName"]
    )

    credit_app_partial_payload["applicant"]["address"].pop("county")
    assert (
        body["applicant"]["address"]
        == credit_app_partial_payload["applicant"]["address"]
    )

    assert body["applicant"]["ssn"] == "788999009"
    assert body["applicant"].get("spouse") is None
    assert body["applicant"].get("previousEmployment") is None
    assert body["applicant"].get("previousAddress") is None


def test_ca_get_with_invalid_deal_ref_id(lambda_context):
    """
    Test to verify api return 400 if required parameters are invalid
    """
    event = {"path": "/v1/deals/dealRefId/credit-apps/creditAppId/"}
    deal_ref_id = "abc123"
    event["pathParameters"] = {"dealRefId": deal_ref_id}
    response = get.credit_app_get(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST

    body = json.loads(response["body"])
    assert body["message"] == ErrorMsgs.missing_deal_from_db.format(
        deal_ref_id=deal_ref_id
    )


def test_full_ca_get_exception(
    dynamodb,
    credit_app_full_payload,
    get_api_gateway_event,
    monkeypatch,
    db_query_items,
    return_exception,
    lambda_context,
):
    """
    Test to verify api return 500 for general exceptions
    """
    deal_ref_id = credit_app_full_payload.get("dealRefId")
    credit_app_id = credit_app_full_payload.get("creditAppId")
    event = get_api_gateway_event(credit_app_full_payload)
    monkeypatch.setattr(DynamoDbHelper, "query_items", return_exception)

    event["pathParameters"] = {"dealRefId": deal_ref_id, "creditAppId": credit_app_id}
    response = get.credit_app_get(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.INTERNAL_SERVER_ERROR


def test_ca_get_payload_with_multiple_trade_ins(
    lambda_context,
    dynamodb,
    credit_app_full_payload,
    get_sqs_event,
    monkeypatch,
    db_query_items,
):
    deal_ref_id = credit_app_full_payload.get("dealRefId")
    credit_app_id = credit_app_full_payload.get("creditAppId")
    credit_app_full_payload["applicant"]["aws:updatedTime"] = "aws_key"
    credit_app_full_payload["tradeIns"].append(credit_app_full_payload["tradeIns"][0])
    event = get_sqs_event(credit_app_full_payload, pt.CREDIT_APP_POST)
    monkeypatch.setattr(DynamoDbHelper, "query_items", db_query_items)

    # First create a deal
    response = deal_consumer.handler(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.CREATED

    # Next we retrieve the deal
    event = get_sqs_event(credit_app_full_payload, pt.CREDIT_APP_POST)
    event["path"] = "/v1/deals/dealRefId/credit-apps/"
    event.pop("Records")
    event["pathParameters"] = {"dealRefId": deal_ref_id, "creditAppId": credit_app_id}
    response = get.credit_app_get(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.OK
    body = json.loads(response["body"])

    # check for tradeIns get data
    assert body["tradeIns"][0].items() <= credit_app_full_payload["tradeIns"][0].items()

    assert body["tradeIns"][1].items() <= credit_app_full_payload["tradeIns"][0].items()

    assert len(body["tradeIns"]) == 2


def test_ca_get_with_request_apr_and_sales_tax_as_zero(
    lambda_context,
    dynamodb,
    credit_app_full_payload,
    get_sqs_event,
    monkeypatch,
    db_query_items,
):
    deal_ref_id = credit_app_full_payload.get("dealRefId")
    credit_app_id = credit_app_full_payload.get("creditAppId")
    credit_app_full_payload["applicant"]["aws:updatedTime"] = "aws_key"
    credit_app_full_payload["financeSummary"]["salesTax"] = 0
    credit_app_full_payload["financeSummary"]["requestedAPR"] = 0.0
    event = get_sqs_event(credit_app_full_payload, pt.CREDIT_APP_POST)
    monkeypatch.setattr(DynamoDbHelper, "query_items", db_query_items)

    # First create a deal
    response = deal_consumer.handler(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.CREATED

    # Next we retrieve the deal
    event = get_sqs_event(credit_app_full_payload, pt.CREDIT_APP_POST)
    event["path"] = "/v1/deals/dealRefId/credit-apps/"
    event.pop("Records")
    event["pathParameters"] = {"dealRefId": deal_ref_id, "creditAppId": credit_app_id}
    response = get.credit_app_get(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.OK
    body = json.loads(response["body"])

    assert body["financeSummary"]["salesTax"] == 0
    assert body["financeSummary"]["requestedAPR"] == 0.0


def test_ca_get_with_empty_dict_and_array(
    lambda_context,
    dynamodb,
    credit_app_full_payload,
    get_sqs_event,
    monkeypatch,
    db_query_items,
):
    deal_ref_id = credit_app_full_payload.get("dealRefId")
    credit_app_id = credit_app_full_payload.get("creditAppId")
    credit_app_full_payload["applicant"]["aws:updatedTime"] = "aws_key"
    credit_app_full_payload["lenderList"] = [{}]
    credit_app_full_payload["applicant"]["currentEmployment"] = {"employerAddress": {}}
    credit_app_full_payload["applicant"]["spouse"] = {}
    credit_app_full_payload["coApplicant"] = {}
    credit_app_full_payload["tradeIns"] = []
    credit_app_full_payload["extraData"].append({})

    event = get_sqs_event(credit_app_full_payload, pt.CREDIT_APP_POST)
    monkeypatch.setattr(DynamoDbHelper, "query_items", db_query_items)

    # First create a deal
    response = deal_consumer.handler(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.CREATED

    # Next we retrieve the deal
    event = get_sqs_event(credit_app_full_payload, pt.CREDIT_APP_POST)
    event["path"] = "/v1/deals/dealRefId/credit-apps/"
    event.pop("Records")
    event["pathParameters"] = {"dealRefId": deal_ref_id, "creditAppId": credit_app_id}
    response = get.credit_app_get(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.OK
    body = json.loads(response["body"])

    assert body.get("lenderList") is None
    assert body.get("applicant").get("currentEmployment") is None
    assert body.get("applicant").get("spouse") is None
    assert body.get("coApplicant") is None
    assert body.get("tradeIns") is None
    assert len(body.get("extraData")) == 1
