# -*- coding: utf-8 -*-

import json
from http import HTTPStatus

from common import deal_consumer
from common.settings import ErrorMsgs, PayloadType as pt
from credit_app import producer
from utils import common


def test_ca_new_deal_successful_no_correlation_id(
    credit_app_full_payload,
    sqs,
    get_api_gateway_event_ca_new_deal,
    uuid_newly_generated,
    response_header,
    lambda_context,
):
    event = get_api_gateway_event_ca_new_deal(credit_app_full_payload)
    event.pop("headers")

    response = producer.credit_apps_handlers(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps(
        {
            "dealRefId": "0000000000AAABBBCCDDEEFFGG",
            "creditAppId": "0000000000AAABBBCCDDEEFFGG",
        }
    )
    assert response["headers"] == response_header(uuid_newly_generated)


def test_ca_new_deal_successful_correlation_id_provided(
    credit_app_full_payload,
    sqs,
    get_api_gateway_event_ca_new_deal,
    uuid_provided,
    response_header,
    lambda_context,
):
    event = get_api_gateway_event_ca_new_deal(credit_app_full_payload)
    response = producer.credit_apps_handlers(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps(
        {
            "dealRefId": "0000000000AAABBBCCDDEEFFGG",
            "creditAppId": "0000000000AAABBBCCDDEEFFGG",
        }
    )
    assert response["headers"] == response_header(uuid_provided)


def test_ca_new_deal_successful_correlation_id_provided_rt1(
    credit_app_full_payload,
    sqs,
    get_api_gateway_event_ca_new_deal,
    uuid_provided,
    response_header,
    lambda_context,
    caplog,
):
    credit_app_full_payload["targetPlatforms"][0]["id"] = "RT1"
    event = get_api_gateway_event_ca_new_deal(credit_app_full_payload)

    response = producer.credit_apps_handlers(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps(
        {
            "dealRefId": "0000000000AAABBBCCDDEEFFGG",
            "creditAppId": "0000000000AAABBBCCDDEEFFGG",
        }
    )
    assert response["headers"] == response_header(uuid_provided)
    assert "Converted RouteOne target platform from RT1 to R1J" in str(caplog.records)


def test_ca_new_deal_no_body(
    sqs,
    uuid_provided,
    response_header,
    get_api_gateway_event_ca_new_deal,
    lambda_context,
):
    event = get_api_gateway_event_ca_new_deal("")
    response = producer.credit_apps_handlers(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps({"message": ErrorMsgs.missing_body_aws_event})
    assert response["headers"] == response_header(uuid_provided)


def test_ca_new_deal_json_decoder_error(
    sqs,
    get_api_gateway_invalid_event_ca_new,
    uuid_provided,
    response_header,
    lambda_context,
):
    event = get_api_gateway_invalid_event_ca_new

    response = producer.credit_apps_handlers(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["headers"] == response_header(uuid_provided)


def test_ca_new_deal_health_check(get_api_gateway_event_ca_healthcheck, lambda_context):
    event = get_api_gateway_event_ca_healthcheck
    event["requestContext"] = {"operationName": "ca_new_deal"}
    response = producer.credit_apps_handlers(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps("Operational")


def test_ca_update_successful_no_headers(
    credit_app_full_payload,
    sqs,
    get_api_gateway_event_ca_update,
    uuid_newly_generated,
    response_header,
    lambda_context,
):

    event = get_api_gateway_event_ca_update(credit_app_full_payload)
    event.pop("headers")

    response = producer.credit_apps_handlers(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.NO_CONTENT
    assert response["body"] == "Credit Application updated"
    assert response["headers"] == response_header(uuid_newly_generated)


def test_ca_update_successful_correlation_id_provided(
    credit_app_full_payload,
    sqs,
    get_api_gateway_event_ca_update,
    uuid_provided,
    response_header,
    lambda_context,
):
    event = get_api_gateway_event_ca_update(credit_app_full_payload)

    response = producer.credit_apps_handlers(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.NO_CONTENT
    assert response["body"] == "Credit Application updated"
    assert response["headers"] == response_header(uuid_provided)


def test_ca_update_successful_correlation_id_provided_rt1(
    credit_app_full_payload,
    sqs,
    get_api_gateway_event_ca_update,
    uuid_provided,
    response_header,
    lambda_context,
    caplog,
):
    credit_app_full_payload["targetPlatforms"][0]["id"] = "RT1"
    event = get_api_gateway_event_ca_update(credit_app_full_payload)

    response = producer.credit_apps_handlers(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.NO_CONTENT
    assert response["body"] == "Credit Application updated"
    assert response["headers"] == response_header(uuid_provided)

    assert "Converted RouteOne target platform from RT1 to R1J" in str(caplog.records)


def test_ca_update_unexpected_validation_error(
    credit_app_full_payload,
    sqs,
    get_api_gateway_event_ca_update,
    uuid_newly_generated,
    response_header,
    monkeypatch,
    return_exception,
    lambda_context,
):
    event = get_api_gateway_event_ca_update(credit_app_full_payload)
    event.pop("headers")

    monkeypatch.setattr(producer, "ExistingDealValidator", return_exception)
    response = producer.credit_apps_handlers(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.INTERNAL_SERVER_ERROR
    assert response["body"] == json.dumps({"message": "error"})


def test_ca_update_health_check(get_api_gateway_event_ca_healthcheck, lambda_context):
    event = get_api_gateway_event_ca_healthcheck
    event["requestContext"] = {"operationName": "ca_update"}
    response = producer.credit_apps_handlers(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps("Operational")


def test_ca_update_no_body(
    sqs, uuid_provided, response_header, get_api_gateway_event_ca_update, lambda_context
):
    event = get_api_gateway_event_ca_update("")
    response = producer.credit_apps_handlers(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps({"message": ErrorMsgs.missing_body_aws_event})
    assert response["headers"] == response_header(uuid_provided)


def test_ca_update_json_decoder_error(
    sqs, get_api_gateway_invalid_event, uuid_provided, response_header, lambda_context
):
    event = get_api_gateway_invalid_event
    event["path"] = ("/v1/deals/dealRefId/credit-apps/creditAppId",)
    event["pathParameters"] = {"creditAppId": "0000000000AAABBBCCDDEEFFGG"}
    event["requestContext"] = {"operationName": "ca_update"}

    response = producer.credit_apps_handlers(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert json.loads(response["body"]) == {"message": "dealRefId not provided"}
    assert response["headers"] == response_header(uuid_provided)


def test_deal_post_app_successful_no_correlation_id(
    credit_app_full_payload,
    sqs,
    get_api_gateway_event_ca_existing_deal,
    uuid_newly_generated,
    response_header,
    lambda_context,
):
    event = get_api_gateway_event_ca_existing_deal(credit_app_full_payload)
    event.pop("headers")

    response = producer.credit_apps_handlers(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps(
        {
            "dealRefId": "0000000000AAABBBCCDDEEFFGG",
            "creditAppId": "0000000000AAABBBCCDDEEFFGG",
        }
    )
    assert response["headers"] == response_header(uuid_newly_generated)


def test_ca_existing_deal_successful(
    credit_app_full_payload,
    sqs,
    get_api_gateway_event_ca_existing_deal,
    uuid_provided,
    response_header,
    lambda_context,
):

    event = get_api_gateway_event_ca_existing_deal(credit_app_full_payload)

    response = producer.credit_apps_handlers(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps(
        {
            "dealRefId": "0000000000AAABBBCCDDEEFFGG",
            "creditAppId": "0000000000AAABBBCCDDEEFFGG",
        }
    )
    assert response["headers"] == response_header(uuid_provided)


def test_ca_existing_deal_health_check(
    lambda_context, get_api_gateway_event_ca_healthcheck
):
    event = get_api_gateway_event_ca_healthcheck
    event["path"] = "/v1/deals/dealRefId/credit-apps/creditAppId"
    event["requestContext"] = {"operationName": "ca_existing_deal"}

    response = producer.credit_apps_handlers(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps("Operational")


def test_ca_existing_deal_no_body(
    sqs,
    uuid_provided,
    response_header,
    get_api_gateway_event_ca_existing_deal,
    lambda_context,
):
    event = get_api_gateway_event_ca_existing_deal("")

    response = producer.credit_apps_handlers(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps({"message": ErrorMsgs.missing_body_aws_event})
    assert response["headers"] == response_header(uuid_provided)


def test_ca_existing_deal_json_decoder_error(
    sqs,
    get_api_gateway_invalid_event_ca_existing_deal,
    uuid_provided,
    response_header,
    lambda_context,
):
    event = get_api_gateway_invalid_event_ca_existing_deal
    event["path"] = "/v1/deals/dealRefId/credit-apps/creditAppId"
    response = producer.credit_apps_handlers(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["headers"] == response_header(uuid_provided)


def test_ca_existing_deal_validation_error(
    credit_app_full_payload,
    sqs,
    get_api_gateway_event_ca_existing_deal,
    uuid_newly_generated,
    response_header,
    monkeypatch,
    return_exception,
    lambda_context,
):
    event = get_api_gateway_event_ca_existing_deal(credit_app_full_payload)
    event.pop("headers")

    monkeypatch.setattr(producer, "ExistingDealValidator", return_exception)
    response = producer.credit_apps_handlers(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.INTERNAL_SERVER_ERROR
    assert response["body"] == json.dumps({"message": "error"})


def test_ca_existing_deal_fail_validation(
    credit_app_full_payload,
    sqs,
    get_api_gateway_event,
    get_api_gateway_event_ca_existing_deal,
    response_header,
    lambda_context,
    get_sqs_event,
):
    deal_ref_id = credit_app_full_payload.get("dealRefId")
    credit_app_full_payload["creditAppId"] = "0000000000AAABBBCCDDEEFFGG"
    event = get_sqs_event(credit_app_full_payload, pt.CREDIT_APP_POST)
    # First create a deal
    response = deal_consumer.handler(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.CREATED
    event = get_api_gateway_event_ca_existing_deal(credit_app_full_payload)
    event["path"] = "/v1/deals/dealRefId/credit-apps"
    event["pathParameters"] = {"dealRefId": deal_ref_id}
    response = producer.credit_apps_handlers(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(
        {"message": common.get_bad_request_message(False)}
    )


def test_ca_existing_deal_and_ca_resource_id_validation_error(
    credit_app_full_payload,
    lambda_context,
    get_sqs_event,
    get_api_gateway_event_ca_update,
):
    deal_ref_id = credit_app_full_payload.get("dealRefId")
    invalid_credit_app_id = "InvalidCreditAppId"

    event = get_sqs_event(credit_app_full_payload, pt.CREDIT_APP_POST)
    # First create a deal
    response = deal_consumer.handler(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.CREATED

    event = get_api_gateway_event_ca_update(credit_app_full_payload)

    event["path"] = "/v1/deals/dealRefId/credit-apps/creditAppId"
    event["pathParameters"] = {
        "dealRefId": deal_ref_id,
        "creditAppId": invalid_credit_app_id,
    }
    event["requestContext"] = {"operationName": "ca_update"}

    response = producer.credit_apps_handlers(event, lambda_context)
    assert response["body"] == json.dumps(
        {
            "message": ErrorMsgs.resource_id_mismatch.format(
                resource_id=invalid_credit_app_id, deal_ref_id=deal_ref_id
            )
        }
    )


def test_ca_new_deal_invalid_ulid(
    credit_app_full_payload,
    sqs,
    get_api_gateway_event_ca_new_deal,
    uuid_provided,
    response_header,
    lambda_context,
):
    event = get_api_gateway_event_ca_new_deal(credit_app_full_payload)
    event["headers"]["X-Deal-Reference-Id"] = "01F2SMF7K7XKA7XB4A4CY10SFA"
    event["headers"]["X-Credit-Application-Reference-Id"] = "01F2SMF7K7XKA7XB4A4CY10SF@"

    response = producer.credit_apps_handlers(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(
        {"message": 'Invalid ulid provided. Error Non-base32 character found: "@"'}
    )
    assert response["headers"] == response_header(uuid_provided)


def test_ca_existing_deal_invalid_ulid(
    credit_app_full_payload,
    sqs,
    get_api_gateway_event_ca_existing_deal,
    uuid_provided,
    response_header,
    lambda_context,
):

    event = get_api_gateway_event_ca_existing_deal(credit_app_full_payload)
    event["headers"]["X-Credit-Application-Reference-Id"] = "01F2SMF7K7XKA7XB4A4CY10SF@"

    response = producer.credit_apps_handlers(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(
        {"message": 'Invalid ulid provided. Error Non-base32 character found: "@"'}
    )
    assert response["headers"] == response_header(uuid_provided)


def test_ca_new_deal_handler(get_api_gateway_event_ca_healthcheck, lambda_context):
    event = get_api_gateway_event_ca_healthcheck
    event["requestContext"] = {"operationName": "ca_new_deal"}
    response = producer.credit_apps_handlers(event, lambda_context)
    response_object_instance = producer.CreditAppProducerLambda().get_handler(
        handler_func="new_deal_handler", payload_type=pt.CREDIT_APP_POST
    )
    response_object_instance = response_object_instance(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.CREATED
    assert response_object_instance["statusCode"] == HTTPStatus.CREATED
    assert response["statusCode"] == response_object_instance["statusCode"]

    assert response["body"] == json.dumps("Operational")
    assert response_object_instance["body"] == json.dumps("Operational")
    assert response["body"] == response_object_instance["body"]


def test_ca_new_deal_dealrefid_given_handler(
    mock_dynamodb_helper_empty,
    get_api_gateway_event_ca_new_deal_dealrefid_given,
    lambda_context,
):
    event = get_api_gateway_event_ca_new_deal_dealrefid_given
    event["requestContext"] = {"operationName": "ca_new_deal"}
    response = producer.credit_apps_handlers(event, lambda_context)
    response_object_instance = producer.CreditAppProducerLambda().get_handler(
        handler_func="new_deal_handler", payload_type=pt.CREDIT_APP_POST
    )
    response_object_instance = response_object_instance(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.CREATED
    assert response_object_instance["statusCode"] == HTTPStatus.CREATED
    assert response["statusCode"] == response_object_instance["statusCode"]

    assert response["body"] == response_object_instance["body"]


def test_ca_new_deal_dealrefid_given_exists(
    get_api_gateway_event_ca_new_deal_dealrefid_given, lambda_context
):
    event = get_api_gateway_event_ca_new_deal_dealrefid_given
    event["requestContext"] = {"operationName": "ca_new_deal"}
    response = producer.credit_apps_handlers(event, lambda_context)
    response_object_instance = producer.CreditAppProducerLambda().get_handler(
        handler_func="new_deal_handler", payload_type=pt.CREDIT_APP_POST
    )
    response_object_instance = response_object_instance(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response_object_instance["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["statusCode"] == response_object_instance["statusCode"]

    assert response["body"] == response_object_instance["body"]


def test_ca_update_handler(get_api_gateway_event_ca_healthcheck, lambda_context):
    event = get_api_gateway_event_ca_healthcheck
    event["requestContext"] = {"operationName": "ca_update"}
    response = producer.credit_apps_handlers(event, lambda_context)
    response_object_instance = producer.CreditAppProducerLambda().get_handler(
        handler_func="update_handler", payload_type=pt.CREDIT_APP_UPDATE
    )
    response_object_instance = response_object_instance(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.CREATED
    assert response_object_instance["statusCode"] == HTTPStatus.CREATED
    assert response["statusCode"] == response_object_instance["statusCode"]

    assert response["body"] == json.dumps("Operational")
    assert response_object_instance["body"] == json.dumps("Operational")
    assert response["body"] == response_object_instance["body"]


def test_ca_update_handler_for_deal_update(
    get_api_gateway_event_ca_healthcheck, lambda_context
):
    event = get_api_gateway_event_ca_healthcheck
    event["requestContext"] = {"operationName": "deal_update"}
    response = producer.credit_apps_handlers(event, lambda_context)
    response_object_instance = producer.CreditAppProducerLambda().get_handler(
        handler_func="update_handler", payload_type=pt.DEAL_UPDATE
    )
    response_object_instance = response_object_instance(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.CREATED
    assert response_object_instance["statusCode"] == HTTPStatus.CREATED

    assert response["body"] == json.dumps("Operational")
    assert response_object_instance["body"] == json.dumps("Operational")


def test_ca_existing_deal_handler(get_api_gateway_event_ca_healthcheck, lambda_context):
    event = get_api_gateway_event_ca_healthcheck
    event["path"] = "/v1/deals/dealRefId/credit-apps/creditAppId"
    event["requestContext"] = {"operationName": "ca_existing_deal"}
    response = producer.credit_apps_handlers(event, lambda_context)
    response_object_instance = producer.CreditAppProducerLambda().get_handler(
        handler_func="existing_deal_handler", payload_type=pt.CREDIT_APP_PATCH
    )
    response_object_instance = response_object_instance(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.CREATED
    assert response_object_instance["statusCode"] == HTTPStatus.CREATED
    assert response["statusCode"] == response_object_instance["statusCode"]

    assert response["body"] == json.dumps("Operational")
    assert response_object_instance["body"] == json.dumps("Operational")
    assert response["body"] == response_object_instance["body"]


def test_ca_wrong_handler(get_api_gateway_event_ca_healthcheck, lambda_context):
    event = get_api_gateway_event_ca_healthcheck
    event["requestContext"] = {"operationName": "ca_wrong"}
    handlers = ["ca_new_deal", "ca_update", "ca_existing_deal"]
    assert event.get("requestContext").get("operationName") != any(handlers)


def test_ca_business_applicant_successful(
    sqs,
    get_api_gateway_event_ca_existing_deal,
    uuid_provided,
    response_header,
    lambda_context,
    business_credit_app_full_payload,
):
    event = get_api_gateway_event_ca_existing_deal(business_credit_app_full_payload)

    response = producer.credit_apps_handlers(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps(
        {
            "dealRefId": "0000000000AAABBBCCDDEEFFGG",
            "creditAppId": "0000000000AAABBBCCDDEEFFGG",
        }
    )
    assert response["headers"] == response_header(uuid_provided)


def test_ca_put_handler_successful(
    ca_put_payload,
    sqs,
    get_api_gateway_event_ca_put_handler,
    uuid_provided,
    response_header,
    lambda_context,
):
    event = get_api_gateway_event_ca_put_handler(ca_put_payload)

    response = producer.credit_apps_handlers(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps(
        {
            "dealRefId": "1111111111AAABBBCCDDEEFFGG",
            "creditAppId": "1111111111AAABBBCCDDEEFFGG",
        }
    )

    assert response["headers"] == response_header(uuid_provided)


def test_ca_put_handler_no_body(
    sqs,
    uuid_provided,
    response_header,
    get_api_gateway_event_ca_put_handler,
    lambda_context,
):
    event = get_api_gateway_event_ca_put_handler("")
    response = producer.credit_apps_handlers(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps({"message": ErrorMsgs.missing_body_aws_event})
    assert response["headers"] == response_header(uuid_provided)


def test_ca_put_handler_json_decoder_error(
    sqs,
    get_api_gateway_event_ca_put_handler,
    uuid_provided,
    response_header,
    lambda_context,
):
    event = get_api_gateway_event_ca_put_handler("invalid")

    response = producer.credit_apps_handlers(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["headers"] == response_header(uuid_provided)


def test_ca_put_handler_health_check(
    get_api_gateway_event_ca_healthcheck, lambda_context
):
    event = get_api_gateway_event_ca_healthcheck
    event["requestContext"] = {"operationName": "ca_put_handler"}
    response = producer.credit_apps_handlers(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps("Operational")


def test_ca_ca_put_handler_no_ca_ref_id_in_header(
    ca_put_payload,
    sqs,
    get_api_gateway_event_ca_put_handler,
    uuid_newly_generated,
    response_header,
    lambda_context,
):

    event = get_api_gateway_event_ca_put_handler(ca_put_payload)
    del event["headers"]["X-Credit-Application-Reference-Id"]
    response = producer.credit_apps_handlers(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
