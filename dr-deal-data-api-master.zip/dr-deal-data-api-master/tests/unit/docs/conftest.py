# -*- coding: utf-8 -*-
import pytest
from common import deal_consumer
from common.settings import GET_DOCS_FILTER_PARAMS


MULTIPLE_DOCS = "multiple_documents"
SINGLE_DOC = "single_document"
SESSION_DOC = "session_doc"


@pytest.fixture()
def add_db_docs_record(
    dynamodb, docs_single_payload, docs_multiple_payload, docs_session_payload
):
    def add_record(payload_type, target_platform=None):
        db = dynamodb.Table(deal_consumer.DealDataParameters().db_name)
        if payload_type == MULTIPLE_DOCS:
            for item in docs_multiple_payload:
                if target_platform:
                    item["dealComponent"] = item["dealComponent"].replace(
                        "DTC", target_platform
                    )
                db.put_item(Item=item)
        elif payload_type == SINGLE_DOC:
            item = docs_single_payload
            if target_platform:
                item["dealComponent"] = item["dealComponent"].replace(
                    "DTC", target_platform
                )
            db.put_item(Item=item)
        elif payload_type == SESSION_DOC:
            item = docs_session_payload
            if target_platform:
                item["dealComponent"] = item["dealComponent"].replace(
                    "DTC", target_platform
                )
            db.put_item(Item=item)

    return add_record


@pytest.fixture()
def docs_single_payload():
    return {
        "dealRefId": "0000000000AAABBBCCDDEEFFGG",
        "dealComponent": "DTC.DOCS.W2.APP",
        "documentId": "W2.APP",
        "customerRole": "Applicant",
        "documentType": "DriversLicense",
        "href": "https://deal-data-docs.drsvc.aws.dealertrack.com/api/v1/documents/APP.DRIVERS_LICENSE",
        "uploadStatus": "Scanning",
        "tags": ["CA"],
        "extensionFields": {"UploadSystem": "VIN"},
    }


@pytest.fixture()
def docs_multiple_payload():
    return [
        {
            "dealRefId": "0000000000AAABBBCCDDEEFFGG",
            "dealComponent": "DTC.DOCS.DRIVERSLICENSE",
            "documentId": "DRIVERSLICENSE",
            "customerRole": "Applicant",
            "documentType": "DriversLicense",
            "href": "https://deal-data-docs.drsvc.aws.dealertrack.com/api/v1/documents/APP.DRIVERS_LICENSE",
            "uploadStatus": "Initialized",
            "tags": ["AB"],
            "extensionFields": {"UploadSystem": "VIN"},
        },
        {
            "dealRefId": "0000000000AAABBBCCDDEEFFGG",
            "dealComponent": "DTC.DOCS.GEN.INSURANCECARD",
            "documentId": "GEN.INSURANCECARD",
            "customerRole": "Generic",
            "documentType": "InsuranceCard",
            "href": "https://deal-data-docs.drsvc.aws.dealertrack.com/api/v1/documents/GEN.INSURANCECARD",
            "uploadStatus": "Scanning",
            "tags": ["CA"],
            "extensionFields": {"UploadSystem": "VIN"},
        },
        {
            "dealRefId": "0000000000AAABBBCCDDEEFFGG",
            "dealComponent": "DTC.DOCS.APP.W2",
            "documentId": "APP.W2",
            "customerRole": "Applicant",
            "documentType": "W2",
            "href": "https://deal-data-docs.drsvc.aws.dealertrack.com/api/v1/documents/APP.W2",
            "uploadStatus": "Infected",
            "tags": ["CD"],
            "extensionFields": {"UploadSystem": "VIN"},
        },
    ]


@pytest.fixture()
def docs_session_payload():
    return {
        "dealRefId": "0000000000AAABBBCCDDEEFFGG",
        "sessionId": "01ARZ3NDEKTSV4RRFFQ69G5FAV",
        "dealComponent": "DTC.DOCS.UPLOADS.01ARZ3NDEKTSV4RRFFQ69G5FAV",
        "documentId": "W2.APP",
        "documentType": "W2",
        "href": "https://deal-data-docs.drsvc.aws.dealertrack.com/api/v1/uploads/01ARZ3NDEKTSV4RRFFQ69G5FAV",
        "customerRole": "Applicant",
        "uploadStatus": "Initialized",
        "pages": {
            "1": {"status": "Scanning"},
            "2": {"status": "Initialized"},
        },
    }


@pytest.fixture()
def startup_db_docs_helper(add_db_docs_record, dynamodb):
    def wrapper(payload_type, target_platform="DTC"):
        add_db_docs_record(payload_type, target_platform)
        db = dynamodb
        record = db.Table(deal_consumer.DealDataParameters().db_name).scan()
        return record

    return wrapper


@pytest.fixture()
def invalid_query_params_docs():
    return [
        {
            "code": "deal.invalidQueryParameter",
            "properties": [
                {
                    "property": "queryParameters",
                    "message": f"Given filter parameters aren't supported. Supported filters: {GET_DOCS_FILTER_PARAMS}",
                }
            ],
        }
    ]


@pytest.fixture()
def missing_document_id_path_param():
    return [
        {
            "code": "deal.missingRequiredProperty",
            "properties": [
                {
                    "property": "documentId",
                    "message": "documentId is missing in provided path parameters",
                }
            ],
        }
    ]


@pytest.fixture()
def missing_session_id_path_param():
    return [
        {
            "code": "deal.missingRequiredProperty",
            "properties": [
                {
                    "property": "sessionId",
                    "message": "sessionId is missing in provided path parameters",
                }
            ],
        }
    ]


@pytest.fixture()
def no_resources_found_response():
    def wrapper(deal_ref_id, field=None, value=None):
        if not field:
            field = "dealRefId"
            message = f"No resources found for given dealRefId {deal_ref_id}."
        else:
            message = f"No resources found for given dealRefId: {deal_ref_id} and {field}: {value}."
        return [
            {
                "code": "deal.noResourcesFound",
                "properties": [
                    {
                        "property": field,
                        "message": message,
                    }
                ],
            }
        ]

    return wrapper
