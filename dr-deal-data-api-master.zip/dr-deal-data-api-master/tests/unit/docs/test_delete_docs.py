# -*- coding: utf-8 -*-
import json
from http import HTTPStatus

from common import deal_consumer, validators
from docs import docs_lambda
from tests.unit.docs.conftest import SINGLE_DOC
from utils import db_helper


def test_delete_successful_dtc(
    get_api_gateway_event,
    lambda_context,
    dynamodb,
    monkeypatch,
    mock_dynamodb_helper_deals,
    mock_validate_api_version,
    mock_cache_attrs,
    startup_db_docs_helper,
    dr_ulid,
):
    """
    Deleting only a DTC record
    """
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        docs_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version,
    )
    monkeypatch.setattr(
        validators.ExistingDealValidator,
        "_cache_attrs",
        mock_cache_attrs,
    )

    records = startup_db_docs_helper(SINGLE_DOC)

    before_call = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()
    assert len(before_call["Items"]) == 1

    document_id_v2 = records["Items"][0]["dealComponent"]

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/dealRefId/documents/documentId"
    event["pathParameters"] = {"dealRefId": dr_ulid, "documentId": document_id_v2}
    event["requestContext"] = {"operationName": "delete_document"}

    response = docs_lambda.docs_handlers(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.NO_CONTENT

    after_call = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()
    assert len(after_call["Items"]) == 0


def test_delete_successful_idl(
    get_api_gateway_event,
    lambda_context,
    dynamodb,
    monkeypatch,
    mock_dynamodb_helper_deals,
    mock_validate_api_version,
    mock_cache_attrs,
    startup_db_docs_helper,
    dr_ulid,
    add_db_docs_record,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        docs_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version,
    )
    monkeypatch.setattr(
        validators.ExistingDealValidator,
        "_cache_attrs",
        mock_cache_attrs,
    )

    # Create DTC record
    records = startup_db_docs_helper(SINGLE_DOC, target_platform="IDL")

    before_call = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()
    assert len(before_call["Items"]) == 1

    document_id_v2 = records["Items"][0]["dealComponent"]

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/dealRefId/documents/documentId"
    event["pathParameters"] = {"dealRefId": dr_ulid, "documentId": document_id_v2}
    event["requestContext"] = {"operationName": "delete_document"}
    event["requestContext"] = {"operationName": "delete_document"}
    event["queryStringParameters"] = {"targetPlatform": "IDL"}

    response = docs_lambda.docs_handlers(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.NO_CONTENT

    after_call = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()
    assert len(after_call["Items"]) == 0


def test_delete_invalid_deal_ref(
    get_api_gateway_event,
    lambda_context,
    dynamodb,
    monkeypatch,
    mock_dynamodb_helper_deals,
    mock_validate_api_version_invalid_dealrefid,
    generic_invalid_dealref_id,
    startup_db_docs_helper,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        docs_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version_invalid_dealrefid,
    )

    records = startup_db_docs_helper(SINGLE_DOC)

    before_call = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()
    assert len(before_call["Items"]) == 1

    deal_ref_id = "INVALID_DEAL_REF"
    document_id = records["Items"][0]["documentId"]

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/dealRefId/documents/documentId"
    event["pathParameters"] = {"dealRefId": deal_ref_id, "documentId": document_id}
    event["requestContext"] = {"operationName": "delete_document"}

    response = docs_lambda.docs_handlers(event, lambda_context)
    body = json.loads(response["body"])

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert body == generic_invalid_dealref_id

    after_call = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()
    assert len(after_call["Items"]) == 1


def test_delete_invalid_document_id(
    get_api_gateway_event,
    lambda_context,
    dynamodb,
    monkeypatch,
    mock_dynamodb_helper_deals,
    mock_cache_attrs,
    mock_validate_api_version,
    no_resources_found_response,
    startup_db_docs_helper,
    dr_ulid,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        docs_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version,
    )
    monkeypatch.setattr(
        validators.ExistingDealValidator,
        "_cache_attrs",
        mock_cache_attrs,
    )

    startup_db_docs_helper(SINGLE_DOC)

    before_call = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()
    assert len(before_call["Items"]) == 1

    deal_ref_id = dr_ulid
    document_id = "INVALID_DOCUMENT_ID"

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/dealRefId/documents/documentId"
    event["pathParameters"] = {"dealRefId": deal_ref_id, "documentId": document_id}
    event["requestContext"] = {"operationName": "delete_document"}

    response = docs_lambda.docs_handlers(event, lambda_context)
    body = json.loads(response["body"])

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert body == no_resources_found_response(
        deal_ref_id, field="documentId", value=document_id
    )

    after_call = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()
    assert len(after_call["Items"]) == 1
