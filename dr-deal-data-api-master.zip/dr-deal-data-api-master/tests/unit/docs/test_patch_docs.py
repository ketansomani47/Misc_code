# -*- coding: utf-8 -*-

# -*- coding: utf-8 -*-
import copy
import json
from http import HTTPStatus

import ulid
from common import deal_consumer, validators
from docs import docs_lambda
from tests.unit.docs.conftest import SESSION_DOC, SINGLE_DOC
from utils import db_helper


def test_patch_document(
    dynamodb,
    get_api_gateway_event,
    lambda_context,
    mock_cache_attrs,
    mock_dynamodb_helper_deals,
    mock_validate_api_version,
    monkeypatch,
    startup_db_docs_helper,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        docs_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version,
    )
    monkeypatch.setattr(
        validators.ExistingDealValidator,
        "_cache_attrs",
        mock_cache_attrs,
    )

    records = startup_db_docs_helper(SINGLE_DOC)
    copy_records = copy.deepcopy(records)

    deal_ref_id = copy_records["Items"][0]["dealRefId"]
    document_id = copy_records["Items"][0]["documentId"]
    document_type = copy_records["Items"][0]["documentType"]
    deal_component = f"DTC.DOCS.{document_id}"

    update_record = get_api_gateway_event({})
    update_record["path"] = "/v1/deals/dealRefId/documents/documentId"
    update_record["queryStringParameters"] = {}
    update_record["pathParameters"] = {
        "dealRefId": deal_ref_id,
        "documentId": deal_component,
    }
    update_record["requestContext"] = {"operationName": "patch_document"}
    update_record["body"] = {"documentType": "TEST"}
    update_record["body"] = json.dumps(update_record["body"])

    response = docs_lambda.docs_handlers(update_record, lambda_context)
    update_records = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()

    new_deal_ref_id = update_records["Items"][0]["dealRefId"]
    new_document_type = update_records["Items"][0]["documentType"]

    assert response["statusCode"] == HTTPStatus.NO_CONTENT
    assert deal_ref_id == new_deal_ref_id
    assert new_document_type != document_type


def test_patch_session_with_pagenumber_status(
    dynamodb,
    get_api_gateway_event,
    lambda_context,
    mock_cache_attrs,
    mock_dynamodb_helper_deals,
    mock_validate_api_version,
    monkeypatch,
    startup_db_docs_helper,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        docs_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version,
    )
    monkeypatch.setattr(
        validators.ExistingDealValidator,
        "_cache_attrs",
        mock_cache_attrs,
    )
    monkeypatch.setattr(
        validators.ExistingDealValidator,
        "get_records_by_deal_component",
        mock_cache_attrs,
    )

    records = startup_db_docs_helper(SESSION_DOC)
    copy_records = copy.deepcopy(records)

    deal_ref_id = copy_records["Items"][0]["dealRefId"]
    session_id = copy_records["Items"][0]["sessionId"]
    deal_component = f"DTC.DOCS.UPLOADS.{session_id}"

    page_number = "1"

    update_record = get_api_gateway_event({"status": "Complete"})
    update_record["path"] = "/v1/deals/dealRefId/uploads/sessionId/pages/pageId"
    update_record["queryStringParameters"] = {}
    update_record["pathParameters"] = {
        "dealRefId": deal_ref_id,
        "sessionId": deal_component,
        "pageId": page_number,
    }
    update_record["requestContext"] = {"operationName": "patch_session_page"}

    response = docs_lambda.docs_handlers(update_record, lambda_context)

    update_records = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()[
        "Items"
    ][0]

    new_deal_ref_id = update_records["dealRefId"]

    assert response["statusCode"] == HTTPStatus.NO_CONTENT
    assert deal_ref_id == new_deal_ref_id
    assert update_records["pages"][page_number]["status"] == "Complete"


def test_patch_session_with_pagenumber_status_location(
    dynamodb,
    get_api_gateway_event,
    lambda_context,
    mock_cache_attrs,
    mock_dynamodb_helper_deals,
    mock_validate_api_version,
    monkeypatch,
    startup_db_docs_helper,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        docs_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version,
    )
    monkeypatch.setattr(
        validators.ExistingDealValidator,
        "_cache_attrs",
        mock_cache_attrs,
    )

    records = startup_db_docs_helper(SESSION_DOC)
    copy_records = copy.deepcopy(records)

    deal_ref_id = copy_records["Items"][0]["dealRefId"]
    session_id = copy_records["Items"][0]["sessionId"]
    deal_component = f"DTC.DOCS.UPLOADS.{session_id}"

    page_number = "1"

    update_record = get_api_gateway_event(
        {"status": "Complete", "location": "/location/file.jpg"}
    )
    update_record["path"] = "/v1/deals/dealRefId/uploads/sessionId/pages/pageId"
    update_record["pathParameters"] = {
        "dealRefId": deal_ref_id,
        "sessionId": deal_component,
        "pageId": page_number,
    }
    update_record["requestContext"] = {"operationName": "patch_session_page"}
    update_record["headers"].update({"page_number": page_number})

    response = docs_lambda.docs_handlers(update_record, lambda_context)
    update_records = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()[
        "Items"
    ][0]

    new_deal_ref_id = update_records["dealRefId"]

    assert response["statusCode"] == HTTPStatus.NO_CONTENT
    assert deal_ref_id == new_deal_ref_id
    assert update_records["pages"][page_number]["status"] == "Complete"
    assert update_records["pages"][page_number]["location"] == "/location/file.jpg"


def test_patch_session_with_pagenumber_no_resource(
    get_api_gateway_event,
    lambda_context,
    mock_cache_attrs,
    mock_dynamodb_helper_deals,
    mock_validate_api_version,
    monkeypatch,
    no_resources_found_response,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        docs_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version,
    )
    monkeypatch.setattr(
        validators.ExistingDealValidator,
        "_cache_attrs",
        mock_cache_attrs,
    )

    deal_ref_id = ulid.new().str
    session_id = ulid.new().str
    page_number = "1"

    update_record = get_api_gateway_event({"status": "Complete"})
    update_record["path"] = "/v1/deals/dealRefId/uploads/sessionId/pages/pageId"
    update_record["queryStringParameters"] = {}
    update_record["pathParameters"] = {
        "dealRefId": deal_ref_id,
        "sessionId": session_id,
        "pageId": page_number,
    }
    update_record["requestContext"] = {"operationName": "patch_session_page"}

    response = docs_lambda.docs_handlers(update_record, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert json.loads(response["body"]) == no_resources_found_response(
        deal_ref_id, field="sessionId", value=session_id
    )


def test_patch_with_no_existing_resource(
    docs_single_payload,
    get_api_gateway_event,
    lambda_context,
    mock_cache_attrs,
    mock_validate_api_version,
    mock_dynamodb_helper_deals,
    monkeypatch,
    no_resources_found_response,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        docs_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version,
    )
    monkeypatch.setattr(
        validators.ExistingDealValidator, "_cache_attrs", mock_cache_attrs
    )

    deal_ref_id = ulid.new().str
    document_id = ulid.new().str

    update_record = get_api_gateway_event({})
    update_record["path"] = "/v1/deals/dealRefId/documents/documentId"
    update_record["queryStringParameters"] = {}
    update_record["pathParameters"] = {
        "dealRefId": deal_ref_id,
        "documentId": document_id,
    }
    update_record["requestContext"] = {"operationName": "patch_document"}
    update_record["body"] = json.dumps(docs_single_payload)

    response = docs_lambda.docs_handlers(update_record, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert json.loads(response["body"]) == no_resources_found_response(
        deal_ref_id, field="documentId", value=document_id
    )


def test_patch_with_missing_path_param_deal_ref_id(
    get_api_gateway_event,
    lambda_context,
    missing_deal_ref_path_param,
    mock_cache_attrs,
    mock_dynamodb_helper_deals,
    mock_validate_api_version,
    monkeypatch,
    startup_db_docs_helper,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        docs_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version,
    )
    monkeypatch.setattr(
        validators.ExistingDealValidator, "_cache_attrs", mock_cache_attrs
    )

    records = startup_db_docs_helper(SINGLE_DOC)
    copy_records = copy.deepcopy(records)

    document_id = copy_records["Items"][0]["documentId"]

    update_record = get_api_gateway_event({})
    update_record["path"] = "/v1/deals/dealRefId/documents/documentId"
    update_record["queryStringParameters"] = {}
    update_record["pathParameters"] = {"documentId": document_id}
    update_record["requestContext"] = {"operationName": "patch_document"}
    update_record["body"] = {"documentId": document_id, "documentType": "TEST"}
    update_record["body"] = json.dumps(update_record["body"])

    response = docs_lambda.docs_handlers(update_record, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert json.loads(response["body"]) == missing_deal_ref_path_param


def test_patch_with_missing_path_param_document_id(
    get_api_gateway_event,
    lambda_context,
    missing_document_id_path_param,
    mock_cache_attrs,
    mock_dynamodb_helper_deals,
    mock_validate_api_version,
    monkeypatch,
    startup_db_docs_helper,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        docs_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version,
    )
    monkeypatch.setattr(
        validators.ExistingDealValidator, "_cache_attrs", mock_cache_attrs
    )

    records = startup_db_docs_helper(SINGLE_DOC)
    copy_records = copy.deepcopy(records)

    deal_ref_id = copy_records["Items"][0]["documentId"]

    update_record = get_api_gateway_event({})
    update_record["path"] = "/v1/deals/dealRefId/documents/documentId"
    update_record["queryStringParameters"] = {}
    update_record["pathParameters"] = {"dealRefId": deal_ref_id}
    update_record["requestContext"] = {"operationName": "patch_document"}
    update_record["body"] = {"dealRefId": deal_ref_id, "documentType": "TEST"}
    update_record["body"] = json.dumps(update_record["body"])

    response = docs_lambda.docs_handlers(update_record, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert json.loads(response["body"]) == missing_document_id_path_param


def test_patch_with_no_body(
    get_api_gateway_event,
    lambda_context,
    missing_body_message,
    mock_cache_attrs,
    mock_dynamodb_helper_deals,
    mock_validate_api_version,
    monkeypatch,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        docs_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version,
    )
    monkeypatch.setattr(
        validators.ExistingDealValidator, "_cache_attrs", mock_cache_attrs
    )

    deal_ref_id = ulid.new().str
    document_id = ulid.new().str

    update_record = get_api_gateway_event({})
    update_record["path"] = "/v1/deals/dealRefId/documents/documentId"
    update_record["queryStringParameters"] = {}
    update_record["pathParameters"] = {
        "dealRefId": deal_ref_id,
        "documentId": document_id,
    }
    update_record["requestContext"] = {"operationName": "patch_document"}

    response = docs_lambda.docs_handlers(update_record, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert json.loads(response["body"]) == missing_body_message


def test_patch_session(
    dynamodb,
    get_api_gateway_event,
    lambda_context,
    mock_cache_attrs,
    mock_dynamodb_helper_deals,
    mock_validate_api_version,
    monkeypatch,
    startup_db_docs_helper,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        docs_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version,
    )
    monkeypatch.setattr(
        validators.ExistingDealValidator,
        "_cache_attrs",
        mock_cache_attrs,
    )

    records = startup_db_docs_helper(SESSION_DOC)
    copy_records = copy.deepcopy(records)

    deal_ref_id = copy_records["Items"][0]["dealRefId"]
    session_id = copy_records["Items"][0]["sessionId"]
    deal_component = f"DTC.DOCS.UPLOADS.{session_id}"
    document_type = copy_records["Items"][0]["documentType"]

    update_record = get_api_gateway_event({})
    update_record["path"] = "/v1/deals/dealRefId/uploads/sessionId"
    update_record["queryStringParameters"] = {}
    update_record["pathParameters"] = {
        "dealRefId": deal_ref_id,
        "sessionId": deal_component,
    }
    update_record["requestContext"] = {"operationName": "patch_session"}
    update_record["body"] = {"documentType": "TEST"}
    update_record["body"] = json.dumps(update_record["body"])

    response = docs_lambda.docs_handlers(update_record, lambda_context)
    update_records = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()

    new_deal_ref_id = update_records["Items"][0]["dealRefId"]
    new_document_type = update_records["Items"][0]["documentType"]

    assert response["statusCode"] == HTTPStatus.NO_CONTENT
    assert deal_ref_id == new_deal_ref_id
    assert new_document_type != document_type


def test_patch_session_no_resources(
    docs_single_payload,
    get_api_gateway_event,
    lambda_context,
    monkeypatch,
    mock_cache_attrs,
    mock_validate_api_version,
    mock_dynamodb_helper_deals,
    no_resources_found_response,
    startup_db_docs_helper,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        docs_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version,
    )
    monkeypatch.setattr(
        validators.ExistingDealValidator,
        "_cache_attrs",
        mock_cache_attrs,
    )

    records = startup_db_docs_helper(SESSION_DOC)
    copy_records = copy.deepcopy(records)

    deal_ref_id = "INVALID_DEAL_REF"
    session_id = copy_records["Items"][0]["sessionId"]

    update_record = get_api_gateway_event({})
    update_record["path"] = "/v1/deals/dealRefId/uploads/sessionId"
    update_record["queryStringParameters"] = {}
    update_record["pathParameters"] = {
        "dealRefId": deal_ref_id,
        "sessionId": session_id,
    }
    update_record["requestContext"] = {"operationName": "patch_session"}
    update_record["body"] = json.dumps(docs_single_payload)

    response = docs_lambda.docs_handlers(update_record, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert json.loads(response["body"]) == no_resources_found_response(
        deal_ref_id, field="sessionId", value=session_id
    )


def test_patch_session_missing_path_param_session_id(
    docs_single_payload,
    get_api_gateway_event,
    lambda_context,
    missing_session_id_path_param,
    mock_cache_attrs,
    mock_validate_api_version,
    mock_dynamodb_helper_deals,
    monkeypatch,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        docs_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version,
    )
    monkeypatch.setattr(
        validators.ExistingDealValidator,
        "_cache_attrs",
        mock_cache_attrs,
    )

    deal_ref_id = ulid.new().str

    update_record = get_api_gateway_event({})
    update_record["path"] = "/v1/deals/dealRefId/uploads/sessionId"
    update_record["queryStringParameters"] = {}
    update_record["pathParameters"] = {"dealRefId": deal_ref_id}
    update_record["requestContext"] = {"operationName": "patch_session"}
    update_record["body"] = json.dumps(docs_single_payload)

    response = docs_lambda.docs_handlers(update_record, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert json.loads(response["body"]) == missing_session_id_path_param


def test_patch_session_missing_path_param_deal_ref_id(
    docs_single_payload,
    get_api_gateway_event,
    lambda_context,
    missing_deal_ref_path_param,
    mock_cache_attrs,
    mock_validate_api_version,
    mock_dynamodb_helper_deals,
    monkeypatch,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        docs_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version,
    )
    monkeypatch.setattr(
        validators.ExistingDealValidator,
        "_cache_attrs",
        mock_cache_attrs,
    )

    session_id = ulid.new().str

    update_record = get_api_gateway_event({})
    update_record["path"] = "/v1/deals/dealRefId/uploads/sessionId"
    update_record["queryStringParameters"] = {}
    update_record["pathParameters"] = {"sessionId": session_id}
    update_record["requestContext"] = {"operationName": "patch_session"}
    update_record["body"] = json.dumps(docs_single_payload)

    response = docs_lambda.docs_handlers(update_record, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert json.loads(response["body"]) == missing_deal_ref_path_param
