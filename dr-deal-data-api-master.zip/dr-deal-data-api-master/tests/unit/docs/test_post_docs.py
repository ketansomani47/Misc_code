# -*- coding: utf-8 -*-
import json
from http import HTTPStatus

import pytest
from common import deal_consumer, validators
from common.settings import DOCS_CUSTOMER_TYPES
from docs import docs_lambda
from tests.functional.service_api import ServiceAPI
from tests.unit.docs.conftest import SESSION_DOC, SINGLE_DOC
from utils import db_helper


def test_post_document_success_dtc(
    get_api_gateway_event,
    lambda_context,
    dynamodb,
    monkeypatch,
    mock_dynamodb_helper_deals,
    mock_validate_api_version,
    mock_cache_attrs,
    post_doc_payload,
    post_doc_headers,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        docs_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version,
    )
    monkeypatch.setattr(
        validators.ExistingDealValidator,
        "_cache_attrs",
        mock_cache_attrs,
    )
    before_call = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()
    assert not before_call["Items"]

    deal_ref_id = ServiceAPI.generate_random_id()

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/dealRefId/documents"
    event["pathParameters"] = {"dealRefId": deal_ref_id}
    event["requestContext"] = {"operationName": "post_document"}
    event["headers"] = post_doc_headers(SINGLE_DOC)
    event["body"] = post_doc_payload

    event["body"] = json.dumps(event["body"])

    response = docs_lambda.docs_handlers(event, lambda_context)
    resp_body = json.loads(response["body"])

    assert response["statusCode"] == HTTPStatus.CREATED

    after_call = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()[
        "Items"
    ]

    assert len(after_call) == 1
    suffix = "DOCS.APP.DRIVERSLICENSE"
    dtc_record = [
        record for record in after_call if record["dealComponent"] == f"DTC.{suffix}"
    ][0]
    assert resp_body["dealRefId"] == dtc_record["dealRefId"]
    assert "UPLOADS" not in dtc_record["dealComponent"]
    assert "pages" not in dtc_record


def test_post_document_success_alternate_platform_no_session(
    get_api_gateway_event,
    lambda_context,
    dynamodb,
    monkeypatch,
    mock_dynamodb_helper_deals,
    mock_validate_api_version,
    mock_cache_attrs,
    post_doc_payload,
    post_doc_headers,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        docs_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version,
    )
    monkeypatch.setattr(
        validators.ExistingDealValidator,
        "_cache_attrs",
        mock_cache_attrs,
    )
    before_call = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()
    assert not before_call["Items"]

    deal_ref_id = ServiceAPI.generate_random_id()

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/dealRefId/documents"
    event["pathParameters"] = {"dealRefId": deal_ref_id}
    event["requestContext"] = {"operationName": "post_document"}
    event["headers"] = post_doc_headers(SINGLE_DOC)
    event["body"] = post_doc_payload
    event["body"]["targetPlatforms"] = [{"id": "IDL"}]
    event["body"] = json.dumps(event["body"])

    response = docs_lambda.docs_handlers(event, lambda_context)
    resp_body = json.loads(response["body"])

    assert response["statusCode"] == HTTPStatus.CREATED

    after_call = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()[
        "Items"
    ]

    assert len(after_call) == 1
    suffix = "DOCS.APP.DRIVERSLICENSE"
    idl_record = [
        record for record in after_call if record["dealComponent"] == f"IDL.{suffix}"
    ][0]
    assert resp_body["dealRefId"] == idl_record["dealRefId"]
    assert "UPLOADS" not in idl_record["dealComponent"]
    assert "pages" not in idl_record


def test_post_document_invalid_deal_ref(
    get_api_gateway_event,
    lambda_context,
    dynamodb,
    monkeypatch,
    mock_dynamodb_helper_deals,
    mock_validate_api_version,
    post_doc_payload,
    post_doc_headers,
    invalid_deal_ref_id_response,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        docs_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version,
    )

    before_call = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()
    assert len(before_call["Items"]) == 0

    deal_ref_id = ServiceAPI.generate_random_id()

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/dealRefId/documents"
    event["pathParameters"] = {"dealRefId": deal_ref_id}
    event["requestContext"] = {"operationName": "post_document"}
    event["headers"] = post_doc_headers(SINGLE_DOC)
    event["body"] = post_doc_payload

    event["body"] = json.dumps(event["body"])

    response = docs_lambda.docs_handlers(event, lambda_context)
    resp_body = json.loads(response["body"])

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert resp_body == invalid_deal_ref_id_response(deal_ref_id)

    after_call = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()
    assert not after_call["Items"]


@pytest.mark.parametrize(
    "required_field", ["documentType", "customerRole", "uploadStatus"]
)
def test_post_document_missing_body_fields(
    get_api_gateway_event,
    lambda_context,
    dynamodb,
    monkeypatch,
    mock_dynamodb_helper_deals,
    mock_validate_api_version,
    post_doc_payload,
    post_doc_headers,
    missing_body_fields_docs_resp,
    required_field,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        docs_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version,
    )

    before_call = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()
    assert len(before_call["Items"]) == 0

    deal_ref_id = ServiceAPI.generate_random_id()

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/dealRefId/documents"
    event["pathParameters"] = {"dealRefId": deal_ref_id}
    event["requestContext"] = {"operationName": "post_document"}
    event["headers"] = post_doc_headers(SINGLE_DOC)
    event["body"] = post_doc_payload
    del event["body"][required_field]

    event["body"] = json.dumps(event["body"])

    response = docs_lambda.docs_handlers(event, lambda_context)
    resp_body = json.loads(response["body"])

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert resp_body == missing_body_fields_docs_resp(
        ["documentType", "customerRole", "uploadStatus"]
    )

    after_call = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()
    assert not after_call["Items"]


def test_post_document_already_exists(
    get_api_gateway_event,
    lambda_context,
    dynamodb,
    monkeypatch,
    mock_dynamodb_helper_deals,
    mock_validate_api_version,
    mock_cache_attrs,
    post_doc_payload,
    post_doc_headers,
    post_duplicate_document_resp,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        docs_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version,
    )
    monkeypatch.setattr(
        validators.ExistingDealValidator,
        "_cache_attrs",
        mock_cache_attrs,
    )
    before_call = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()
    assert not before_call["Items"]

    deal_ref_id = ServiceAPI.generate_random_id()

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/dealRefId/documents"
    event["pathParameters"] = {"dealRefId": deal_ref_id}
    event["requestContext"] = {"operationName": "post_document"}
    event["headers"] = post_doc_headers(SINGLE_DOC)
    event["body"] = post_doc_payload

    event["body"] = json.dumps(event["body"])

    response = docs_lambda.docs_handlers(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.CREATED

    response = docs_lambda.docs_handlers(event, lambda_context)
    err_msg = json.loads(response["body"])

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert err_msg == post_duplicate_document_resp


def test_post_document_invalid_customer_type(
    get_api_gateway_event,
    lambda_context,
    dynamodb,
    monkeypatch,
    mock_dynamodb_helper_deals,
    mock_validate_api_version,
    mock_cache_attrs,
    post_doc_payload,
    post_doc_headers,
    invalid_customer_role_docs_resp,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        docs_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version,
    )
    monkeypatch.setattr(
        validators.ExistingDealValidator,
        "_cache_attrs",
        mock_cache_attrs,
    )
    before_call = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()
    assert not before_call["Items"]

    deal_ref_id = ServiceAPI.generate_random_id()

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/dealRefId/documents"
    event["pathParameters"] = {"dealRefId": deal_ref_id}
    event["requestContext"] = {"operationName": "post_document"}
    event["headers"] = post_doc_headers(SESSION_DOC)
    event["body"] = post_doc_payload
    event["body"]["customerRole"] = "Invalid"

    event["body"] = json.dumps(event["body"])

    response = docs_lambda.docs_handlers(event, lambda_context)
    resp_body = json.loads(response["body"])

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert resp_body == invalid_customer_role_docs_resp(
        list(DOCS_CUSTOMER_TYPES.keys())
    )


def test_post_session_no_body_tp(
    get_api_gateway_event,
    lambda_context,
    dynamodb,
    monkeypatch,
    mock_dynamodb_helper_deals,
    mock_validate_api_version,
    mock_cache_attrs,
    post_doc_payload,
    post_doc_headers,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        docs_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version,
    )
    monkeypatch.setattr(
        validators.ExistingDealValidator,
        "_cache_attrs",
        mock_cache_attrs,
    )
    before_call = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()
    assert not before_call["Items"]

    deal_ref_id = ServiceAPI.generate_random_id()

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/dealRefId/uploads"
    event["pathParameters"] = {"dealRefId": deal_ref_id}
    event["requestContext"] = {"operationName": "post_document"}
    event["headers"] = post_doc_headers(SESSION_DOC)
    event["body"] = post_doc_payload

    event["body"] = json.dumps(event["body"])

    response = docs_lambda.docs_handlers(event, lambda_context)
    resp_body = json.loads(response["body"])

    assert response["statusCode"] == HTTPStatus.CREATED

    after_call = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()[
        "Items"
    ]

    assert len(after_call) == 2

    for record in after_call:
        if record["dealComponent"].startswith("DTC.DOCS.UPLOADS"):
            posted_session = record
        else:
            posted_document = record
    assert resp_body["dealRefId"] == posted_session["dealRefId"]
    assert resp_body["dealRefId"] == posted_document["dealRefId"]

    assert "sessionId" not in posted_document

    assert "pages" in posted_session
    assert len(posted_session["pages"]) == int(event["headers"]["pageCount"])


def test_post_session_dtc(
    get_api_gateway_event,
    lambda_context,
    dynamodb,
    monkeypatch,
    mock_dynamodb_helper_deals,
    mock_validate_api_version,
    mock_cache_attrs,
    post_doc_payload,
    post_doc_headers,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        docs_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version,
    )
    monkeypatch.setattr(
        validators.ExistingDealValidator,
        "_cache_attrs",
        mock_cache_attrs,
    )
    before_call = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()
    assert not before_call["Items"]

    deal_ref_id = ServiceAPI.generate_random_id()

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/dealRefId/uploads"
    event["pathParameters"] = {"dealRefId": deal_ref_id}
    event["requestContext"] = {"operationName": "post_document"}
    event["headers"] = post_doc_headers(SESSION_DOC)
    event["body"] = post_doc_payload

    event["body"] = json.dumps(event["body"])

    response = docs_lambda.docs_handlers(event, lambda_context)
    resp_body = json.loads(response["body"])

    assert response["statusCode"] == HTTPStatus.CREATED

    after_call = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()[
        "Items"
    ]

    # only DTC record and tp specific session
    assert len(after_call) == 2

    posted_session, posted_document = {}, {}
    for record in after_call:
        if record["dealComponent"].startswith("DTC.DOCS.UPLOADS"):
            posted_session = record
        else:
            posted_document = record
    assert resp_body["dealRefId"] == posted_session["dealRefId"]
    assert resp_body["dealRefId"] == posted_document["dealRefId"]

    assert "sessionId" not in posted_document

    assert "pages" in posted_session
    assert len(posted_session["pages"]) == int(event["headers"]["pageCount"])


def test_post_session_alternate_platform(
    get_api_gateway_event,
    lambda_context,
    dynamodb,
    monkeypatch,
    mock_dynamodb_helper_deals,
    mock_validate_api_version,
    mock_cache_attrs,
    post_doc_payload,
    post_doc_headers,
):
    idl_tp = "IDL"
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        docs_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version,
    )
    monkeypatch.setattr(
        validators.ExistingDealValidator,
        "_cache_attrs",
        mock_cache_attrs,
    )
    before_call = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()
    assert not before_call["Items"]

    deal_ref_id = ServiceAPI.generate_random_id()

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/dealRefId/uploads"
    event["pathParameters"] = {"dealRefId": deal_ref_id}
    event["requestContext"] = {"operationName": "post_document"}
    event["headers"] = post_doc_headers(SESSION_DOC)
    event["body"] = post_doc_payload
    event["body"]["targetPlatforms"] = [{"id": idl_tp}]
    event["body"] = json.dumps(event["body"])

    response = docs_lambda.docs_handlers(event, lambda_context)
    resp_body = json.loads(response["body"])

    assert response["statusCode"] == HTTPStatus.CREATED

    after_call = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()[
        "Items"
    ]
    assert len(after_call) == 2
    posted_document = [
        record
        for record in after_call
        if record["dealComponent"] == f"{idl_tp}.DOCS.APP.W2"
    ]

    posted_session = [
        record
        for record in after_call
        if record["dealComponent"].startswith(f"{idl_tp}.DOCS.UPLOADS")
    ][0]
    assert "sessionId" not in posted_document
    assert "pages" in posted_session
    assert resp_body["dealRefId"] == posted_session["dealRefId"]
    assert len(posted_session["pages"]) == int(event["headers"]["pageCount"])


def test_post_session_invalid_page_count(
    get_api_gateway_event,
    lambda_context,
    dynamodb,
    monkeypatch,
    mock_dynamodb_helper_deals,
    mock_validate_api_version,
    mock_cache_attrs,
    post_doc_payload,
    post_doc_headers,
    invalid_page_count_docs_resp,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        docs_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version,
    )
    monkeypatch.setattr(
        validators.ExistingDealValidator,
        "_cache_attrs",
        mock_cache_attrs,
    )
    before_call = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()
    assert not before_call["Items"]

    deal_ref_id = ServiceAPI.generate_random_id()

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/dealRefId/uploads"
    event["pathParameters"] = {"dealRefId": deal_ref_id}
    event["requestContext"] = {"operationName": "post_document"}
    event["headers"] = post_doc_headers(SESSION_DOC)
    event["headers"]["pageCount"] = "five"
    event["body"] = post_doc_payload

    event["body"] = json.dumps(event["body"])

    response = docs_lambda.docs_handlers(event, lambda_context)
    resp_body = json.loads(response["body"])

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert resp_body == invalid_page_count_docs_resp


def test_post_session_doc_already_exists(
    get_api_gateway_event,
    lambda_context,
    dynamodb,
    monkeypatch,
    mock_dynamodb_helper_deals,
    mock_validate_api_version,
    mock_cache_attrs,
    post_doc_payload,
    post_doc_headers,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        docs_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version,
    )
    monkeypatch.setattr(
        validators.ExistingDealValidator,
        "_cache_attrs",
        mock_cache_attrs,
    )

    # First we POST only a document
    before_call = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()
    assert not before_call["Items"]

    deal_ref_id = ServiceAPI.generate_random_id()

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/dealRefId/documents"
    event["pathParameters"] = {"dealRefId": deal_ref_id}
    event["requestContext"] = {"operationName": "post_document"}
    event["headers"] = post_doc_headers(SINGLE_DOC)
    event["body"] = post_doc_payload

    event["body"] = json.dumps(event["body"])

    response = docs_lambda.docs_handlers(event, lambda_context)
    resp_body = json.loads(response["body"])

    assert response["statusCode"] == HTTPStatus.CREATED

    after_call = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()[
        "Items"
    ]

    assert len(after_call) == 1
    assert resp_body["dealRefId"] == after_call[0]["dealRefId"]
    assert "UPLOADS" not in after_call[0]["dealComponent"]
    assert "pages" not in after_call[0]

    # Now we post again but with a pageCount this time, specifying we want to upload a session.
    # Since there is already a document under this dealRefId, only a session should be created.
    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/dealRefId/uploads"
    event["pathParameters"] = {"dealRefId": resp_body["dealRefId"]}
    event["requestContext"] = {"operationName": "post_document"}
    event["headers"] = post_doc_headers(SESSION_DOC)
    event["body"] = post_doc_payload
    event["body"].pop("tags")
    event["body"].pop("extensionFields")
    event["body"].pop("uploadStatus")
    event["body"] = json.dumps(event["body"])

    response = docs_lambda.docs_handlers(event, lambda_context)
    resp_body = json.loads(response["body"])

    assert response["statusCode"] == HTTPStatus.CREATED

    after_call = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()[
        "Items"
    ]

    assert len(after_call) == 2

    posted_session = (
        after_call[0]
        if after_call[0]["dealComponent"].startswith("DTC.DOCS.UPLOADS")
        else after_call[1]
    )

    assert resp_body["dealRefId"] == posted_session["dealRefId"]
    assert "pages" in posted_session
    assert len(posted_session["pages"]) == int(event["headers"]["pageCount"])
