# -*- coding: utf-8 -*-
import copy
import json
from http import HTTPStatus

from common.settings import HEALTHCHECK_HEADER_FIELD, HEALTHCHECK_HEADER_VALUE
from docs import docs_lambda
from tests.unit.docs.conftest import MULTIPLE_DOCS, SESSION_DOC, SINGLE_DOC
from utils import db_helper


def test_docs_health_check(lambda_context):
    event = {
        "headers": {HEALTHCHECK_HEADER_FIELD: HEALTHCHECK_HEADER_VALUE},
        "path": "/v1/deals/dealRefId/documents/",
    }

    response = docs_lambda.docs_handlers(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.OK
    assert response["body"] == json.dumps("Operational")


def test_get_single_doc(
    startup_db_docs_helper,
    get_api_gateway_event,
    lambda_context,
    monkeypatch,
    dr_ulid,
    mock_validate_api_version,
    mock_dynamodb_helper_deals,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        docs_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version,
    )

    records = startup_db_docs_helper(SINGLE_DOC, target_platform="IDL")
    copy_records = copy.deepcopy(records)
    document_id = copy_records["Items"][0]["documentId"]
    customer_role = copy_records["Items"][0]["customerRole"]
    document_type = copy_records["Items"][0]["documentType"]

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/dealRefId/documents/documentId"
    event["queryStringParameters"] = {}
    event["pathParameters"] = {"dealRefId": dr_ulid, "documentId": "IDL.DOCS.W2.APP"}
    event["requestContext"] = {"operationName": "get_single_document"}

    response = docs_lambda.docs_handlers(event, lambda_context)
    body = json.loads(response["body"])[0]

    assert response["statusCode"] == HTTPStatus.OK
    assert body["documentId"] == document_id
    assert body["customerRole"] == customer_role
    assert body["documentType"] == document_type


def test_get_single_doc_invalid_deal_ref(
    startup_db_docs_helper,
    get_api_gateway_event,
    lambda_context,
    monkeypatch,
    mock_dynamodb_helper_deals,
    mock_validate_api_version_invalid_dealrefid,
    generic_invalid_dealref_id,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        docs_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version_invalid_dealrefid,
    )

    records = startup_db_docs_helper(SINGLE_DOC)
    copy_records = copy.deepcopy(records)

    deal_ref_id = "INVALID_DEAL_REF"
    document_id = copy_records["Items"][0]["documentId"]

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/dealRefId/documents/documentId"
    event["queryStringParameters"] = {}
    event["pathParameters"] = {"dealRefId": deal_ref_id, "documentId": document_id}
    event["requestContext"] = {"operationName": "get_single_document"}

    response = docs_lambda.docs_handlers(event, lambda_context)
    body = json.loads(response["body"])

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert body == generic_invalid_dealref_id


def test_get_single_doc_invalid_document_id(
    startup_db_docs_helper,
    get_api_gateway_event,
    lambda_context,
    monkeypatch,
    dr_ulid,
    mock_validate_api_version,
    mock_dynamodb_helper_deals,
    no_resources_found_response,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        docs_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version,
    )

    startup_db_docs_helper(SINGLE_DOC)

    deal_ref_id = dr_ulid
    document_id = "INVALID_DOCUMENT_ID"

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/dealRefId/documents/documentId"
    event["queryStringParameters"] = {}
    event["pathParameters"] = {"dealRefId": deal_ref_id, "documentId": document_id}
    event["requestContext"] = {"operationName": "get_single_document"}

    response = docs_lambda.docs_handlers(event, lambda_context)
    message = json.loads(response["body"])

    assert response["statusCode"] == HTTPStatus.NOT_FOUND
    assert message == no_resources_found_response(
        deal_ref_id, field="documentId", value=document_id
    )


def test_get_documents(
    startup_db_docs_helper,
    get_api_gateway_event,
    lambda_context,
    monkeypatch,
    dr_ulid,
    mock_validate_api_version,
    mock_dynamodb_helper_deals,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        docs_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version,
    )
    startup_db_docs_helper(MULTIPLE_DOCS)
    deal_ref_id = dr_ulid

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/dealRefId/documents/"
    event["queryStringParameters"] = {}
    event["pathParameters"] = {"dealRefId": deal_ref_id}
    event["requestContext"] = {"operationName": "get_documents"}

    response = docs_lambda.docs_handlers(event, lambda_context)
    body = json.loads(response["body"])

    assert response["statusCode"] == HTTPStatus.OK
    assert len(body) == 3
    for item in body:
        assert deal_ref_id == item["dealRefId"]


def test_get_documents_idl(
    startup_db_docs_helper,
    get_api_gateway_event,
    lambda_context,
    monkeypatch,
    dr_ulid,
    mock_validate_api_version,
    mock_dynamodb_helper_deals,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        docs_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version,
    )
    startup_db_docs_helper(MULTIPLE_DOCS, target_platform="IDL")
    deal_ref_id = dr_ulid

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/dealRefId/documents/"
    event["queryStringParameters"] = {}
    event["pathParameters"] = {"dealRefId": deal_ref_id}
    event["requestContext"] = {"operationName": "get_documents"}

    response = docs_lambda.docs_handlers(event, lambda_context)
    body = json.loads(response["body"])

    assert response["statusCode"] == HTTPStatus.OK
    assert len(body) == 3
    for item in body:
        assert deal_ref_id == item["dealRefId"]


def test_get_docs_with_query_params(
    startup_db_docs_helper,
    get_api_gateway_event,
    lambda_context,
    monkeypatch,
    dr_ulid,
    mock_validate_api_version,
    mock_dynamodb_helper_deals,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        docs_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version,
    )

    startup_db_docs_helper(MULTIPLE_DOCS)

    deal_ref_id = dr_ulid

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/dealRefId/documents"
    event["queryStringParameters"] = {"documentType": "InsuranceCard"}
    event["pathParameters"] = {"dealRefId": deal_ref_id}
    event["requestContext"] = {"operationName": "get_documents"}

    response = docs_lambda.docs_handlers(event, lambda_context)
    body = json.loads(response["body"])

    assert response["statusCode"] == HTTPStatus.OK
    assert body[0]["dealRefId"] == deal_ref_id
    assert body[0]["dealComponent"] == "DTC.DOCS.GEN.INSURANCECARD"
    assert len(body) == 1


def test_get_docs_with_query_params_tags(
    startup_db_docs_helper,
    get_api_gateway_event,
    lambda_context,
    monkeypatch,
    dr_ulid,
    mock_validate_api_version,
    mock_dynamodb_helper_deals,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        docs_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version,
    )

    startup_db_docs_helper(MULTIPLE_DOCS)

    deal_ref_id = dr_ulid

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/dealRefId/documents"
    event["queryStringParameters"] = {"tags": "CA"}
    event["pathParameters"] = {"dealRefId": deal_ref_id}
    event["requestContext"] = {"operationName": "get_documents"}

    response = docs_lambda.docs_handlers(event, lambda_context)
    body = json.loads(response["body"])

    assert response["statusCode"] == HTTPStatus.OK
    assert body[0]["dealRefId"] == deal_ref_id
    assert body[0]["dealComponent"] == "DTC.DOCS.GEN.INSURANCECARD"
    assert len(body) == 1


def test_get_docs_with_invalid_query_params(
    startup_db_docs_helper,
    get_api_gateway_event,
    lambda_context,
    monkeypatch,
    dr_ulid,
    mock_validate_api_version,
    mock_dynamodb_helper_deals,
    invalid_query_params_docs,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        docs_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version,
    )

    startup_db_docs_helper(MULTIPLE_DOCS)

    deal_ref_id = dr_ulid

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/dealRefId/documents"
    event["queryStringParameters"] = {"notValidQueryParam": "Test"}
    event["pathParameters"] = {"dealRefId": deal_ref_id}
    event["requestContext"] = {"operationName": "get_documents"}

    response = docs_lambda.docs_handlers(event, lambda_context)
    body = json.loads(response["body"])

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert body == invalid_query_params_docs


def test_get_docs_with_invalid_deal_ref(
    startup_db_docs_helper,
    get_api_gateway_event,
    lambda_context,
    monkeypatch,
    mock_dynamodb_helper_deals,
    mock_validate_api_version_invalid_dealrefid,
    generic_invalid_dealref_id,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        docs_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version_invalid_dealrefid,
    )

    startup_db_docs_helper(MULTIPLE_DOCS)

    deal_ref_id = "INVALID_DEAL_REF"

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/dealRefId/documents"
    event["queryStringParameters"] = {}
    event["pathParameters"] = {"dealRefId": deal_ref_id}
    event["requestContext"] = {"operationName": "get_documents"}

    response = docs_lambda.docs_handlers(event, lambda_context)
    body = json.loads(response["body"])

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert body == generic_invalid_dealref_id


def test_get_session(
    startup_db_docs_helper,
    get_api_gateway_event,
    lambda_context,
    monkeypatch,
    dr_ulid,
    mock_validate_api_version,
    mock_dynamodb_helper_deals,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        docs_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version,
    )

    records = startup_db_docs_helper(SESSION_DOC)
    copy_records = copy.deepcopy(records)

    session_id = copy_records["Items"][0]["sessionId"]
    deal_component = f"DTC.DOCS.UPLOADS.{session_id}"
    document_id = copy_records["Items"][0]["documentId"]
    customer_role = copy_records["Items"][0]["customerRole"]
    document_type = copy_records["Items"][0]["documentType"]

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/dealRefId/uploads/sessionId"
    event["queryStringParameters"] = {}
    event["pathParameters"] = {"dealRefId": dr_ulid, "sessionId": deal_component}
    event["requestContext"] = {"operationName": "get_session"}

    response = docs_lambda.docs_handlers(event, lambda_context)
    body = json.loads(response["body"])[0]

    assert response["statusCode"] == HTTPStatus.OK
    assert body["documentId"] == document_id
    assert body["sessionId"] == session_id
    assert body["customerRole"] == customer_role
    assert body["documentType"] == document_type
    assert "1" in body["pages"] and "2" in body["pages"]


def test_get_session_idl(
    startup_db_docs_helper,
    get_api_gateway_event,
    lambda_context,
    monkeypatch,
    dr_ulid,
    mock_validate_api_version,
    mock_dynamodb_helper_deals,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        docs_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version,
    )

    records = startup_db_docs_helper(SESSION_DOC, target_platform="IDL")
    copy_records = copy.deepcopy(records)
    session_id = copy_records["Items"][0]["sessionId"]
    deal_component = f"IDL.DOCS.UPLOADS.{session_id}"
    document_id = copy_records["Items"][0]["documentId"]
    customer_role = copy_records["Items"][0]["customerRole"]
    document_type = copy_records["Items"][0]["documentType"]

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/dealRefId/uploads/sessionId"
    event["queryStringParameters"] = {}
    event["pathParameters"] = {"dealRefId": dr_ulid, "sessionId": deal_component}
    event["requestContext"] = {"operationName": "get_session"}

    response = docs_lambda.docs_handlers(event, lambda_context)
    body = json.loads(response["body"])[0]

    assert response["statusCode"] == HTTPStatus.OK
    assert body["documentId"] == document_id
    assert body["sessionId"] == session_id
    assert body["customerRole"] == customer_role
    assert body["documentType"] == document_type
    assert "1" in body["pages"] and "2" in body["pages"]


def test_get_session_invalid_deal_ref(
    startup_db_docs_helper,
    get_api_gateway_event,
    lambda_context,
    monkeypatch,
    mock_validate_api_version_invalid_dealrefid,
    mock_dynamodb_helper_deals,
    generic_invalid_dealref_id,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        docs_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version_invalid_dealrefid,
    )

    records = startup_db_docs_helper(SESSION_DOC)
    copy_records = copy.deepcopy(records)

    deal_ref_id = "INVALID_DEAL_REF"
    session_id = copy_records["Items"][0]["sessionId"]

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/dealRefId/uploads/sessionId"
    event["queryStringParameters"] = {}
    event["pathParameters"] = {"dealRefId": deal_ref_id, "sessionId": session_id}
    event["requestContext"] = {"operationName": "get_session"}

    response = docs_lambda.docs_handlers(event, lambda_context)
    body = json.loads(response["body"])

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert body == generic_invalid_dealref_id


def test_get_session_invalid_session_id(
    startup_db_docs_helper,
    get_api_gateway_event,
    lambda_context,
    monkeypatch,
    dr_ulid,
    mock_validate_api_version,
    mock_dynamodb_helper_deals,
    no_resources_found_response,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        docs_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version,
    )

    startup_db_docs_helper(SESSION_DOC)

    deal_ref_id = dr_ulid
    session_id = "INVALID_SESSION_ID"

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/dealRefId/uploads/sessionId"
    event["queryStringParameters"] = {}
    event["pathParameters"] = {"dealRefId": deal_ref_id, "sessionId": session_id}
    event["requestContext"] = {"operationName": "get_session"}

    response = docs_lambda.docs_handlers(event, lambda_context)
    message = json.loads(response["body"])

    assert response["statusCode"] == HTTPStatus.NOT_FOUND
    assert message == no_resources_found_response(
        deal_ref_id, field="sessionId", value=session_id
    )
