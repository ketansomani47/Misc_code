# -*- coding: utf-8 -*-
import json
from http import HTTPStatus
from unittest.mock import patch

from common import settings as se
from decisions import payment_detail
from utils import exceptions


def test_get_health_check(lambda_context, payment_event):
    event = payment_event({}, operation="payment_detail_post")
    event["headers"] = {se.HEALTHCHECK_HEADER_FIELD: se.HEALTHCHECK_HEADER_VALUE}
    response = payment_detail.payment_detail_handler(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps("Operational")


@patch("common.lambda_base.logger")
@patch("decisions.payment_detail.common.store_to_s3")
@patch("decisions.payment_detail.ExistingDealValidator.validate_reference_ids")
@patch("decisions.payment_detail.ExistingDealValidator._cache_db_records")
def test_payment_detail_post_payload_success(
    mock_db_records,
    mock_validate_ref_ids,
    mock_s3_client,
    mock_logger,
    lambda_context,
    payment_response,
    payment_event,
):
    """
    Test to check successful post payment details.
    """
    event = payment_event(payment_response, operation="payment_detail_post")
    response = payment_detail.payment_detail_handler(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.CREATED


@patch("common.lambda_base.logger")
@patch("decisions.payment_detail.common.store_to_s3")
@patch("decisions.payment_detail.ExistingDealValidator.validate_reference_ids")
@patch("decisions.payment_detail.ExistingDealValidator._cache_db_records")
def test_payment_detail_post_empty_body_error(
    mock_db_records,
    mock_validate_ref_ids,
    mock_s3_client,
    mock_logger,
    lambda_context,
    missing_body_message,
    payment_event,
):
    """
    Test to check empty body error for post payment details.
    """
    event = payment_event({}, operation="payment_detail_post")
    response = payment_detail.payment_detail_handler(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert eval(json.loads(response["body"])["message"]) == missing_body_message


@patch("common.lambda_base.logger")
@patch("decisions.payment_detail.common.store_to_s3")
@patch("decisions.payment_detail.ExistingDealValidator.validate_reference_ids")
@patch("decisions.payment_detail.ExistingDealValidator._cache_db_records")
def test_payment_detail_post_exception(
    mock_db_records,
    mock_validate_ref_ids,
    mock_s3_exception,
    mock_logger,
    lambda_context,
    payment_response,
    payment_event,
):
    """
    Test to check exception for post payment details.
    """
    event = payment_event(payment_response, operation="payment_detail_post")
    mock_s3_exception.side_effect = exceptions.S3SaveError(
        se.ErrorMsgs.s3_save_error_msg.format(error="error raised in testing")
    )
    response = payment_detail.payment_detail_handler(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.INTERNAL_SERVER_ERROR
    assert "Error saving data to s3" in response["body"]


@patch("common.lambda_base.logger")
@patch("decisions.lender_decision.get_latest_decision_from_s3")
def test_payment_detail_get_success(
    mock_get_latest_decision,
    mock_logger,
    lambda_context,
    payment_event,
    s3_response,
):
    """
    Test for successful get payment details response.
    """
    mock_get_latest_decision.return_value = (HTTPStatus.OK, s3_response)
    response = payment_detail.payment_detail_handler(payment_event({}), lambda_context)
    assert response["statusCode"] == HTTPStatus.OK
    assert response["body"] == json.dumps(s3_response)
    mock_get_latest_decision.assert_called_once()


@patch("common.lambda_base.logger")
@patch("decisions.lender_decision.get_latest_decision_from_s3")
def test_get_payment_detail_bad_request(
    mock_get_latest_decision,
    mock_logger,
    lambda_context,
    payment_event,
):
    """
    Test for bad request error for get payment details.
    """
    mock_get_latest_decision.side_effect = exceptions.BadRequestError(
        "Bad Request Error"
    )
    response = payment_detail.payment_detail_handler(payment_event({}), lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert "Bad Request Error" in response["body"]


@patch("common.lambda_base.logger")
@patch("decisions.lender_decision.get_latest_decision_from_s3")
def test_get_payment_detail_internal_server_error(
    mock_get_latest_decision,
    mock_logger,
    lambda_context,
    payment_event,
):
    """
    Test for internal server error for get payment details.
    """
    mock_get_latest_decision.side_effect = Exception("Unexpected Error")
    response = payment_detail.payment_detail_handler(payment_event({}), lambda_context)
    assert response["statusCode"] == HTTPStatus.INTERNAL_SERVER_ERROR
    assert "Unexpected Error" in response["body"]
