# -*- coding: utf-8 -*-
import json
from http import HTTPStatus
from unittest.mock import patch

from common import settings as se
from decisions import lender_decision
from utils import exceptions


def test_lender_decision_get_payload_ok_pii_scrubbed(
    lambda_context,
    lender_decision_response,
    monkeypatch,
    boto3_s3_client,
    get_cd_gateway_event,
    lender_decision_response_pii_scrubbed,
):
    """
    Test to check successful get for lender decision.
    """
    event = get_cd_gateway_event({})

    monkeypatch.setattr(lender_decision.boto3, "client", boto3_s3_client)
    boto3_s3_client().put_object(
        Body=lender_decision_response,
        Bucket=lender_decision.Env.DEAL_BUCKET,
        Tagging="CD",
        ContentType="application/json",
        Key="VIN/PARTNERDEALERID/DEALREFID/CA/LENDERID/LATEST.json",
    )

    response = lender_decision.get_latest(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.OK
    assert response["body"] == lender_decision_response_pii_scrubbed


def test_lender_decision_get_payload_not_found(
    lambda_context,
    lender_decision_response,
    monkeypatch,
    boto3_s3_client,
    get_cd_gateway_event,
):
    """
    Test to check not found for lender decision.
    """
    event = get_cd_gateway_event({})
    event["pathParameters"] = {
        "dealRefId": "invalid",
        "partnerDealerId": "partnerDealerId",
        "lenderId": "lenderId",
    }
    monkeypatch.setattr(lender_decision.boto3, "client", boto3_s3_client)
    boto3_s3_client().put_object(
        Body=lender_decision_response,
        Bucket=lender_decision.Env.DEAL_BUCKET,
        Tagging="CD",
        ContentType="application/json",
        Key="VIN/PARTNERDEALERID/DEALREFID/CA/LENDERID/event.json",
    )

    response = lender_decision.get_latest(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.NOT_FOUND
    assert response["body"] == '{"message": "Not Found"}'


def test_get_health_check(lambda_context, get_cd_gateway_event):
    event = get_cd_gateway_event({})
    event["headers"] = {se.HEALTHCHECK_HEADER_FIELD: se.HEALTHCHECK_HEADER_VALUE}
    response = lender_decision.get_latest(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps("Operational")


def test_lender_decision_bad_request_error(
    lambda_context,
    lender_decision_response,
    monkeypatch,
    boto3_s3_client,
    get_cd_gateway_event,
):
    event = get_cd_gateway_event({})

    event["headers"].pop(se.CD_SOURCE_PARTNER)
    monkeypatch.setattr(lender_decision.boto3, "client", boto3_s3_client)
    boto3_s3_client().put_object(
        Body=lender_decision_response,
        Bucket=lender_decision.Env.DEAL_BUCKET,
        Tagging="CD",
        ContentType="application/json",
        Key="VIN/PARTNERDEALERID/DEALREFID/CA/LENDERID/event.json",
    )

    response = lender_decision.get_latest(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST


def test_lender_decision_exception(
    lambda_context,
    lender_decision_response,
    monkeypatch,
    boto3_s3_client,
    get_cd_gateway_event,
    return_exception,
):
    """
    Test to check successful get for lender decision.
    """
    event = get_cd_gateway_event({})

    monkeypatch.setattr(lender_decision.boto3, "client", boto3_s3_client)
    monkeypatch.setattr(
        lender_decision.ExistingDealValidator, "validate_header", return_exception
    )

    boto3_s3_client().put_object(
        Body=lender_decision_response,
        Bucket=lender_decision.Env.DEAL_BUCKET,
        Tagging="CD",
        ContentType="application/json",
        Key="VIN/PARTNERDEALERID/DEALREFID/CA/LENDERID/event.json",
    )

    response = lender_decision.get_latest(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.INTERNAL_SERVER_ERROR
    assert response["body"] == '{"message": "Unable to process request"}'


def test_get_health_check_fld(lambda_context, fld_event):
    event = fld_event({}, operation="fld_with_credit_app_get")
    event["headers"] = {se.HEALTHCHECK_HEADER_FIELD: se.HEALTHCHECK_HEADER_VALUE}
    response = lender_decision.fld_with_credit_app_handler(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps("Operational")


@patch("common.lambda_base.logger")
@patch("decisions.lender_decision.get_latest_decision_from_s3")
def test_fld_with_credit_app_get_success(
    mock_get_latest_decision,
    mock_logger,
    lambda_context,
    fld_event,
    s3_response,
):
    """
    Test for successful get payment details response.
    """
    mock_get_latest_decision.return_value = (HTTPStatus.OK, s3_response)
    response = lender_decision.fld_with_credit_app_handler(
        fld_event({}), lambda_context
    )
    assert response["statusCode"] == HTTPStatus.OK
    assert response["body"] == json.dumps(s3_response)
    mock_get_latest_decision.assert_called_once()


@patch("common.lambda_base.logger")
@patch("decisions.lender_decision.get_latest_decision_from_s3")
def test_fld_with_credit_app_bad_request(
    mock_get_latest_decision,
    mock_logger,
    lambda_context,
    fld_event,
):
    """
    Test for bad request error for get payment details.
    """
    mock_get_latest_decision.side_effect = exceptions.BadRequestError(
        "Bad Request Error"
    )
    response = lender_decision.fld_with_credit_app_handler(
        fld_event({}), lambda_context
    )
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert "Bad Request Error" in response["body"]
