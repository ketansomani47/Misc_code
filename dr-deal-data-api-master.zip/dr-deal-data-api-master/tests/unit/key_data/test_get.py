# -*- coding: utf-8 -*-
import json
from http import HTTPStatus

import pytest
from common.settings import (
    HEALTHCHECK_HEADER_FIELD,
    HEALTHCHECK_HEADER_VALUE,
    ErrorMsgs,
)
from key_data import get
from utils.db_helper import DynamoDbHelper


query_string_list = ["dealJacketId", "dealRefId", "leadRefId"]


@pytest.mark.parametrize("query_string", query_string_list)
def test_key_data_get_payload_without_target_platform(
    lambda_context,
    monkeypatch,
    key_data_db_query_items,
    get_api_gateway_event,
    response_header,
    uuid_provided,
    query_string,
):
    """
    Test to check successful persistence and GET for cross reference records
    """
    monkeypatch.setattr(DynamoDbHelper, "query_items", key_data_db_query_items)

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/key-data/"
    event["queryStringParameters"] = {
        query_string: key_data_db_query_items()[0][query_string]
    }

    response = get.key_data_get(event, lambda_context)
    body = json.loads(response["body"])[0]

    assert response["statusCode"] == HTTPStatus.OK

    fields_to_return = [
        "dealRefId",
        "leadRefId",
        "creditAppId",
        "appRefIdFD",
        "dealRefIdFD",
        "appRefIdFDInt",
        "dealRefIdFDInt",
        "sourcePartnerId",
        "sourcePartnerDealerId",
        "proxyPartnerId",
        "financeMethod",
        "dealJacketId",
        "dealIdFI",
        "dealerCode",
    ]

    for field in fields_to_return:
        assert body[field] == key_data_db_query_items()[0][field]

    fields_not_to_return = [
        "dealJacketIdIDL",
        "dealId",
        "dealJacketIdR1",
        "conversationId",
        "creditAppIdR1",
    ]

    for field in fields_not_to_return:
        assert field not in body.keys()

    assert response["headers"] == response_header(
        uuid_provided, {"X-Data-Source": "dynamoDb"}
    )


query_string_list_dtc = ["dealJacketId", "dealRefId", "leadRefId"]


@pytest.mark.parametrize("query_string", query_string_list_dtc)
def test_key_data_get_payload_with_target_platform_dtc(
    lambda_context,
    monkeypatch,
    key_data_db_query_items,
    get_api_gateway_event,
    response_header,
    uuid_provided,
    query_string,
):
    """
    Test to check successful persistence and GET for cross reference records
    """
    monkeypatch.setattr(DynamoDbHelper, "query_items", key_data_db_query_items)

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/key-data/"
    event["queryStringParameters"] = {
        query_string: key_data_db_query_items()[0][query_string],
        "targetPlatformId": "DTC",
    }

    response = get.key_data_get(event, lambda_context)
    body = json.loads(response["body"])[0]

    assert response["statusCode"] == HTTPStatus.OK

    fields_to_return = [
        "dealRefId",
        "leadRefId",
        "creditAppId",
        "appRefIdFD",
        "dealRefIdFD",
        "appRefIdFDInt",
        "dealRefIdFDInt",
        "sourcePartnerId",
        "sourcePartnerDealerId",
        "proxyPartnerId",
        "financeMethod",
        "dealJacketId",
        "dealIdFI",
        "dealerCode",
    ]

    for field in fields_to_return:
        assert body[field] == key_data_db_query_items()[0][field]

    fields_not_to_return = [
        "dealJacketIdIDL",
        "dealId",
        "dealJacketIdR1",
        "conversationId",
        "creditAppIdR1",
    ]

    for field in fields_not_to_return:
        assert field not in body.keys()

    assert response["headers"] == response_header(
        uuid_provided, {"X-Data-Source": "dynamoDb"}
    )


query_string_list_idl = [
    ("dealJacketId", "dealJacketIdIDL"),
    ("dealRefId", "dealRefId"),
    ("leadRefId", "leadRefId"),
]


@pytest.mark.parametrize("query_string, query_string_value", query_string_list_idl)
def test_key_data_get_payload_with_target_platform_idl(
    lambda_context,
    monkeypatch,
    key_data_db_query_items,
    get_api_gateway_event,
    response_header,
    uuid_provided,
    query_string,
    query_string_value,
):
    """
    Test to check successful persistence and GET for cross reference records
    """
    monkeypatch.setattr(DynamoDbHelper, "query_items", key_data_db_query_items)

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/key-data/"
    event["queryStringParameters"] = {
        query_string: key_data_db_query_items()[0][query_string_value],
        "targetPlatformId": "IDL",
    }

    response = get.key_data_get(event, lambda_context)
    body = json.loads(response["body"])[0]

    assert response["statusCode"] == HTTPStatus.OK

    fields_to_return = [
        ("dealRefId", "dealRefId"),
        ("leadRefId", "leadRefId"),
        ("creditAppId", "creditAppId"),
        ("appRefIdFD", "appRefIdFD"),
        ("dealRefIdFD", "dealRefIdFD"),
        ("appRefIdFDInt", "appRefIdFDInt"),
        ("dealRefIdFDInt", "dealRefIdFDInt"),
        ("sourcePartnerId", "sourcePartnerId"),
        ("sourcePartnerDealerId", "sourcePartnerDealerId"),
        ("proxyPartnerId", "proxyPartnerId"),
        ("financeMethod", "financeMethod"),
        ("dealJacketId", "dealJacketIdIDL"),
        ("dealId", "dealIdIDL"),
    ]

    for field in fields_to_return:
        assert body[field[0]] == key_data_db_query_items()[0][field[1]]

    fields_not_to_return = [
        "dealJacketIdR1",
        "conversationId",
        "creditAppIdR1",
        "dealIdFI",
        "dealerCode",
    ]

    for field in fields_not_to_return:
        assert field not in body.keys()

    assert response["headers"] == response_header(
        uuid_provided, {"X-Data-Source": "dynamoDb"}
    )


query_string_list_r1 = [
    ("dealJacketId", "dealJacketIdR1"),
    ("dealRefId", "dealRefId"),
    ("leadRefId", "leadRefId"),
]


@pytest.mark.parametrize("query_string, query_string_value", query_string_list_r1)
def test_key_data_get_payload_with_target_platform_r1(
    lambda_context,
    monkeypatch,
    key_data_db_query_items,
    get_api_gateway_event,
    response_header,
    uuid_provided,
    query_string,
    query_string_value,
):
    """
    Test to check successful persistence and GET for cross reference records
    """
    monkeypatch.setattr(DynamoDbHelper, "query_items", key_data_db_query_items)

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/key-data/"
    event["queryStringParameters"] = {
        query_string: key_data_db_query_items()[0][query_string_value],
        "targetPlatformId": "R1J",
    }

    response = get.key_data_get(event, lambda_context)
    body = json.loads(response["body"])[0]

    assert response["statusCode"] == HTTPStatus.OK

    fields_to_return = [
        ("dealRefId", "dealRefId"),
        ("leadRefId", "leadRefId"),
        ("creditAppId", "creditAppId"),
        ("appRefIdFD", "appRefIdFD"),
        ("dealRefIdFD", "dealRefIdFD"),
        ("appRefIdFDInt", "appRefIdFDInt"),
        ("dealRefIdFDInt", "dealRefIdFDInt"),
        ("sourcePartnerId", "sourcePartnerId"),
        ("sourcePartnerDealerId", "sourcePartnerDealerId"),
        ("proxyPartnerId", "proxyPartnerId"),
        ("financeMethod", "financeMethod"),
        ("dealJacketId", "dealJacketIdR1"),
        ("conversationId", "conversationIdR1"),
        ("creditAppIdR1", "creditAppIdR1"),
    ]

    for field in fields_to_return:
        assert body[field[0]] == key_data_db_query_items()[0][field[1]]

    fields_not_to_return = ["dealIdFI", "dealerCode", "dealId"]

    for field in fields_not_to_return:
        assert field not in body.keys()

    assert response["headers"] == response_header(
        uuid_provided, {"X-Data-Source": "dynamoDb"}
    )


def test_key_data_get_payload_without_target_platform_and_invalid_query(
    lambda_context,
    monkeypatch,
    key_data_db_query_items,
    get_api_gateway_event,
):
    """
    Test to check successful persistence and GET for cross reference records
    """
    monkeypatch.setattr(DynamoDbHelper, "query_items", key_data_db_query_items)

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/key-data/"
    event["queryStringParameters"] = {
        "creditAppIdR1": "123",
    }

    response = get.key_data_get(event, lambda_context)
    body = json.loads(response["body"])

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert body == {
        "message": "Given query param, creditAppIdR1 is not supported for targetPlatformId DTC"
    }


def test_key_data_get_payload_with_target_platform_invalid(
    lambda_context,
    monkeypatch,
    key_data_db_query_items,
    get_api_gateway_event,
):
    """
    Test to check successful persistence and GET for cross reference records
    """
    monkeypatch.setattr(DynamoDbHelper, "query_items", key_data_db_query_items)

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/key-data/"
    event["queryStringParameters"] = {
        "dealJacketId": key_data_db_query_items()[0]["dealJacketId"],
        "targetPlatformId": "ABC",
    }

    response = get.key_data_get(event, lambda_context)
    body = json.loads(response["body"])

    assert body == {"message": "Given target platform, ABC is not supported."}
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST


def test_key_data_get_no_querystring(lambda_context, get_api_gateway_event):
    """
    Test to verify api return 400 if required querystring parameters are missing
    """

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/key-data/"

    response = get.key_data_get(event, lambda_context)
    body = json.loads(response["body"])

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert body["message"] == "No query string parameters provided"


def test_key_data_get_no_querystring_value(lambda_context, get_api_gateway_event):
    """
    Test to verify api return 400 if required querystring parameters are missing
    """

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/key-data/"
    event["queryStringParameters"] = {"dealJacketId": ""}

    response = get.key_data_get(event, lambda_context)
    body = json.loads(response["body"])

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert body["message"] == "Query string value cannot be empty"


def test_key_data_get_unsupported_querystring(lambda_context, get_api_gateway_event):
    """
    Test to verify api return 400 if required querystring parameters isn't supported
    """
    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/key-data/"
    event["queryStringParameters"] = {"testQs": "ABCD"}

    response = get.key_data_get(event, lambda_context)
    body = json.loads(response["body"])

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert body["message"] == ErrorMsgs.error_unsupported_key_data.format(
        field="testQs"
    )


def test_key_data_get_when_multiple_querystring(lambda_context, get_api_gateway_event):
    """
    Test to verify api return 400 if required querystring parameters are more than 1,
    """
    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/key-data/"
    event["queryStringParameters"] = {
        "testQs": "ABCD",
        "dealJacketId": "1234567890123456",
    }

    response = get.key_data_get(event, lambda_context)
    body = json.loads(response["body"])

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert body["message"] == ErrorMsgs.error_multiple_key_data_query_param


def test_full_deal_get_exception(
    monkeypatch,
    get_api_gateway_event,
    return_exception,
    lambda_context,
    update_body_with_key_data,
):
    """
    Test to verify api return 500 for general exceptions
    """
    payload = update_body_with_key_data({})
    event = get_api_gateway_event(payload)
    event["path"] = "/v1/deals/key-data/"
    event["queryStringParameters"] = {"dealJacketId": payload["dealJacketId"]}
    monkeypatch.setattr(DynamoDbHelper, "query_items", return_exception)

    response = get.key_data_get(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.INTERNAL_SERVER_ERROR


def test_get_health_check(lambda_context):
    event = {
        "headers": {HEALTHCHECK_HEADER_FIELD: HEALTHCHECK_HEADER_VALUE},
        "path": "/v1/deals/key-data/",
    }

    response = get.key_data_get(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps("Operational")


def test_key_data_get_payload_missing_deal(
    lambda_context,
    get_api_gateway_event,
    monkeypatch,
    db_query_no_items,
    response_header,
    uuid_provided,
):
    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/key-data/"
    event["queryStringParameters"] = {"dealJacketId": "bad_value"}
    monkeypatch.setattr(DynamoDbHelper, "query_items", db_query_no_items)

    response = get.key_data_get(event, lambda_context)
    body = json.loads(response["body"])

    assert response["statusCode"] == HTTPStatus.OK
    assert body == []
    assert response["headers"] == response_header(
        uuid_provided, {"X-Data-Source": "dynamoDb"}
    )


def test_validate_query_string_params_unsupported(
    dr_ulid_new,
    get_api_gateway_event,
    lambda_context,
):
    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/key-data/"
    event["queryStringParameters"] = {"foo": dr_ulid_new}
    response = get.key_data_get(event, lambda_context)
    body = json.loads(response["body"])

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert body["message"] == ErrorMsgs.error_unsupported_key_data.format(field="foo")
