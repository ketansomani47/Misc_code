# -*- coding: utf-8 -*-
import pytest


@pytest.fixture()
def key_data_db_query_items(dr_ulid, dr_ulid_new, dlr_code):
    def query_items(*args, **kwargs):
        return [
            {
                "dealComponent": "DTC.DEAL",
                "dealRefId": dr_ulid,
                "leadRefId": dr_ulid,
                "creditAppId": dr_ulid,
                "appRefIdFD": dr_ulid,
                "dealRefIdFD": dr_ulid,
                "appRefIdFDInt": dr_ulid,
                "dealRefIdFDInt": dr_ulid,
                "sourcePartnerId": "DXR",
                "sourcePartnerDealerId": dlr_code,
                "proxyPartnerId": "TLK",
                "financeMethod": "Lease",
                "dealJacketId": dr_ulid_new,
                "dealIdFI": dr_ulid,
                "dealerCode": dlr_code,
                "dealJacketIdIDL": dr_ulid_new,
                "dealIdIDL": dr_ulid,
                "dealJacketIdR1": dr_ulid_new,
                "conversationIdR1": dr_ulid_new,
                "creditAppIdR1": dr_ulid,
            }
        ]

    return query_items


@pytest.fixture()
def key_data_db_query_items_v2(dr_ulid, dr_ulid_new, dlr_code):
    def query_items(*args, **kwargs):
        return [
            {
                "updatedTimestamp": "2024-02-14T15:09:30.201136",
                "dealRefId": dr_ulid,
                "creditAppId": dr_ulid,
                "sourcePartnerId": "DXR",
                "dealComponent": "REF_IDS.DTA",
                "dealRefIdFD": dr_ulid,
                "dealRefIdFDInt": dr_ulid,
                "leadRefId": dr_ulid,
                "ttl": 1713107370,
                "createdTimestamp": "2024-02-14T15:09:30.201136",
                "financeMethod": "Retail",
            },
            {
                "updatedTimestamp": "2024-02-14T15:09:30.201136",
                "dealRefId": dr_ulid,
                "creditAppId": dr_ulid,
                "dealComponent": "REF_IDS.DTA.01HPM2MRQV9J1TZFMCCGWH2WRZ",
                "appRefIdFD": dr_ulid,
                "ttl": 1713107370,
                "createdTimestamp": "2024-02-14T15:09:30.201136",
                "appRefIdFDInt": dr_ulid,
            },
            {
                "dealerCode": dlr_code,
                "sourcePartnerDealerId": "DXR",
                "updatedTimestamp": "2024-02-14T15:12:27.357240",
                "dealRefId": dr_ulid,
                "dealComponent": "REF_IDS.DTC",
                "documentMasterIndexId": dr_ulid,
                "ttl": 1713107370,
                "createdTimestamp": "2024-02-14T15:09:30.201136",
                "dealJacketId": dr_ulid,
            },
        ]

    return query_items


@pytest.fixture()
def expected_get_v2_response(dr_ulid, dr_ulid_new, dlr_code):
    return [
        {
            "dealRefId": dr_ulid,
            "creditAppId": dr_ulid,
            "sourcePartnerId": "DXR",
            "dealRefIdFD": dr_ulid,
            "dealRefIdFDInt": dr_ulid,
            "leadRefId": dr_ulid,
            "financeMethod": "Retail",
            "targetPlatformId": "DTA",
            "appRefIdFD": dr_ulid,
            "appRefIdFDInt": dr_ulid,
        },
        {
            "dealerCode": dlr_code,
            "sourcePartnerDealerId": "DXR",
            "documentMasterIndexId": dr_ulid,
            "dealJacketId": dr_ulid,
            "targetPlatformId": "DTC",
        },
    ]


@pytest.fixture()
def key_data_full_payload(dr_ulid, dr_ulid_new, dlr_code):
    return {
        "appRefIdFD": dr_ulid,
        "dealRefIdFD": dr_ulid,
        "appRefIdFDInt": dr_ulid,
        "dealRefIdFDInt": dr_ulid,
        "sourcePartnerId": "DXR",
        "sourcePartnerDealerId": dlr_code,
        "proxyPartnerId": "TLK",
        "financeMethod": "Lease",
        "dealJacketId": dr_ulid_new,
        "dealIdFI": dr_ulid,
        "dealerCode": dlr_code,
        "dealId": dr_ulid,
        "conversationId": dr_ulid_new,
        "creditAppIdR1": dr_ulid,
    }


@pytest.fixture()
def key_data_payload_idl(dr_ulid_new, dlr_code):
    return {"dealJacketIdIDL": dr_ulid_new, "dealerCodeIDL": dlr_code}


@pytest.fixture()
def key_data_payload_r1j(dr_ulid_new, dlr_code):
    return {
        "dealJacketIdR1": dr_ulid_new,
        "conversationIdR1": dlr_code,
        "creditAppIdR1": dr_ulid_new,
    }


@pytest.fixture()
def expected_full_payload(dr_ulid, dr_ulid_new, dlr_code):
    return {
        "appRefIdFD": dr_ulid,
        "dealRefIdFD": dr_ulid,
        "appRefIdFDInt": dr_ulid,
        "dealRefIdFDInt": dr_ulid,
        "sourcePartnerId": "DXR",
        "sourcePartnerDealerId": dlr_code,
        "proxyPartnerId": "TLK",
        "financeMethod": "Lease",
        "dealJacketId": dr_ulid_new,
        "dealIdFI": dr_ulid,
        "dealerCode": dlr_code,
        "dealId": dr_ulid,
        "conversationId": dr_ulid_new,
        "creditAppIdR1": dr_ulid,
        "REF_IDS.DTC": {
            "dealJacketId": dr_ulid_new,
            "dealerCode": dlr_code,
            "sourcePartnerDealerId": dlr_code,
        },
        "REF_IDS.DTA": {
            "dealRefIdFD": dr_ulid,
            "dealRefIdFDInt": dr_ulid,
            "sourcePartnerId": "DXR",
            "proxyPartnerId": "TLK",
            "financeMethod": "Lease",
        },
        f"REF_IDS.DTC.{dr_ulid}": {"dealId": dr_ulid},
    }


@pytest.fixture()
def expected_dtc_target_platform_record():
    return {
        "REF_IDS.DTC": {
            "dealJacketId": "1111111111AAABBBCCDDEEFFGG",
            "dealerCode": "12345",
        },
        "dealJacketId": "1111111111AAABBBCCDDEEFFGG",
        "dealerCode": "12345",
    }


@pytest.fixture()
def expected_idl_target_platform_record():
    return {
        "REF_IDS.IDL": {
            "dealJacketId": "1111111111AAABBBCCDDEEFFGG",
            "dealerCode": "12345",
        },
        "dealJacketIdIDL": "1111111111AAABBBCCDDEEFFGG",
        "dealerCodeIDL": "12345",
    }
