# -*- coding: utf-8 -*-
from copy import deepcopy

from common.settings import PayloadType
from key_data.mapper import transform_key_data_records


def test_without_target_platform(key_data_payload, expected_dtc_target_platform_record):
    response = transform_key_data_records(key_data_payload, PayloadType.KEY_DATA_POST)
    assert response == expected_dtc_target_platform_record


def test_with_dtc_target_platform(
    key_data_payload, expected_dtc_target_platform_record
):
    key_data_payload["targetPlatformId"] = "DTC"
    response = transform_key_data_records(key_data_payload, PayloadType.KEY_DATA_POST)
    assert response == expected_dtc_target_platform_record


def test_with_dtc_dta_target_platform(key_data_full_payload, expected_full_payload):
    key_data_full_payload["targetPlatformId"] = "DTC"
    response = transform_key_data_records(
        key_data_full_payload, PayloadType.KEY_DATA_POST
    )
    assert response == expected_full_payload


def test_with_idl_target_platform(
    key_data_payload_idl, expected_idl_target_platform_record
):
    key_data_payload_idl["targetPlatformId"] = "IDL"
    response = transform_key_data_records(
        key_data_payload_idl, PayloadType.KEY_DATA_POST
    )
    assert response == expected_idl_target_platform_record


def test_with_r1_target_platform(key_data_payload_r1j, dr_ulid_new, dlr_code):
    data = deepcopy(key_data_payload_r1j)
    data["targetPlatformId"] = "R1J"
    response = transform_key_data_records(data, PayloadType.KEY_DATA_POST)
    expected = {
        **key_data_payload_r1j,
        "REF_IDS.R1J": {"dealJacketId": dr_ulid_new},
        f"REF_IDS.R1J.{dlr_code}": {
            "conversationId": dlr_code,
            "creditAppIdR1": dr_ulid_new,
        },
    }
    assert response == expected


def test_ca_api_with_single_targets(credit_app_partial_payload, dr_ulid):
    credit_app_partial_payload["dealRefIdFD"] = dr_ulid
    credit_app_partial_payload["targetPlatforms"] = [{"id": "DTC", "partyId": "123987"}]
    data = deepcopy(credit_app_partial_payload)
    response = transform_key_data_records(data, PayloadType.CREDIT_APP_POST)
    expected = {
        **credit_app_partial_payload,
        "REF_IDS.DTC": {"sourcePartnerDealerId": "123987"},
        "REF_IDS.DTA": {
            "dealRefIdFD": dr_ulid,
            "sourcePartnerId": "VIN",
            "financeMethod": "Lease",
        },
    }
    assert response == expected


def test_ca_api_with_multiple_targets(credit_app_partial_payload, dr_ulid):
    credit_app_partial_payload["dealRefIdFD"] = dr_ulid
    credit_app_partial_payload["targetPlatforms"] = [
        {"id": "DTC", "partyId": "123987"},
        {"id": "IDL", "partyId": "78665"},
    ]
    data = deepcopy(credit_app_partial_payload)
    response = transform_key_data_records(data, PayloadType.CREDIT_APP_POST)

    expected = {
        **credit_app_partial_payload,
        "REF_IDS.DTC": {"sourcePartnerDealerId": "123987"},
        "REF_IDS.IDL": {"sourcePartnerDealerId": "78665"},
        "REF_IDS.DTA": {
            "dealRefIdFD": dr_ulid,
            "sourcePartnerId": "VIN",
            "financeMethod": "Lease",
        },
    }
    assert response == expected
