# -*- coding: utf-8 -*-
import json
from http import HTTPStatus

from common import settings
from common.settings import PayloadType
from key_data import producer
from utils.db_helper import DynamoDbHelper


def test_key_data_post_without_target_platform(
    key_data_payload,
    sqs,
    get_api_gateway_event,
    uuid_provided,
    response_header,
    lambda_context,
    monkeypatch,
    mock_query_pk_filter,
    dr_ulid,
):
    event = get_api_gateway_event(key_data_payload)
    event["requestContext"] = {"operationName": "key_data_post"}
    monkeypatch.setattr(DynamoDbHelper, "query_pk_filter", mock_query_pk_filter)
    response = producer.key_data_handlers(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.CREATED
    assert json.loads(response["body"]) == {"dealRefId": dr_ulid}
    assert response["headers"] == response_header(uuid_provided)


def test_key_data_post_with_target_platform(
    key_data_payload,
    sqs,
    get_api_gateway_event,
    uuid_provided,
    response_header,
    lambda_context,
    monkeypatch,
    mock_query_pk_filter,
    dr_ulid,
):
    key_data_payload["targetPlatformId"] = "DTC"
    event = get_api_gateway_event(key_data_payload)
    event["requestContext"] = {"operationName": "key_data_post"}
    monkeypatch.setattr(DynamoDbHelper, "query_pk_filter", mock_query_pk_filter)
    response = producer.key_data_handlers(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.CREATED
    assert json.loads(response["body"]) == {"dealRefId": dr_ulid}
    assert response["headers"] == response_header(uuid_provided)


def test_key_data_post_with_target_platform_and_unspported_field(
    key_data_payload,
    sqs,
    get_api_gateway_event,
    uuid_provided,
    response_header,
    lambda_context,
    monkeypatch,
    mock_query_pk_filter,
):
    key_data_payload["targetPlatformId"] = "IDL"
    key_data_payload["dealIdFI"] = "123"
    event = get_api_gateway_event(key_data_payload)
    event["requestContext"] = {"operationName": "key_data_post"}
    monkeypatch.setattr(DynamoDbHelper, "query_pk_filter", mock_query_pk_filter)
    response = producer.key_data_handlers(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert json.loads(response["body"]) == {
        "message": "Given fields 'dealIdFI' is not supported for targetPlatformId IDL"
    }
    assert response["headers"] == response_header(uuid_provided)


def test_key_data_post_transformation(key_data_full_payload):
    response = producer.KeyDataProducerLambda().transform_body_by_target_platform(
        key_data_full_payload
    )

    assert "dealJacketId" in response

    key_data_handler = producer.KeyDataProducerLambda()
    key_data_handler._target_platform_id = "R1J"

    response = key_data_handler.transform_body_by_target_platform(key_data_full_payload)

    assert "dealJacketIdR1" in response

    key_data_handler = producer.KeyDataProducerLambda()
    key_data_handler._target_platform_id = "IDL"

    response = key_data_handler.transform_body_by_target_platform(key_data_full_payload)

    assert "dealJacketIdIDL" in response


def test_key_data_post_health_check(lambda_context, get_api_gateway_event):
    event = get_api_gateway_event({})
    event["headers"] = {
        settings.HEALTHCHECK_HEADER_FIELD: settings.HEALTHCHECK_HEADER_VALUE
    }
    event["requestContext"] = {"operationName": "key_data_post"}

    response = producer.key_data_handlers(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps("Operational")


def test_key_data_post_no_body(
    sqs, uuid_provided, response_header, get_api_gateway_event, lambda_context, dr_ulid
):
    event = get_api_gateway_event("")
    event["pathParameters"] = {"dealRefId": dr_ulid}
    event["requestContext"] = {"operationName": "key_data_post"}

    response = producer.key_data_handlers(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(
        {"message": settings.ErrorMsgs.missing_body_aws_event}
    )
    assert response["headers"] == response_header(uuid_provided)


def test_key_data_post_json_decoder_error(
    sqs, get_api_gateway_invalid_event, uuid_provided, response_header, lambda_context
):
    event = get_api_gateway_invalid_event
    event["path"] = "/v1/deals/key-data"
    event["requestContext"] = {"operationName": "key_data_patch"}
    response = producer.key_data_handlers(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["headers"] == response_header(uuid_provided)


def test_key_data_patch(
    key_data_payload,
    sqs,
    get_api_gateway_event,
    uuid_provided,
    response_header,
    lambda_context,
    monkeypatch,
    mock_query_pk_filter,
    dr_ulid,
):
    event = get_api_gateway_event(key_data_payload)
    event["pathParameters"] = {"dealRefId": dr_ulid}
    event["requestContext"] = {"operationName": "key_data_patch"}
    monkeypatch.setattr(DynamoDbHelper, "query_pk_filter", mock_query_pk_filter)
    response = producer.key_data_handlers(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.NO_CONTENT
    assert response["headers"] == response_header(uuid_provided)


def test_key_data_patch_health_check(lambda_context, get_api_gateway_event, dr_ulid):
    event = get_api_gateway_event({})
    event["headers"] = {
        settings.HEALTHCHECK_HEADER_FIELD: settings.HEALTHCHECK_HEADER_VALUE
    }
    event["pathParameters"] = {"dealRefId": dr_ulid}
    event["requestContext"] = {"operationName": "key_data_patch"}

    response = producer.key_data_handlers(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps("Operational")


def test_key_data_patch_no_body(
    sqs, uuid_provided, response_header, get_api_gateway_event, lambda_context, dr_ulid
):
    event = get_api_gateway_event("")
    event["pathParameters"] = {"dealRefId": dr_ulid}
    event["requestContext"] = {"operationName": "key_data_patch"}

    response = producer.key_data_handlers(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(
        {"message": settings.ErrorMsgs.missing_body_aws_event}
    )
    assert response["headers"] == response_header(uuid_provided)


def test_key_data_patch_json_decoder_error(
    sqs,
    get_api_gateway_invalid_event,
    uuid_provided,
    response_header,
    lambda_context,
    dr_ulid,
):
    event = get_api_gateway_invalid_event
    event["path"] = f"/v1/deals/{dr_ulid}/key-data"
    event["requestContext"] = {"operationName": "key_data_patch"}
    response = producer.key_data_handlers(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["headers"] == response_header(uuid_provided)


def test_key_data_patch_no_deal_ref_id(
    sqs, uuid_provided, response_header, get_api_gateway_event, lambda_context
):
    event = get_api_gateway_event("")
    event["requestContext"] = {"operationName": "key_data_patch"}

    response = producer.key_data_handlers(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(
        {"message": settings.ErrorMsgs.deal_ref_id_not_provided}
    )
    assert response["headers"] == response_header(uuid_provided)


def test_key_data_post_handler(
    key_data_payload,
    sqs,
    get_api_gateway_event,
    uuid_provided,
    response_header,
    mock_query_pk_filter,
    monkeypatch,
    lambda_context,
    dr_ulid,
):
    event = get_api_gateway_event(key_data_payload)
    event["requestContext"] = {"operationName": "key_data_post"}
    monkeypatch.setattr(DynamoDbHelper, "query_pk_filter", mock_query_pk_filter)
    response = producer.key_data_handlers(event, lambda_context)

    response_object_instance = producer.KeyDataProducerLambda().get_handler(
        handler_func="new_deal_key_data_handler", payload_type=PayloadType.KEY_DATA_POST
    )
    response_object_instance = response_object_instance(event, lambda_context)

    assert event.get("requestContext").get("operationName") == "key_data_post"

    assert response["statusCode"] == HTTPStatus.CREATED
    assert response_object_instance["statusCode"] == HTTPStatus.CREATED
    assert response["statusCode"] == response_object_instance["statusCode"]

    assert json.loads(response["body"]) == {"dealRefId": dr_ulid}
    assert json.loads(response_object_instance["body"]) == {"dealRefId": dr_ulid}
    assert json.loads(response["body"]) == json.loads(response_object_instance["body"])

    assert response["headers"] == response_header(uuid_provided)
    assert response_object_instance["headers"] == response_header(uuid_provided)
    assert response["headers"] == response_object_instance["headers"]


def test_key_data_post_wrong_handler(
    key_data_payload,
    sqs,
    get_api_gateway_event,
    mock_query_pk_filter,
    monkeypatch,
):
    event = get_api_gateway_event(key_data_payload)
    event["requestContext"] = {"operationName": "key_data_delete"}
    monkeypatch.setattr(DynamoDbHelper, "query_pk_filter", mock_query_pk_filter)
    handlers = ["key_data_post", "key_data_patch"]
    assert event.get("requestContext").get("operationName") != any(handlers)


def test_key_data_patch_handler(
    key_data_payload,
    sqs,
    get_api_gateway_event,
    uuid_provided,
    response_header,
    mock_query_pk_filter,
    monkeypatch,
    lambda_context,
    dr_ulid,
):
    event = get_api_gateway_event(key_data_payload)
    event["pathParameters"] = {"dealRefId": dr_ulid}
    event["requestContext"] = {"operationName": "key_data_patch"}
    monkeypatch.setattr(DynamoDbHelper, "query_pk_filter", mock_query_pk_filter)
    response = producer.key_data_handlers(event, lambda_context)

    object_instance = producer.KeyDataProducerLambda().get_handler(
        handler_func="existing_deal_key_data_handler",
        payload_type=PayloadType.KEY_DATA_UPDATE,
    )
    response_object_instance = object_instance(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.NO_CONTENT
    assert response_object_instance["statusCode"] == HTTPStatus.NO_CONTENT
    assert response["statusCode"] == response_object_instance["statusCode"]

    assert response["headers"] == response_header(uuid_provided)
    assert response_object_instance["headers"] == response_header(uuid_provided)
    assert response["headers"] == response_object_instance["headers"]


def test_key_data_patch_handler_lead_ref_id_check_using_payload(
    key_data_payload,
    sqs,
    get_api_gateway_event,
    mock_query_pk_filter_with_additional_fields,
    monkeypatch,
    lambda_context,
    dr_ulid,
):
    producer.Env.CHECK_LEAD_REFERENCE_ID = "true"
    key_data_payload["dealRefIdFD"] = 123
    event = get_api_gateway_event(key_data_payload)
    event["pathParameters"] = {"dealRefId": dr_ulid}
    event["requestContext"] = {"operationName": "key_data_patch"}
    monkeypatch.setattr(
        DynamoDbHelper,
        "query_pk_filter",
        mock_query_pk_filter_with_additional_fields(
            additional_dtc_fields={"dealRefIdFD": 123}
        ).query_pk_filter,
    )
    response = producer.key_data_handlers(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(
        {
            "message": "'dealRefIdFD' already exists for resource dealRefId=0000000000AAABBBCCDDEEFFGG"
        }
    )


def test_key_data_patch_handler_lead_ref_id_check_using_headers(
    key_data_payload,
    sqs,
    get_api_gateway_event,
    mock_query_pk_filter_with_additional_fields,
    monkeypatch,
    lambda_context,
    dr_ulid,
):
    producer.Env.CHECK_LEAD_REFERENCE_ID = "true"
    event = get_api_gateway_event(
        key_data_payload, additional_headers={"X-Lead-Reference-Number": 123}
    )
    event["pathParameters"] = {"dealRefId": dr_ulid}
    event["requestContext"] = {"operationName": "key_data_patch"}
    monkeypatch.setattr(
        DynamoDbHelper,
        "query_pk_filter",
        mock_query_pk_filter_with_additional_fields(
            additional_dtc_fields={"dealRefIdFD": 123}
        ).query_pk_filter,
    )
    response = producer.key_data_handlers(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(
        {
            "message": "'dealRefIdFD' already exists for resource dealRefId=0000000000AAABBBCCDDEEFFGG"
        }
    )
