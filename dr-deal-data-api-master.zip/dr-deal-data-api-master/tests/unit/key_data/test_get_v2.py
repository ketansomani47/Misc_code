# -*- coding: utf-8 -*-
import json
from http import HTTPStatus

import pytest
from common.settings import (
    HEALTHCHECK_HEADER_FIELD,
    HEALTHCHECK_HEADER_VALUE,
    ErrorMsgs,
)
from key_data import get_v2 as get
from utils.db_helper import DynamoDbHelper


query_string_list = ["dealRefId", "dealRefIdFD", "dealRefIdFDInt"]


@pytest.mark.parametrize("query_string", query_string_list)
def test_key_data_get_payload_without_target_platform(
    lambda_context,
    monkeypatch,
    key_data_db_query_items_v2,
    expected_get_v2_response,
    get_api_gateway_event,
    query_string,
):
    """
    Test to check successful persistence and GET for cross reference records
    """
    monkeypatch.setattr(DynamoDbHelper, "query_items", key_data_db_query_items_v2)

    event = get_api_gateway_event({})
    event["path"] = "/v2/deals/key-data/"
    event["queryStringParameters"] = {
        query_string: key_data_db_query_items_v2()[0][query_string]
    }

    response = get.key_data_get(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.OK
    assert response["body"] == json.dumps(expected_get_v2_response)


query_string_list_dtc = ["dealJacketId"]


@pytest.mark.parametrize("query_string", query_string_list_dtc)
def test_key_data_get_payload_with_target_platform_dtc(
    lambda_context,
    monkeypatch,
    key_data_db_query_items_v2,
    get_api_gateway_event,
    expected_get_v2_response,
    query_string,
):
    """
    Test to check successful persistence and GET for cross reference records
    """
    monkeypatch.setattr(DynamoDbHelper, "query_items", key_data_db_query_items_v2)

    event = get_api_gateway_event({})
    event["path"] = "/v2/deals/key-data/"
    event["queryStringParameters"] = {
        query_string: key_data_db_query_items_v2()[2][query_string],
        "targetPlatformId": "DTC",
    }

    response = get.key_data_get(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.OK
    assert response["body"] == json.dumps(expected_get_v2_response)


def test_key_data_get_payload_without_target_platform_and_invalid_query(
    lambda_context,
    monkeypatch,
    key_data_db_query_items_v2,
    get_api_gateway_event,
):
    """
    Test to check successful persistence and GET for cross reference records
    """
    monkeypatch.setattr(DynamoDbHelper, "query_items", key_data_db_query_items_v2)

    event = get_api_gateway_event({})
    event["path"] = "/v2/deals/key-data/"
    event["queryStringParameters"] = {
        "creditAppIdR1": "123",
    }

    response = get.key_data_get(event, lambda_context)
    body = json.loads(response["body"])

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert body == {
        "message": "Given query param, creditAppIdR1 is not supported for targetPlatformId DTA"
    }


def test_key_data_get_payload_with_target_platform_invalid(
    lambda_context,
    monkeypatch,
    key_data_db_query_items_v2,
    get_api_gateway_event,
):
    """
    Test to check successful persistence and GET for cross reference records
    """
    monkeypatch.setattr(DynamoDbHelper, "query_items", key_data_db_query_items_v2)

    event = get_api_gateway_event({})
    event["path"] = "/v2/deals/key-data/"
    event["queryStringParameters"] = {
        "dealJacketId": key_data_db_query_items_v2()[2]["dealJacketId"],
        "targetPlatformId": "ABC",
    }

    response = get.key_data_get(event, lambda_context)
    body = json.loads(response["body"])

    assert body == {"message": "Given target platform, ABC is not supported."}
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST


def test_key_data_get_no_querystring(lambda_context, get_api_gateway_event):
    """
    Test to verify api return 400 if required querystring parameters are missing
    """

    event = get_api_gateway_event({})
    event["path"] = "/v2/deals/key-data/"

    response = get.key_data_get(event, lambda_context)
    body = json.loads(response["body"])

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert body["message"] == "No query string parameters provided"


def test_key_data_get_no_querystring_value(lambda_context, get_api_gateway_event):
    """
    Test to verify api return 400 if required querystring parameters are missing
    """

    event = get_api_gateway_event({})
    event["path"] = "/v2/deals/key-data/"
    event["queryStringParameters"] = {"dealRefId": ""}

    response = get.key_data_get(event, lambda_context)
    body = json.loads(response["body"])

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert body["message"] == "Query string value cannot be empty"


def test_key_data_get_unsupported_querystring(lambda_context, get_api_gateway_event):
    """
    Test to verify api return 400 if required querystring parameters isn't supported
    """
    event = get_api_gateway_event({})
    event["path"] = "/v2/deals/key-data/"
    event["queryStringParameters"] = {"testQs": "ABCD"}

    response = get.key_data_get(event, lambda_context)
    body = json.loads(response["body"])

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert body["message"] == ErrorMsgs.unsupported_key_data_query_field.format(
        field="testQs", target_platform_id="DTA"
    )


def test_key_data_get_when_multiple_querystring(lambda_context, get_api_gateway_event):
    """
    Test to verify api return 400 if required querystring parameters are more than 1,
    """
    event = get_api_gateway_event({})
    event["path"] = "/v2/deals/key-data/"
    event["queryStringParameters"] = {
        "testQs": "ABCD",
        "dealJacketId": "1234567890123456",
    }

    response = get.key_data_get(event, lambda_context)
    body = json.loads(response["body"])

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert body["message"] == ErrorMsgs.error_multiple_key_data_query_param


def test_key_data_get_exception(
    monkeypatch,
    get_api_gateway_event,
    return_exception,
    lambda_context,
):
    """
    Test to verify api return 500 for general exceptions
    """
    event = get_api_gateway_event({})
    event["path"] = "/v2/deals/key-data/"
    event["queryStringParameters"] = {"dealRefId": "123"}
    monkeypatch.setattr(DynamoDbHelper, "query_items", return_exception)

    response = get.key_data_get(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.INTERNAL_SERVER_ERROR


def test_get_health_check(lambda_context):
    event = {
        "headers": {HEALTHCHECK_HEADER_FIELD: HEALTHCHECK_HEADER_VALUE},
        "path": "/v2/deals/key-data/",
    }

    response = get.key_data_get(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps("Operational")


def test_key_data_get_payload_missing_deal(
    lambda_context,
    get_api_gateway_event,
    monkeypatch,
    db_query_no_items,
    response_header,
    uuid_provided,
):
    event = get_api_gateway_event({})
    event["path"] = "/v2/deals/key-data/"
    event["queryStringParameters"] = {"dealRefId": "bad_value"}
    monkeypatch.setattr(DynamoDbHelper, "query_items", db_query_no_items)

    response = get.key_data_get(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.NO_CONTENT


def test_key_data_get_invalid_header_value(
    lambda_context,
    get_api_gateway_event,
    monkeypatch,
    db_query_no_items,
    response_header,
    uuid_provided,
):
    event = get_api_gateway_event({}, additional_headers={"includeInactiveRefs": "123"})
    event["path"] = "/v2/deals/key-data/"
    event["queryStringParameters"] = {"dealRefId": "bad_value"}
    monkeypatch.setattr(DynamoDbHelper, "query_items", db_query_no_items)

    response = get.key_data_get(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(
        {
            "message": "Provided includeInactiveRefs '123' is not supported. "
            "Please provide one of the enum ['true', 'false']"
        }
    )
