# -*- coding: utf-8 -*-
import json
from http import HTTPStatus

from common import settings
from key_data import producer_v2
from utils.db_helper import DynamoDbHelper


def test_patch_with_dta(
    sqs,
    get_api_gateway_event,
    uuid_provided,
    response_header,
    lambda_context,
    monkeypatch,
    mock_query_pk_filter,
    dr_ulid,
):
    payload = {
        "targetPlatformId": "DTA",
        "proxyPartnerId": dr_ulid,
        "dealXgDealId": dr_ulid,
        "dealXgDealVersion": dr_ulid,
    }
    event = get_api_gateway_event(payload)
    event["pathParameters"] = {"dealRefId": dr_ulid}
    event["requestContext"] = {"operationName": "key_data_patch"}
    monkeypatch.setattr(DynamoDbHelper, "query_pk_filter", mock_query_pk_filter)
    response = producer_v2.handler(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.NO_CONTENT
    assert response["headers"] == response_header(uuid_provided)


def test_patch_with_dtc(
    sqs,
    get_api_gateway_event,
    uuid_provided,
    response_header,
    lambda_context,
    monkeypatch,
    mock_query_pk_filter,
    dr_ulid,
):
    payload = {
        "targetPlatformId": "DTC",
        "dealJacketId": dr_ulid,
        "dealerCode": dr_ulid,
        "documentMasterIndexId": dr_ulid,
    }
    event = get_api_gateway_event(payload)
    event["pathParameters"] = {"dealRefId": dr_ulid}
    event["requestContext"] = {"operationName": "key_data_patch"}
    monkeypatch.setattr(DynamoDbHelper, "query_pk_filter", mock_query_pk_filter)
    response = producer_v2.handler(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.NO_CONTENT
    assert response["headers"] == response_header(uuid_provided)


def test_patch_with_idl(
    sqs,
    get_api_gateway_event,
    uuid_provided,
    response_header,
    lambda_context,
    monkeypatch,
    mock_query_pk_filter,
    dr_ulid,
):
    payload = {
        "targetPlatformId": "DTC",
        "dealJacketId": dr_ulid,
        "dealerCode": dr_ulid,
        "documentMasterIndexId": dr_ulid,
    }
    event = get_api_gateway_event(payload)
    event["pathParameters"] = {"dealRefId": dr_ulid}
    event["requestContext"] = {"operationName": "key_data_patch"}
    monkeypatch.setattr(DynamoDbHelper, "query_pk_filter", mock_query_pk_filter)
    response = producer_v2.handler(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.NO_CONTENT
    assert response["headers"] == response_header(uuid_provided)


def test_patch_with_dta_credit_app_conditional_validations(
    sqs,
    get_api_gateway_event,
    uuid_provided,
    response_header,
    lambda_context,
    monkeypatch,
    mock_query_pk_filter,
    dr_ulid,
):
    payload = {
        "targetPlatformId": "DTA",
        "proxyPartnerId": dr_ulid,
        "dealXgDealId": dr_ulid,
        "dealXgDealVersion": dr_ulid,
        "financeMethod": "Lease",
    }
    event = get_api_gateway_event(payload)
    event["pathParameters"] = {"dealRefId": dr_ulid}
    event["requestContext"] = {"operationName": "key_data_patch"}
    monkeypatch.setattr(DynamoDbHelper, "query_pk_filter", mock_query_pk_filter)
    response = producer_v2.handler(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(
        {
            "message": "'creditAppId' and 'financeMethod' are mutually conditional, "
            "if one is provided the other becomes mandatory"
        }
    )
    assert response["headers"] == response_header(uuid_provided)


def test_patch_with_dtc_credit_app_conditional_validations(
    sqs,
    get_api_gateway_event,
    uuid_provided,
    response_header,
    lambda_context,
    monkeypatch,
    mock_query_pk_filter,
    dr_ulid,
):
    payload = {
        "targetPlatformId": "DTC",
        "dealJacketId": dr_ulid,
        "dealerCode": dr_ulid,
        "documentMasterIndexId": dr_ulid,
        "dealId": dr_ulid,
    }
    event = get_api_gateway_event(payload)
    event["pathParameters"] = {"dealRefId": dr_ulid}
    event["requestContext"] = {"operationName": "key_data_patch"}
    monkeypatch.setattr(DynamoDbHelper, "query_pk_filter", mock_query_pk_filter)
    response = producer_v2.handler(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(
        {
            "message": "'creditAppId' and 'dealId' are mutually conditional, "
            "if one is provided the other becomes mandatory"
        }
    )
    assert response["headers"] == response_header(uuid_provided)


def test_patch_with_idl_credit_app_conditional_validations(
    sqs,
    get_api_gateway_event,
    uuid_provided,
    response_header,
    lambda_context,
    monkeypatch,
    mock_query_pk_filter,
    dr_ulid,
):
    payload = {
        "targetPlatformId": "IDL",
        "dealJacketId": dr_ulid,
        "dealerCode": dr_ulid,
        "documentMasterIndexId": dr_ulid,
        "dealId": dr_ulid,
    }
    event = get_api_gateway_event(payload)
    event["pathParameters"] = {"dealRefId": dr_ulid}
    event["requestContext"] = {"operationName": "key_data_patch"}
    monkeypatch.setattr(DynamoDbHelper, "query_pk_filter", mock_query_pk_filter)
    response = producer_v2.handler(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(
        {
            "message": "'creditAppId' and 'dealId' are mutually conditional, "
            "if one is provided the other becomes mandatory"
        }
    )
    assert response["headers"] == response_header(uuid_provided)


def test_patch_with_r1j_credit_app_conditional_validations(
    sqs,
    get_api_gateway_event,
    uuid_provided,
    response_header,
    lambda_context,
    monkeypatch,
    mock_query_pk_filter,
    dr_ulid,
):
    payload = {
        "targetPlatformId": "R1J",
        "dealJacketId": dr_ulid,
        "creditAppIdR1": dr_ulid,
    }
    event = get_api_gateway_event(payload)
    event["pathParameters"] = {"dealRefId": dr_ulid}
    event["requestContext"] = {"operationName": "key_data_patch"}
    monkeypatch.setattr(DynamoDbHelper, "query_pk_filter", mock_query_pk_filter)
    response = producer_v2.handler(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(
        {"message": "'conversationId' is required if 'creditAppIdR1' is provided"}
    )
    assert response["headers"] == response_header(uuid_provided)


def test_patch_with_dta_with_ca_found(
    sqs,
    get_api_gateway_event,
    uuid_provided,
    response_header,
    lambda_context,
    monkeypatch,
    mock_query_pk_filter,
    dr_ulid,
):
    payload = {
        "targetPlatformId": "DTA",
        "proxyPartnerId": dr_ulid,
        "dealXgDealId": dr_ulid,
        "dealXgDealVersion": dr_ulid,
        "financeMethod": "Lease",
        "creditAppId": dr_ulid,
        "dealRefIdFD": dr_ulid,
        "dealRefIdFDInt": 2364656,
    }
    event = get_api_gateway_event(payload)
    event["pathParameters"] = {"dealRefId": dr_ulid}
    event["requestContext"] = {"operationName": "key_data_patch"}
    monkeypatch.setattr(DynamoDbHelper, "query_pk_filter", mock_query_pk_filter)
    response = producer_v2.handler(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(
        {
            "message": "Provided creditAppId 0000000000AAABBBCCDDEEFFGG is not associated "
            "to dealRefId 0000000000AAABBBCCDDEEFFGG"
        }
    )
    assert response["headers"] == response_header(uuid_provided)


def test_patch_with_random_field(
    sqs,
    get_api_gateway_event,
    uuid_provided,
    response_header,
    lambda_context,
    monkeypatch,
    mock_query_pk_filter,
    dr_ulid,
):
    payload = {"targetPlatformId": "DTA", "randomField": dr_ulid}
    event = get_api_gateway_event(payload)
    event["pathParameters"] = {"dealRefId": dr_ulid}
    event["requestContext"] = {"operationName": "key_data_patch"}
    monkeypatch.setattr(DynamoDbHelper, "query_pk_filter", mock_query_pk_filter)
    response = producer_v2.handler(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(
        {
            "message": "Given fields 'randomField' is not supported for targetPlatformId DTA"
        }
    )
    assert response["headers"] == response_header(uuid_provided)


def test_patch_with_unsupported_target(
    sqs,
    get_api_gateway_event,
    uuid_provided,
    response_header,
    lambda_context,
    monkeypatch,
    mock_query_pk_filter,
    dr_ulid,
):
    payload = {"targetPlatformId": "ABC"}
    event = get_api_gateway_event(payload)
    event["pathParameters"] = {"dealRefId": dr_ulid}
    event["requestContext"] = {"operationName": "key_data_patch"}
    monkeypatch.setattr(DynamoDbHelper, "query_pk_filter", mock_query_pk_filter)
    response = producer_v2.handler(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(
        {"message": "Given target platform, ABC is not supported."}
    )
    assert response["headers"] == response_header(uuid_provided)


def test_patch_health_check(lambda_context, get_api_gateway_event, dr_ulid):
    event = get_api_gateway_event({})
    event["headers"] = {
        settings.HEALTHCHECK_HEADER_FIELD: settings.HEALTHCHECK_HEADER_VALUE
    }
    event["pathParameters"] = {"dealRefId": dr_ulid}
    event["requestContext"] = {"operationName": "key_data_patch"}

    response = producer_v2.handler(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps("Operational")


def test_patch_json_decoder_error(
    sqs,
    get_api_gateway_invalid_event,
    uuid_provided,
    response_header,
    lambda_context,
    dr_ulid,
):
    event = get_api_gateway_invalid_event
    event["path"] = f"/v1/deals/{dr_ulid}/key-data"
    event["requestContext"] = {"operationName": "key_data_patch"}
    response = producer_v2.handler(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["headers"] == response_header(uuid_provided)


def test_patch_no_deal_ref_id(
    sqs, uuid_provided, response_header, get_api_gateway_event, lambda_context
):
    event = get_api_gateway_event("")
    event["requestContext"] = {"operationName": "key_data_patch"}

    response = producer_v2.handler(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(
        {"message": settings.ErrorMsgs.deal_ref_id_not_provided}
    )
    assert response["headers"] == response_header(uuid_provided)
