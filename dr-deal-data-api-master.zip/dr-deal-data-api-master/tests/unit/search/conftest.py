# -*- coding: utf-8 -*-
import pytest
from utils.db_helper import DynamoDbHelper


@pytest.fixture()
def mock_dynamodb_helper(monkeypatch, mock_query_pk_filter):
    monkeypatch.setattr(DynamoDbHelper, "query_pk_filter", mock_query_pk_filter)


@pytest.fixture()
def mock_event_data(uuid_newly_generated, dr_ulid):
    def return_value(*args, **kwargs):
        return [
            {
                "dealComponent": f"DTC.EVENTS.{uuid_newly_generated}",
                "dealRefId": uuid_newly_generated,
                "eventId": uuid_newly_generated,
                "eventKeyData": {"lenderId": "ALY"},
            },
            {
                "dealComponent": f"DTC.EVENTS.{uuid_newly_generated}",
                "dealRefId": uuid_newly_generated,
                "eventId": uuid_newly_generated,
                "eventKeyData": {"lenderId": "BOA"},
            },
        ]

    return return_value


@pytest.fixture()
def expected_lender_ids():
    return ["ALY", "BOA"]


@pytest.fixture()
def mock_event_data_no_lender_ids(mock_event_data):
    def return_value(*args, **kwargs):
        event_data = mock_event_data()
        for value in event_data:
            value.pop("eventKeyData")
        return event_data

    return return_value
