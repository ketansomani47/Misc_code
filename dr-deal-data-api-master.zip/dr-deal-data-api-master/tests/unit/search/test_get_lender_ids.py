# -*- coding: utf-8 -*-
import json
from http import HTTPStatus

from common.settings import ErrorMsgs
from search import get_lender_ids
from utils.db_helper import DynamoDbHelper


def test_get_lender_ids(
    lambda_context,
    monkeypatch,
    mock_event_data,
    get_api_gateway_event,
    dr_ulid,
    expected_lender_ids,
    mock_dynamodb_helper,
):
    """
    Test to check successful GET for lender id records
    """
    monkeypatch.setattr(
        DynamoDbHelper, "query_with_selected_attributes", mock_event_data
    )

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/dealRefId/lender-ids"
    event["pathParameters"] = {"dealRefId": dr_ulid}

    response = get_lender_ids.get_lender_ids(event, lambda_context)
    body = json.loads(response["body"])

    assert response["statusCode"] == HTTPStatus.OK
    assert sorted(body["lenderIds"]) == sorted(expected_lender_ids)


def test_get_lender_ids_for_idl(
    lambda_context,
    monkeypatch,
    mock_event_data,
    get_api_gateway_event,
    dr_ulid,
    expected_lender_ids,
    mock_dynamodb_helper,
):
    """
    Test to check successful GET for lender id records
    """
    monkeypatch.setattr(
        DynamoDbHelper, "query_with_selected_attributes", mock_event_data
    )

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/dealRefId/lender-ids"
    event["pathParameters"] = {"dealRefId": dr_ulid}
    event["queryStringParameters"] = {"targetPlatformId": "IDL"}

    response = get_lender_ids.get_lender_ids(event, lambda_context)
    body = json.loads(response["body"])

    assert response["statusCode"] == HTTPStatus.OK
    assert sorted(body["lenderIds"]) == sorted(expected_lender_ids)


def test_get_np_lender_ids(
    lambda_context,
    monkeypatch,
    mock_query_items_empty,
    get_api_gateway_event,
    dr_ulid,
    mock_dynamodb_helper,
):
    """
    Test to check successful GET for No lender id records
    """
    monkeypatch.setattr(
        DynamoDbHelper, "query_with_selected_attributes", mock_query_items_empty
    )

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/dealRefId/lender-ids"
    event["pathParameters"] = {"dealRefId": dr_ulid}

    response = get_lender_ids.get_lender_ids(event, lambda_context)
    body = json.loads(response["body"])

    assert response["statusCode"] == HTTPStatus.OK
    assert sorted(body["lenderIds"]) == []


def test_get_no_deal(
    lambda_context, monkeypatch, get_api_gateway_event, dr_ulid, db_query_items
):
    """
    Test to check if no deal is present for dealRefId
    """
    monkeypatch.setattr(DynamoDbHelper, "query_items", db_query_items)

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/{dealRefId}/lender-ids"
    event["pathParameters"] = {"dealRefId": dr_ulid}
    response = get_lender_ids.get_lender_ids(event, lambda_context)
    body = json.loads(response["body"])

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert body["message"] == ErrorMsgs.missing_deal_from_db.format(deal_ref_id=dr_ulid)


def test_get_lender_id_exception(
    lambda_context,
    monkeypatch,
    return_exception,
    get_api_gateway_event,
    dr_ulid,
    mock_dynamodb_helper,
):
    """
    Test to check if exception is handled
    """
    monkeypatch.setattr(
        DynamoDbHelper, "query_with_selected_attributes", return_exception
    )

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/{dealRefId}/lender-ids"
    event["pathParameters"] = {"dealRefId": dr_ulid}
    response = get_lender_ids.get_lender_ids(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.INTERNAL_SERVER_ERROR
