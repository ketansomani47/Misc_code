# -*- coding: utf-8 -*-
import pytest
from common import settings
from utils.db_helper import DynamoDbHelper


@pytest.fixture(autouse=True)
def mock_dynamodb_helper(monkeypatch, mock_query_pk_filter):
    monkeypatch.setattr(DynamoDbHelper, "query_pk_filter", mock_query_pk_filter)


@pytest.fixture()
def lead_full_payload(credit_app_full_payload):
    return credit_app_full_payload


@pytest.fixture()
def get_api_gateway_event_lead_new_deal(get_api_gateway_event):
    def api_gateway_event(body):
        event = get_api_gateway_event(body)
        event["path"] = "/v1/deals/dealRefId/credit-apps"
        event["requestContext"] = {"operationName": "lead_new_deal"}
        return event

    return api_gateway_event


@pytest.fixture()
def get_api_gateway_event_lead_existing_deal(get_api_gateway_event):
    def api_gateway_event(body):
        event = get_api_gateway_event(body)
        event["path"] = "/v1/deals/dealRefId/credit-apps"
        event["pathParameters"] = {"dealRefId": "0000000000AAABBBCCDDEEFFGG"}
        event["requestContext"] = {"operationName": "lead_existing_deal"}
        return event

    return api_gateway_event


@pytest.fixture()
def get_api_gateway_event_lead_update(get_api_gateway_event):
    def api_gateway_event(body):
        event = get_api_gateway_event(body)
        event["path"] = "/v1/deals/dealRefId/leads/leadRefId"
        event["pathParameters"] = {
            "dealRefId": "0000000000AAABBBCCDDEEFFGG",
            "leadRefId": "0000000000AAABBBCCDDEEFFGG",
        }
        event["requestContext"] = {"operationName": "lead_update"}
        return event

    return api_gateway_event


@pytest.fixture()
def get_api_gateway_event_new_lead(get_api_gateway_event, dr_ulid_new):
    def api_gateway_event(body):
        event = get_api_gateway_event(body)
        event["path"] = "/v1/deals/leads"
        event["headers"] = {settings.DEAL_REF_ID_HEADER_KEY: dr_ulid_new}
        event["requestContext"] = {"operationName": "lead_new_deal"}
        return event

    return api_gateway_event


@pytest.fixture()
def get_api_gateway_event_lead_healthcheck(get_api_gateway_event):
    event = get_api_gateway_event("")
    event["headers"] = {
        settings.HEALTHCHECK_HEADER_FIELD: settings.HEALTHCHECK_HEADER_VALUE
    }
    event["path"] = "/v1/deals/dealRefId/leads"
    return event
