# -*- coding: utf-8 -*-

import json
from http import HTTPStatus

from common import deal_consumer, settings
from common.settings import ErrorMsgs, PayloadType as pt
from common.validators import BaseValidator
from lead import producer


def test_lead_new_deal_successful(
    lead_full_payload,
    sqs,
    get_api_gateway_event_lead_new_deal,
    uuid_newly_generated,
    response_header,
    dr_ulid,
    lambda_context,
    mock_dr_utils,
    dynamodb,
):
    event = get_api_gateway_event_lead_new_deal(lead_full_payload)
    event.pop("headers")
    response = producer.lead_handlers(event, lambda_context)
    mock_dr_utils.send_payload_to_queue.assert_called_with(
        queue="DealDataQueue",
        payload={
            **lead_full_payload,
            **{"sourcePartnerDealerId": "123987", "baggage": None},
        },
        region="us-east-1",
        msg_group_id=dr_ulid,
        payloadType=pt.LEAD_POST,
        correlationId=uuid_newly_generated,
        dealRefId=dr_ulid,
        leadRefId=dr_ulid,
    )

    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps({"dealRefId": dr_ulid, "leadRefId": dr_ulid})
    assert response["headers"] == response_header(uuid_newly_generated)


def test_lead_new_deal_successful_correlation_id_provided(
    lead_full_payload,
    sqs,
    get_api_gateway_event_lead_new_deal,
    uuid_provided,
    response_header,
    dr_ulid,
    lambda_context,
):
    event = get_api_gateway_event_lead_new_deal(lead_full_payload)

    response = producer.lead_handlers(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps({"dealRefId": dr_ulid, "leadRefId": dr_ulid})
    assert response["headers"] == response_header(uuid_provided)


def test_lead_new_deal_no_body(
    sqs,
    uuid_provided,
    response_header,
    get_api_gateway_event_lead_new_deal,
    lambda_context,
):
    event = get_api_gateway_event_lead_new_deal("")
    response = producer.lead_handlers(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps({"message": ErrorMsgs.missing_body_aws_event})
    assert response["headers"] == response_header(uuid_provided)


def test_lead_new_deal_json_decoder_error(
    sqs,
    get_api_gateway_invalid_event,
    uuid_provided,
    response_header,
    lambda_context,
    dr_ulid,
):
    event = get_api_gateway_invalid_event
    event["pathParameters"] = {"dealRefId": dr_ulid, "leadRefId": dr_ulid}
    event["requestContext"] = {"operationName": "lead_new_deal"}

    response = producer.lead_handlers(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["headers"] == response_header(uuid_provided)


def test_lead_new_deal_health_check(
    lambda_context, get_api_gateway_event_lead_healthcheck
):
    event = get_api_gateway_event_lead_healthcheck
    event["requestContext"] = {"operationName": "lead_new_deal"}
    response = producer.lead_handlers(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps("Operational")


def test_update_successful(
    lead_full_payload,
    sqs,
    get_api_gateway_event_lead_update,
    uuid_provided,
    response_header,
    lambda_context,
):

    event = get_api_gateway_event_lead_update(lead_full_payload)

    response = producer.lead_handlers(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.NO_CONTENT
    assert response["body"] == "Lead was updated"
    assert response["headers"] == response_header(uuid_provided)


def test_update_generates_correlation_id(
    lead_full_payload,
    sqs,
    get_api_gateway_event_lead_update,
    uuid_provided,
    response_header,
    lambda_context,
):

    event = get_api_gateway_event_lead_update(lead_full_payload)

    response = producer.lead_handlers(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.NO_CONTENT
    assert response["body"] == "Lead was updated"
    assert response["headers"] == response_header(uuid_provided)


def test_update_successful_correlation_id_provided(
    lead_full_payload,
    sqs,
    get_api_gateway_event_lead_update,
    uuid_provided,
    response_header,
    lambda_context,
):
    event = get_api_gateway_event_lead_update(lead_full_payload)

    response = producer.lead_handlers(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.NO_CONTENT
    assert response["body"] == "Lead was updated"
    assert response["headers"] == response_header(uuid_provided)


def test_health_check_for_update(lambda_context):
    event = {
        "headers": {
            settings.HEALTHCHECK_HEADER_FIELD: settings.HEALTHCHECK_HEADER_VALUE
        },
        "path": "/v1/deals/dealRefId/leads/leadRefId",
        "requestContext": {"operationName": "lead_update"},
    }
    response = producer.lead_handlers(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps("Operational")


def test_update_no_body(
    sqs,
    uuid_provided,
    response_header,
    get_api_gateway_event_lead_update,
    lambda_context,
):
    event = get_api_gateway_event_lead_update("")
    response = producer.lead_handlers(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps({"message": ErrorMsgs.missing_body_aws_event})
    assert response["headers"] == response_header(uuid_provided)


def test_update_json_decoder_error(
    sqs,
    get_api_gateway_invalid_event,
    uuid_provided,
    response_header,
    dr_ulid,
    lambda_context,
):
    event = get_api_gateway_invalid_event
    event.update({"path": "/v1/deals/dealRefId/leads/leadRefId"})
    event["pathParameters"] = {"dealRefId": dr_ulid, "leadRefId": dr_ulid}
    event["requestContext"] = {"operationName": "lead_update"}

    response = producer.lead_handlers(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["headers"] == response_header(uuid_provided)


def test_lead_existing_deal_successful(
    lead_full_payload,
    sqs,
    get_api_gateway_event_lead_existing_deal,
    uuid_provided,
    response_header,
    dr_ulid,
    lambda_context,
):

    event = get_api_gateway_event_lead_existing_deal(lead_full_payload)

    response = producer.lead_handlers(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps({"dealRefId": dr_ulid, "leadRefId": dr_ulid})
    assert response["headers"] == response_header(uuid_provided)


def test_lead_generic_error(
    monkeypatch,
    lambda_context,
    lead_full_payload,
    sqs,
    get_api_gateway_event_lead_existing_deal,
    uuid_provided,
    response_header,
    dr_ulid,
):
    def raise_error(self, *args, **kwargs):
        raise Exception("test exception")

    event = get_api_gateway_event_lead_existing_deal(lead_full_payload)
    monkeypatch.setattr(BaseValidator, "__init__", raise_error)

    test_subjects = ["lead_new_deal", "lead_existing_deal", "lead_update"]

    for test_subject in test_subjects:
        event["requestContext"] = {"operationName": test_subject}
        response = producer.lead_handlers(event, lambda_context)
        assert response["statusCode"] == HTTPStatus.INTERNAL_SERVER_ERROR
        assert response["body"] == json.dumps({"message": "test exception"})
        assert response["headers"] == response_header(uuid_provided)


def test_lead_existing_deal_successful_correlation_id_provided(
    lead_full_payload,
    sqs,
    get_api_gateway_event_lead_existing_deal,
    uuid_provided,
    response_header,
    dr_ulid,
    lambda_context,
):
    event = get_api_gateway_event_lead_existing_deal(lead_full_payload)

    response = producer.lead_handlers(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps({"dealRefId": dr_ulid, "leadRefId": dr_ulid})
    assert response["headers"] == response_header(uuid_provided)


def test_health_check_for_lead_existing_deal(lambda_context):
    event = {
        "headers": {
            settings.HEALTHCHECK_HEADER_FIELD: settings.HEALTHCHECK_HEADER_VALUE
        },
        "path": "/v1/deals/dealRefId/leads/leadRefId",
        "requestContext": {"operationName": "lead_existing_deal"},
    }
    response = producer.lead_handlers(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps("Operational")


def test_lead_existing_deal_no_body(
    sqs,
    uuid_provided,
    response_header,
    get_api_gateway_event_lead_existing_deal,
    lambda_context,
):
    event = get_api_gateway_event_lead_existing_deal("")
    response = producer.lead_handlers(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps({"message": ErrorMsgs.missing_body_aws_event})
    assert response["headers"] == response_header(uuid_provided)


def test_lead_existing_deal_json_decoder_error(
    sqs,
    get_api_gateway_invalid_event,
    uuid_provided,
    response_header,
    lambda_context,
    dr_ulid,
):
    event = get_api_gateway_invalid_event
    event["path"] = "/v1/deals/dealRefId/leads/leadRefId"
    event["pathParameters"] = {"dealRefId": dr_ulid, "leadRefId": dr_ulid}
    event["requestContext"] = {"operationName": "lead_existing_deal"}

    response = producer.lead_handlers(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["headers"] == response_header(uuid_provided)


def test_ca_existing_deal_and_lead_resourceid_validation_error(
    lead_full_payload, lambda_context, get_sqs_event, get_api_gateway_event_lead_update
):
    deal_ref_id = lead_full_payload.get("dealRefId")
    invalid_leadRef_id = "invalidLeadRefId"

    event = get_sqs_event(lead_full_payload, pt.LEAD_POST)
    response = deal_consumer.handler(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.CREATED

    event = get_api_gateway_event_lead_update(lead_full_payload)
    event["path"] = "/v1/deals/dealRefId/leads/leadRefId"
    event["pathParameters"] = {
        "dealRefId": deal_ref_id,
        "leadRefId": invalid_leadRef_id,
    }
    event["requestContext"] = {"operationName": "lead_update"}

    response = producer.lead_handlers(event, lambda_context)
    assert response["body"] == json.dumps(
        {
            "message": ErrorMsgs.resource_id_mismatch.format(
                resource_id=invalid_leadRef_id, deal_ref_id=deal_ref_id
            )
        }
    )


def test_lead_new_deal_invalid_ulid(
    lead_full_payload,
    sqs,
    get_api_gateway_event_lead_new_deal,
    uuid_provided,
    response_header,
    lambda_context,
):
    event = get_api_gateway_event_lead_new_deal(lead_full_payload)
    event["headers"]["X-Deal-Reference-Id"] = "01F2SMF7K7XKA7XB4A4CY10SF@"
    event["requestContext"] = {"operationName": "lead_new_deal"}

    response = producer.lead_handlers(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(
        {"message": 'Invalid ulid provided. Error Non-base32 character found: "@"'}
    )
    assert response["headers"] == response_header(uuid_provided)


def test_lead_existing_deal_invalid_ulid(
    lead_full_payload,
    sqs,
    get_api_gateway_event_lead_existing_deal,
    uuid_provided,
    response_header,
    lambda_context,
):

    event = get_api_gateway_event_lead_existing_deal(lead_full_payload)
    event["headers"]["X-Deal-Reference-Id"] = "01F2SMF7K7XKA7XB4A4CY10SF@"
    event["requestContext"] = {"operationName": "lead_existing_deal"}

    response = producer.lead_handlers(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(
        {"message": 'Invalid ulid provided. Error Non-base32 character found: "@"'}
    )
    assert response["headers"] == response_header(uuid_provided)


def test_lead_new_deal_handler(lambda_context, get_api_gateway_event_lead_healthcheck):
    event = get_api_gateway_event_lead_healthcheck
    event["requestContext"] = {"operationName": "lead_new_deal"}
    response = producer.lead_handlers(event, lambda_context)
    response_object_instance = producer.LeadProducerLambda().get_handler(
        handler_func="new_deal_handler", payload_type=pt.LEAD_POST
    )
    response_object_instance = response_object_instance(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.CREATED
    assert response_object_instance["statusCode"] == HTTPStatus.CREATED
    assert response["statusCode"] == response_object_instance["statusCode"]

    assert response["body"] == json.dumps("Operational")
    assert response_object_instance["body"] == json.dumps("Operational")
    assert response["body"] == response_object_instance["body"]


def test_lead_new_deal_dealrefid_given(lambda_context, get_api_gateway_event_new_lead):
    event = get_api_gateway_event_new_lead("")
    response = producer.lead_handlers(event, lambda_context)
    response_object_instance = producer.LeadProducerLambda().get_handler(
        handler_func="new_deal_handler", payload_type=pt.LEAD_POST
    )
    response_object_instance = response_object_instance(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response_object_instance["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["statusCode"] == response_object_instance["statusCode"]

    assert response["body"] == response_object_instance["body"]


def test_lead_update_handler(lambda_context, get_api_gateway_event_lead_healthcheck):
    event = {
        "headers": {
            settings.HEALTHCHECK_HEADER_FIELD: settings.HEALTHCHECK_HEADER_VALUE
        },
        "path": "/v1/deals/dealRefId/leads/leadRefId",
        "requestContext": {"operationName": "lead_update"},
    }
    response = producer.lead_handlers(event, lambda_context)
    response_object_instance = producer.LeadProducerLambda().get_handler(
        handler_func="update_handler", payload_type=pt.LEAD_UPDATE
    )
    response_object_instance = response_object_instance(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.CREATED
    assert response_object_instance["statusCode"] == HTTPStatus.CREATED
    assert response["statusCode"] == response_object_instance["statusCode"]

    assert response["body"] == json.dumps("Operational")
    assert response_object_instance["body"] == json.dumps("Operational")
    assert response["body"] == response_object_instance["body"]


def test_lead_existing_deal_handler(
    lambda_context, get_api_gateway_event_lead_healthcheck
):
    event = {
        "headers": {
            settings.HEALTHCHECK_HEADER_FIELD: settings.HEALTHCHECK_HEADER_VALUE
        },
        "path": "/v1/deals/dealRefId/leads/leadRefId",
        "requestContext": {"operationName": "lead_existing_deal"},
    }
    response = producer.lead_handlers(event, lambda_context)
    response_object_instance = producer.LeadProducerLambda().get_handler(
        handler_func="existing_deal_handler", payload_type=pt.LEAD_PATCH
    )
    response_object_instance = response_object_instance(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.CREATED
    assert response_object_instance["statusCode"] == HTTPStatus.CREATED
    assert response["statusCode"] == response_object_instance["statusCode"]

    assert response["body"] == json.dumps("Operational")
    assert response_object_instance["body"] == json.dumps("Operational")
    assert response["body"] == response_object_instance["body"]
