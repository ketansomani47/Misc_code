# -*- coding: utf-8 -*-
import json
from copy import deepcopy

import pytest
from utils.exceptions import BadRequestError

import utils.schema
from stringcase import camelcase
from utils import common as common_utils
from utils.db_helper import DynamoDbHelper
from uuid import uuid4 as uuid


class TestUtils:
    def test_convert_empty_strings_to_none(
        self, sample_payload_with_empty_string, expected_payload_with_none
    ):
        """
        Test to verifies that empty string in given payload converted to None
        :param sample_payload_with_empty_string: dict with empty string as values
        :param expected_payload_with_none: dict with None as values
        """
        payload = common_utils.convert_empty_strings_to_none(
            sample_payload_with_empty_string
        )
        assert payload == expected_payload_with_none

    def test_check_api_version_for_update(self, monkeypatch, db_query_empty):
        monkeypatch.setattr(DynamoDbHelper, "query_items", db_query_empty)
        with pytest.raises(Exception):
            common_utils.validate_api_version("us-east-1", "deals", "123456", "v1")

    def test_decimal_default(self, raw_event_dict, serialized_raw_event_dict):
        actual = json.dumps(
            raw_event_dict, cls=common_utils.decimal_decoder(), indent=8
        )
        assert actual == serialized_raw_event_dict

    def test_decimal_not_default(self):
        with pytest.raises(TypeError):
            common_utils.decimal_decoder().default(5.5)

    def test_decimal_and_set_default(
        self, raw_event_dict_with_set, serialized_raw_event_dict_with_set
    ):
        actual = json.dumps(
            raw_event_dict_with_set, cls=common_utils.decimal_set_decoder(), indent=8
        )
        assert actual == serialized_raw_event_dict_with_set

    def test_decimal_and_set_not_default(self):
        with pytest.raises(TypeError):
            common_utils.decimal_set_decoder().default(5.5)
        with pytest.raises(TypeError):
            common_utils.decimal_set_decoder().default(set({"Test"}))

    def test_change_dict_naming(
        self, sample_payload_with_snake_case, expected_payload_with_camel_case
    ):
        actual = common_utils.change_dict_naming(
            sample_payload_with_snake_case, camelcase
        )
        assert actual == expected_payload_with_camel_case

    def test_extract_key_data(self):
        test_request_headers = {
            "X-Lead-Reference-Number": "1",
            "X-Application-Reference-Number": "2",
            "X-Deal-Jacket-ID": "3",
            "X-Dealer-Code": "6",
            "X-Deal-Reference-Number-UniFI": "7",
            "X-ABCD-ID": "8",
        }
        expected = {
            "dealRefIdFD": "1",
            "appRefIdFD": "2",
            "dealJacketId": "3",
            "dealerCode": "6",
            "dealRefIdFI": "7",
        }
        actual = common_utils.extract_key_data(test_request_headers)
        assert actual == expected

    def test_generate_s3_file_tags(self):
        s3_tag_keys = {
            "dealRefId": "12345",
            "partnerDealerId": "23451",
            "creditAppId": "34512",
            "lenderId": "45123",
            "partnerId": "51234",
        }
        expected = "dealRefId=12345&partnerDealerId=23451&creditAppId=34512&lenderId=45123&partnerId=51234"
        actual = common_utils.generate_s3_file_tags(s3_tag_keys)
        assert actual == expected

    def test_generate_s3_key(self):
        key = "{partnerId}/{partnerDealerId}/{creditAppId}/TEST/{lenderId}"
        expected = "DBX/23451/34512/TEST/45123"
        actual = common_utils.generate_s3_key(
            key,
            partnerId="DBX",
            partnerDealerId="23451",
            creditAppId="34512",
            lenderId="45123",
        )
        assert actual == expected


class TestDynamoDbHelper:

    TABLE = "deals"
    REGION = "us-east-1"

    def test_update_item_and_scan_item(
        self, dynamodb, sample_dynamodb_record, filter_record_scan
    ):
        db = DynamoDbHelper(region=self.REGION, table_name=self.TABLE)
        db.table = dynamodb.Table(self.TABLE)
        db.table.put_item(Item=sample_dynamodb_record)
        sample_dynamodb_record.update({"testCol": "test"})
        db.update_item(
            partition_key="dealRefId",
            sort_key="dealComponent",
            update_record=deepcopy(sample_dynamodb_record),
        )
        filter_record = filter_record_scan(sample_dynamodb_record)
        scan_records = db.scan_items(filter_expr_dict=filter_record)
        assert scan_records[0].items() >= sample_dynamodb_record.items()

    def test_query_items(
        self, dynamodb, sample_dynamodb_record, key_expr, key_expr_dict
    ):
        db = DynamoDbHelper(region=self.REGION, table_name=self.TABLE)
        db.table = dynamodb.Table(self.TABLE)
        db.table.put_item(Item=sample_dynamodb_record)

        records = db.query_items(key_expr_dict=key_expr_dict)
        assert records[0] == sample_dynamodb_record

        records = db.query_items(key_expression=key_expr)
        assert records[0] == sample_dynamodb_record


def test_add_ttl(constant_time):
    actual = common_utils.add_ttl({}, 5)
    assert actual == {"ttl": constant_time + 5}


def test_generate_schema_components():
    schema = {"applicant": {"firstName": "str"}}

    data = {"applicant": {"firstName": "Bernard"}, "foo": "bar"}

    actual = utils.schema.generate_schema_components(schema, data)
    expected = {"APPLICANT": "applicant"}

    assert actual == expected


def test_remove_empty_nodes():
    data = {"applicant": {"firstName": "str", "address": {}}}

    expected = {"applicant": {"firstName": "str"}}
    actual = common_utils.remove_empty_nodes(data)

    assert actual == expected


def test_drop_ref_ids():
    resp = common_utils.drop_ref_ids_from_payload(
        data={"dealRefIdFD": "123", "test": "value"}
    )

    assert resp == {"test": "value"}


def test_verify_and_add_source_partner_dealer_id_no_partner_dealer():
    data = {
        "targetPlatforms": [
            {"id": "RT1x", "partyId": "23125"},
            {"id": "DTCx", "partyId": "23687"},
        ]
    }
    resp = common_utils.verify_and_add_source_partner_dealer_id(data=data)
    assert resp["sourcePartnerDealerId"] == "23125"


def test_verify_and_add_source_partner_dealer_id_exist_partner_dealer():
    data = {
        "sourcePartnerDealerId": "a123",
        "targetPlatforms": [
            {"id": "RT1x", "partyId": "23125"},
            {"id": "DTCx", "partyId": "23687"},
        ],
    }
    resp = common_utils.verify_and_add_source_partner_dealer_id(data=data)
    assert resp["sourcePartnerDealerId"] == "a123"


def test_verify_and_add_source_partner_dealer_id_no_partner_dealer_no_target():
    data = {}
    resp = common_utils.verify_and_add_source_partner_dealer_id(data=data)
    assert resp == {}


def test_verify_uuid_success():
    test_uuid = str(uuid())
    resp = common_utils.verify_uuid(test_uuid)
    assert resp is None


def test_verify_uuid_error():
    test_uuid = "1234"
    with pytest.raises(BadRequestError):
        common_utils.verify_uuid(test_uuid)
