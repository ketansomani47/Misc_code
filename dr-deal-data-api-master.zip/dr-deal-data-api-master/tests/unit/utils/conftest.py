# -*- coding: utf-8 -*-
import pytest
from boto3.dynamodb.conditions import Key


@pytest.fixture()
def sample_deal_component():
    return "dtc.test"


@pytest.fixture()
def sample_dynamodb_record(dr_ulid, sample_deal_component):
    return {
        "dealRefId": dr_ulid,
        "dealComponent": sample_deal_component,
        "partnerId": "F00COX-1-6TMC2QKF2F",
    }


@pytest.fixture()
def filter_record_scan():
    def wrapper(update_record):
        return {
            "dealComponent": {
                "operation": "eq",
                "value": update_record["dealComponent"],
            },
            "partnerId": {
                "operation": "contains",
                "value": update_record["partnerId"].split("-")[-1],
            },
        }

    return wrapper


@pytest.fixture()
def key_expr_dict(dr_ulid, sample_deal_component):
    return {
        "dealComponent": {"operation": "eq", "value": sample_deal_component},
        "dealRefId": {"operation": "eq", "value": dr_ulid},
    }


@pytest.fixture()
def key_expr(dr_ulid, sample_deal_component):
    return Key("dealRefId").eq(dr_ulid) & Key("dealComponent").eq(sample_deal_component)


@pytest.fixture()
def sample_message_attributes():
    return {"foo": {"StringValue": "bar", "DataType": "String"}}


@pytest.fixture()
def sample_payload_with_snake_case():
    return {
        "eventVersion": "1.1",
        "event_id": "1111-c754-41e0-8ba6-4198a34aa0a5",
        "event_time": "2018-07-03T19:16:37.327Z",
        "event_name": "Deal:CreditDecisionResponse",
        "event_identity_id": "1212",
        "event_source": "AHC:decisions",
        "event_transaction_id": "d3aa88e2-c754-41e0-8ba6-5258a34aa0a5",
        "event_entity_id": "104334",
        "payload_schema": "DealDecisionsSummary/v1.0",
        "payload": [
            {
                "partnerId": "MMD",
                "mix_match_format": "MMD",
                "partnerDealerId": 123456789,
                "dealRefId": "d3aa88e2-c754-41e0-8ba6-5258a34aa0a4",
            }
        ],
    }


@pytest.fixture()
def expected_payload_with_camel_case():
    return {
        "eventVersion": "1.1",
        "eventId": "1111-c754-41e0-8ba6-4198a34aa0a5",
        "eventTime": "2018-07-03T19:16:37.327Z",
        "eventName": "Deal:CreditDecisionResponse",
        "eventIdentityId": "1212",
        "eventSource": "AHC:decisions",
        "eventTransactionId": "d3aa88e2-c754-41e0-8ba6-5258a34aa0a5",
        "eventEntityId": "104334",
        "payloadSchema": "DealDecisionsSummary/v1.0",
        "payload": [
            {
                "partnerId": "MMD",
                "mixMatchFormat": "MMD",
                "partnerDealerId": 123456789,
                "dealRefId": "d3aa88e2-c754-41e0-8ba6-5258a34aa0a4",
            }
        ],
    }
