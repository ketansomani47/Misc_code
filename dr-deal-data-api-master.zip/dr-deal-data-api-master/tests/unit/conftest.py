# -*- coding: utf-8 -*-
import copy
import datetime
import json
import os
import secrets
import time
from decimal import Decimal
from http import HTTPStatus
from unittest.mock import MagicMock

import boto3
import freezegun
import pytest
import ulid
from uuid import uuid4 as uuid
from boto3.dynamodb.conditions import Key
from botocore.exceptions import ClientError
from common import (
    deal,
    deal_consumer,
    healthchecks,
    info,
    lambda_base,
    mixins,
    router,
    settings as se,
    validators,
)
from common.validators import ExistingDealValidator
from contract import producer as con_producer, producer_v2 as con_producer_v2
from credit_app import get as credit_app_get, producer as credit_app_producer
from credit_bureau import producer as credit_bureau_producer
from decisions import lender_decision
from docs import docs_lambda
from events import (
    consumer as event_consumer,
    events_lambda,
    producer as event_producer,
    route as event_route,
    utils as event_utils,
)
from key_data import (
    get as key_data_get,
    get_v2 as key_data_get_v2,
    producer as key_data_producer,
    producer_v2 as key_data_producer_v2,
)
from lead import producer as lead_producer
from moto import mock_aws
from reprocess import dlq_processing
from search import get_lender_ids
from snapshots import consumer as snapshot_consumer
from tests.unit.credit_bureau.conftest import CREDIT_BUREAU_ID
from utils import common, db_helper, exceptions, logging


TIME = 1234567890000
TIMESTAMP = "2018-12-31T23:11:22.543545"
DATETIME = datetime.datetime.strptime(TIMESTAMP, "%Y-%m-%dT%H:%M:%S.%f")
DR_ULID = "0000000000AAABBBCCDDEEFFGG"
DR_ULID_NEW = "1111111111AAABBBCCDDEEFFGG"
DR_UUID_PROVIDED = "12345abc-abc1-2def-56ef-000000000000"
DR_UUID_NEW = "99999aaa-abc1-2def-56ef-000000newgen"
DLR_CD = "12345"
DR_DLR_ID = "123456"


@pytest.fixture()
def dlr_code():
    return DLR_CD


@pytest.fixture()
def dr_ulid():
    return DR_ULID


@pytest.fixture()
def dr_ulid_new():
    return DR_ULID_NEW


@pytest.fixture()
def uuid_provided():
    return DR_UUID_PROVIDED


@pytest.fixture()
def uuid_newly_generated():
    return DR_UUID_NEW


@pytest.fixture()
def dr_ttl():
    return Decimal(TIME + se.RetentionPeriod.general)


@pytest.fixture()
def time_stamp():
    return TIMESTAMP


@pytest.fixture()
def frozen_time():
    return TIME


@pytest.fixture()
def lambda_context():
    class MockLambdaContext:
        invoked_function_arn = "arn:sample:service:region:account-id:resource-id"

    return MockLambdaContext()


@pytest.fixture()
def constant_time():
    return TIME


@pytest.fixture(autouse=True)
def mock_uuid(monkeypatch):
    def mock_uuid():
        return "99999aaa-abc1-2def-56ef-000000newgen"

    monkeypatch.setattr(deal_consumer, "uuid", mock_uuid)
    monkeypatch.setattr(common, "uuid", mock_uuid)
    monkeypatch.setattr(event_consumer, "uuid", mock_uuid)
    monkeypatch.setattr(lambda_base, "uuid", mock_uuid)


class MockUlid:
    int = TIME
    datetime = DATETIME

    def __init__(self, ulid):
        self.str = ulid

    def new(self):
        return self

    def timestamp(self):
        return self

    def parse(self, ulid):
        return self


@pytest.fixture(autouse=True)
def patch_ulid(monkeypatch):
    mock_ulid = MockUlid(DR_ULID)
    monkeypatch.setattr(ulid, "new", mock_ulid.new)


@pytest.fixture(autouse=True)
def patch_retry_time(monkeypatch):
    monkeypatch.setattr(
        deal_consumer, "RETRY_DELAY_TIME", {1: 0.1, 2: 0.1, 3: 0.1, 4: 0.1, 5: 0.1}
    )
    monkeypatch.setattr(
        se, "RETRY_DELAY_TIME", {1: 0.1, 2: 0.1, 3: 0.1, 4: 0.1, 5: 0.1}
    )


@pytest.fixture(autouse=True)
def patch_datetime_utcnow(monkeypatch):
    class Mydatetime(datetime.datetime):
        @classmethod
        def utcnow(cls):
            return DATETIME

    monkeypatch.setattr(deal_consumer, "datetime", Mydatetime)
    monkeypatch.setattr(db_helper, "datetime", Mydatetime)


@pytest.fixture(autouse=True)
def patch_time(monkeypatch):
    def mock_time():
        return TIME

    monkeypatch.setattr(time, "time", mock_time)


class MockEnv:
    AWS_REGION = "us-east-1"
    DEAL_DATA_DLQ = "DealDataDLQ"
    DEAL_DATA_QUEUE = "DealDataQueue"
    DEAL_DATA_STATUS_QUEUE = "DealDataStatusQueue"
    EVENT_BUS = "test-event-bus"
    EVENT_SOURCE = "test.event.source"
    KEY = "123456789"
    KMS_REGULATED_KEY_ALIAS_NAME = "test-key-alias"
    ROUTE_ONE_QUEUE = "RouteOneQueue"
    ROUTE_ONE_JSON_QUEUE = "RouteOneJsonQueue"
    HONDA_QUEUE = "HondaQueue"
    UNIFI_BRIDGE_QUEUE = "UnifiBridgeQueue"
    UNIFI_BRIDGE_DLQ = "UnifiBridgeDLQ"
    QUEUE_MAPPING = {
        "RT1": ROUTE_ONE_QUEUE,
        "R1J": ROUTE_ONE_JSON_QUEUE,
        "IDL": HONDA_QUEUE,
        "DTC": UNIFI_BRIDGE_QUEUE,
    }
    STAGE = "mock"
    URL = "mock123456.execute-api.us-east-1.amazonaws.com/stage"
    VERSION = "v1.0"
    EVENT_QUEUE = "EventQueue"
    EVENT_ROUTE_QUEUE = "EventRouteQueue"
    DEPLOY_ENV = "lab"
    SERVICE_NAME = "dr_deal_data_api"
    ROUTE_ONE_SERVICE_NAME = "dr_routeone_bridge"
    HONDA_SERVICE_NAME = "dr_honda_bridge"
    UNIFI_BRIDGE_SERVICE_NAME = "dr_unifi_bridge"
    DEPLOY_STATUS = "Completed"
    SNAPSHOT_BUCKET = "SnapshotS3Bucket"
    DEAL_BUCKET = "SnapshotS3Bucket"
    REPROCESSING_GARAGE = "ReprocessingGarage"
    SNAPSHOT_QUEUE = "SnapshotQueue"
    SNAPSHOT_DLQ = "SnapshotDLQ"
    EVENTS_ENDPOINT = "events-dvi1.drsvcnp.aws.dealertrack.com/v1/deals"
    SETTINGS_ENDPOINT = "get-subscription.settings.aws.dealertrack.com"
    SETTINGS_API_KEY = secrets.token_urlsafe(16)
    AWS_SESSION_TOKEN = "AWS_SESSION_TOKEN"
    API_NAME = "dr-deal-data-api"
    CHECK_LEAD_REFERENCE_ID = "false"
    DEALXG_BRIDGE_QUEUE = "DEALXG_BRIDGE_QUEUE"
    DEALXG_BRIDGE_SERVICE_NAME = "dr-dealxg-bridge"


@pytest.fixture()
def mock_env():
    return MockEnv()


@pytest.fixture(autouse=True)
def patch_env(monkeypatch):
    monkeypatch.setattr(common, "Env", MockEnv)
    monkeypatch.setattr(credit_bureau_producer, "Env", MockEnv)
    monkeypatch.setattr(deal, "Env", MockEnv)
    monkeypatch.setattr(deal_consumer, "Env", MockEnv)
    monkeypatch.setattr(event_consumer, "Env", MockEnv)
    monkeypatch.setattr(event_producer, "Env", MockEnv)
    monkeypatch.setattr(event_route, "Env", MockEnv)
    monkeypatch.setattr(event_utils, "Env", MockEnv)
    monkeypatch.setattr(healthchecks, "Env", MockEnv)
    monkeypatch.setattr(info, "Env", MockEnv)
    monkeypatch.setattr(lambda_base, "Env", MockEnv)
    monkeypatch.setattr(lead_producer, "Env", MockEnv)
    monkeypatch.setattr(credit_app_producer, "Env", MockEnv)
    monkeypatch.setattr(key_data_get, "Env", MockEnv)
    monkeypatch.setattr(router, "Env", MockEnv)
    monkeypatch.setattr(validators, "Env", MockEnv)
    monkeypatch.setattr(snapshot_consumer, "Env", MockEnv)
    monkeypatch.setattr(key_data_producer, "Env", MockEnv)
    monkeypatch.setattr(key_data_producer_v2, "Env", MockEnv)
    monkeypatch.setattr(lender_decision, "Env", MockEnv)
    monkeypatch.setattr(get_lender_ids, "Env", MockEnv)
    monkeypatch.setattr(se, "Env", MockEnv)
    monkeypatch.setattr(events_lambda, "Env", MockEnv)
    monkeypatch.setattr(docs_lambda, "Env", MockEnv)
    monkeypatch.setattr(dlq_processing, "Env", MockEnv)
    monkeypatch.setattr(db_helper, "Env", MockEnv)
    monkeypatch.setattr(key_data_get_v2, "Env", MockEnv)
    monkeypatch.setattr(credit_app_get, "Env", MockEnv)


@pytest.fixture()
def get_sqs_event(uuid_provided, credit_app_partial_payload, decimal_encoder):
    def sqs_event(body, payload_type):
        return {
            "Records": [
                {
                    "attributes": {
                        "ApproximateReceiveCount": "1",
                        "SentTimestamp": "1573251510774",
                        "SequenceNumber": "18849496460467696128",
                        "MessageGroupId": "1",
                        "SenderId": "AIDAIO23YVJENQZJOL4VO",
                        "MessageDeduplicationId": "1",
                        "ApproximateFirstReceiveTimestamp": "1573251510774",
                    },
                    "body": json.dumps(body, cls=decimal_encoder),
                    "messageAttributes": {
                        "correlationId": {
                            "stringValue": uuid_provided,
                            "stringListValues": [],
                            "binaryListValues": [],
                            "dataType": "String",
                        },
                        "payloadType": {
                            "stringValue": payload_type,
                            "stringListValues": [],
                            "binaryListValues": [],
                            "dataType": "String",
                        },
                        "dealRefId": {
                            "stringValue": DR_ULID,
                            "stringListValues": [],
                            "binaryListValues": [],
                            "dataType": "String",
                        },
                        "dealTTL": {
                            "stringValue": 1234573074000,
                            "stringListValues": [],
                            "binaryListValues": [],
                            "dataType": "Number",
                        },
                    },
                }
            ]
        }

    return sqs_event


@pytest.fixture()
def get_sqs_event_dvm_partner(
    uuid_provided, credit_app_dvm_partner_payload, decimal_encoder
):
    def sqs_event(body, payload_type):
        return {
            "Records": [
                {
                    "body": json.dumps(body, cls=decimal_encoder),
                    "messageAttributes": {
                        "correlationId": {
                            "stringValue": uuid_provided,
                            "stringListValues": [],
                            "binaryListValues": [],
                            "dataType": "String",
                        },
                        "payloadType": {
                            "stringValue": payload_type,
                            "stringListValues": [],
                            "binaryListValues": [],
                            "dataType": "String",
                        },
                        "dealRefId": {
                            "stringValue": DR_ULID,
                            "stringListValues": [],
                            "binaryListValues": [],
                            "dataType": "String",
                        },
                        "dealTTL": {
                            "stringValue": 1234573074000,
                            "stringListValues": [],
                            "binaryListValues": [],
                            "dataType": "Number",
                        },
                    },
                }
            ]
        }

    return sqs_event


@pytest.fixture()
def get_api_gateway_event(uuid_provided, decimal_encoder):
    def api_gateway_event(body, additional_headers={}):
        return {
            "body": json.dumps(body, cls=decimal_encoder),
            "headers": {
                se.CORRELATION_ID_HEADER_KEY: uuid_provided,
                **additional_headers,
            },
            "path": "/v1",
            "resource": "/apigateway/resource",
        }

    return api_gateway_event


@pytest.fixture()
def get_api_gateway_invalid_event(uuid_provided):
    return {
        "body": "invalid",
        "headers": {se.CORRELATION_ID_HEADER_KEY: uuid_provided},
        "path": "/v1",
    }


@pytest.fixture()
def get_api_gateway_invalid_event_ca_new(uuid_provided):
    return {
        "body": "invalid",
        "headers": {se.CORRELATION_ID_HEADER_KEY: uuid_provided},
        "path": "/v1",
        "requestContext": {"operationName": "ca_new_deal"},
    }


@pytest.fixture()
def get_api_gateway_invalid_event_ca_existing_deal(uuid_provided):
    return {
        "body": "invalid",
        "headers": {se.CORRELATION_ID_HEADER_KEY: uuid_provided},
        "path": "/v1",
        "requestContext": {"operationName": "ca_existing_deal"},
    }


@pytest.fixture()
def get_cd_gateway_event(uuid_provided, decimal_encoder):
    def api_cd_gateway_event(body):
        return {
            "body": json.dumps(body, cls=decimal_encoder),
            "headers": {
                se.CORRELATION_ID_HEADER_KEY: uuid_provided,
                se.CD_SOURCE_PARTNER: "VIN",
            },
            "path": "/v1/deals/dealRefId/partner-dealers/partnerDealerId/credit-apps/lender/lenderId/decisions/latest",
            "pathParameters": {
                "dealRefId": "dealRefId",
                "partnerDealerId": "partnerDealerId",
                "lenderId": "lenderId",
            },
        }

    return api_cd_gateway_event


@pytest.fixture()
def payment_event(decimal_encoder):
    def api_payment_event(body, operation="payment_detail_get"):
        return {
            "body": json.dumps(body, cls=decimal_encoder),
            "headers": {
                "eventId": str(uuid()),
                "Source-Partner": "DTS",
                "X-CoxAuto-Correlation-Id": DR_UUID_NEW,
            },
            "path": (
                "/v1/deals/dealRefId/partner-dealers/partnerDealerId/"
                "credit-apps/creditAppId/lenders/lenderId/decisions/program"
            ),
            "pathParameters": {
                "dealRefId": DLR_CD,
                "partnerDealerId": DR_DLR_ID,
                "creditAppId": DR_DLR_ID,
                "lenderId": DLR_CD,
            },
            "requestContext": {
                "operationName": operation,
            },
        }

    return api_payment_event


@pytest.fixture()
def fld_event(dr_ulid_new, decimal_encoder):
    def api_fld_event(body, operation="fld_with_credit_app_get"):
        return {
            "body": json.dumps(body, cls=decimal_encoder),
            "headers": {
                "eventId": dr_ulid_new,
                "Source-Partner": "DTS",
                "X-CoxAuto-Correlation-Id": DR_UUID_NEW,
            },
            "path": (
                "/v1/deals/dealRefId/partner-dealers/partnerDealerId/"
                "credit-apps/creditAppId/lenders/lenderId/decisions/latest"
            ),
            "pathParameters": {
                "dealRefId": DLR_CD,
                "partnerDealerId": DR_DLR_ID,
                "creditAppId": DR_DLR_ID,
                "lenderId": DLR_CD,
            },
            "requestContext": {
                "operationName": operation,
            },
        }

    return api_fld_event


@pytest.fixture
def s3_response():
    return {"some_key": "some_value"}


@pytest.fixture()
def update_body_with_key_data():
    def get_body(body):
        body.update({"dealJacketId": DR_ULID_NEW, "dealerCode": DLR_CD})
        return body

    return get_body


@pytest.fixture()
def key_data_payload():
    return {"dealJacketId": DR_ULID_NEW, "dealerCode": DLR_CD}


@pytest.fixture()
def expected_healthcheck_record():
    return {
        "dealRefId": "00000000000000000000000000000",
        "dealComponent": f"{healthchecks.Env.AWS_REGION} Health Check DB Entry Do Not Delete",
    }


@pytest.fixture()
def unexpected_healthcheck_record():
    return {
        "dealRefId": "12345678900987654323456789654",
        "dealComponent": f"{healthchecks.Env.AWS_REGION} Health Check DB Entry Do Not Delete",
    }


@pytest.fixture()
def mock_post():
    def wrap(response_code):
        class MockGet:
            def __init__(self, *args, **kwargs):
                pass

            status_code = response_code

        return MockGet

    return wrap


@pytest.fixture()
def applicant_v1_payload():
    return {
        "customerRole": "Applicant",
        "relationship": "Self",
        "salutation": "Mr.",
        "firstName": "Earnest",
        "lastName": "Winhoffer",
        "middleName": "T",
        "suffix": "JR",
        "phone": "5167349659",
        "address": {
            "line1": "8374 Test St",
            "line2": "APT #D19",
            "city": "Littleton",
            "state": "CO",
            "postalCode": "80128",
        },
        "ssn": "788999009",
        "dateOfBirth": "1963-06-18",
        "driversLicenseNumber": "784534987",
        "driversLicenseState": "CO",
        "monthsAtCurrentAddress": 18,
        "otherPhone": "5167349659",
        "email": "test_email@testserver.com",
        "preferredContactMethod": "Email",
        "preferredLanguage": "English",
        "currentEmployment": {
            "employerName": "Boyles Test Co.",
            "totalMonthsEmployed": 36,
            "occupation": "Program Manager",
            "workPhone": "7130780239",
            "status": "Employed",
            "employerAddress": {
                "line1": "8374 Test St",
                "line2": "APT #D19",
                "city": "Littleton",
                "state": "CO",
                "postalCode": "80128",
            },
        },
        "income": 0,
        "incomeFrequency": "Monthly",
        "otherMonthlyIncome": 104,
        "otherMonthlyIncomeSource": "Pension",
        "housingStatus": "Rent",
        "maritalStatus": "Married",
        "mortgageOrRentAmount": 3500.89,
        "previousAddress": {
            "line1": "8374 Test St",
            "line2": "APT #D19",
            "city": "Littleton",
            "state": "CO",
            "postalCode": "80128",
        },
        "monthsAtPreviousAddress": 18,
        "previousEmployment": {
            "employerName": "Boyles Test Co.",
            "totalMonthsEmployed": 36,
            "occupation": "Program Manager",
            "workPhone": "7130780239",
            "status": "Employed",
            "employerAddress": {
                "line1": "8374 Test St",
                "line2": "APT #D19",
                "city": "Littleton",
                "state": "CO",
                "postalCode": "80128",
            },
        },
        "spouse": {
            "firstName": "Earnest",
            "lastName": "Winhoffer",
            "middleName": "T",
            "suffix": "JR",
            "line1": "1234 Street Blvd",
            "line2": "Unit 1201",
            "city": "Charlotte",
            "state": "CO",
            "postalCode": "282732321",
            "income": 0,
            "incomeFrequency": "Monthly",
            "otherMonthlyIncome": 1000,
            "otherMonthlyIncomeSource": "Rent",
        },
        "consentGiven": True,
    }


@pytest.fixture()
def applicant():
    return {
        "relationship": "Self",
        "salutation": "Mr.",
        "firstName": "Earnest",
        "lastName": "Winhoffer",
        "middleName": "T",
        "suffix": "JR",
        "phone": "5167349659",
        "address": {
            "line1": "8374 Test St",
            "line2": "APT #D19",
            "city": "Littleton",
            "state": "CO",
            "postalCode": "80128",
            "county": "Nassau",
        },
        "protected": {
            "ssn": "788999009",
            "dateOfBirth": "1963-06-18",
            "driversLicenseNumber": "784534987",
            "driversLicenseState": "CO",
        },
        "monthsAtCurrentAddress": 18,
        "otherPhone": "5167349659",
        "email": "test_email@testserver.com",
        "preferredContactMethod": "Email",
        "preferredLanguage": "English",
        "currentEmployment": {
            "employerName": "Boyles Test Co.",
            "totalMonthsEmployed": 36,
            "occupation": "Program Manager",
            "workPhone": "7130780239",
            "status": "Employed",
            "employerAddress": {
                "line1": "8374 Test St",
                "line2": "APT #D19",
                "city": "Littleton",
                "state": "CO",
                "postalCode": "80128",
            },
        },
        "income": 0,
        "incomeFrequency": "Monthly",
        "otherMonthlyIncome": 104,
        "otherMonthlyIncomeSource": "Pension",
        "housingStatus": "Rent",
        "maritalStatus": "Married",
        "mortgageOrRentAmount": 3500.89,
        "previousAddress": {
            "line1": "8374 Test St",
            "line2": "APT #D19",
            "city": "Littleton",
            "state": "CO",
            "postalCode": "80128",
            "county": "Nassau",
        },
        "monthsAtPreviousAddress": 18,
        "previousEmployment": {
            "employerName": "Boyles Test Co.",
            "totalMonthsEmployed": 36,
            "occupation": "Program Manager",
            "workPhone": "7130780239",
            "status": "Employed",
            "employerAddress": {
                "line1": "8374 Test St",
                "line2": "APT #D19",
                "city": "Littleton",
                "state": "CO",
                "postalCode": "80128",
            },
        },
        "reportedCreditScore": 740,
        "spouse": {
            "firstName": "Earnest",
            "lastName": "Winhoffer",
            "middleName": "T",
            "suffix": "JR",
            "address": {
                "line1": "8374 Test St",
                "line2": "APT #D19",
                "city": "Littleton",
                "state": "CO",
                "postalCode": "80128",
            },
            "income": 0,
            "incomeFrequency": "Monthly",
            "otherMonthlyIncome": 1000,
            "otherMonthlyIncomeSource": "Rent",
        },
        "references": [
            {
                "salutation": "Mr.",
                "firstName": "Earnest",
                "lastName": "Winhoffer",
                "middleName": "T",
                "suffix": "JR",
                "phone": "5167349659",
                "ssn": "788999009",
                "dateOfBirth": "1963-06-18",
                "address": {
                    "line1": "8374 Test St",
                    "line2": "APT #D19",
                    "city": "Littleton",
                    "state": "CO",
                    "postalCode": "80128",
                    "county": "Nassau",
                },
            }
        ],
    }


@pytest.fixture()
def expected_applicant():
    return {
        "dealComponent": "DTC.APPLICANT",
        "ttl": Decimal(TIME + se.RetentionPeriod.general),
        "applicantId": DR_ULID,
        "dealRefId": DR_ULID,
        "createdTimestamp": TIMESTAMP,
        "updatedTimestamp": TIMESTAMP,
        "relationship": "Self",
        "salutation": "Mr.",
        "firstName": "Earnest",
        "lastName": "Winhoffer",
        "middleName": "T",
        "suffix": "JR",
        "phone": "5167349659",
        "address": {
            "line1": "8374 Test St",
            "line2": "APT #D19",
            "city": "Littleton",
            "state": "CO",
            "postalCode": "80128",
            "county": "Nassau",
        },
        "monthsAtCurrentAddress": Decimal(18),
        "otherPhone": "5167349659",
        "email": "test_email@testserver.com",
        "preferredContactMethod": "Email",
        "preferredLanguage": "English",
        "currentEmployment": {
            "employerName": "Boyles Test Co.",
            "totalMonthsEmployed": Decimal(36),
            "occupation": "Program Manager",
            "workPhone": "7130780239",
            "status": "Employed",
        },
        "currentEmployment_employerAddress": {
            "line1": "8374 Test St",
            "line2": "APT #D19",
            "city": "Littleton",
            "state": "CO",
            "postalCode": "80128",
        },
        "income": Decimal(0),
        "incomeFrequency": "Monthly",
        "otherMonthlyIncome": Decimal(104),
        "otherMonthlyIncomeSource": "Pension",
        "housingStatus": "Rent",
        "maritalStatus": "Married",
        "mortgageOrRentAmount": Decimal("3500.89"),
        "previousAddress": {
            "line1": "8374 Test St",
            "line2": "APT #D19",
            "city": "Littleton",
            "state": "CO",
            "postalCode": "80128",
            "county": "Nassau",
        },
        "monthsAtPreviousAddress": Decimal(18),
        "previousEmployment": {
            "employerName": "Boyles Test Co.",
            "totalMonthsEmployed": Decimal(36),
            "occupation": "Program Manager",
            "workPhone": "7130780239",
            "status": "Employed",
        },
        "previousEmployment_employerAddress": {
            "line1": "8374 Test St",
            "line2": "APT #D19",
            "city": "Littleton",
            "state": "CO",
            "postalCode": "80128",
        },
        "reportedCreditScore": Decimal(740),
        "spouse": {
            "firstName": "Earnest",
            "lastName": "Winhoffer",
            "middleName": "T",
            "suffix": "JR",
            "income": Decimal(0),
            "incomeFrequency": "Monthly",
            "otherMonthlyIncome": Decimal(1000),
            "otherMonthlyIncomeSource": "Rent",
        },
        "spouse_address": {
            "line1": "8374 Test St",
            "line2": "APT #D19",
            "city": "Littleton",
            "state": "CO",
            "postalCode": "80128",
        },
        "references": [
            {
                "salutation": "Mr.",
                "firstName": "Earnest",
                "lastName": "Winhoffer",
                "middleName": "T",
                "suffix": "JR",
                "phone": "5167349659",
                "ssn": "788999009",
                "dateOfBirth": "1963-06-18",
                "address": {
                    "line1": "8374 Test St",
                    "line2": "APT #D19",
                    "city": "Littleton",
                    "state": "CO",
                    "postalCode": "80128",
                    "county": "Nassau",
                },
            }
        ],
    }


@pytest.fixture()
def coapplicant():
    return {
        "relationship": "Self",
        "salutation": "Mr.",
        "firstName": "Earnest",
        "lastName": "Winhoffer",
        "middleName": "T",
        "suffix": "JR",
        "phone": "5167349659",
        "ssn": "788999009",
        "dateOfBirth": "1963-06-18",
        "address": {
            "line1": "8374 Test St",
            "line2": "APT #D19",
            "city": "Littleton",
            "state": "CO",
            "postalCode": "80128",
            "county": "Nassau",
        },
        "driversLicenseNumber": "784534987",
        "driversLicenseState": "CO",
        "monthsAtCurrentAddress": 18,
        "otherPhone": "5167349659",
        "email": "test_email@testserver.com",
        "preferredContactMethod": "Email",
        "preferredLanguage": "English",
        "currentEmployment": {
            "employerName": "Boyles Test Co.",
            "totalMonthsEmployed": 36,
            "occupation": "Program Manager",
            "workPhone": "7130780239",
            "status": "Employed",
            "employerAddress": {
                "line1": "8374 Test St",
                "line2": "APT #D19",
                "city": "Littleton",
                "state": "CO",
                "postalCode": "80128",
            },
        },
        "income": 0,
        "incomeFrequency": "Monthly",
        "otherMonthlyIncome": 104,
        "otherMonthlyIncomeSource": "Pension",
        "housingStatus": "Rent",
        "maritalStatus": "Married",
        "mortgageOrRentAmount": 3500.89,
        "previousAddress": {
            "line1": "8374 Test St",
            "line2": "APT #D19",
            "city": "Littleton",
            "state": "CO",
            "postalCode": "80128",
            "county": "Nassau",
        },
        "monthsAtPreviousAddress": 18,
        "previousEmployment": {
            "employerName": "Boyles Test Co.",
            "totalMonthsEmployed": 36,
            "occupation": "Program Manager",
            "workPhone": "7130780239",
            "status": "Employed",
            "employerAddress": {
                "line1": "8374 Test St",
                "line2": "APT #D19",
                "city": "Littleton",
                "state": "CO",
                "postalCode": "80128",
            },
        },
        "reportedCreditScore": 740,
        "spouse": {
            "firstName": "Earnest",
            "lastName": "Winhoffer",
            "middleName": "T",
            "suffix": "JR",
            "address": {
                "line1": "8374 Test St",
                "line2": "APT #D19",
                "city": "Littleton",
                "state": "CO",
                "postalCode": "80128",
            },
            "income": 0,
            "incomeFrequency": "Monthly",
            "otherMonthlyIncome": 1000,
            "otherMonthlyIncomeSource": "Rent",
        },
        "references": [
            {
                "salutation": "Mr.",
                "firstName": "Earnest",
                "lastName": "Winhoffer",
                "middleName": "T",
                "suffix": "JR",
                "phone": "5167349659",
                "ssn": "788999009",
                "dateOfBirth": "1963-06-18",
                "address": {
                    "line1": "8374 Test St",
                    "line2": "APT #D19",
                    "city": "Littleton",
                    "state": "CO",
                    "postalCode": "80128",
                    "county": "Nassau",
                },
            }
        ],
    }


@pytest.fixture()
def vehicle():
    return {
        "inventoryVehicleCondition": "Used",
        "vin": "2T1BURHE0JC981147",
        "stockNumber": "181425AN",
        "chromeYear": 2017,
        "chromeMake": "Toyota",
        "chromeModel": "Corolla",
        "chromeStyle": "4dr Reg WB Plus 1SB Pkg",
        "chromeMakeId": 12,
        "chromeModelId": 125,
        "chromeStyleId": 125534,
        "otherYear": 2017,
        "otherMake": "Toyota",
        "otherModel": "Corolla",
        "otherTrim": "4dr Reg WB Plus 1SB Pkg",
        "otherOptions": "Pwr Sunroof, Wheels",
        "certifiedUsed": True,
        "odometerReading": 32445,
        "mileage": 3101,
        "odometerType": "Miles",
        "vehicleType": "Auto",
        "interiorColor": "Tan",
        "exteriorColor": "Blue",
        "transmissionType": "Automatic",
        "engineType": "V8",
        "grossVehicleWeightRating": 3500,
        "cylinders": 8,
        "fuelType": "GasFuel",
        "url": "https://www.dealertrack.com/inventory/certified-used-2016-bmw-4-series",
    }


@pytest.fixture()
def payment_response():
    return {
        "userProgramQuotesResults": [
            {
                "callerItemId": 1,
                "quotes": [
                    {
                        "payment": {
                            "dealType": "Lease",
                            "contractDate": "2018-08-17",
                            "totalOfPaymentsAndConsideration": 20841.95,
                            "term": 36,
                        },
                        "state": "NY",
                        "pricing": {
                            "vehicleSalePrice": 27000.0,
                            "vehicleRetail": 35000.0,
                            "listPrice": 30000.0,
                        },
                    }
                ],
            }
        ]
    }


@pytest.fixture()
def expected_vehicle_data(to_decimal, vehicle, extra_dynamodb_fields):
    v = copy.deepcopy(vehicle)
    to_decimal(v)
    v.update(extra_dynamodb_fields)
    v["dealComponent"] = "DTC.VEHICLE"
    return v


@pytest.fixture()
def expected_key_data():
    return {"dealJacketId": DR_ULID_NEW, "dealerCode": DLR_CD}


@pytest.fixture()
def updated_applicant_data():
    return {
        "applicant": {
            "firstName": "Test",
            "lastName": "Updated",
            "middleName": "J",
            "suffix": "SR",
            "phone": "6463475555",
            "dateOfBirthMonth": Decimal(1),
            "dateOfBirthDay": Decimal(21),
            "protected": {"ssn": "encrypted", "dob": "encrypted"},
        }
    }


@pytest.fixture()
def expected_updated_applicant_data(expected_applicant):
    expected_applicant.update(
        {
            "firstName": "Test",
            "lastName": "Updated",
            "middleName": "J",
            "suffix": "SR",
            "phone": "6463475555",
            "dateOfBirthMonth": "1",
            "dateOfBirthDay": "21",
        }
    )

    return expected_applicant


@pytest.fixture()
def updated_vehicle_data():
    return {
        "vehicle": {
            "inventoryVehicleCondition": "New",
            "vin": "2T1BURHE0JC900000",
            "stockNumber": "181425TN",
            "chromeYear": 2019,
            "chromeMake": "BMW",
            "chromeModel": "X5",
        }
    }


@pytest.fixture()
def expected_updated_vehicle_data(expected_vehicle_data):
    expected_vehicle_data.update(
        {
            "inventoryVehicleCondition": "New",
            "vin": "2T1BURHE0JC900000",
            "stockNumber": "181425TN",
            "chromeYear": 2019,
            "chromeMake": "BMW",
            "chromeModel": "X5",
        }
    )
    return expected_vehicle_data


@pytest.fixture()
def updated_finance_data():
    return {
        "financeSummary": {
            "vehicleSellingPrice": 12000.99,
            "salesTax": 2400.99,
            "governmentFees": 454.99,
            "cashDown": 2300.99,
            "rebate": 4532.99,
            "creditLifeIns": 70.99,
        }
    }


@pytest.fixture()
def expected_updated_finance_data(expected_finance_summary_data):
    expected_finance_summary_data.update(
        {
            "vehicleSellingPrice": 12000.99,
            "salesTax": 2400.99,
            "governmentFees": 454.99,
            "cashDown": 2300.99,
            "rebate": 4532.99,
            "creditLifeIns": 70.99,
        }
    )
    return expected_finance_summary_data


@pytest.fixture()
def updated_tradein_data():
    return {
        "tradeIns": {
            "chromeMakeId": 44,
            "chromeModelId": 123,
            "chromeStyleId": 4334543,
            "otherYear": 2016,
            "otherMake": "BMW",
        }
    }


@pytest.fixture()
def expected_updated_tradein_data(expected_tradein_data):
    expected_tradein_data["tradeIns"][0].update(
        {
            "chromeMakeId": 44,
            "chromeModelId": 123,
            "chromeStyleId": 4334543,
            "otherYear": 2016,
            "otherMake": "BMW",
        }
    )
    return expected_tradein_data


@pytest.fixture()
def update_deal_data(
    updated_applicant_data,
    updated_tradein_data,
    updated_vehicle_data,
    updated_finance_data,
):
    def update(data: dict):
        updated_objects = {
            **updated_applicant_data,
            **updated_finance_data,
            **updated_vehicle_data,
            **updated_tradein_data,
        }
        for k, v in data.items():
            if k in updated_objects:
                if isinstance(v, list):
                    v[0].update(updated_objects[k])
                else:
                    v.update(updated_objects[k])
        return data

    return update


@pytest.fixture()
def tradein_vehicles():
    return [
        {
            "inventoryVehicleCondition": "Used",
            "vin": "2T1BURHE0JC981147",
            "stockNumber": "181425AN",
            "chromeYear": 2017,
            "chromeMake": "Toyota",
            "chromeModel": "Corolla",
            "chromeStyle": "4dr Reg WB Plus 1SB Pkg",
            "chromeMakeId": 12,
            "chromeModelId": 125,
            "chromeStyleId": 125534,
            "otherYear": 2017,
            "otherMake": "Toyota",
            "otherModel": "Corolla",
            "otherTrim": "4dr Reg WB Plus 1SB Pkg",
            "otherOptions": "Pwr Sunroof, Wheels",
            "certifiedUsed": True,
            "tradeInType": "Finance",
            "actualCashValue": 15000,
            "monthlyPayment": 250,
            "payoffAmount": 18000,
            "allowanceAmount": 1880,
            "netTrade": 3500,
            "tradeInLicensePlateNumber": "TTH-1234",
            "vehicleBookCondition": "VeryGood",
            "fuelType": "GasFuel",
            "lienHolder": {
                "name": "Ford Motor Credit Co",
                "phone": "336-968-4645",
                "address": {
                    "line1": "8374 Test St",
                    "line2": "APT #D19",
                    "city": "Littleton",
                    "state": "CO",
                    "postalCode": "80128",
                },
            },
            "odometerReading": 32445,
            "mileage": 3101,
            "odometerType": "Miles",
            "vehicleType": "Auto",
            "interiorColor": "Tan",
            "exteriorColor": "Blue",
            "transmissionType": "Automatic",
            "engineType": "V8",
            "grossVehicleWeightRating": 3500,
            "cylinders": 8,
            "url": "https://www.dealertrack.com/inventory/certified-used-2016-bmw-4-series",
            "appraisalDate": "2019-09-01",
            "appraisalSource": "KBB",
            "appraisalReferenceNumber": "01DDY25TBPNE21EH3P287DNJQ0",
        }
    ]


@pytest.fixture()
def expected_tradein_data(to_decimal, tradein_vehicles, extra_dynamodb_fields):
    record = {"tradeIns": tradein_vehicles}
    record.update(extra_dynamodb_fields)
    record["dealComponent"] = "DTC.TRADEINS"
    return record


@pytest.fixture()
def finance_summary():
    return {
        "vehicleSellingPrice": 23000.99,
        "salesTax": 2000.99,
        "governmentFees": 300.99,
        "cashDown": 3999.99,
        "rebate": 1000.99,
        "creditLifeIns": 39.99,
        "term": 60,
        "requestedAPR": 1.99,
        "acquisitionFees": 399.99,
        "invoiceAmount": 29000.99,
        "warranty": 310.99,
        "gap": 310.99,
        "accidentHealthIns": 30.99,
        "frontEndFees": 390.99,
        "msrp": 24000.99,
        "estimatedBalloonAmount": 23310.99,
        "estimatedAmountFinanced": 9314.06,
        "estimatedPayment": 310.99,
        "usedCarBook": "KBB",
        "mileage": 3101,
        "otherFees": 310.99,
        "retailBookDetails": [
            {"source": "KBB", "value": 19500, "condition": "VeryGood"}
        ],
        "wholesaleBookDetails": [
            {"source": "KBB", "value": 19500, "condition": "VeryGood"}
        ],
        "bookValueType": "Loan",
        "netTrade": 31010.99,
        "amountRequested": 23310.99,
        "creditScoreClassification": "SuperPrime",
        "applicantType": "Individual",
        "unpaidBalance": 18000,
        "customerNegotiatedPrice": 23310.99,
        "dealerNegotiatedPrice": 23310.99,
    }


@pytest.fixture()
def expected_finance_summary_data(to_decimal, finance_summary, extra_dynamodb_fields):
    fin = copy.deepcopy(finance_summary)
    to_decimal(fin)
    fin.update(extra_dynamodb_fields)
    fin["dealComponent"] = "DTC.FINANCESUMMARY"
    return fin


@pytest.fixture()
def fees():
    return [
        {
            "feeType": "MileageFees",
            "feeAmount": 1000.73,
            "feeDescription": "Mileage Fees",
            "category": "Dealer",
            "capitalizedOrUpfront": "Capitalized",
            "frontEndIndicator": True,
            "backEndIndicator": True,
        }
    ]


@pytest.fixture()
def expected_fees_data(to_decimal, fees):
    expected = {"fees": fees}
    to_decimal(expected)
    expected["dealComponent"] = "DTC.FEES"
    return expected


@pytest.fixture()
def taxes():
    return [
        {
            "taxType": "AcquisitionTax",
            "taxAmount": 1000.73,
            "taxDescription": "Mileage surcharge Tax",
            "capitalizedOrUpfront": "Capitalized",
        }
    ]


@pytest.fixture()
def expected_taxes_data(to_decimal, taxes):
    expected = {"taxes": taxes}
    to_decimal(expected)
    expected["dealComponent"] = "DTC.TAXES"
    return expected


@pytest.fixture()
def products():
    return [
        {
            "productType": "Accessories",
            "productName": "Gap",
            "productCost": 500.55,
            "sellingPrice": 500.55,
            "packageIndicator": True,
            "packageName": "string",
            "taxableIndicator": True,
            "capitalizedIndicator": True,
            "residualizedIndicator": True,
            "residualizedAmount": 500.55,
            "frontEndIndicator": True,
            "backEndIndicator": True,
            "term": 60,
            "miles": 3101,
            "productMinPrice": 600,
            "productMaxPrice": 600,
            "deductible": 600,
            "providerName": "XYZ Insurance Co.",
            "providerAddress": {
                "line1": "8374 Test St",
                "line2": "APT #D19",
                "city": "Littleton",
                "state": "CO",
                "postalCode": "80128",
            },
            "insuranceBeneficiary": "Applicant",
            "maxTotalPayout": 0,
            "maxMonthlyPayout": 0,
        }
    ]


@pytest.fixture()
def expected_products_data(to_decimal, products):
    expected = {"products": products}
    to_decimal(expected)
    expected["dealComponent"] = "DTC.PRODUCTS"
    return expected


@pytest.fixture()
def extra_dynamodb_fields():
    return {
        "dealComponent": None,
        "createdTimestamp": "2018-12-31T23:11:22.543545",
        "dealRefId": "0000000000AAABBBCCDDEEFFGG",
        "updatedTimestamp": "2018-12-31T23:11:22.543545",
        "ttl": Decimal(TIME + se.RetentionPeriod.general),
    }


@pytest.fixture()
def contract_full_payload(credit_app_full_payload, finance_information_payload):
    payload = copy.deepcopy(credit_app_full_payload)
    payload["applicant"]["reportedCreditScore"] = 740
    payload["coApplicant"]["reportedCreditScore"] = 740
    payload.update(finance_information_payload)

    return payload


@pytest.fixture()
def contract_v2_payload():
    return {
        "sourcePartnerId": "DXR",
        "targetPlatforms": [{"id": "DTC", "partyId": "123987"}],
        "financeMethod": "Finance",
    }


@pytest.fixture()
def credit_app_full_payload(
    applicant,
    coapplicant,
    vehicle,
    tradein_vehicles,
    finance_summary,
    fees,
    taxes,
    products,
):
    return {
        "dealRefId": DR_ULID,
        "creditAppId": DR_ULID,
        "leadRefId": DR_ULID,
        "sourcePartnerId": "VIN",
        "targetPlatforms": [{"id": "R1J", "partyId": "123987"}],
        "financeMethod": "Lease",
        "customerType": "Individual",
        "applicant": applicant,
        "coApplicant": coapplicant,
        "vehicle": vehicle,
        "tradeIns": tradein_vehicles,
        "financeSummary": finance_summary,
        "fees": fees,
        "taxes": taxes,
        "products": products,
        "lenderList": [{"lenderId": "BOA", "lenderName": "Bank of America"}],
        "partnerSource": "string",
        "comments": "Credit Application comments to the lender. Customer needs to get confirmation from his wife.",
        "regulationBIndicator": True,
        "privacyNoticeIndicator": True,
        "communityPropertyDisclosureIndicator": True,
        "extraData": [{"name": "OTDXDCMB01", "value": "CustomValue-SOJCD165"}],
    }


@pytest.fixture()
def deal_update_payload(applicant, vehicle, tradein_vehicles, finance_summary):
    return {
        "dealRefId": DR_ULID,
        "dealRefIdDR": DR_ULID,
        "creditAppRefId": DR_ULID,
        "applicationReferenceNumber": DR_ULID,
        "sourcePartnerId": "DWR",
        "targetPlatforms": [{"id": "IDL", "partyId": "1001000"}],
        "financeMethod": "Lease",
        "customerType": "Individual",
        "applicant": applicant,
        "vehicle": vehicle,
        "tradeIns": tradein_vehicles,
        "financeSummary": finance_summary,
        "lenderList": [{"lenderId": "BOA", "lenderName": "Bank of America"}],
        "partnerSource": "string",
        "comments": "Credit Application comments to the lender. Customer needs to get confirmation from his wife.",
    }


@pytest.fixture()
def credit_app_full_payload_new_dealrefid(credit_app_full_payload):
    credit_app_full_payload["dealRefId"] = DR_ULID_NEW


@pytest.fixture()
def finance_information_payload():
    return {
        "vehicleSellingPrice": 23000,
        "msrp": 24000,
        "invoiceAmount": 29000,
        "amountFinanced": 50555,
        "dealerRebate": 1000,
        "manufacturerRebate": 1500,
        "lenderCharge": 1255.56,
        "cashDown": 3000,
        "dateOfFirstPayment": "2021-02-02",
        "monthlyPayment": 310.99,
        "lastMonthPayment": 310.99,
        "term": 60,
        "deferredDownPayment": 2100,
        "deferredDownPaymentDate": "2021-05-01",
        "fees": [
            {
                "feeType": "MileageFees",
                "feeAmount": 1000.73,
                "feeDescription": "Mileage Fees",
                "category": "Dealer",
                "capitalizedOrUpfront": "Capitalized",
                "frontEndIndicator": True,
                "backEndIndicator": True,
            }
        ],
        "taxes": [
            {
                "taxType": "SalesTax",
                "taxAmount": 1000.73,
                "taxDescription": "Mileage surcharge Tax",
                "capitalizedOrUpfront": "Capitalized",
            }
        ],
        "products": [
            {
                "productCode": "Gap",
                "productName": "Gap",
                "productCost": 500.55,
                "sellingPrice": 500.55,
                "packageIndicator": True,
                "packageName": "string",
                "taxableIndicator": True,
                "capitalizedIndicator": True,
                "residualizedIndicator": True,
                "residualizedAmount": 500.55,
                "frontEndIndicator": True,
                "backEndIndicator": True,
                "term": 60,
                "miles": 3101,
                "productMinPrice": 600,
                "productMaxPrice": 600,
                "deductible": 600,
                "providerName": "XYZ Insurance Co.",
                "providerAddress": {
                    "line1": "8374 Test St",
                    "line2": "APT #D19",
                    "city": "Littleton",
                    "state": "CO",
                    "postalCode": "80128",
                },
            }
        ],
    }


@pytest.fixture()
def credit_app_partial_payload(applicant):
    return {
        "dealRefId": DR_ULID,
        "sourcePartnerId": "VIN",
        "targetPlatforms": [{"id": "R1J", "partyId": "123987"}],
        "financeMethod": "Lease",
        "customerType": "Individual",
        "applicant": applicant,
    }


@pytest.fixture()
def lender_list_payload():
    return {
        "sourcePartnerId": "DTS",
        "targetPlatforms": [{"id": "DTC", "partyId": "1001000"}],
        "lenderList": [
            {"lenderId": "BOA", "lenderName": "Bank of America"},
            {"lenderId": "CMB", "lenderName": "Chase Bank"},
        ],
    }


@pytest.fixture()
def transformed_lender_list_payload():
    return {
        "sourcePartnerId": "DTS",
        "targetPlatforms": [{"id": "DTC", "partyId": "1001000"}],
        "lenderList.BOA": {"lenderId": "BOA", "lenderName": "Bank of America"},
        "lenderList.CMB": {"lenderId": "CMB", "lenderName": "Chase Bank"},
    }


@pytest.fixture()
def credit_app_dvm_partner_payload(applicant):
    return {
        "dealRefId": DR_ULID,
        "sourcePartnerId": "DVM",
        "targetPlatforms": [{"id": "R1J", "partyId": "123987"}],
        "financeMethod": "Lease",
        "customerType": "Individual",
        "applicant": applicant,
    }


@pytest.fixture()
def sample_payload_with_empty_string():
    return {
        "sourcePartnerId": "",
        "customers": [
            {"customerRole": "Applicant", "relationship": ""},
            {"customerRole": "Coapplicant", "relationship": "Spouse"},
        ],
        "vehicle": {"inventoryVehicleCondition": ""},
    }


@pytest.fixture()
def sample_payload_for_encryption(applicant, tradein_vehicles):
    tradein_vehicles[0].update({"protected": {"ssn": 123456789}})
    return {
        "dealRefId": DR_ULID,
        "sourcePartnerId": "VIN",
        "targetPlatforms": [{"id": "R1J", "partyId": "123987"}],
        "financeMethod": "Lease",
        "customerType": "Individual",
        "applicant": applicant,
        "protected": {"ssn": 123456789},
        "tradeIns": tradein_vehicles,
    }


@pytest.fixture()
def expected_payload_with_none():
    return {
        "sourcePartnerId": None,
        "customers": [
            {"customerRole": "Applicant", "relationship": None},
            {"customerRole": "Coapplicant", "relationship": "Spouse"},
        ],
        "vehicle": {"inventoryVehicleCondition": None},
    }


@pytest.fixture()
def sample_payload_with_deal_ref_id(credit_app_full_payload):
    deal_ref_id = ulid.new()
    credit_app_full_payload.update({"dealRefId": deal_ref_id.str})
    return credit_app_full_payload


@pytest.fixture()
def db_query_no_items(dynamodb, **kwargs):
    def query_items(*args, **kwargs):
        return []

    return query_items


@pytest.fixture()
def db_query_items(dynamodb, **kwargs):
    def query_items(*args, **kwargs):
        deals_table = dynamodb.Table(deal_consumer.DealDataParameters().db_name)
        key_expression = kwargs.get("key_expression")
        index_name = kwargs.get("index")

        query_kwargs = (
            {"KeyConditionExpression": key_expression, "IndexName": index_name}
            if index_name
            else {"KeyConditionExpression": key_expression}
        )
        record = deals_table.query(**query_kwargs).get("Items", [])
        # this is needed in producer test cases where validation is done on some id,
        # add data below to return when validation occur
        if not record:
            return [
                {"apiVersion": "1"},
                {
                    "dealComponent": "CB.REDFLAG.APPLICANT.1111111111AAABBBCCDDEEFFGG",
                    "dealRefId": "0000000000AAABBBCCDDEEFFGG",
                },
            ]
        return record

    return query_items


@pytest.fixture()
def query_item_vin_source_partner(**kwargs):
    def query_items(*args, **kwargs):
        return [
            {
                "dealRefId": "01FMSP049ZGTZ5GSBG31A0F4M0",
                "dealRefIdDR": "01FMSP049ZGTZ5GSBG31A0F4M0",
                "lenderId": "BOA",
                "partnerCode": "400016558",
                "sourcePartnerDealerId": "123456789",
                "sourcePartnerId": "VIN",
                "dealJacketId": DR_ULID_NEW,
                "dealerCode": DLR_CD,
                "dealerId": DR_DLR_ID,
            }
        ]

    return query_items


@pytest.fixture()
def query_item_dts_source_partner(**kwargs):
    def query_items(*args, **kwargs):
        return [
            {
                "dealRefId": "01FMSP049ZGTZ5GDDF31A0F4M0",
                "dealRefIdDR": "01FMSP049ZDDZ4FSBG31A0F4M0",
                "lenderId": "BOA",
                "partnerCode": "400016558",
                "sourcePartnerDealerId": "123456789",
                "sourcePartnerId": "DTS",
                "dealJacketId": DR_ULID_NEW,
                "dealerCode": DLR_CD,
                "dealerId": DR_DLR_ID,
            }
        ]

    return query_items


@pytest.fixture()
def query_item_dvm_source_partner(**kwargs):
    def query_items(*args, **kwargs):
        return [
            {
                "dealRefId": "01DHHVT56TMC2QKF2FFBMVREBP_TEST",
                "dealRefIdDR": "01DHHVT56TMC2QKF2FFBMVREBP_TEST",
                "lenderId": "BOA",
                "partnerCode": "400016558",
                "sourcePartnerDealerId": "123456789",
                "sourcePartnerId": "DVM",
                "dealJacketId": DR_ULID_NEW,
                "dealerCode": DLR_CD,
                "dealerId": DR_DLR_ID,
            }
        ]

    return query_items


@pytest.fixture()
def db_query_empty(**kwargs):
    def query_items(*args, **kwargs):
        return []

    return query_items


def db_records(additional_dtc_fields=None):
    additional_dtc_fields = additional_dtc_fields if additional_dtc_fields else {}
    return [
        {
            "aws:rep:deleting": False,
            "updatedTimestamp": "2020-03-13T18:44:29.146662",
            "dealRefId": "0000000000AAABBBCCDDEEFFGG",
            "status": "done",
            "dealComponent": "CB.EXPERIAN.REDFLAG.COAPPLICANT.1234",
            "provider": "Experian",
            "aws:rep:updateregion": "us-east-1",
            "aws:rep:updatetime": Decimal("1584125069.330002"),
            "createdTimestamp": "2020-03-13T18:44:29.146662",
            "type": "Redflag",
        },
        {
            "aws:rep:deleting": False,
            "updatedTimestamp": "2020-03-13T18:44:29.146662",
            "dealRefId": "01E3AK55DC17CPZ02VXMH62HEQ",
            "dealComponent": "CB.TRANSUNION.SOFTPULL.APPLICANT.1234",
            "provider": "Transunion",
            "aws:rep:updateregion": "us-east-1",
            "aws:rep:updatetime": Decimal("1584125069.333001"),
            "createdTimestamp": "2020-03-13T18:44:29.146662",
            "type": "SoftPull",
        },
        {
            "updatedTimestamp": "2020-03-13T18:43:48.422224",
            "sourcePartnerId": "VIN",
            "comments": "Credit Application comments to the lender.",
            "aws:rep:deleting": False,
            "sourcePartnerDealerId": "123456789",
            "targetPlatforms": [{"partyId": "123456789", "id": "VIN"}],
            "customerType": "Individual",
            "creditAppId": "01E3AK55DCB3PBD783DKS6XHNV",
            "dealRefId": "01E3AK55DC17CPZ02VXMH62HEQ",
            "dealComponent": "DTC.DEAL",
            "aws:rep:updateregion": "us-east-1",
            "partnerSource": "string",
            "aws:rep:updatetime": Decimal("1584125029.258003"),
            "createdTimestamp": "2020-03-13T18:40:27.664270",
            "financeMethod": "Lease",
            **additional_dtc_fields,
        },
        {
            "aws:rep:deleting": False,
            "updatedTimestamp": "2020-03-13T18:40:27.664270",
            "dealRefId": "01E3AK55DC17CPZ02VXMH62HEQ",
            "dealComponent": "DTC.VERSION",
            "aws:rep:updateregion": "us-east-1",
            "aws:rep:updatetime": Decimal("1584124827.894001"),
            "apiVersion": "1.1.16",
            "createdTimestamp": "2020-03-13T18:40:27.664270",
        },
    ]


@pytest.fixture()
def mock_query_pk_filter(dynamodb):
    def query_pk_filter(*args, **kwargs):
        return db_records()

    return query_pk_filter


@pytest.fixture()
def mock_query_pk_filter_with_additional_fields(dynamodb):
    class MockFilter:
        def __init__(self, additional_dtc_fields):
            self.db_records = db_records(additional_dtc_fields)

        def query_pk_filter(self, *args, **kwargs):
            return self.db_records

    return MockFilter


@pytest.fixture()
def db_query_dtc_deal(dynamodb, **kwargs):
    def query_items(*args, **kwargs):
        return [
            {"dealRefId": DR_ULID, "leadRefId": DR_ULID, "creditAppId": DR_ULID},
            {"apiVersion": "1"},
        ]

    return query_items


@pytest.fixture()
def db_query_existing_deal(dynamodb, **kwargs):
    def query_items(*args, **kwargs):
        return [
            {
                "dealRefId": "0000000000AAABBBCCDDEEFFGG",
                "leadRefId": "0000000000AAABBBCCDDEEFFGG",
                "creditAppId": "0000000000AAABBBCCDDEEFFGG",
            },
            {"apiVersion": "1"},
        ]

    return query_items


@pytest.fixture()
def return_exception():
    def exception(*args, **kwargs):
        raise Exception("error")

    return exception


@pytest.fixture()
def return_bad_request():
    def exception(*args, **kwargs):
        raise exceptions.BadRequestError("error")

    return exception


@pytest.fixture()
def patch_aws_credentials_env():
    """Mocked AWS Credentials for moto."""
    os.environ["AWS_ACCESS_KEY_ID"] = "test-access-key"
    os.environ["AWS_SECRET_ACCESS_KEY"] = "test-secret-access-key"
    os.environ["AWS_SECURITY_TOKEN"] = "test-security-token"
    os.environ["AWS_SESSION_TOKEN"] = "test-session-token"


@pytest.fixture()
def dynamodb(patch_env, patch_aws_credentials_env, monkeypatch):
    """
    Create mock dynamodb Deals table for tests.
    :return: a mock dynamodb resource object
    """
    # Workaround for moto bug where just importing it causes AWS environment variables to be overwritten
    # See https://github.com/spulec/moto/issues/2172
    from moto import mock_aws

    with mock_aws():
        client = boto3.client("dynamodb", region_name=deal_consumer.Env.AWS_REGION)
        client.create_table(
            AttributeDefinitions=[
                {"AttributeName": "dealRefId", "AttributeType": "S"},
                {"AttributeName": "dealComponent", "AttributeType": "S"},
            ],
            KeySchema=[
                {"AttributeName": "dealRefId", "KeyType": "HASH"},
                {"AttributeName": "dealComponent", "KeyType": "RANGE"},
            ],
            TableName=deal_consumer.DealDataParameters().db_name,
            ProvisionedThroughput={"ReadCapacityUnits": 1, "WriteCapacityUnits": 1},
            GlobalSecondaryIndexes=[
                {
                    "IndexName": "dealJacketId-index",
                    "KeySchema": [{"AttributeName": "dealRefId", "KeyType": "HASH"}],
                    "Projection": {
                        "ProjectionType": "INCLUDE",
                        "NonKeyAttributes": [
                            "dealRefId",
                            "appRefIdFD",
                            "dealJacketId",
                            "dealRefIdFD",
                            "partnerId",
                            "partnerDealerId",
                            "dealRefIdFI",
                            "leadRefId",
                            "dealIdFI",
                            "dealerId",
                            "sourcePartnerId",
                            "sourcePartnerDealerId",
                            "creditAppId",
                            "eventId",
                        ],
                    },
                },
                {
                    "IndexName": "dealRefId-index",
                    "KeySchema": [{"AttributeName": "dealRefId", "KeyType": "HASH"}],
                    "Projection": {
                        "ProjectionType": "INCLUDE",
                        "NonKeyAttributes": [
                            "dealRefId",
                            "appRefIdFD",
                            "dealJacketId",
                            "dealRefIdFD",
                            "partnerId",
                            "partnerDealerId",
                            "dealRefIdFI",
                            "leadRefId",
                            "dealIdFI",
                            "dealerId",
                            "sourcePartnerId",
                            "sourcePartnerDealerId",
                            "creditAppId",
                            "documentId",
                            "eventId",
                            "documentType",
                            "tags",
                        ],
                    },
                },
                {
                    "IndexName": "dealRefIdFD-index",
                    "KeySchema": [{"AttributeName": "dealRefId", "KeyType": "HASH"}],
                    "Projection": {
                        "ProjectionType": "INCLUDE",
                        "NonKeyAttributes": [
                            "dealRefId",
                            "appRefIdFD",
                            "dealJacketId",
                            "dealRefIdFD",
                            "partnerId",
                            "partnerDealerId",
                            "dealRefIdFI",
                            "leadRefId",
                            "dealIdFI",
                            "dealerId",
                            "sourcePartnerId",
                            "sourcePartnerDealerId",
                            "creditAppId",
                            "documentId",
                            "eventId",
                        ],
                    },
                },
            ],
        )

        resource = boto3.resource("dynamodb", region_name=deal_consumer.Env.AWS_REGION)
        yield resource


@pytest.fixture()
def s3(patch_env, patch_aws_credentials_env, monkeypatch):
    """
    Create mock S3 bucket for tests.
    :return: a mock s3 resource object
    """
    # Workaround for moto bug where jus importing it causes AWS environment variables to be overwritten
    # See https://github.com/spulec/moto/issues/2172
    from moto import mock_aws

    with mock_aws():
        client = boto3.client("s3", region_name=deal_consumer.Env.AWS_REGION)
        client.create_bucket(Bucket=deal_consumer.Env.SNAPSHOT_BUCKET)
        client.create_bucket(Bucket=deal_consumer.Env.REPROCESSING_GARAGE)

        yield client


@pytest.fixture()
def freeze_time():
    with freezegun.freeze_time():
        yield


@pytest.fixture()
def apig_client(patch_env, patch_aws_credentials_env, monkeypatch, freeze_time):
    with mock_aws():
        client = boto3.client("apigateway", region_name=healthchecks.Env.AWS_REGION)
        res = client.create_rest_api(
            name="dr-deal-data-api", description="this is my api"
        )

        yield client, res["id"]


@pytest.fixture()
def boto3_apig_client(apig_client, **kwargs):
    def client(*args, **kwargs):
        return MockApig

    class MockApig:
        @staticmethod
        def get_paginator(*args, **kwargs):
            return apig_client[0].get_paginator("get_rest_apis")

        @staticmethod
        def get_resources(*args, **kwargs):
            return apig_client[0].get_resources(restApiId=apig_client[1], limit=500)

    return client


@pytest.fixture()
def boto3_resource_table_delete_item_error(dynamodb, **kwargs):
    def resource(*args, **kwargs):
        return MockResource

    class MockResource:
        class Table:
            def __init__(self, *args, **kwargs):
                pass

            @staticmethod
            def batch_writer(*args, **kwargs):
                raise Exception("dynamoDB Test Exception")

            @staticmethod
            def put_item(*args, **kwargs):
                raise Exception("dynamoDB Test Exception")

            def delete_item(*args, **kwargs):
                if "DTC.ERROR_TRIGGER" in kwargs.get("Key", {}).get("dealComponent"):
                    raise ClientError({}, "Mock Operation")

    return resource


@pytest.fixture()
def boto3_client_api_gateway(patch_aws_credentials_env):
    def client(*args, **kwargs):
        return MockClient

    class MockClient:
        @staticmethod
        def get_usage_plans(*args, **kwargs):
            return {"items": [{"id": "test", "name": "dr-deal-data-api-test"}]}

        @staticmethod
        def get_usage(*args, **kwargs):
            return {"items": {"test": [[5, 45]]}}

        @staticmethod
        def get_credentials(*args, **kwargs):
            class Creds:
                def __init__(self):
                    self.access_key = secrets.token_urlsafe(16)
                    self.secret_key = secrets.token_urlsafe(16)
                    self.token = "test-token"

            return Creds()

    return client


@pytest.fixture()
def boto3_client(dynamodb, **kwargs):
    def client(*args, **kwargs):
        if "lambda" in args or "lambda" in kwargs:
            return MockLambda
        else:
            return MockClient

    class MockClient:
        @staticmethod
        def transact_write_items(*args, **kwargs):
            records = kwargs.get("TransactItems")
            table = dynamodb.Table("deals")
            for item in records:
                element = item.get("Update")
                table.update_item(
                    Key={
                        "dealRefId": element["Key"]["dealRefId"]["S"],
                        "dealComponent": element["Key"]["dealComponent"]["S"],
                    },
                    UpdateExpression=element["UpdateExpression"],
                    ExpressionAttributeValues=element["ExpressionAttributeValues"],
                    ExpressionAttributeNames=element["ExpressionAttributeNames"],
                )
            return "updated"

    class MockLambda:
        @staticmethod
        def list_event_source_mappings(*args, **kwargs):
            if kwargs["FunctionName"] == "NoEventSourceLambda":
                return {"EventSourceMappings": []}
            elif kwargs["FunctionName"] == "StateDisabledLambda":
                return {"EventSourceMappings": [{"State": "Disabled"}]}
            else:
                return {"EventSourceMappings": [{"State": "Enabled"}]}

    return client


@pytest.fixture()
def boto3_s3_client(s3, **kwargs):
    def client(*args, **kwargs):
        return MockS3

    class MockS3:
        @staticmethod
        def put_object(*args, **kwargs):
            if kwargs.get("Body") == '"raise_snapshot_error"':
                raise Exception("Snapshot Create Failed")
            s3.put_object(
                Body=kwargs.get("Body"),
                Bucket=kwargs.get("Bucket"),
                Key=kwargs.get("Key"),
                Tagging=kwargs.get("Tagging"),
                ContentType=kwargs.get("ContentType"),
            )
            return True

        @staticmethod
        def list_objects_v2(*args, **kwargs):
            return s3.list_objects_v2(*args, **kwargs)

        @staticmethod
        def get_object(*args, **kwargs):
            return s3.get_object(*args, **kwargs)

        @staticmethod
        def get_bucket_acl(*args, **kwargs):
            return s3.get_bucket_acl(*args, **kwargs)

    return client


@pytest.fixture()
def sqs(patch_env, patch_aws_credentials_env):
    """
    Create mock sqs for tests.
    :return: a mock sqs resource object
    """
    # Workaround for moto bug where jus importing it causes AWS environment variables to be overwritten
    # See https://github.com/spulec/moto/issues/2172
    from moto import mock_aws

    queues = [
        healthchecks.Env.DEAL_DATA_DLQ,
        healthchecks.Env.DEAL_DATA_QUEUE,
        healthchecks.Env.EVENT_ROUTE_QUEUE,
        router.Env.ROUTE_ONE_QUEUE,
        router.Env.UNIFI_BRIDGE_DLQ,
        router.Env.DEALXG_BRIDGE_QUEUE,
    ]

    with mock_aws():
        client = boto3.client("sqs", region_name=healthchecks.Env.AWS_REGION)
        for queue_name in queues:
            client.create_queue(QueueName=queue_name)
        yield client


@pytest.fixture()
def response_header():
    def wrapper(col_id, extra_headers=None):
        extra_headers = extra_headers or {}
        headers = {
            se.CORRELATION_ID_HEADER_KEY: col_id,
            "x-aws-region": "us-east-1",
            "x-api-version": "v1.0",
            "Cache-Control": "public, max-age=3600, s-maxage=3600",
            "Content-Security-Policy": "default-src 'none'",
            "X-Frame-Options": "deny",
            "X-Content-Type-Options": "nosniff",
        }
        return dict(headers, **extra_headers)

    return wrapper


@pytest.fixture(autouse=True)
def mock_dr_utils_imports(monkeypatch, mock_dr_utils):
    monkeypatch.setattr(deal_consumer, "dr_utils", mock_dr_utils)
    monkeypatch.setattr(router, "dr_utils", mock_dr_utils)
    monkeypatch.setattr(credit_app_producer, "dr_utils", mock_dr_utils())
    monkeypatch.setattr(lead_producer, "dr_utils", mock_dr_utils())
    monkeypatch.setattr(key_data_producer, "dr_utils", mock_dr_utils())
    monkeypatch.setattr(key_data_producer_v2, "dr_utils", mock_dr_utils())
    monkeypatch.setattr(con_producer, "dr_utils", mock_dr_utils())
    monkeypatch.setattr(con_producer_v2, "dr_utils", mock_dr_utils())
    monkeypatch.setattr(credit_bureau_producer, "dr_utils", mock_dr_utils())
    monkeypatch.setattr(event_consumer, "dr_utils", mock_dr_utils())
    monkeypatch.setattr(event_route, "dr_utils", mock_dr_utils())
    monkeypatch.setattr(event_producer, "dr_utils", mock_dr_utils())
    monkeypatch.setattr(logging, "dr_utils", mock_dr_utils())
    monkeypatch.setattr(mixins, "dr_utils", mock_dr_utils())


class MockUtilsExtended:
    def get_apic_request_headers(self, *args, **kwargs):
        return {
            "Authorization": "Bearer test",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

    class ParameterStore:
        def __init__(self, *args, **kwargs):
            pass

        def get_secret(self, name):
            return "deals"


@pytest.fixture()
def mock_dr_utils(decimal_encoder):
    class MockUtils(MockUtilsExtended):
        @staticmethod
        def get_sqs_msg_attr(key, message):
            return message.get("messageAttributes", {}).get(key, {}).get("stringValue")

        def compose_message_attributes(*args, **kwargs):
            return {}

        def retry_or_fail(*args, **kwargs):
            msg = "Exceeded maximum retry count, failed to send application"
            return (HTTPStatus.OK, msg)

        def get_secret(*args, **kwargs):
            return {"client_id": "TEST_ID", "client_secret": "TEST_SECRET"}

        def get_api_connect_request_headers(*args, **kwargs):
            return {
                "Authorization": "Bearer 01DXK5NJCR07BH4CY4JBV2F3QZ",
                "Content-Type": "application/json",
                "Accept": "application/json",
            }

        def get_region(*args, **kwargs):
            return "us-east-1"

        class exceptions:
            class NoQueueFound(Exception):
                pass

            class BadRequestError(Exception):
                pass

        class PIIScrubber:
            def obfuscate_pii(self, xml_string):
                return xml_string

        DecimalEncoder = decimal_encoder
        DecimalDecoder = common.decimal_decoder()

    MockUtils.send_payload_to_queue = MagicMock(return_value=True)
    return MockUtils


@pytest.fixture()
def raw_event_dict():
    return {
        "event": "foo event",
        "logger": "__main__",
        "level": "info",
        "int_number": 1,
        "dec_number_float": Decimal("1.1"),
        "dec_number_int": Decimal("1"),
        "dec_number_bool": Decimal(True),
    }


@pytest.fixture()
def serialized_raw_event_dict():
    return """{
        "event": "foo event",
        "logger": "__main__",
        "level": "info",
        "int_number": 1,
        "dec_number_float": 1.1,
        "dec_number_int": 1,
        "dec_number_bool": 1\n}"""


@pytest.fixture()
def raw_event_dict_with_set():
    return {
        "event": "foo event",
        "logger": "__main__",
        "level": "info",
        "int_number": 1,
        "dec_number_float": Decimal("1.1"),
        "dec_number_int": Decimal("1"),
        "dec_number_bool": Decimal(True),
        "string_set": set({"1"}),
    }


@pytest.fixture()
def serialized_raw_event_dict_with_set():
    return """{
        "event": "foo event",
        "logger": "__main__",
        "level": "info",
        "int_number": 1,
        "dec_number_float": 1.1,
        "dec_number_int": 1,
        "dec_number_bool": 1,
        "string_set": [
                "1"
        ]\n}"""


@pytest.fixture()
def mock_add_updated_timestamp():
    def add_updated_timestamp(update_expressions, attr_names, attr_values):
        return update_expressions, attr_names, attr_values

    return add_updated_timestamp


@pytest.fixture()
def expected_info_response():
    return {"service": "dr_deal_data_api", "region": "us-east-1", "version": "v1.0"}


@pytest.fixture()
def cb_applicant(applicant):
    applicant["reports"] = [
        {"provider": "Transunion", "type": "SoftPull"},
        {"provider": "Equifax", "type": "CreditBureau"},
        {"provider": "Equifax", "type": "Redflag"},
        {"provider": "Equifax", "type": "OFAC"},
    ]
    return applicant


@pytest.fixture()
def cb_coapplicant(coapplicant):
    coapplicant["reports"] = [
        {"provider": "Experian", "type": "CreditBureau"},
        {"provider": "Experian", "type": "Redflag"},
        {"provider": "Equifax", "type": "SoftPull"},
    ]

    return coapplicant


@pytest.fixture()
def cb_applicant_response(applicant):
    cb_applicant_response = copy.deepcopy(applicant)
    cb_applicant_response["reports"] = [
        {
            "provider": "Transunion",
            "type": "SoftPull",
            "status": "pending",
            "creditBureauScore": "800",
        },
        {
            "provider": "Equifax",
            "type": "CreditBureau",
            "status": "done",
            "creditBureauScore": "755",
        },
        {
            "provider": "Equifax",
            "type": "Redflag",
            "status": "failed",
            "creditBureauScore": "743",
        },
        {
            "provider": "Equifax",
            "type": "OFAC",
            "status": "done",
            "creditBureauScore": "788",
        },
    ]
    return cb_applicant_response


@pytest.fixture()
def credit_bureau_full_payload(dr_ulid, cb_applicant, cb_coapplicant):
    return {
        "headers": {se.CB_PULL_HEADER_KEY: CREDIT_BUREAU_ID},
        "body": {
            "dealRefId": dr_ulid,
            "sourcePartnerId": "VIN",
            "targetPlatforms": [{"id": "R1J", "partyId": "123987"}],
            "financeMethod": "Lease",
            "applicant": cb_applicant,
            "coApplicant": cb_coapplicant,
        },
    }


@pytest.fixture()
def get_sqs_event_credit_bureau(
    credit_app_partial_payload, decimal_encoder, get_sqs_event
):
    def sqs_event(body, payload_type):
        event = get_sqs_event(body, payload_type)
        event["Records"][0]["messageAttributes"].update(
            {
                "cbPullId": {
                    "stringValue": CREDIT_BUREAU_ID,
                    "stringListValues": [],
                    "binaryListValues": [],
                    "dataType": "String",
                }
            }
        )
        return event

    return sqs_event


@pytest.fixture()
def get_mock_existing_deal_validator():
    def mock_existing_deal_validator(mock_body):
        class MockExistingDealValidator(ExistingDealValidator):
            def validate_id_uniqueness(self, *args, **kwargs):
                return mock_body

        return MockExistingDealValidator

    return mock_existing_deal_validator


@pytest.fixture()
def lender_decision_response(applicant):
    return json.dumps(
        {
            "dealRefId": DR_ULID,
            "sourcePartnerId": "VIN",
            "targetPlatforms": [{"id": "R1J", "partyId": "123987"}],
            "financeMethod": "Lease",
            "customerType": "Individual",
            "applicant": applicant,
            "ssn": "788999009",
            "dateOfBirth": "1963-06-18",
            "driversLicenseNumber": "784534987",
            "driversLicenseState": "CO",
        }
    )


@pytest.fixture()
def lender_decision_response_pii_scrubbed(applicant, lender_decision_response):
    masked_pii_data = {
        "ssn": "XXXX",
        "dateOfBirth": "XXXX",
        "driversLicenseNumber": "XXXX",
        "driversLicenseState": "XXXX",
    }
    masked_ref_pii_data = {"ssn": "XXXX", "dateOfBirth": "XXXX"}

    masked_lender_decision_response = json.loads(lender_decision_response)
    masked_lender_decision_response.update(masked_pii_data)
    masked_lender_decision_response["applicant"]["protected"].update(masked_pii_data)
    masked_lender_decision_response["applicant"]["references"][0].update(
        masked_ref_pii_data
    )

    return json.dumps(masked_lender_decision_response)


@pytest.fixture()
def mock_query_items_empty(*args, **kwargs):
    def query_items(*args, **kwargs):
        return []

    return query_items


@pytest.fixture()
def mock_ca_event_decision():
    """
    Test response
    :return: test credit app decision event response.
    """
    return {
        "eventVersion": "1.1",
        "eventId": "01DHHVT56TMC2QKF2FFBMVREBP",
        "eventTime": "2018-07-03T19:16:37.327Z",
        "eventName": "Deal:CreditDecisionResponse",
        "eventDetailHref": "https://fni-api.dealertrack.com/shopper/decisions/lender-id/CMB/d3aa88e2-c754-41e0-8ba6-4198a34aa0a2/?type=credit",
        "eventSource": "ahc:decisions",
        "eventTransactionId": "d3aa88e2-c754-41e0-8ba6-5258a34aa0a4",
        "eventEntityId": "104334",
        "payloadSchema": "DealDecisions/v1",
        "payload": {
            "approvalStatus": "Approved",
            "approvedAmount": 23310.99,
            "approvedRate": 2.99,
            "approvedTerm": 36,
            "lenderId": "BOA",
            "lenderName": "Bank of America",
            "tier": "Gold",
            "stipulations": ["", "Stipulation2"],
            "monthlyPayment": 530.88,
            "lenderMoneyFactor": 0.00209,
            "customerMoneyFactor": 0.00209,
            "downPayment": 530.88,
            "financeMethod": "Lease",
            "lenderApplicationId": "BOA-BAR",
        },
    }


@pytest.fixture()
def mock_ca_event_decision_no_payload():
    """
    Test response
    :return: test credit app decision event response without payload.
    """
    return {
        "eventVersion": "1.1",
        "eventId": "01DHHVT56TMC2QKF2FFBMVREBP",
        "eventTime": "2018-07-03T19:16:37.327Z",
        "eventName": "Deal:CreditDecisionResponse",
        "eventDetailHref": "https://fni-api.dealertrack.com/shopper/decisions/lender-id/CMB/d3aa88e2-c754-41e0-8ba6-4198a34aa0a2/?type=credit",
        "eventSource": "ahc:decisions",
        "eventTransactionId": "d3aa88e2-c754-41e0-8ba6-5258a34aa0a4",
        "eventEntityId": "104334",
        "payloadSchema": "DealDecisions/v1",
    }


@pytest.fixture()
def mock_ideal_event_decision_empty():
    """
    Test response
    :return: test iDeal decision declined event response.
    """
    return {}


@pytest.fixture()
def mock_func_decision_payload():
    """
    Test response
    :return: test functional credit app decision event response.
    """
    return {
        "eventVersion": "1.1",
        "eventId": "d3aa88e2-c754-41e0-8ba6-4198a34aa0a2",
        "eventTime": "2018-07-03T19:16:37.327Z",
        "eventName": "Deal:CreditDecisionResponse",
        "eventDetailHref": "https://fni-api.dealertrack.com/shopper/decisions/lender-id/CMB/d3aa88e2-c754-41e0-8ba6-4198a34aa0a2/?type=credit",
        "eventSource": "fni:decisions",
        "eventType": "AHC:decisions",
        "eventTransactionId": "01DHHVT56TMC2QKF2FFBMVREBP_TEST",
        "eventEntityId": "104334",
        "payloadSchema": "DealDecisions/v1",
        "payload": {
            "approvalStatus": "Approved",
            "approvedAmount": 23310.99,
            "approvedRate": 2.99,
            "approvedTerm": 36,
            "lenderId": "BOA",
            "lenderName": "Bank of America",
            "tier": "Gold",
            "stipulations": ["Stipulation1", "Stipulation2", {"test3": "Stipulation3"}],
            "monthlyPayment": 530.88,
            "lenderMoneyFactor": 0.00209,
            "customerMoneyFactor": 0.00209,
            "downPayment": 530.88,
            "financeMethod": "Lease",
        },
    }


@pytest.fixture()
def mock_ideal_key_data():
    """
    Test response
    :return: ideal key data object.
    """
    return {
        "dealRefId": "01FHHVT56TMC2QKF2FFBMVREBP",
        "dealRefIdDR": "01FHHVT56TMC2QKF2FFBMVREBP",
        "lenderId": "BOA",
        "partnerCode": "400016559",
        "sourcePartnerDealerId": "123454789",
        "sourcePartnerId": "MMD",
    }


@pytest.fixture()
def query_item_mmd_source_partner(**kwargs):
    def query_items(*args, **kwargs):
        return [
            {
                "dealRefId": "01FHHVT56TMC2QKF2FFBMVREBP",
                "dealRefIdDR": "01FHHVT56TMC2QKF2FFBMVREBP",
                "lenderId": "BOA",
                "partnerCode": "400016559",
                "sourcePartnerDealerId": "123454789",
                "sourcePartnerId": "MMD",
            }
        ]

    return query_items


@pytest.fixture()
def mock_func_decision_payload_declined():
    """
    Test response
    :return: test iDeal decision declined event response.
    """

    return {
        "eventVersion": "1.1",
        "eventId": "01FHHVT56TMC2QKF2FFBMVREBP",
        "eventTime": "2018-07-03T18:16:37.327Z",
        "eventName": "Deal:CreditDecisionResponse",
        "eventDetailHref": "https://fni-api.dealertrack.com/shopper/decisions/lender-id/CMB/d4aa88e2-c754-41e0-8ba6-4198a34aa0a2/?type=credit",
        "eventSource": "AHC:decisions",
        "eventType": "AHC:decisions",
        "eventTransactionId": "d4aa88e2-c754-41e0-8ba6-5258a34aa0a4",
        "eventEntityId": "104334",
        "payloadSchema": "DealDecisions/v1",
        "payload": {
            "approvalStatus": "Declined",
            "approvedAmount": 23310.99,
            "approvedRate": 2.99,
            "approvedTerm": 36,
            "lenderId": "BOA",
            "lenderName": "Bank of America",
            "tier": "Gold",
            "monthlyPayment": 530.88,
            "lenderMoneyFactor": 0.00209,
            "customerMoneyFactor": 0.00209,
            "downPayment": 530.88,
            "financeMethod": "Lease",
        },
    }


@pytest.fixture()
def mock_func_decision_headers():
    """
    Test response
    :return: test route_to_events decision headers.
    """
    return {
        "X-CoxAuto-Correlation-Id": "12345abc-abc1-2def-56ef-000000000000",
    }


@pytest.fixture()
def mock_func_decision_payload_vin():
    """
    Test response
    :return: test vin iDeal decision event response.
    """

    return {
        "eventVersion": "1.1",
        "eventId": "01FHGFT56TMC2QKF2FFBMVREBP",
        "eventTime": "2018-07-03T18:16:37.327Z",
        "eventName": "Deal:CreditDecisionResponse",
        "eventDetailHref": "https://fni-api.dealertrack.com/shopper/decisions/lender-id/CMB/d4aa88e2-c754-41e0-8ba6-4198a34aa0a2/?type=credit",
        "eventSource": "AHC:decisions",
        "eventType": "AHC:decisions",
        "eventTransactionId": "01FMSP049ZGTZ5GSBG31A0F4M0",
        "eventEntityId": "104334",
        "payloadSchema": "DealDecisions/v1",
        "payload": {
            "approvalStatus": "Declined",
            "approvedAmount": 23310.99,
            "approvedRate": 2.99,
            "approvedTerm": 36,
            "lenderId": "BOA",
            "lenderName": "Bank of America",
            "tier": "Gold",
            "monthlyPayment": 530.88,
            "lenderMoneyFactor": 0.00209,
            "customerMoneyFactor": 0.00209,
            "downPayment": 530.88,
            "financeMethod": "Lease",
        },
    }


@pytest.fixture()
def mock_func_decision_payload_approved():
    """
    Test response
    :return: test functional credit app decision event response.
    """
    return {
        "eventVersion": "1.1",
        "eventId": "d3aa88e2-c754-41e0-8ba6-4198a34aa0a2",
        "eventTime": "2018-07-03T19:16:37.327Z",
        "eventName": "Deal:CreditDecisionResponse",
        "eventDetailHref": "https://fni-api.dealertrack.com/shopper/decisions/lender-id/CMB/d3aa88e2-c754-41e0-8ba6-4198a34aa0a2/?type=credit",
        "eventSource": "AHC:decisions",
        "eventType": "AHC:decisions",
        "eventTransactionId": "01FHHVT56TMC2QKF2FFBMVREBP",
        "eventEntityId": "104334",
        "payloadSchema": "DealDecisions/v1",
        "payload": {
            "approvalStatus": "Approved",
            "approvedAmount": 23310.99,
            "approvedRate": 2.99,
            "approvedTerm": 36,
            "lenderId": "BOA",
            "lenderName": "Bank of America",
            "tier": "Gold",
            "stipulations": ["Stipulation1", "Stipulation2", {"test3": "Stipulation3"}],
            "monthlyPayment": 530.88,
            "lenderMoneyFactor": 0.00209,
            "customerMoneyFactor": 0.00209,
            "downPayment": 530.88,
            "financeMethod": "Lease",
        },
    }


@pytest.fixture()
def dr_events_payload():
    return {
        "eventVersion": 1.2,
        "eventId": "b6863f84-2394-11eb-8016-0242ac120002",
        "eventTime": "2018-10-26T10:34:01",
        "eventName": "CreditDecisions:Approved",
        "eventDetailHref": "https://fni-api.dealertrack.com/dr-decisions/v1/responses/responseId/lenders/lenderId/",
        "eventSource": "fni:Deals",
        "eventType": "fni:CreditApplications",
        "eventIdentityId": "b6863f84-2394-11eb-8016-0242ac120002",
        "eventEntityId": "329179",
        "eventTransactionId": DR_ULID,
        "eventKeyData": {},
        "payload": {},
    }


@pytest.fixture()
def mock_get_events_query(dr_events_payload):
    def query_items(*args, **kwargs):
        return [dr_events_payload]

    return query_items


@pytest.fixture()
def mock_get_events_query_response():
    def query_items(*args, **kwargs):
        return []

    return query_items


@pytest.fixture()
def contract_verify_payload():
    return {
        "sourcePartnerId": "VIN",
        "financeMethod": "Finance",
        "targetPlatforms": [{"id": "DTC", "partyId": "123456789"}],
    }


@pytest.fixture()
def contract_sign_payload():
    return {
        "sourcePartnerId": "VIN",
        "targetPlatforms": [{"id": "DTC", "partyId": "123456789"}],
        "applicant": {
            "emailAddress": "test_app@test.com",
            "firstName": "Earnest",
            "lastName": "Winhoffer",
            "phone": "5167349659",
        },
        "coApplicant": {
            "emailAddress": "test_coapp@test.com",
            "firstName": "Earnestrr",
            "lastName": "Winhofferee",
            "phone": "5167349650",
        },
        "dealer": {
            "emailAddress": "test_email@test.com",
            "firstName": "Eaynestrr",
            "lastName": "Winferee",
            "phone": "5160949650",
            "dealerName": "ROI Motors",
        },
        "guarantorPrimary": {
            "emailAddress": "test_guarantor@test.com",
            "firstName": "Smith",
            "lastName": "Winhofferee",
            "phone": "5167899650",
        },
        "guarantorAdditional": {
            "emailAddress": "guarantor_additional@test.com",
            "firstName": "John",
            "lastName": "Winhofferee",
            "phone": "5167099650",
        },
    }


@pytest.fixture()
def contract_deal_status_payload():
    return {
        "sourcePartnerId": "VIN",
        "targetPlatforms": [{"id": "DTC", "partyId": "123456789"}],
        "contractStatusCode": "Book",
    }


@pytest.fixture()
def contract_cancel_payload():
    return {
        "sourcePartnerId": "VIN",
        "targetPlatforms": [{"id": "DTC", "partyId": "123456789"}],
    }


@pytest.fixture()
def kms(patch_aws_credentials_env):
    """
    Create mock kms key id and arn for tests.
    :return Tuple(KeyId, KeyArn) where:
        KeyId: AWS globally-unique string ID
        KeyArn: Amazon Resource Name of the CMK
    """
    with mock_aws():
        client = boto3.client("kms", region_name="us-east-1")
        response = client.create_key()
        client.create_alias(
            AliasName="alias/test-alias", TargetKeyId=response["KeyMetadata"]["KeyId"]
        )
        yield response


# @pytest.fixture(autouse=True)
def mock_parameter_store(patch_aws_credentials_env, kms):
    # Workaround for moto bug where jus importing it causes AWS environment variables to be overwritten
    # See https://github.com/spulec/moto/issues/2172
    from moto import mock_aws

    with mock_aws():
        ssm = boto3.client("ssm", "us-east-1")
        parameters = [
            "/qa1/honda/ca/apic-onprem/fd_events_url",
            "/qa1/honda/ca/apic-onprem/token_url",
            "/qa1/honda/ca/apic-onprem/client_secret"
            "/qa1/honda/ca/apic-onprem/client_id",
            "/qa1/honda/ca/apic-onprem/scope",
            "/qa1/honda/ca/apic-aws/fd_events_url",
            "/qa1/honda/ca/apic-aws/token_url",
            "/qa1/honda/ca/apic-aws/client_secret" "/qa1/honda/ca/apic-aws/client_id",
            "/qa1/honda/ca/apic-aws/scope",
        ]
        for param in parameters:
            ssm.put_parameter(
                Name=param,
                Description="A test parameter",
                Value="test data",
                Type="SecureString",
            )
        yield ssm


@pytest.fixture()
def mock_dynamodb_helper_deals(dynamodb):
    class MockDynamoDBHelper:
        def __init__(self, table_name, region, *args, **kwargs):
            self.db_resource = dynamodb
            self.table_name = table_name
            self.region = region
            self.table = dynamodb.Table(table_name)

        def update_item(self, *args, **kwargs):
            partition_key = kwargs.get("partition_key")
            sort_key = kwargs.get("sort_key")
            update_record = kwargs.get("update_record")

            condition_expression = kwargs.get("condition_expression")
            update_expression_list = []
            expression_attribute_names = {}
            expression_attribute_values = {}

            partition_value = update_record.pop(partition_key)
            key_info = {partition_key: partition_value}
            if sort_key:
                sort_key_val = update_record.pop(sort_key)
                key_info.update({sort_key: sort_key_val})

            if not condition_expression:
                condition_expression = boto3.dynamodb.conditions.Attr(partition_key).eq(
                    str(partition_value)
                )
                if sort_key:
                    condition_expression = (
                        condition_expression
                        & boto3.dynamodb.conditions.Attr(sort_key).eq(str(sort_key_val))
                    )

            for key, val in update_record.items():
                update_expression_list.append(f"#{key} = :{key}")
                expression_attribute_names[f"#{key}"] = str(key)
                expression_attribute_values[f":{key}"] = val

            self.db_resource.Table(
                deal_consumer.DealDataParameters().db_name
            ).update_item(
                Key=key_info,
                ConditionExpression=condition_expression,
                UpdateExpression=f"SET {' , '.join(update_expression_list)}",
                ExpressionAttributeNames=expression_attribute_names,
                ExpressionAttributeValues=expression_attribute_values,
            )

        def query_items(self, *args, **kwargs):
            """
            Will fetch all records of particular key condition expression
            If filter_key_value is provided function itself creates key_expression with basic & condition in between
            multiple filter keys
            For complex filter_expression, provide filter_expression instead of filter_key_value
            :param key_expr_dict: (dict) Should be dict format:
                                    { "filter key": {
                                                    "operation": "eq",
                                                    "value": "filter value",
                                                    }}
            :param key_expression: (boto3 condition object) Filter expression to fetch records from dynamo
            :param index: Name of an index to query.
            :return: List of records
            """
            key_expression = kwargs.get("key_expression")
            key_expr_dict = kwargs.get("key_expr_dict")
            index = kwargs.get("index")
            filter_expression = kwargs.get("filter_expression")

            if not key_expression:
                for counter, (key, value) in enumerate(key_expr_dict.items()):
                    exp = eval(
                        f"conditions.Key('{key}').{value.get('operation')}('{value.get('value')}')"
                    )
                    key_expression = key_expression & exp if counter > 0 else exp

            if index:
                records = (
                    self.table.query(
                        KeyConditionExpression=key_expression,
                        IndexName=index,
                        FilterExpression=filter_expression,
                    )
                    if filter_expression
                    else self.table.query(
                        KeyConditionExpression=key_expression, IndexName=index
                    )
                )
            else:
                records = (
                    self.table.query(
                        KeyConditionExpression=key_expression,
                        FilterExpression=filter_expression,
                    )
                    if filter_expression
                    else self.table.query(KeyConditionExpression=key_expression)
                )

            return records.get("Items", [])

        def query_db_pk_sk(
            self,
            deal_ref_id: str,
            deal_component: str = None,
            deal_component_op: str = "eq",
        ):
            """
            Query DynamoDB by PartitionKey and SortKey
            :param deal_ref_id: dealRefId from path parameters
            :param deal_component: sort key for the db to form key expression
            :param deal_component_op: boto3 key expression attribute operation ('eq', 'begins_with')
            :return: version number from db
            """

            key_expression = Key("dealRefId").eq(deal_ref_id)
            if deal_component:
                component_expr = getattr(Key("dealComponent"), deal_component_op)(
                    deal_component
                )
                key_expression = key_expression & component_expr

            return self.query_items(key_expression=key_expression)

    return MockDynamoDBHelper


@pytest.fixture()
def mock_validate_reference_ids():
    def wrapper(*args, **kwargs):
        pass

    return wrapper


@pytest.fixture()
def mock_validate_api_version():
    def wrapper(*args, **kwargs):
        pass

    return wrapper


# TODO Make this dynamic
@pytest.fixture()
def generic_invalid_dealref_id():
    return [
        {
            "code": "deal.invalidRefId",
            "properties": [{"property": "dealRefId", "message": "Invalid dealRefId"}],
        }
    ]


@pytest.fixture()
def mock_validate_api_version_invalid_dealrefid(generic_invalid_dealref_id):
    def wrapper(*args, **kwargs):
        error = generic_invalid_dealref_id
        raise exceptions.BadRequestError(error)

    return wrapper


@pytest.fixture()
def mock_cache_attrs():
    def wrapper(*args, **kwargs):
        pass

    return wrapper


@pytest.fixture(autouse=True)
def mock_deal_parameters(monkeypatch):
    def mock_get_parameter(*args, **kwargs):
        return "deals"

    monkeypatch.setattr(common.DealDataParameters, "get_parameter", mock_get_parameter)
    monkeypatch.setattr(
        healthchecks.DealDataParameters, "get_parameter", mock_get_parameter
    )


@pytest.fixture
def partial_db_record_lender():
    """
    Including record from Lender Decision that also has lenderId.
    This record should not be processed as a lenderList, so we need to test this.
    """
    return [
        {
            "dealComponent": f"CD.DT6.{DR_ULID}",
            "lenderId": "DT6",
            "lenderName": "DT TEST BALANCER",
            "ttl": Decimal("1234573074000"),
            "dealerMessage": "Lender Approved",
            "createdTimestamp": "2018-12-31T23:11:22.543545",
            "updatedTimestamp": "2018-12-31T23:11:22.543545",
        },
        {
            "dealComponent": "DTC.LENDERLIST.BOA",
            "lenderId": "BOA",
            "lenderName": "Bank of America",
            "ttl": Decimal("1234573074000"),
            "dealRefId": "0000000000AAABBBCCDDEEFFGG",
            "createdTimestamp": "2018-12-31T23:11:22.543545",
            "updatedTimestamp": "2018-12-31T23:11:22.543545",
        },
        {
            "dealComponent": "DTC.LENDERLIST.CMB",
            "lenderId": "CMB",
            "lenderName": "Chase Bank",
            "ttl": Decimal("1234573074000"),
            "dealRefId": "0000000000AAABBBCCDDEEFFGG",
            "createdTimestamp": "2018-12-31T23:11:22.543545",
            "updatedTimestamp": "2018-12-31T23:11:22.543545",
        },
    ]


@pytest.fixture()
def business_applicant():
    return {
        "bankInformation": {
            "bankName": "Wells Fargo",
            "bankAccountno": 31456965367549,
            "bankContactname": "Money Bags",
            "bankContactPhoneNo": "503-705-3249",
        },
        "address": {
            "line1": "1466 downing street",
            "line2": "unit 22",
            "city": "beaverton",
            "state": "or",
            "postalCode": "97006",
        },
        "businessEmail": "businessEmail@cox.com",
        "businessTaxid": "068784448",
        "businessName": "Bcatest_Dev_120",
        "businessEstablisheddate": "2005-11-27t00:00:00",
        "businessPhoneno": "5164455598",
        "yearsInBusiness": 2,
        "numberOfEmployees": 5500,
        "preferredContactMethod": "Email",
        "businessType": "llc",
        "financialStatement": {"type_desc": "cpa_reviewed", "type_code": "cc"},
        "requestor": {
            "firstName": "Nikhil",
            "lastName": "Raina",
            "title": "Earl of Swuanee",
            "suffix": "",
        },
        "beneficialOwner": [
            {
                "address": {
                    "line1": "1160 main st",
                    "line2": "Line 2 here",
                    "city": "Suwanee",
                    "state": "GA",
                    "postalCode": "30024",
                },
                "dateOfBirth": "06/02/1974",
                "citizenshipCountryCode": "USA",
                "documentName": "Social Security Card",
                "expiryDate": "02/24/2030",
                "firstName": "FNameBenFirst",
                "IdentificationNumber": "113-22-1122",
                "identificationType": "SocialSecurityNumber",
                "issuanceCountryCode": "USA",
                "issuanceDate": "07/02/1974",
                "lastName": "LName",
                "middleInitial": "G",
                "ownershipPercentage": 100,
                "secondCitizenshipCountryCode": "",
                "suffix": "JR",
                "title": "Mr.",
            }
        ],
    }


@pytest.fixture()
def business_credit_app_full_payload(
    business_applicant,
    coapplicant,
    vehicle,
    tradein_vehicles,
    finance_summary,
    fees,
    taxes,
    products,
):
    return {
        "dealRefId": DR_ULID,
        "creditAppId": DR_ULID,
        "leadRefId": DR_ULID,
        "sourcePartnerId": "VIN",
        "targetPlatforms": [{"id": "R1J", "partyId": "123987"}],
        "financeMethod": "Lease",
        "customerType": "Individual",
        "businessApplicant": business_applicant,
        "coApplicant": coapplicant,
        "vehicle": vehicle,
        "tradeIns": tradein_vehicles,
        "financeSummary": finance_summary,
        "fees": fees,
        "taxes": taxes,
        "products": products,
        "lenderList": [{"lenderId": "BOA", "lenderName": "Bank of America"}],
        "partnerSource": "string",
        "comments": "Credit Application comments to the lender. Customer needs to get confirmation from his wife.",
        "regulationBIndicator": True,
        "privacyNoticeIndicator": True,
        "communityPropertyDisclosureIndicator": True,
        "extraData": [{"name": "OTDXDCMB01", "value": "CustomValue-SOJCD165"}],
    }


@pytest.fixture()
def ca_put_payload():
    return {
        "dealRefId": DR_ULID,
        "creditAppId": DR_ULID_NEW,
        "sourcePartnerId": "DTS",
        "targetPlatforms": [{"id": "DTC", "partyId": "1001000"}],
        "financeMethod": "Lease",
        "applicant": {
            "income": 156,
            "housingStatus": "Rent",
        },
        "financeSummary": {
            "vehicleSellingPrice": 83482,
            "term": 60,
            "warranty": 707,
            "wholesaleCondition": "Average",
            "wholesaleValueType": "NA",
            "wholesaleValue": 10000,
        },
        "vehicle": {
            "inventoryVehicleCondition": "Used",
            "vin": "2T1BURHE0JC981147",
            "stockNumber": "181425AN",
            "chromeStyleId": "125534",
            "otherYear": 2017,
            "otherMake": "Toyota",
            "otherModel": "Corolla",
            "otherTrim": "4dr Reg WB Plus 1SB Pkg",
            "certifiedUsed": True,
        },
        "tradeIns": [
            {
                "chromeStyleId": "125534",
                "otherYear": 2017,
                "otherMake": "Toyota",
                "otherModel": "Corolla",
                "otherTrim": "4dr Reg WB Plus 1SB Pkg",
                "monthlyPayment": 250,
                "vehicleBookCondition": "Clean",
                "lienHolder": {
                    "name": "Ford Motor Credit Co",
                    "phone": "336-968-4645",
                    "address": {
                        "line1": "8374 Test St",
                        "line2": "APT #D19",
                        "city": "Littleton",
                        "state": "CO",
                        "postalCode": "80128",
                    },
                },
            }
        ],
        "lenderList": [{"lenderId": "DTL", "lenderName": "DT Test Lender"}],
    }
