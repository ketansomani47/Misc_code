# -*- coding: utf-8 -*-
import copy
import json
from http import HTTPStatus

import ulid
from common import deal_consumer
from events import events_lambda
from utils import db_helper


def test_patch_with_existing_resource(
    startup_db_events_helper,
    get_api_gateway_event,
    lambda_context,
    dynamodb,
    monkeypatch,
    mock_dynamodb_helper_deals,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)

    records = startup_db_events_helper
    copy_records = copy.deepcopy(records)

    old_source_partner_id = copy_records["Items"][0]["sourcePartnerId"]
    deal_ref_id = copy_records["Items"][0]["dealRefId"]
    event_id = copy_records["Items"][0]["eventId"]

    update_event = get_api_gateway_event({})
    update_event["path"] = "/v1/deals/dealRefId/events/eventId"
    update_event["pathParameters"] = {"dealRefId": deal_ref_id, "eventId": event_id}
    update_event["requestContext"] = {"operationName": "patch_event"}
    update_event["body"] = {"sourcePartnerId": "TEST", "eventId": "TEST"}
    update_event["body"] = json.dumps(update_event["body"])

    response = events_lambda.events_handlers(update_event, lambda_context)
    updated_records = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()

    new_deal_ref_id = updated_records["Items"][0]["dealRefId"]
    new_source_partner_id = updated_records["Items"][0]["sourcePartnerId"]
    new_event_id = updated_records["Items"][0]["eventId"]

    assert response["statusCode"] == HTTPStatus.NO_CONTENT
    assert deal_ref_id == new_deal_ref_id
    assert new_source_partner_id == old_source_partner_id
    assert new_event_id != event_id


def test_patch_with_no_existing_resource(
    lambda_context,
    dynamodb,
    monkeypatch,
    mock_dtc_deal,
    mock_dynamodb_helper_deals,
    get_api_gateway_event,
    mock_validate_api_version_invalid_dealrefid,
    generic_invalid_dealref_id,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        events_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version_invalid_dealrefid,
    )
    deal_ref_id = ulid.new().str
    event_id = ulid.new().str

    update_event = get_api_gateway_event({})
    update_event["pathParameters"] = {"dealRefId": deal_ref_id, "eventId": event_id}
    update_event["requestContext"] = {"operationName": "patch_event"}
    update_event["path"] = "/v1/deals/dealRefId/events/eventId"
    update_event["body"] = json.dumps(mock_dtc_deal())

    response = events_lambda.events_handlers(update_event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert json.loads(response["body"]) == generic_invalid_dealref_id


def test_patch_with_missing_path_param_deal_ref_id(
    startup_db_events_helper,
    lambda_context,
    monkeypatch,
    dynamodb,
    mock_dynamodb_helper_deals,
    get_api_gateway_event,
    missing_deal_ref_path_param,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)

    records = startup_db_events_helper
    copy_records = copy.deepcopy(records)

    event_id = copy_records["Items"][0]["eventId"]

    update_event = get_api_gateway_event({})
    update_event["path"] = "/v1/deals/dealRefId/events/eventId"
    update_event["pathParameters"] = {"eventId": event_id}
    update_event["requestContext"] = {"operationName": "patch_event"}
    update_event["body"] = {"eventId": event_id, "sourcePartnerId": "TEST"}

    update_event["body"] = json.dumps(update_event["body"])

    response = events_lambda.events_handlers(update_event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert json.loads(response["body"]) == missing_deal_ref_path_param


def test_patch_with_no_body(
    startup_db_events_helper,
    lambda_context,
    monkeypatch,
    mock_dynamodb_helper_deals,
    get_api_gateway_event,
    missing_body_message,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)

    startup_db_events_helper

    deal_ref_id = ulid.new().str
    event_id = ulid.new().str

    update_event = get_api_gateway_event({})
    update_event["path"] = "/v1/deals/dealRefId/events/eventId"
    update_event["pathParameters"] = {"dealRefId": deal_ref_id, "eventId": event_id}
    update_event["requestContext"] = {"operationName": "patch_event"}

    response = events_lambda.events_handlers(update_event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert json.loads(response["body"]) == missing_body_message


def test_patch_with_extra_body_fields(
    startup_db_events_helper,
    lambda_context,
    dynamodb,
    monkeypatch,
    mock_dynamodb_helper_deals,
    get_api_gateway_event,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)

    records = startup_db_events_helper
    copy_records = copy.deepcopy(records)

    old_source_partner_id = copy_records["Items"][0]["sourcePartnerId"]
    deal_ref_id = copy_records["Items"][0]["dealRefId"]
    event_id = copy_records["Items"][0]["eventId"]

    update_event = get_api_gateway_event({})
    update_event["path"] = "/v1/deals/dealRefId/events/eventId"
    update_event["pathParameters"] = {"dealRefId": deal_ref_id, "eventId": event_id}
    update_event["requestContext"] = {"operationName": "patch_event"}
    update_event["body"] = {"sourcePartnerId": "TEST", "foo": "bar"}
    update_event["body"] = json.dumps(update_event["body"])

    response = events_lambda.events_handlers(update_event, lambda_context)
    updated_records = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()

    new_deal_ref_id = updated_records["Items"][0]["dealRefId"]
    new_source_partner_id = updated_records["Items"][0]["sourcePartnerId"]

    assert response["statusCode"] == HTTPStatus.NO_CONTENT
    assert deal_ref_id == new_deal_ref_id
    assert new_source_partner_id == old_source_partner_id


def test_patch_with_null_values(
    startup_db_events_helper,
    lambda_context,
    dynamodb,
    monkeypatch,
    mock_dynamodb_helper_deals,
    get_api_gateway_event,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)

    records = startup_db_events_helper
    copy_records = copy.deepcopy(records)

    old_source_partner_id = copy_records["Items"][0]["sourcePartnerId"]
    deal_ref_id = copy_records["Items"][0]["dealRefId"]
    event_id = copy_records["Items"][0]["eventId"]

    update_event = get_api_gateway_event({})
    update_event["path"] = "/v1/deals/dealRefId/events/eventId"
    update_event["pathParameters"] = {"dealRefId": deal_ref_id, "eventId": event_id}
    update_event["requestContext"] = {"operationName": "patch_event"}
    update_event["body"] = {"sourcePartnerId": None}
    update_event["body"] = json.dumps(update_event["body"])

    response = events_lambda.events_handlers(update_event, lambda_context)
    updated_records = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()

    new_deal_ref_id = updated_records["Items"][0]["dealRefId"]
    new_source_partner_id = updated_records["Items"][0]["sourcePartnerId"]

    assert response["statusCode"] == HTTPStatus.NO_CONTENT
    assert deal_ref_id == new_deal_ref_id
    assert new_source_partner_id == old_source_partner_id


def test_patch_with_null_deal_ref_id(
    startup_db_events_helper,
    lambda_context,
    monkeypatch,
    mock_dynamodb_helper_deals,
    get_api_gateway_event,
    mock_validate_api_version_invalid_dealrefid,
    missing_deal_ref_path_param,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        events_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version_invalid_dealrefid,
    )
    startup_db_events_helper

    deal_ref_id = None
    event_id = ulid.new().str

    update_event = get_api_gateway_event({})
    update_event["path"] = "/v1/deals/dealRefId/events/eventId"
    update_event["pathParameters"] = {"dealRefId": deal_ref_id, "eventId": event_id}
    update_event["body"] = {"sourcePartnerId": None}
    update_event["body"] = json.dumps(update_event["body"])
    update_event["requestContext"] = {"operationName": "patch_event"}

    response = events_lambda.events_handlers(update_event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert json.loads(response["body"]) == missing_deal_ref_path_param


def test_patch_with_null_deal_component(
    startup_db_events_helper,
    lambda_context,
    monkeypatch,
    mock_dynamodb_helper_deals,
    get_api_gateway_event,
    mock_validate_api_version,
    missing_event_id_path_param,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        events_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version,
    )
    records = startup_db_events_helper

    deal_ref_id = records["Items"][0]["dealRefId"]
    event_id = None

    update_event = get_api_gateway_event({})
    update_event["path"] = "/v1/deals/dealRefId/events/eventId"
    update_event["pathParameters"] = {"dealRefId": deal_ref_id, "eventId": event_id}
    update_event["requestContext"] = {"operationName": "patch_event"}
    update_event["body"] = {"sourcePartnerId": "TEST"}
    update_event["body"] = json.dumps(update_event["body"])

    response = events_lambda.events_handlers(update_event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert json.loads(response["body"]) == missing_event_id_path_param


def test_patch_with_no_deal_component(
    startup_db_events_helper,
    lambda_context,
    monkeypatch,
    mock_dynamodb_helper_deals,
    get_api_gateway_event,
    mock_validate_api_version,
    missing_event_id_path_param,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        events_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version,
    )
    records = startup_db_events_helper

    deal_ref_id = records["Items"][0]["dealRefId"]

    update_event = get_api_gateway_event({})
    update_event["path"] = "/v1/deals/dealRefId/events/eventId"
    update_event["pathParameters"] = {"dealRefId": deal_ref_id}
    update_event["requestContext"] = {"operationName": "patch_event"}
    update_event["body"] = {"sourcePartnerId": "TEST"}
    update_event["body"] = json.dumps(update_event["body"])

    response = events_lambda.events_handlers(update_event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert json.loads(response["body"]) == missing_event_id_path_param


def test_patch_valid_deal_ref_invalid_event_id(
    startup_db_events_helper,
    get_api_gateway_event,
    lambda_context,
    dynamodb,
    monkeypatch,
    mock_dynamodb_helper_deals,
    invalid_event_id,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)

    records = startup_db_events_helper
    copy_records = copy.deepcopy(records)

    deal_ref_id = copy_records["Items"][0]["dealRefId"]
    invalid_event_id_value = "INVALID_EVENT_ID"

    update_event = get_api_gateway_event({})
    update_event["path"] = "/v1/deals/dealRefId/events/eventId"
    update_event["pathParameters"] = {
        "dealRefId": deal_ref_id,
        "eventId": invalid_event_id_value,
    }
    update_event["requestContext"] = {"operationName": "patch_event"}
    update_event["body"] = {"sourcePartnerId": "TEST"}
    update_event["body"] = json.dumps(update_event["body"])

    response = events_lambda.events_handlers(update_event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert json.loads(response["body"]) == invalid_event_id(
        invalid_event_id_value, deal_ref_id
    )
