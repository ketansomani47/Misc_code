# -*- coding: utf-8 -*-
import copy
import json
from http import HTTPStatus

from common.settings import HEALTHCHECK_HEADER_FIELD, HEALTHCHECK_HEADER_VALUE
from events import events_lambda
from utils import db_helper
from utils.db_helper import DynamoDbHelper


def test_get_event(
    lambda_context,
    monkeypatch,
    get_api_gateway_event,
    dr_ulid,
    uuid_newly_generated,
    mock_dynamodb_helper_events,
    add_db_events_record,
    mock_func_decision_payload,
    dr_events_payload,
):
    """
    Test to check successful GET of event related to a deal
    """
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_events)

    db_record = copy.deepcopy(mock_func_decision_payload)
    db_record.pop("payload")
    db_record.update(
        {
            "dealRefId": dr_ulid,
            "dealComponent": f"DTC.EVENTS.{uuid_newly_generated}",
            "eventName": dr_events_payload["eventName"],
            "eventSource": dr_events_payload["eventSource"],
            "eventType": dr_events_payload["eventType"],
        }
    )
    add_db_events_record(**{"Item": db_record})

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/dealRefId/events/eventId"
    event["queryStringParameters"] = {}
    event["pathParameters"] = {"dealRefId": dr_ulid, "eventId": uuid_newly_generated}
    event["requestContext"] = {"operationName": "get_event"}
    response = events_lambda.events_handlers(event, lambda_context)

    body = json.loads(response["body"])[0]

    assert response["statusCode"] == HTTPStatus.OK
    assert body["eventName"] == dr_events_payload["eventName"]
    assert body["eventType"] == dr_events_payload["eventType"]
    assert body["eventSource"] == dr_events_payload["eventSource"]


def test_get_event_no_resources(
    lambda_context,
    monkeypatch,
    get_api_gateway_event,
    dr_ulid,
    uuid_newly_generated,
    mock_dynamodb_helper_events,
    invalid_event_id,
    mock_func_decision_payload,
    dr_events_payload,
):
    """
    Test to check successful GET of event related to a deal
    """
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_events)

    db_record = copy.deepcopy(mock_func_decision_payload)
    db_record.pop("payload")
    db_record.update(
        {
            "dealRefId": dr_ulid,
            "dealComponent": f"DTC.EVENTS.{uuid_newly_generated}",
            "eventName": dr_events_payload["eventName"],
            "eventSource": dr_events_payload["eventSource"],
            "eventType": dr_events_payload["eventType"],
        }
    )
    event_id = uuid_newly_generated
    deal_ref_id = dr_ulid

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/dealRefId/events/eventId"
    event["queryStringParameters"] = {}
    event["pathParameters"] = {"dealRefId": deal_ref_id, "eventId": event_id}
    event["requestContext"] = {"operationName": "get_event"}
    response = events_lambda.events_handlers(event, lambda_context)
    err_msg = json.loads(response["body"])

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert err_msg == invalid_event_id(event_id, deal_ref_id)


def test_get_events_with_missing_deal_ref_id(
    lambda_context,
    monkeypatch,
    get_api_gateway_event,
    uuid_newly_generated,
    mock_get_events_query,
    expected_con_verify_or_sign_app_missing_deal_ref_id,
    mock_query_pk_filter_verify_or_sign_contract,
):

    monkeypatch.setattr(DynamoDbHelper, "query_items", mock_get_events_query)
    monkeypatch.setattr(
        DynamoDbHelper,
        "query_pk_filter",
        mock_query_pk_filter_verify_or_sign_contract,
    )

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/dealRefId/events/eventId"
    event["pathParameters"] = {"eventId": uuid_newly_generated}
    event["requestContext"] = {"operationName": "get_event"}

    response = events_lambda.events_handlers(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(
        expected_con_verify_or_sign_app_missing_deal_ref_id
    )


def test_get_events_with_missing_event_id(
    lambda_context,
    monkeypatch,
    get_api_gateway_event,
    dr_ulid,
    mock_get_events_query,
    missing_event_id_path_param,
    mock_query_pk_filter_verify_or_sign_contract,
):

    monkeypatch.setattr(DynamoDbHelper, "query_items", mock_get_events_query)
    monkeypatch.setattr(
        DynamoDbHelper,
        "query_pk_filter",
        mock_query_pk_filter_verify_or_sign_contract,
    )

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/dealRefId/events/eventId"
    event["pathParameters"] = {"dealRefId": dr_ulid}
    event["requestContext"] = {"operationName": "get_event"}

    response = events_lambda.events_handlers(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(missing_event_id_path_param)


def test_get_health_check(lambda_context):
    event = {
        "headers": {HEALTHCHECK_HEADER_FIELD: HEALTHCHECK_HEADER_VALUE},
        "path": "/v1/deals/dealRefId/events/eventId",
    }

    response = events_lambda.events_handlers(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.OK
    assert response["body"] == json.dumps("Operational")
