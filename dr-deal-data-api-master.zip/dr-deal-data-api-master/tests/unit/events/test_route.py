# -*- coding: utf-8 -*-
import json
from http import HTTPStatus

import pytest
from common import settings
from events import route
from events.settings import EventSource
from events.utils import Env
from key_data import get as get_key_data
from tests.unit.conftest import MockEnv
from utils.db_helper import DynamoDbHelper


class TestEventsRoute:
    def test_empty_body_raises_exception(self, lambda_context):
        with pytest.raises(json.decoder.JSONDecodeError):
            event = {"Records": [{"body": "None"}]}
            route.handler(event=event, context=lambda_context)

    def test_event_route_post_to_virtual_ef(
        self,
        lambda_context,
        monkeypatch,
        mock_event_route_requests,
        mock_func_decision_payload,
        get_sqs_event,
        query_item_vin_source_partner,
    ):
        monkeypatch.setattr(route, "requests", mock_event_route_requests("VIN"))
        monkeypatch.setattr(
            DynamoDbHelper, "query_items", query_item_vin_source_partner
        )
        event = get_sqs_event(mock_func_decision_payload, EventSource.DECISIONS)
        result = route.handler(event=event, context=lambda_context)
        assert result == {"statusCode": HTTPStatus.OK, "body": '"Successfully Sent"'}

    def test_event_route_post_empty_body(
        self, lambda_context, monkeypatch, mock_client_connection_error
    ):
        monkeypatch.setattr(route, "requests", mock_client_connection_error)
        data = {}
        event = {"Records": [{"body": json.dumps(data)}]}
        with pytest.raises(Exception):
            route.handler(event=event, context=lambda_context)

    def test_event_route_post_to_ef_status_failed(
        self,
        lambda_context,
        monkeypatch,
        mock_event_route_request_exceptions,
        mock_ca_event_decision,
        get_sqs_event,
        query_item_mmd_source_partner,
    ):
        monkeypatch.setattr(
            route, "requests", mock_event_route_request_exceptions("MMD")
        )
        monkeypatch.setattr(
            DynamoDbHelper, "query_items", query_item_mmd_source_partner
        )
        data = mock_ca_event_decision
        event = get_sqs_event(data, EventSource.DECISIONS)
        with pytest.raises(BaseException) as exec_info:
            route.handler(event=event, context=lambda_context)
        assert "Failed to submit event to EventsFramework" in str(exec_info)

    def test_event_route_get_to_ef_status_failed(
        self,
        lambda_context,
        monkeypatch,
        mock_event_route_request_exceptions,
        mock_ca_event_decision,
        get_sqs_event,
        query_item_mmd_source_partner,
    ):
        Env.EVENTS_ENDPOINT = MockEnv.EVENTS_ENDPOINT
        monkeypatch.setattr(
            route, "requests", mock_event_route_request_exceptions("MMD")
        )
        monkeypatch.setattr(
            DynamoDbHelper, "query_items", query_item_mmd_source_partner
        )
        data = mock_ca_event_decision
        event = get_sqs_event(data, EventSource.DECISIONS)
        with pytest.raises(BaseException) as exec_info:
            route.handler(event=event, context=lambda_context)
        assert "Failed to submit event to EventsFramework" in str(exec_info)

    def test_event_route_max_retry_error(
        self,
        lambda_context,
        monkeypatch,
        mock_client_connection_error_instance,
        mock_ca_event_decision,
        get_sqs_event,
        query_item_dvm_source_partner,
    ):
        monkeypatch.setattr(route, "requests", mock_client_connection_error_instance)
        monkeypatch.setattr(
            DynamoDbHelper, "query_items", query_item_dvm_source_partner
        )
        data = mock_ca_event_decision
        data["retry_count"] = 6
        event = get_sqs_event(data, EventSource.DECISIONS)
        result = route.handler(event=event, context=lambda_context)
        resp_text = "Exceeded maximum retry count, failed to send application"
        assert result == {"statusCode": HTTPStatus.OK, "body": json.dumps(resp_text)}

    def test_unregistered_event_type(
        self,
        lambda_context,
        monkeypatch,
        mock_event_route_requests,
        mock_ca_event_decision,
        get_sqs_event,
    ):
        monkeypatch.setattr(route, "requests", mock_event_route_requests("DVM"))
        event = get_sqs_event(mock_ca_event_decision, "fooEvent")
        result = route.handler(event=event, context=lambda_context)
        assert result == {
            "statusCode": HTTPStatus.OK,
            "body": '"Unregistered event source:fooEvent, message cannot be routed"',
        }

    def test_event_route_post_to_dd(
        self,
        lambda_context,
        monkeypatch,
        mock_event_route_requests,
        mock_cb_response,
        get_sqs_event,
    ):
        monkeypatch.setattr(route, "requests", mock_event_route_requests("DVM"))
        event = get_sqs_event(mock_cb_response, EventSource.CREDITBUREAUS)
        result = route.handler(event=event, context=lambda_context)
        assert result == {
            "statusCode": HTTPStatus.OK,
            "body": '"Successfully sent to deal data api"',
        }

    def test_event_route_post_to_dd_simulator(
        self,
        lambda_context,
        monkeypatch,
        mock_event_route_requests,
        mock_cb_response,
        get_sqs_event,
    ):
        mock_cb_response["eventTransactionId"] = "01DHHVT56TMC2QKF2FFBMVREBP_TEST"
        monkeypatch.setattr(route, "requests", mock_event_route_requests("DVM"))
        event = get_sqs_event(mock_cb_response, EventSource.CREDITBUREAUS)
        result = route.handler(event=event, context=lambda_context)
        assert result == {
            "statusCode": HTTPStatus.OK,
            "body": '"Successfully sent to deal data api"',
        }

    def test_event_route_post_to_dd_failed(
        self,
        lambda_context,
        monkeypatch,
        mock_event_route_request_exceptions,
        mock_cb_response,
        get_sqs_event,
    ):
        monkeypatch.setattr(
            route, "requests", mock_event_route_request_exceptions("DVM")
        )
        data = mock_cb_response
        event = get_sqs_event(data, EventSource.CREDITBUREAUS)
        with pytest.raises(BaseException) as exec_info:
            route.handler(event=event, context=lambda_context)
        assert f"Failed to submit {EventSource.CREDITBUREAUS} to DealData API" in str(
            exec_info
        )

    def test_event_route_post_to_events(
        self,
        lambda_context,
        monkeypatch,
        mock_event_route_requests,
        mock_func_decision_payload_approved,
        query_item_mmd_source_partner,
        get_sqs_event,
    ):
        Env.EVENTS_ENDPOINT = MockEnv.EVENTS_ENDPOINT
        monkeypatch.setattr(route, "requests", mock_event_route_requests("MMD"))
        monkeypatch.setattr(
            DynamoDbHelper, "query_items", query_item_mmd_source_partner
        )
        event = get_sqs_event(
            mock_func_decision_payload_approved, EventSource.DECISIONS
        )
        result = route.handler(event=event, context=lambda_context)
        assert result == {"statusCode": HTTPStatus.OK, "body": '"Successfully Sent"'}

    def test_event_route_events_object_fields(
        self,
        lambda_context,
        monkeypatch,
        mock_event_route_requests,
        mock_func_decision_payload_approved,
        query_item_mmd_source_partner,
        get_sqs_event,
    ):
        Env.EVENTS_ENDPOINT = MockEnv.EVENTS_ENDPOINT
        monkeypatch.setattr(route, "requests", mock_event_route_requests("MMD"))
        monkeypatch.setattr(
            DynamoDbHelper, "query_items", query_item_mmd_source_partner
        )
        event = get_sqs_event(
            mock_func_decision_payload_approved, EventSource.DECISIONS
        )
        event["path"] = "/v1/deals/key-data/"
        event["queryStringParameters"] = {
            "dealRefId": mock_func_decision_payload_approved["eventTransactionId"]
        }
        json_body = json.dumps(mock_func_decision_payload_approved)
        event["body"] = json_body

        result = get_key_data.key_data_get(event, lambda_context)
        deserialized_body = json.loads(result["body"])
        assert (
            mock_func_decision_payload_approved["eventTransactionId"]
            == deserialized_body[0]["dealRefId"]
        )

        event["data"] = mock_func_decision_payload_approved
        result = route.handler(event=event, context=lambda_context)
        assert result == {"statusCode": HTTPStatus.OK, "body": '"Successfully Sent"'}

    def test_event_route_get_with_dvm(
        self,
        lambda_context,
        monkeypatch,
        mock_event_route_requests,
        mock_ca_event_decision,
        mock_func_decision_payload,
        get_sqs_event,
        query_item_dvm_source_partner,
    ):
        event = get_sqs_event(mock_ca_event_decision, EventSource.DECISIONS)
        event["path"] = "/v1/deals/key-data/"
        event["queryStringParameters"] = {
            "dealRefId": mock_func_decision_payload["eventTransactionId"]
        }
        monkeypatch.setattr(route, "requests", mock_event_route_requests("DVM"))
        monkeypatch.setattr(
            DynamoDbHelper, "query_items", query_item_dvm_source_partner
        )

        json_body = json.dumps(mock_func_decision_payload)
        event["body"] = json_body
        result = get_key_data.key_data_get(event, lambda_context)
        deserialized_body = json.loads(result["body"])
        assert isinstance(deserialized_body, list)
        assert len(deserialized_body) > 0
        assert (
            mock_func_decision_payload["eventTransactionId"]
            == deserialized_body[0]["dealRefId"]
        )
        assert "DVM" == deserialized_body[0]["sourcePartnerId"]

        event["data"] = mock_func_decision_payload
        response = route.handler(event, lambda_context)
        assert response == {"statusCode": HTTPStatus.OK, "body": '"Successfully Sent"'}

    def test_event_route_get_with_other_partner_id(
        self,
        lambda_context,
        monkeypatch,
        mock_event_route_requests,
        mock_func_decision_payload_vin,
        get_sqs_event,
        query_item_vin_source_partner,
    ):
        Env.EVENTS_ENDPOINT = MockEnv.EVENTS_ENDPOINT
        event = get_sqs_event(mock_func_decision_payload_vin, EventSource.DECISIONS)
        event["path"] = "/v1/deals/key-data/"
        event["queryStringParameters"] = {
            "dealRefId": mock_func_decision_payload_vin["eventTransactionId"]
        }
        monkeypatch.setattr(route, "requests", mock_event_route_requests("VIN"))
        monkeypatch.setattr(
            DynamoDbHelper, "query_items", query_item_vin_source_partner
        )

        json_body = json.dumps(mock_func_decision_payload_vin)
        event["body"] = json_body
        result = get_key_data.key_data_get(event, lambda_context)
        deserialized_body = json.loads(result["body"])
        assert (
            mock_func_decision_payload_vin["eventTransactionId"]
            == deserialized_body[0]["dealRefId"]
        )
        assert "DVM" != deserialized_body[0]["sourcePartnerId"]

        event["data"] = mock_func_decision_payload_vin
        response = route.handler(event, lambda_context)
        assert response == {"statusCode": HTTPStatus.OK, "body": '"Successfully Sent"'}

    def test_event_route_get_with_empty_response_from_key_data(
        self,
        lambda_context,
        monkeypatch,
        mock_event_route_requests,
        mock_func_decision_payload_vin,
        get_sqs_event,
        db_query_empty,
    ):
        Env.EVENTS_ENDPOINT = MockEnv.EVENTS_ENDPOINT
        event = get_sqs_event(mock_func_decision_payload_vin, EventSource.DECISIONS)
        event["path"] = "/v1/deals/key-data/"
        event["queryStringParameters"] = {"dealRefId": "0000000000000"}
        monkeypatch.setattr(route, "requests", mock_event_route_requests("VIN"))
        monkeypatch.setattr(DynamoDbHelper, "query_items", db_query_empty)

        json_body = json.dumps(mock_func_decision_payload_vin)
        event["body"] = json_body
        result = get_key_data.key_data_get(event, lambda_context)
        deserialized_body = json.loads(result["body"])

        assert isinstance(deserialized_body, list)
        assert 0 == len(deserialized_body)

        event["data"] = mock_func_decision_payload_vin

        with pytest.raises(Exception) as error:
            route.handler(event=event, context=lambda_context)
            assert str(error) == "Exception: Failed to get key data record"

    def test_event_route_post_to_events_with_empty_body(
        self,
        lambda_context,
        monkeypatch,
        mock_ideal_event_decision_empty,
        get_sqs_event,
        mock_client_connection_error,
    ):
        monkeypatch.setattr(route, "requests", mock_client_connection_error)
        data = {}
        event = {"Records": [{"body": json.dumps(data)}]}
        with pytest.raises(Exception) as exec_info:
            route.handler(event=event, context=lambda_context)
        assert "No record or body found in AWS event payload" in str(exec_info)

    def test_event_route_post_to_events_declined(
        self,
        lambda_context,
        monkeypatch,
        mock_requests,
        mock_func_decision_payload_declined,
        get_sqs_event,
    ):
        monkeypatch.setattr(route, "requests", mock_func_decision_payload_declined)
        event = get_sqs_event(
            mock_func_decision_payload_declined, EventSource.DECISIONS
        )
        body = json.loads(event["Records"][0]["body"])
        declined = body["payload"]["approvalStatus"]
        assert declined == "Declined"

    def test_event_route_deal_ref_id_endswith_test(
        self,
        lambda_context,
        monkeypatch,
        mock_requests,
        mock_func_decision_payload,
        get_sqs_event,
    ):
        monkeypatch.setattr(route, "requests", mock_func_decision_payload)
        event = get_sqs_event(mock_func_decision_payload, EventSource.DECISIONS)
        body = json.loads(event["Records"][0]["body"])
        assert body.get("eventTransactionId").endswith(
            "_TEST"
        ) == "01DHHVT56TMC2QKF2FFBMVREBP_TEST".endswith("_TEST")

    def test_event_route_headers_and_endpoint(
        self, mock_func_decision_payload_declined, mock_func_decision_headers
    ):
        Env.EVENTS_ENDPOINT = MockEnv.EVENTS_ENDPOINT
        corr_id = "12345abc-abc1-2def-56ef-000000000000"
        dd_headers = route.get_deal_data_headers(correlation_id=corr_id)
        assert mock_func_decision_headers == dd_headers
        deal_ref_id = mock_func_decision_payload_declined.get("eventTransactionId")
        endpoint = (
            settings.SIMULATOR_POST
            if deal_ref_id.endswith("_TEST")
            else MockEnv.EVENTS_ENDPOINT
        )
        assert endpoint == MockEnv.EVENTS_ENDPOINT

    def test_event_route_post_to_events_approved(
        self,
        lambda_context,
        monkeypatch,
        mock_requests,
        mock_func_decision_payload_approved,
        get_sqs_event,
    ):
        monkeypatch.setattr(route, "requests", mock_requests)
        monkeypatch.setattr(route, "requests", mock_func_decision_payload_approved)
        event = get_sqs_event(
            mock_func_decision_payload_approved, EventSource.DECISIONS
        )
        body = json.loads(event["Records"][0]["body"])
        approved = body["payload"]["approvalStatus"]
        assert approved == "Approved"

    def test_event_resolve_name(self):
        result = route.EVENT_NAME_MAPPING["Approved"]
        assert result == "CreditDecisions:Approved"
        result = route.EVENT_NAME_MAPPING["Declined"]
        assert result == "CreditDecisions:Declined"
        result = route.EVENT_NAME_MAPPING["AppSubmitted"]
        assert result == "CreditApplications:Submitted"

    def test_event_resolve_type(self):
        result = route.EVENT_TYPE_MAPPING["Approved"]
        assert result == "ideal:CreditDecisions"
        result = route.EVENT_TYPE_MAPPING["Declined"]
        assert result == "ideal:CreditDecisions"
        result = route.EVENT_TYPE_MAPPING["AppSubmitted"]
        assert result == "ideal:CreditApplications"
