# -*- coding: utf-8 -*-
import json
from http import HTTPStatus

import pytest
from common.settings import (
    CORRELATION_ID_HEADER_KEY,
    HEALTHCHECK_HEADER_FIELD,
    HEALTHCHECK_HEADER_VALUE,
    ErrorMsgs,
)
from events import consumer
from utils.db_helper import DynamoDbHelper
from utils.exceptions import BadRequestError


def test_post_successful(
    mock_ca_event_decision,
    sqs,
    get_api_gateway_event,
    uuid_provided,
    response_header,
    lambda_context,
):
    correlation_id = uuid_provided
    mock_ca_event_decision.pop("eventId")
    event = get_api_gateway_event(mock_ca_event_decision)
    expected_headers = response_header(correlation_id)
    return_body = {"status": "SUCCESS"}
    expected = {
        "headers": expected_headers,
        "statusCode": HTTPStatus.OK,
        "body": json.dumps(return_body),
    }
    actual = consumer.post(event, lambda_context)
    assert actual == expected


def test_post_without_corelation_id(
    mock_ca_event_decision,
    sqs,
    uuid_newly_generated,
    get_api_gateway_event,
    response_header,
    lambda_context,
):
    correlation_id = uuid_newly_generated
    event = get_api_gateway_event(mock_ca_event_decision)
    event.pop("headers")
    expected_headers = response_header(correlation_id)
    return_body = {"status": "SUCCESS"}
    expected = {
        "headers": expected_headers,
        "statusCode": HTTPStatus.OK,
        "body": json.dumps(return_body),
    }
    actual = consumer.post(event, lambda_context)
    assert actual == expected


def test_post_json_decoder_error(
    sqs, get_api_gateway_invalid_event, uuid_provided, response_header, lambda_context
):
    event = get_api_gateway_invalid_event
    response = consumer.post(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["headers"] == response_header(uuid_provided)


def test_post_health_check(lambda_context):
    event = {"headers": {HEALTHCHECK_HEADER_FIELD: HEALTHCHECK_HEADER_VALUE}}
    response = consumer.post(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps("Operational")


def test_post_empty_body_error(
    sqs, uuid_newly_generated, response_header, lambda_context
):
    event = {"headers": {CORRELATION_ID_HEADER_KEY: uuid_newly_generated}}
    response = consumer.post(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.INTERNAL_SERVER_ERROR
    assert response["body"] == json.dumps({"message": ErrorMsgs.missing_body_aws_event})
    assert response["headers"] == response_header(uuid_newly_generated)


def test_reprocess_event(
    monkeypatch,
    lambda_context,
    mock_dr_utils,
    mock_get_event_deal,
    uuid_newly_generated,
):
    event = {
        "headers": {CORRELATION_ID_HEADER_KEY: uuid_newly_generated},
        "pathParameters": {
            "eventTransactionId": "TEST_1234567890",
            "dealComponnt": "AHC.DECISION",
        },
        "path": "/v1/",
    }
    monkeypatch.setattr(consumer, "get_event_deal", mock_get_event_deal)
    response = consumer.reprocess_handler(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.NO_CONTENT


def test_reprocess_event_with_no_records(
    monkeypatch, lambda_context, mock_query_items_empty, uuid_newly_generated
):
    monkeypatch.setattr(DynamoDbHelper, "query_items", mock_query_items_empty)
    event = {
        "headers": {CORRELATION_ID_HEADER_KEY: uuid_newly_generated},
        "pathParameters": {
            "eventTransactionId": "TEST_1234567890000",
            "dealComponent": "AHC.DECISION",
        },
        "path": "/v1/",
    }
    response = consumer.reprocess_handler(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST


def test_reprocess_event_handle_exception(
    monkeypatch,
    lambda_context,
    mock_get_event_deal_raises_exception,
    uuid_newly_generated,
):
    monkeypatch.setattr(
        consumer, "get_event_deal", mock_get_event_deal_raises_exception
    )
    event = {
        "headers": {CORRELATION_ID_HEADER_KEY: uuid_newly_generated},
        "pathParameters": {
            "eventTransactionId": "TEST_1234567890000",
            "dealComponent": "AHC.DECISION",
        },
        "path": "/v1/",
    }
    response = consumer.reprocess_handler(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.INTERNAL_SERVER_ERROR


def test_get_event_deal_with_data(
    monkeypatch,
    lambda_context,
    mock_query_items,
    mock_ca_event_decision,
    uuid_newly_generated,
):
    monkeypatch.setattr(DynamoDbHelper, "query_items", mock_query_items)
    event_transaction_id, deal_component = get_event_deal_data(uuid_newly_generated)
    actual = consumer.get_event_deal(event_transaction_id, deal_component)
    expected = mock_ca_event_decision
    assert actual == expected, "Event-Deal get Query Items result failed."


def test_get_event_deal_with_empty_data(
    monkeypatch, lambda_context, mock_query_items_empty, uuid_newly_generated
):
    monkeypatch.setattr(DynamoDbHelper, "query_items", mock_query_items_empty)
    event_transaction_id, deal_component = get_event_deal_data(uuid_newly_generated)
    with pytest.raises(BadRequestError):
        consumer.get_event_deal(event_transaction_id, deal_component)


def get_event_deal_data(uuid_newly_generated):
    event_transaction_id = "TEST_1234567890000"
    deal_component = "AHC.DECISION"
    return event_transaction_id, deal_component
