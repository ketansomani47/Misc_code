# -*- coding: utf-8 -*-
import json
from http import HTTPStatus

import ulid
from common.settings import HEALTHCHECK_HEADER_FIELD, HEALTHCHECK_HEADER_VALUE
from events import events_lambda
from utils import db_helper


def test_post_lender_decision(
    dr_ulid,
    dynamodb,
    generate_decision_record,
    get_api_gateway_event_post_lender_decision,
    lambda_context,
    monkeypatch,
    mock_dynamodb_helper_deals,
    mock_validate_reference_ids,
    mock_validate_api_version,
    add_db_events_record,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        events_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version,
    )
    monkeypatch.setattr(
        events_lambda.ExistingDealValidator,
        "validate_reference_ids",
        mock_validate_reference_ids,
    )
    add_db_events_record(**{"dealRefId": ulid.new().str, "dealComponent": "DTC.DEAL"})

    credit_app_id = "01E3AK55DCB3PBD783DKS6XHNV"

    event = get_api_gateway_event_post_lender_decision(
        body=generate_decision_record(), credit_app_id=credit_app_id
    )
    response = events_lambda.events_handlers(event, lambda_context)

    records = dynamodb.Table("deals").scan()
    assert response["statusCode"] == HTTPStatus.CREATED
    assert json.loads(response["body"])["message"] == "Lender decision posted"
    assert len(records["Items"]) == 2
    assert records["Items"][1]["dealRefId"] == dr_ulid
    assert records["Items"][0]["dealComponent"] == f"CD.DT6.{credit_app_id}"


def test_post_lender_decision_invalid_ref_id(
    dr_ulid,
    dynamodb,
    generate_decision_record,
    get_api_gateway_event_post_lender_decision,
    lambda_context,
    monkeypatch,
    mock_dynamodb_helper_deals,
    mock_validate_api_version_invalid_dealrefid,
    generic_invalid_dealref_id,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        events_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version_invalid_dealrefid,
    )

    event = get_api_gateway_event_post_lender_decision(body=generate_decision_record())
    response = events_lambda.events_handlers(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert json.loads(response["body"]) == generic_invalid_dealref_id


def test_post_lender_decision_with_missing_path_param_deal_ref_id(
    lambda_context,
    generate_decision_record,
    monkeypatch,
    mock_dynamodb_helper_deals,
    get_api_gateway_event_post_lender_decision,
    missing_deal_ref_path_param,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)

    event = get_api_gateway_event_post_lender_decision(
        body=generate_decision_record(),
    )
    event["pathParameters"]["dealRefId"] = None

    response = events_lambda.events_handlers(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert json.loads(response["body"]) == missing_deal_ref_path_param


def test_post_lender_decision_with_missing_path_param_credit_app_id(
    dr_ulid,
    dynamodb,
    generate_decision_record,
    get_api_gateway_event_post_lender_decision,
    lambda_context,
    monkeypatch,
    mock_dynamodb_helper_deals,
    mock_validate_api_version,
    missing_credit_app_id_path_param,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        events_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version,
    )

    event = get_api_gateway_event_post_lender_decision(body=generate_decision_record())
    event["pathParameters"]["creditAppId"] = None
    response = events_lambda.events_handlers(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert json.loads(response["body"]) == missing_credit_app_id_path_param


def test_post_lender_decision_with_missing_lender_id(
    lambda_context,
    generate_decision_record,
    monkeypatch,
    mock_dynamodb_helper_deals,
    get_api_gateway_event_post_lender_decision,
    missing_lender_id,
    add_db_events_record,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    add_db_events_record(**{"dealRefId": ulid.new().str, "dealComponent": "DTC.DEAL"})

    credit_app_id = "01E3AK55DCB3PBD783DKS6XHNV"

    event = get_api_gateway_event_post_lender_decision(
        body=generate_decision_record(), credit_app_id=credit_app_id
    )
    body = json.loads(event["body"])
    body.pop("lenderId")
    event.update({"body": json.dumps(body)})
    response = events_lambda.events_handlers(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert json.loads(response["body"]) == missing_lender_id


def test_post_lender_decision_missing_all_path_param(
    lambda_context,
    generate_decision_record,
    monkeypatch,
    mock_dynamodb_helper_deals,
    get_api_gateway_event_post_lender_decision,
    post_lender_decision_missing_all_path_param,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)

    event = get_api_gateway_event_post_lender_decision(
        body=generate_decision_record(),
    )
    event["pathParameters"]["dealRefId"] = None
    event["pathParameters"]["creditAppId"] = None
    event["pathParameters"]["lenderId"] = None

    response = events_lambda.events_handlers(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert json.loads(response["body"]) == post_lender_decision_missing_all_path_param


def test_post_lender_decision_with_no_body(
    get_api_gateway_event_post_lender_decision,
    lambda_context,
    monkeypatch,
    mock_dynamodb_helper_deals,
    missing_body_message,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)

    event = get_api_gateway_event_post_lender_decision(
        body=None,
    )

    response = events_lambda.events_handlers(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert json.loads(response["body"]) == missing_body_message


def test_get_health_check(lambda_context):
    event = {
        "headers": {HEALTHCHECK_HEADER_FIELD: HEALTHCHECK_HEADER_VALUE},
        "path": "/v1/deals/dealRefId/events/",
    }

    response = events_lambda.events_handlers(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.OK
    assert response["body"] == json.dumps("Operational")


def test_post_lender_decision_no_deal_association(
    dynamodb,
    generate_decision_record,
    get_api_gateway_event_post_lender_decision,
    lambda_context,
    monkeypatch,
    mock_dynamodb_helper_deals,
    mock_validate_api_version_invalid_dealrefid,
    generic_invalid_dealref_id,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        events_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version_invalid_dealrefid,
    )

    event = get_api_gateway_event_post_lender_decision(generate_decision_record())

    response = events_lambda.events_handlers(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert json.loads(response["body"]) == generic_invalid_dealref_id


def test_post_lender_decision_invalid_credit_app_id(
    dr_ulid,
    dynamodb,
    generate_decision_record,
    get_api_gateway_event_post_lender_decision,
    lambda_context,
    monkeypatch,
    mock_dynamodb_helper_deals,
    mock_validate_api_version,
    invalid_credit_app_id_error,
):
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        events_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version,
    )

    event = get_api_gateway_event_post_lender_decision(body=generate_decision_record())
    event["pathParameters"]["creditAppId"] = "invalid-creditapp-id"
    response = events_lambda.events_handlers(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert json.loads(response["body"]) == invalid_credit_app_id_error
