# -*- coding: utf-8 -*-
import json
from http import HTTPStatus

from common.settings import HEALTHCHECK_HEADER_FIELD, HEALTHCHECK_HEADER_VALUE
from events import events_lambda
from utils.db_helper import DynamoDbHelper


def test_get_events_no_filters(
    lambda_context,
    monkeypatch,
    get_api_gateway_event,
    dr_ulid,
    dr_events_payload,
    mock_get_events_query,
):
    """
    Test to check successful GET of events related to a deal
    """
    monkeypatch.setattr(DynamoDbHelper, "query_items", mock_get_events_query)

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/dealRefId/events/"
    event["queryStringParameters"] = {}
    event["pathParameters"] = {"dealRefId": dr_ulid}
    event["requestContext"] = {"operationName": "get_events"}
    response = events_lambda.events_handlers(event, lambda_context)

    body = json.loads(response["body"])[0]

    assert response["statusCode"] == HTTPStatus.OK
    assert body["eventName"] == dr_events_payload["eventName"]
    assert body["eventType"] == dr_events_payload["eventType"]
    assert body["eventSource"] == dr_events_payload["eventSource"]


def test_get_events_with_filters(
    lambda_context,
    monkeypatch,
    get_api_gateway_event,
    dr_ulid,
    dr_events_payload,
    mock_get_events_query,
):
    """
    Test to check successful GET of events related to a deal with filters
    """
    monkeypatch.setattr(DynamoDbHelper, "query_items", mock_get_events_query)

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/dealRefId/events/"
    event["queryStringParameters"] = {
        "eventName": dr_events_payload["eventName"],
        "eventType": dr_events_payload["eventType"],
    }
    event["pathParameters"] = {"dealRefId": dr_ulid}
    event["requestContext"] = {"operationName": "get_events"}

    response = events_lambda.events_handlers(event, lambda_context)
    body = json.loads(response["body"])[0]

    assert response["statusCode"] == HTTPStatus.OK
    assert body["eventName"] == dr_events_payload["eventName"]
    assert body["eventType"] == dr_events_payload["eventType"]
    assert body["eventSource"] == dr_events_payload["eventSource"]


def test_get_events_with_unsupported_filters(
    lambda_context,
    monkeypatch,
    get_api_gateway_event,
    dr_ulid,
    dr_events_payload,
    mock_get_events_query,
    expected_invalid_query_params_get_events,
):
    monkeypatch.setattr(DynamoDbHelper, "query_items", mock_get_events_query)

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/dealRefId/events/"
    event["queryStringParameters"] = {
        "foo": dr_events_payload["eventName"],
        "bar": dr_events_payload["eventType"],
    }
    event["pathParameters"] = {"dealRefId": dr_ulid}
    event["requestContext"] = {"operationName": "get_events"}

    response = events_lambda.events_handlers(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(expected_invalid_query_params_get_events)


def test_get_events_with_missing_deal_ref_id(
    lambda_context,
    monkeypatch,
    get_api_gateway_event,
    dr_events_payload,
    mock_get_events_query,
    expected_con_verify_or_sign_app_missing_deal_ref_id,
    mock_query_pk_filter_verify_or_sign_contract,
):

    monkeypatch.setattr(DynamoDbHelper, "query_items", mock_get_events_query)
    monkeypatch.setattr(
        DynamoDbHelper,
        "query_pk_filter",
        mock_query_pk_filter_verify_or_sign_contract,
    )

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/dealRefId/events/"
    event["queryStringParameters"] = {
        "eventName": dr_events_payload["eventName"],
        "eventType": dr_events_payload["eventType"],
    }
    event["requestContext"] = {"operationName": "get_events"}

    response = events_lambda.events_handlers(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(
        expected_con_verify_or_sign_app_missing_deal_ref_id
    )


def test_get_events_empty_response(
    lambda_context,
    monkeypatch,
    dr_ulid,
    get_api_gateway_event,
    dr_events_payload,
    mock_get_events_query_response,
    mock_query_pk_filter_verify_or_sign_contract,
    expected_con_verify_or_sign_app_missing_deal_ref_id,
):

    monkeypatch.setattr(DynamoDbHelper, "query_items", mock_get_events_query_response)

    event = get_api_gateway_event({})
    event["path"] = "/v1/deals/dealRefId/events/"
    event["pathParameters"] = {"dealRefId": dr_ulid}
    event["queryStringParameters"] = {
        "eventName": dr_events_payload["eventName"],
        "eventType": dr_events_payload["eventType"],
    }
    event["requestContext"] = {"operationName": "get_events"}

    response = events_lambda.events_handlers(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.NOT_FOUND
    assert json.loads(response["body"]) == []


def test_get_health_check(lambda_context):
    event = {
        "headers": {HEALTHCHECK_HEADER_FIELD: HEALTHCHECK_HEADER_VALUE},
        "path": "/v1/deals/dealRefId/events/",
    }

    response = events_lambda.events_handlers(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.OK
    assert response["body"] == json.dumps("Operational")
