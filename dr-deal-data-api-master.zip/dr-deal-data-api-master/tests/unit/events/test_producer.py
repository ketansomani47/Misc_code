# -*- coding: utf-8 -*-
import json
from http import HTTPStatus

import pytest
from common.settings import ErrorMsgs
from events.producer import add_deal_info, get_event_timestamp, handler
from events.settings import EventSource
from utils.common import convert_empty_strings_to_none


def test_timestamp_lenght_for_milliseconds():
    actual_timestamp = get_event_timestamp()
    assert len(str(actual_timestamp)) == 13


def test_producer_handler(
    lambda_context, dynamodb, mock_ca_event_decision, get_sqs_event
):
    event = get_sqs_event(mock_ca_event_decision, EventSource.DECISIONS)
    expected = {
        "statusCode": HTTPStatus.OK,
        "body": json.dumps(
            {
                "description": "Decision stored successfully.",
                "dealRefId": mock_ca_event_decision.get("eventTransactionId"),
            }
        ),
    }
    actual = handler(event=event, context=lambda_context)
    assert actual == expected


def test_add_deal_info(mock_ca_event_decision, uuid_provided):
    actual = add_deal_info(event_data=mock_ca_event_decision, deal_ref_id=uuid_provided)
    mock_ca_event_decision.update(
        {"dealRefId": uuid_provided, "dealComponent": "BOA.DECISION"}
    )
    assert mock_ca_event_decision == actual

    actual = add_deal_info(
        event_data=mock_ca_event_decision,
        deal_ref_id=uuid_provided,
        include_timestamp=True,
    )
    mock_ca_event_decision.update(
        {
            "dealRefId": f"{uuid_provided}.DECISION",
            "dealComponent": "BOA.DECISION.1530645397327",
        }
    )

    assert mock_ca_event_decision == actual


def test_convert_empty_strings_to_none(mock_ca_event_decision):
    unexpected = mock_ca_event_decision.get("payload").get("stipulations")
    expected = [None, "Stipulation2"]
    actual_data = convert_empty_strings_to_none(mock_ca_event_decision)
    assert actual_data.get("payload").get("stipulations") != unexpected
    assert actual_data.get("payload").get("stipulations") == expected


def test_producer_empty_body_error(sqs, lambda_context):
    event = {"Records": [{"body": json.dumps({})}]}
    with pytest.raises(Exception) as e:
        handler(event, lambda_context)
        assert str(e) == ErrorMsgs.missing_body_aws_event


def test_empty_body_raises_json_decode_error(sqs, lambda_context):
    event = {"Records": [{"body": "None"}]}
    with pytest.raises(json.decoder.JSONDecodeError):
        handler(event=event, context=lambda_context)
