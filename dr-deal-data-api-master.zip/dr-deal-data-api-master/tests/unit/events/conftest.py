# -*- coding: utf-8 -*-
import pytest
import ulid
from boto3.dynamodb import conditions
from common import deal_consumer, settings
from requests.exceptions import ConnectTimeout
from utils.db_helper import DynamoDbHelper


class MockRequest:
    def post(self, *args, **kwargs):
        class MockResponse:
            text = ""
            status_code = 201

        mock_response_text = MockResponse()
        return mock_response_text


@pytest.fixture()
def mock_requests():
    resource = MockRequest()
    return resource


class MockEventRouteRequest:
    def __init__(self, source_partner_id):
        self.source_partner_id = source_partner_id

    def post(self, *args, **kwargs):
        class MockResponse:
            if self.source_partner_id == "DVM":
                text = {"dealRefId": "01DHHVT56TMC2QKF2FFBMVREBP_TEST"}
                status_code = 201
            elif self.source_partner_id == "VIN":
                text = {"dealRefId": "01DHHVT56TMC2GKF2FFBMVREBP_TEST"}
                status_code = 201
            elif self.source_partner_id == "MMD":
                text = {"dealRefId": "01DHHVT56TMC2QKF2FFBMVRFDP_TEST"}
                status_code = 201
            elif self.source_partner_id == "DTS":
                text = {"dealRefId": "01DHHVT56TMC2GGF2FFBMVRFDP_TEST"}
                status_code = 201

            def json(self):
                return self.text

        mock_response_text = MockResponse()
        return mock_response_text

    def get(self, *args, **kwargs):
        class MockResponse:
            if self.source_partner_id == "DVM":
                text = {"count": 0, "settings": []}
                status_code = 404
            elif self.source_partner_id == "VIN":
                text = {"count": 0, "settings": []}
                status_code = 404
            elif self.source_partner_id == "MMD":
                text = MMD
                status_code = 200
            elif self.source_partner_id == "DTS":
                text = DTS
                status_code = 200

            def json(self):
                return self.text

        mock_response_text = MockResponse()
        return mock_response_text


@pytest.fixture()
def mock_event_route_requests():
    def wrapper(source_partner_id):
        resource = MockEventRouteRequest(source_partner_id)
        return resource

    return wrapper


class MockConnectionException(MockRequest):
    def post(self, *args, **kwargs):
        raise ConnectTimeout

    def get(self, *args, **kwargs):
        class MockResponse:
            text = {"count": 0, "settings": []}
            status_code = 404

            def json(self):
                return self.text

        mock_response_text = MockResponse()
        return mock_response_text


class MockClientTimeoutError(MockRequest):
    def post(self, *args, **kwargs):
        raise TimeoutError


class MockException(MockRequest):
    def post(self, *args, **kwargs):
        raise Exception("Failed to Submit. StatusCode: 400")


class MockExceptionStatusFailed:
    def post(self, *args, **kwargs):
        class MockResponse:
            text = ""
            status_code = 400

        mock_response_text = MockResponse()
        return mock_response_text


class MockEventRouteKeyErrorExceptionStatusFailed:
    def post(self, *args, **kwargs):
        raise Exception("payload")

    def get(self, *args, **kwargs):
        class MockResponse:
            text = {"count": 0, "settings": []}
            status_code = 404

            def json(self):
                return self.text

        mock_response_text = MockResponse()
        return mock_response_text


@pytest.fixture
def mock_client_connection_error():
    return MockConnectionException


@pytest.fixture
def mock_client_connection_error_instance():
    resource = MockConnectionException()
    return resource


@pytest.fixture
def mock_exception():
    return MockException()


@pytest.fixture
def mock_exception_status_failed():
    return MockExceptionStatusFailed


@pytest.fixture
def mock_event_route_key_error_exception_status_failed():
    resource = MockEventRouteKeyErrorExceptionStatusFailed()
    return resource


@pytest.fixture()
def mock_query_items_events(mock_get_events_query, *args, **kwargs):
    def mock_query(*args, **kwargs):
        index = kwargs.get("index")
        if index:
            # validate_deal_fields
            return [
                {
                    "dealRefId": "01FRM6T1BX99CZBEX5MYG2Q16V",
                    "dealComponent": "DTC.DEAL",
                    "leadRefId": "01FRM6T1BXH0A0A04X5BVH87XA",
                    "sourcePartnerId": "DWR",
                    "sourcePartnerDealerId": "1441000",
                    "targetPlatforms": [{"partyId": "1441000", "id": "DTC"}],
                    "customerType": "Individual",
                    "dealRefIdFD": "160000010006191534",
                    "financeMethod": "Retail",
                }
            ]
        else:
            # get_events
            return mock_get_events_query()

    return mock_query


class MockEventRouteRequestException:
    def __init__(self, source_partner_id):
        self.source_partner_id = source_partner_id

    def post(self, *args, **kwargs):
        class MockResponse:
            if self.source_partner_id == "DVM":
                text = {"dealRefId": ""}
                status_code = 400
            elif self.source_partner_id == "VIN":
                text = {"dealRefId": ""}
                status_code = 400
            elif self.source_partner_id == "MMD":
                text = {"dealRefId": ""}
                status_code = 400

            def json(self):
                return self.text

        mock_response_text = MockResponse()
        return mock_response_text

    def get(self, *args, **kwargs):
        class MockResponse:
            if self.source_partner_id == "DVM":
                text = {"count": 0, "settings": []}
                status_code = 404
            elif self.source_partner_id == "VIN":
                text = {"count": 0, "settings": []}
                status_code = 404
            elif self.source_partner_id == "MMD":
                text = MMD
                status_code = 200

            def json(self):
                return self.text

        mock_response_text = MockResponse()
        return mock_response_text


@pytest.fixture()
def mock_event_route_request_exceptions():
    def wrapper(source_partner_id):
        resource = MockEventRouteRequestException(source_partner_id)
        return resource

    return wrapper


@pytest.fixture()
def mock_get_event_deal(mock_ca_event_decision):
    """
    DB query response.
    """

    def wrapper(*args, **kwargs):
        return mock_ca_event_decision

    return wrapper


@pytest.fixture()
def mock_get_event_deal_raises_exception(mock_exception):
    def wrapper(*args, **kwargs):
        raise mock_exception

    return wrapper


@pytest.fixture()
def mock_query_items(mock_ca_event_decision):
    def query_items(*args, **kwargs):
        return [mock_ca_event_decision]

    return query_items


@pytest.fixture()
def mock_func_decision_payload():
    """
    Test response
    :return: test functional credit app decision event response.
    """
    return {
        "eventVersion": "1.1",
        "eventId": "d3aa88e2-c754-41e0-8ba6-4198a34aa0a2",
        "eventTime": "2018-07-03T19:16:37.327Z",
        "eventName": "Deal:CreditDecisionResponse",
        "eventDetailHref": "https://fni-api.dealertrack.com/shopper/decisions/lender-id/CMB/d3aa88e2-c754-41e0-8ba6-4198a34aa0a2/?type=credit",
        "eventSource": "fni:decisions",
        "eventTransactionId": "01DHHVT56TMC2QKF2FFBMVREBP_TEST",
        "eventEntityId": "104334",
        "payloadSchema": "DealDecisions/v1",
        "payload": {
            "approvalStatus": "Approved",
            "approvedAmount": 23310.99,
            "approvedRate": 2.99,
            "approvedTerm": 36,
            "lenderId": "BOA",
            "lenderName": "Bank of America",
            "tier": "Gold",
            "stipulations": ["Stipulation1", "Stipulation2", {"test3": "Stipulation3"}],
            "monthlyPayment": 530.88,
            "lenderMoneyFactor": 0.00209,
            "customerMoneyFactor": 0.00209,
            "downPayment": 530.88,
            "financeMethod": "Lease",
        },
    }


@pytest.fixture()
def mock_cb_response():
    """
    Test response
    :return: test credit app decision event response.
    """
    return {
        "dealRefId": "01DR12345ABCDE12345ABCDEFG",
        "eventVersion": "1.1",
        "eventId": "01DHHVT56TMC2QKF2FFBMVREBP",
        "eventTime": "2018-07-03T19:16:37.327Z",
        "eventType": "dr:CreditBureauResponse",
        "eventName": "deal:CreditBureauResponse",
        "eventDetailHref": "https://fni-api.dealertrack.com/shopper/decisions/lender-id/CMB/d3aa88e2-c754-41e0-8ba6-4198a34aa0a2/?type=credit",
        "eventSource": "dr:CreditBureaus",
        "eventTransactionId": "01DHHVT56TMC2QKF2FFBMVREBP",
        "eventEntityId": "104334",
        "payloadSchema": "DealDecisions/v1",
        "payload": {
            "sourcePartnerId": "VIN",
            "sourcePartnerDealerId": "123456789",
            "targetPlatforms": [{"id": "VIN", "partyId": "123456789"}],
            "financeMethod": "Lease",
        },
    }


MMD = {
    "count": 1,
    "settings": [
        {
            "otherPartnerSubscriptions": {},
            "subfeature_custom_key": "SUB.MMD",
            "destinationType": {
                "notificationType": "HTTP Callback URL",
                "clientID": "mmddemo",
                "secret": "credsubmitsecret",
                "partnerURL": "https://secure-qa.accelerate.dealer.com/api/creditDecision",
            },
            "feature": "EVENTS",
            ".PARTNER_ID": "MMD",
            "lenderSubscriptions": {"subscribeToLenders": False},
            "eventSources": {
                "fni": {
                    "CreditApplicationsEvents": ["NotSubmitted", "Submitted"],
                    "CreditDecisionsEvents": ["ConditionallyApproved", "Declined"],
                    "CreditDecisions": True,
                    "CreditApplications": True,
                },
                "ideal": {
                    "CreditDecisions": True,
                    "CreditDecisionsEvents": ["Approved", "Declined"],
                },
                "dr": {"Contracting": False},
                "unifi": {
                    "CreditDecisionsEvents": ["Expired", "Pending"],
                    "Compliance": False,
                    "CreditDecisions": True,
                    "Contracting": False,
                    "ContractingDecisions": False,
                    "DealJacket": True,
                    "CreditApplications": False,
                },
            },
        }
    ],
}


DTS = {
    "count": 1,
    "settings": [
        {
            "otherPartnerSubscriptions": {"subscribeToPartners": False},
            "subfeature_custom_key": "SUB.DTS",
            "destinationType": {
                "partnerURL": "https://simulation-qa.drsvcnp.aws.dealertrack.com/v1/virtualpartner",
                "notificationType": "HTTP Callback URL",
            },
            "feature": "EVENTS",
            ".PARTNER_ID": "DTS",
            "lenderSubscriptions": {"subscribeToLenders": False},
            "eventSources": {
                "fni": {
                    "CreditApplicationsEvents": ["Error", "NotSubmitted", "Submitted"],
                    "CreditDecisionsEvents": [
                        "Approved",
                        "ConditionallyApproved",
                        "Declined",
                    ],
                    "CreditDecisions": True,
                    "CreditApplications": True,
                },
                "ideal": {"CreditDecisions": False},
                "dr": {
                    "Contracting": True,
                    "ContractingEvents": ["SavedSuccessfully", "SaveFailed"],
                },
                "unifi": {
                    "CreditDecisionsEvents": ["Cancelled", "Expired", "Pending"],
                    "Compliance": True,
                    "ContractingEvents": [
                        "Cancelled",
                        "DocumentsSubmittedForSigning",
                        "PartiallySigned",
                        "Signed",
                        "SubmittedForFunding",
                    ],
                    "CreditDecisions": True,
                    "ComplianceEvents": ["RedFlagOfac"],
                    "Contracting": True,
                    "ContractingDecisions": True,
                    "DealJacket": True,
                    "ContractingDecisionsEvents": [
                        "Booked",
                        "Funded",
                        "PendingDocs",
                        "Returned",
                        "Verified",
                        "VerificationExpired",
                        "VerificationFailed",
                        "VerifiedWithWarnings",
                    ],
                    "DealJacketEvents": ["Created", "LeadPrefilled"],
                    "CreditApplications": False,
                },
            },
        }
    ],
}


@pytest.fixture()
def add_db_events_record(dynamodb, mock_dtc_deal):
    def add_record(**kwargs):
        item = kwargs.get("Item", mock_dtc_deal(**kwargs))
        db = dynamodb
        db.Table(deal_consumer.DealDataParameters().db_name).put_item(Item=item)

    return add_record


@pytest.fixture()
def mock_dtc_deal():
    def wrapper(**kwargs):
        return {
            "dealRefId": kwargs.get("dealRefId", "01FRM6T1BX99CZBEX5MYG2Q16V"),
            "dealComponent": kwargs.get("dealComponent", "DTC.EVENTS.849124214"),
            "leadRefId": "01FRM6T1BXH0A0A04X5BVH87XA",
            "sourcePartnerId": "DWR",
            "eventId": "849124214",
            "sourcePartnerDealerId": "1441000",
            "targetPlatforms": [{"partyId": "1441000", "id": "DTC"}],
            "customerType": "Individual",
            "dealRefIdFD": "160000010006191534",
            "financeMethod": "Retail",
        }

    return wrapper


@pytest.fixture()
def startup_db_events_helper(add_db_events_record, mock_dtc_deal, dynamodb):
    add_db_events_record()
    db = dynamodb
    record = db.Table(deal_consumer.DealDataParameters().db_name).scan()
    return record


@pytest.fixture()
def expected_invalid_query_params_get_events():
    return [
        {
            "code": "deal.invalidQueryParameter",
            "properties": [
                {
                    "property": "queryParameters",
                    "message": settings.ErrorMsgs.error_unsupported_events_filter.format(
                        filters=settings.GET_EVENTS_FILTER_PARAMS
                    ),
                }
            ],
        }
    ]


@pytest.fixture()
def expected_con_verify_or_sign_app_missing_deal_ref_id():
    return [
        {
            "code": "deal.missingRequiredProperty",
            "properties": [
                {
                    "property": "dealRefId",
                    "message": "dealRefId is missing in provided path parameters",
                }
            ],
        }
    ]


@pytest.fixture()
def mock_query_pk_filter_verify_or_sign_contract(dynamodb, **kwargs):
    def query_pk_filter(*args, **kwargs):
        return []

    return query_pk_filter


@pytest.fixture(autouse=True)
def mock_dynamodb_helper(monkeypatch, mock_query_pk_filter):
    monkeypatch.setattr(DynamoDbHelper, "query_pk_filter", mock_query_pk_filter)


@pytest.fixture()
def generate_decision_record():
    def decision_record(lender_id=None):
        return {
            "approvalStatus": "Approved",
            "approvedAmount": "29088",
            "approvedRate": "5",
            "approvedTerm": "60",
            "customerMoneyFactor": "0.002",
            "downPayment": "4380",
            "financeMethod": "Retail",
            "lenderId": lender_id or "DT6",
            "lenderMoneyFactor": "0.005",
            "lenderName": "American Honda Finance Corporation",
            "monthlyPayment": "458",
            "stipulations": [{"text": "test1"}, {"text": "test2"}],
            "tier": "Gold",
        }

    return decision_record


@pytest.fixture()
def get_api_gateway_event_post_event(get_api_gateway_event, dr_events_payload):
    def api_gateway_event(deal_ref_id=None, custom_body={}, credit_app_id_dr=None):
        body = dr_events_payload
        body["eventKeyData"].update(
            {
                "creditAppIdDR": credit_app_id_dr or ulid.new().str,
                "sourcePartnerDealerId": "123456789",
                "sourcePartnerId": "VIN",
            }
        )
        body.update(custom_body)

        event = get_api_gateway_event(body)
        event.update(
            {
                "path": "/v1/deals/dealRefId/events/",
                "pathParameters": {"dealRefId": deal_ref_id or ulid.new().str},
                "requestContext": {"operationName": "post_event"},
            }
        )
        return event

    return api_gateway_event


@pytest.fixture()
def get_api_gateway_event_post_lender_decision(decimal_encoder, get_api_gateway_event):
    def api_gateway_event(body, deal_ref_id=None, lender_id=None, credit_app_id=None):
        event = get_api_gateway_event(body)
        event.update(
            {
                "path": "/v1/deals/dealRefId/lender-decision/lenderId",
                "pathParameters": {
                    "dealRefId": deal_ref_id or ulid.new().str,
                    "creditAppId": credit_app_id or ulid.new().str,
                },
                "requestContext": {"operationName": "post_lender_decision"},
            }
        )
        return event

    return api_gateway_event


@pytest.fixture()
def missing_event_id_path_param():
    return [
        {
            "code": "deal.missingRequiredProperty",
            "properties": [
                {
                    "property": "eventId",
                    "message": "eventId is missing in provided path parameters",
                }
            ],
        }
    ]


@pytest.fixture()
def posting_duplicate_event_error():
    return [
        {
            "code": "deal.invalidRefId",
            "properties": [
                {"property": "dealComponent", "message": "Event record already posted"}
            ],
        }
    ]


@pytest.fixture()
def missing_keydata_errors():
    return [
        {
            "code": "deal.missingRequiredProperty",
            "properties": [
                {
                    "property": "eventKeyData.sourcePartnerId",
                    "message": "sourcePartnerId is missing in eventKeyData",
                },
                {
                    "property": "eventKeyData.sourcePartnerDealerId",
                    "message": "sourcePartnerDealerId is missing in eventKeyData",
                },
                {
                    "property": "eventKeyData.creditAppIdDR",
                    "message": "creditAppIdDR is missing in eventKeyData",
                },
            ],
        }
    ]


@pytest.fixture()
def missing_credit_app_id_path_param():
    return [
        {
            "code": "deal.missingRequiredProperty",
            "properties": [
                {
                    "property": "creditAppId",
                    "message": "creditAppId is missing in provided path parameters",
                }
            ],
        }
    ]


@pytest.fixture()
def missing_lender_id():
    return [
        {
            "code": "deal.missingRequiredProperty",
            "properties": [
                {
                    "property": "lenderId",
                    "message": "lenderId is missing in provided decision",
                }
            ],
        }
    ]


@pytest.fixture()
def post_lender_decision_missing_all_path_param():
    return [
        {
            "code": "deal.missingRequiredProperty",
            "properties": [
                {
                    "property": "dealRefId",
                    "message": "dealRefId is missing in provided path parameters",
                },
                {
                    "property": "creditAppId",
                    "message": "creditAppId is missing in provided path parameters",
                },
            ],
        }
    ]


@pytest.fixture()
def invalid_credit_app_id_error():
    return [
        {
            "code": "deal.invalidRefId",
            "properties": [
                {
                    "property": "creditAppId",
                    "message": "Invalid ulid provided. Error Expects 26 characters for decoding; got 20",
                }
            ],
        }
    ]


@pytest.fixture()
def mock_dynamodb_helper_events(dynamodb):
    class MockDynamoDBHelper:
        def __init__(self, table_name, region, *args, **kwargs):
            self.db_resource = dynamodb
            self.table_name = table_name
            self.region = region
            self.table = dynamodb.Table(table_name)

        def query_db_pk_sk(
            self, deal_ref_id, deal_component, deal_component_op: str = "eq"
        ):
            key_expression = conditions.Key("dealRefId").eq(deal_ref_id)
            if deal_component:
                component_expr = getattr(
                    conditions.Key("dealComponent"), deal_component_op
                )(deal_component)
                key_expression = key_expression & component_expr

            return self.query_items(key_expression=key_expression)

        def query_items(self, key_expression):
            records = self.table.query(KeyConditionExpression=key_expression)
            return records.get("Items", [])

        def update_item(self, *args, **kwargs):
            partition_key = kwargs.get("partition_key")
            sort_key = kwargs.get("sort_key")
            update_record = kwargs.get("update_record")

            condition_expression = kwargs.get("condition_expression")
            update_expression_list = []
            expression_attribute_names = {}
            expression_attribute_values = {}

            partition_value = update_record.pop(partition_key)
            key_info = {partition_key: partition_value}
            if sort_key:
                sort_key_val = update_record.pop(sort_key)
                key_info.update({sort_key: sort_key_val})

            if not condition_expression:
                condition_expression = conditions.Attr(partition_key).eq(
                    str(partition_value)
                )
                if sort_key:
                    condition_expression = condition_expression & conditions.Attr(
                        sort_key
                    ).eq(str(sort_key_val))

            for key, val in update_record.items():
                update_expression_list.append(f"#{key} = :{key}")
                expression_attribute_names[f"#{key}"] = str(key)
                expression_attribute_values[f":{key}"] = val

            self.db_resource.Table(
                deal_consumer.DealDataParameters().db_name
            ).update_item(
                Key=key_info,
                ConditionExpression=condition_expression,
                UpdateExpression=f"SET {' , '.join(update_expression_list)}",
                ExpressionAttributeNames=expression_attribute_names,
                ExpressionAttributeValues=expression_attribute_values,
            )

        def put_item(self, *args, **kwargs):
            pass

    return MockDynamoDBHelper
