# -*- coding: utf-8 -*-
import json
from http import HTTPStatus

import ulid
from common import deal_consumer
from events import events_lambda
from utils import db_helper


def test_post_success(
    lambda_context,
    dynamodb,
    monkeypatch,
    mock_dynamodb_helper_deals,
    get_api_gateway_event_post_event,
):
    before_adding = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()

    assert before_adding["Count"] == 0
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)

    event_id_inbound = ulid.new().str
    deal_ref_id = ulid.new().str

    new_event = get_api_gateway_event_post_event(
        deal_ref_id=deal_ref_id, custom_body={"eventId": event_id_inbound}
    )

    response = events_lambda.events_handlers(new_event, lambda_context)

    updated_records = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()

    assert response["statusCode"] == HTTPStatus.CREATED
    assert json.loads(response["body"]) == {
        "dealRefId": deal_ref_id,
        "eventId": event_id_inbound,
    }
    assert updated_records["Count"] == 1
    assert event_id_inbound == updated_records["Items"][0]["eventIdInbound"]


def test_post_existing_resource(
    lambda_context,
    dynamodb,
    monkeypatch,
    mock_dynamodb_helper_deals,
    startup_db_events_helper,
    get_api_gateway_event_post_event,
):
    before_adding = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()

    assert before_adding["Count"] == 1

    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)

    event_id_inbound = ulid.new().str
    deal_ref_id = ulid.new().str

    new_event = get_api_gateway_event_post_event(
        deal_ref_id=deal_ref_id, custom_body={"eventId": event_id_inbound}
    )

    response = events_lambda.events_handlers(new_event, lambda_context)

    updated_records = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()

    assert response["statusCode"] == HTTPStatus.CREATED
    assert json.loads(response["body"]) == {
        "dealRefId": deal_ref_id,
        "eventId": event_id_inbound,
    }
    assert updated_records["Count"] == 2

    assert (
        updated_records["Items"][1]["eventId"]
        != updated_records["Items"][0]["eventIdInbound"]
    )


def test_post_missing_deal_ref_id(
    lambda_context,
    dynamodb,
    monkeypatch,
    mock_dynamodb_helper_deals,
    get_api_gateway_event_post_event,
    missing_deal_ref_path_param,
):
    before_adding = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()

    assert before_adding["Count"] == 0

    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)

    event_id_inbound = ulid.new().str

    new_event = get_api_gateway_event_post_event(
        custom_body={"eventId": event_id_inbound}
    )
    new_event["pathParameters"].update({"dealRefId": ""})

    response = events_lambda.events_handlers(new_event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert json.loads(response["body"]) == missing_deal_ref_path_param


def test_post_deal_ref_id_null(
    lambda_context,
    dynamodb,
    monkeypatch,
    mock_dynamodb_helper_deals,
    get_api_gateway_event_post_event,
    missing_deal_ref_path_param,
):
    before_adding = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()
    assert before_adding["Count"] == 0

    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)

    event_id_inbound = ulid.new().str

    new_event = get_api_gateway_event_post_event(
        custom_body={"eventId": event_id_inbound}
    )
    new_event["pathParameters"].update({"dealRefId": None})

    response = events_lambda.events_handlers(new_event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert json.loads(response["body"]) == missing_deal_ref_path_param


def test_post_extra_keys_provided(
    lambda_context,
    dynamodb,
    monkeypatch,
    mock_dynamodb_helper_deals,
    get_api_gateway_event_post_event,
):
    before_adding = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()

    assert before_adding["Count"] == 0

    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)

    event_id_inbound = ulid.new().str
    deal_ref_id = ulid.new().str

    new_event = get_api_gateway_event_post_event(
        deal_ref_id=deal_ref_id,
        custom_body={
            "eventId": event_id_inbound,
            "dealComponent": f"DTC.EVENTS.{event_id_inbound}",
        },
    )

    new_event["dealRefId"] = None
    new_event["test"] = 123

    response = events_lambda.events_handlers(new_event, lambda_context)

    assert response["statusCode"] == HTTPStatus.CREATED
    assert json.loads(response["body"]) == {
        "dealRefId": deal_ref_id,
        "eventId": event_id_inbound,
    }


def test_post_event_empty_body(
    lambda_context,
    dynamodb,
    monkeypatch,
    mock_dynamodb_helper_deals,
    get_api_gateway_event_post_event,
    missing_body_message,
):
    initial_table = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()

    assert initial_table["Count"] == 0
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)

    new_event = get_api_gateway_event_post_event()
    new_event["body"] = {}

    response = events_lambda.events_handlers(new_event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert json.loads(response["body"]) == missing_body_message


def test_post_invalid_deal_ref_id(
    lambda_context,
    dynamodb,
    monkeypatch,
    mock_dynamodb_helper_deals,
    get_api_gateway_event_post_event,
    mock_validate_api_version_invalid_dealrefid,
    generic_invalid_dealref_id,
):
    initial_table = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()

    assert initial_table["Count"] == 0
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)
    monkeypatch.setattr(
        events_lambda.ExistingDealValidator,
        "validate_api_version",
        mock_validate_api_version_invalid_dealrefid,
    )

    event_id_inbound = ulid.new().str

    new_event = get_api_gateway_event_post_event(
        custom_body={"eventId": event_id_inbound}
    )

    response = events_lambda.events_handlers(new_event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert json.loads(response["body"]) == generic_invalid_dealref_id


def test_post_duplicate_event_record(
    lambda_context,
    dynamodb,
    monkeypatch,
    mock_dynamodb_helper_deals,
    get_api_gateway_event_post_event,
    posting_duplicate_event_error,
):
    initial_table = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()

    assert initial_table["Count"] == 0
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)

    event_id_inbound = ulid.new().str

    new_event = get_api_gateway_event_post_event(
        custom_body={"eventId": event_id_inbound}
    )

    response = events_lambda.events_handlers(new_event, lambda_context)

    updated_records = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()

    assert updated_records["Count"] == 1
    assert event_id_inbound == updated_records["Items"][0]["eventIdInbound"]
    assert response["statusCode"] == HTTPStatus.CREATED

    response = events_lambda.events_handlers(new_event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert json.loads(response["body"]) == posting_duplicate_event_error


def test_post_multiple_events(
    lambda_context,
    dynamodb,
    monkeypatch,
    mock_dynamodb_helper_deals,
    get_api_gateway_event_post_event,
):
    initial_table = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()

    assert initial_table["Count"] == 0
    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)

    first_event_id = "123"

    first_event = get_api_gateway_event_post_event(
        custom_body={"eventId": first_event_id}
    )

    response = events_lambda.events_handlers(first_event, lambda_context)

    updated_records = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()

    assert response["statusCode"] == HTTPStatus.CREATED
    assert json.loads(response["body"]) == {
        "dealRefId": ulid.new().str,
        "eventId": first_event_id,
    }
    assert updated_records["Count"] == 1
    assert first_event_id == updated_records["Items"][0]["eventIdInbound"]

    second_event_id = "456"

    second_event = get_api_gateway_event_post_event(
        custom_body={"eventId": second_event_id}
    )

    response = events_lambda.events_handlers(second_event, lambda_context)

    updated_records = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()

    assert response["statusCode"] == HTTPStatus.CREATED
    assert json.loads(response["body"]) == {
        "dealRefId": ulid.new().str,
        "eventId": second_event_id,
    }
    assert updated_records["Count"] == 2
    assert second_event_id == updated_records["Items"][1]["eventIdInbound"]


def test_post_href_is_empty(
    lambda_context,
    dynamodb,
    monkeypatch,
    mock_dynamodb_helper_deals,
    get_api_gateway_event_post_event,
):
    before_adding = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()
    assert before_adding["Count"] == 0

    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)

    event_id_inbound = ulid.new().str

    new_event = get_api_gateway_event_post_event(
        custom_body={"eventId": event_id_inbound, "eventDetailHref": ""}
    )

    events_lambda.events_handlers(new_event, lambda_context)
    after_adding = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()

    assert "eventDetailHref" not in after_adding["Items"][0]
    # assert after_adding["Items"][0].get("eventDetailHref") == "test"


def test_post_href_is_not_empty(
    lambda_context,
    dynamodb,
    monkeypatch,
    mock_dynamodb_helper_deals,
    get_api_gateway_event_post_event,
):
    before_adding = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()
    assert before_adding["Count"] == 0

    monkeypatch.setattr(db_helper, "DynamoDbHelper", mock_dynamodb_helper_deals)

    event_id_inbound = ulid.new().str

    new_event = get_api_gateway_event_post_event(
        custom_body={"eventId": event_id_inbound}
    )

    events_lambda.events_handlers(new_event, lambda_context)
    after_adding = dynamodb.Table(deal_consumer.DealDataParameters().db_name).scan()

    assert (
        after_adding["Items"][0].get("eventDetailHref")
        == "https://fni-api.dealertrack.com/dr-decisions/v1/responses/responseId/lenders/lenderId/"
    )
