# -*- coding: utf-8 -*-
import pytest
from common.settings import S3_DLQ_OBJECT_KEY_TEMPLATE
from reprocess import dlq_processing


class MockTimeStamp:
    time_stamp = "2022-12-31T23:11:22.543545"


@pytest.fixture()
def mock_time_stamp():
    return MockTimeStamp()


@pytest.fixture()
def patch_time_stamp(monkeypatch, generate_s3_dlq_bucket_key):
    monkeypatch.setattr(
        dlq_processing.DlqProcessingLambda,
        "generate_reprocessing_garage_bucket_key",
        generate_s3_dlq_bucket_key,
    )


@pytest.fixture()
def generate_s3_dlq_bucket_key(dr_ulid):
    def get_key(*args):
        return S3_DLQ_OBJECT_KEY_TEMPLATE.format(
            dlqName="DealDataDLQ",
            dealRefId=dr_ulid,
            timestamp="2022-12-31T23:11:22.543545",
            content_type="txt",
        )

    return get_key


@pytest.fixture()
def expected_s3_dlq_object_tags():
    return [
        {"Key": "correlationId", "Value": "12345abc-abc1-2def-56ef-000000000000"},
        {"Key": "payloadType", "Value": "CONTRACT_POST"},
        {"Key": "dealRefId", "Value": "0000000000AAABBBCCDDEEFFGG"},
        {"Key": "dealTTL", "Value": "1234573074000"},
        {"Key": "x-aws-region", "Value": "us-east-1"},
        {"Key": "msg_group_id", "Value": "1"},
    ]
