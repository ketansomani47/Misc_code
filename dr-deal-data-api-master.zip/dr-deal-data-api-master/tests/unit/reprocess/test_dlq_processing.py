# -*- coding: utf-8 -*-
import json
from http import HTTPStatus

import pytest
from common.settings import PayloadType as pt
from reprocess import dlq_processing


def test_reprocessing_garage_save_successful(
    s3,
    get_sqs_event,
    lambda_context,
    boto3_s3_client,
    generate_s3_dlq_bucket_key,
    expected_s3_dlq_object_tags,
    credit_app_partial_payload,
    patch_time_stamp,
    monkeypatch,
):
    """
    Test to verify DealDataDlq message save successful to reprocessing garage s3 bucket
    """
    event = get_sqs_event(credit_app_partial_payload, pt.CONTRACT_POST)
    event["Records"][0]["awsRegion"] = "us-east-1"
    monkeypatch.setattr(dlq_processing.boto3, "client", boto3_s3_client)
    response = dlq_processing.handler(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.CREATED

    s3_object = s3.get_object(
        Bucket=dlq_processing.Env.REPROCESSING_GARAGE,
        Key=f"{generate_s3_dlq_bucket_key()}",
    )

    s3_object_tags = s3.get_object_tagging(
        Bucket=dlq_processing.Env.REPROCESSING_GARAGE,
        Key=f"{generate_s3_dlq_bucket_key()}",
    )

    s3_object_body = json.loads(s3_object.get("Body").read().decode("utf-8"))

    s3_object_tags = s3_object_tags.get("TagSet")

    assert s3_object.get("ContentType") == "txt"
    assert s3_object_body == credit_app_partial_payload
    assert s3_object_tags == expected_s3_dlq_object_tags


def test_reprocessing_garage_raises_exception(
    lambda_context,
    get_sqs_event,
    monkeypatch,
    return_exception,
    credit_app_partial_payload,
):
    """
    Test to verify exception handles while saving dlq messages to reprocessing garage bucket
    """

    event = get_sqs_event(credit_app_partial_payload, pt.CONTRACT_POST)
    event["Records"][0]["awsRegion"] = "us-east-1"

    monkeypatch.setattr(dlq_processing, "handler", return_exception)

    with pytest.raises(Exception) as exception:
        dlq_processing.handler(event, lambda_context)

    assert "error" in str(exception)
