# -*- coding: utf-8 -*-

import json

import pytest
from common.settings import S3_OBJECT_KEY_TEMPLATE


CORRELATION_ID = "99999aaa-abc1-2def-56ef-000000"
DR_ULID = "0000000000AAABBBCCDDEEFFGG"
DR_DLR_ID = "123456"


@pytest.fixture()
def get_s3_object_tags_value():
    return json.dumps(
        {"correlation_id": CORRELATION_ID, "creditBureauRefIdUnifi": "123456789323234"}
    )


@pytest.fixture()
def get_s3_object_tags_bad_value():
    return "bad_data"


@pytest.fixture()
def expected_s3_object_tags():
    return [
        {"Key": "correlation_id", "Value": CORRELATION_ID},
        {"Key": "creditBureauRefIdUnifi", "Value": "123456789323234"},
        {"Key": "__api_version__", "Value": "v1"},
    ]


@pytest.fixture()
def expected_s3_object_single_tag():
    return [{"Key": "__api_version__", "Value": "v1"}]


@pytest.fixture()
def get_sqs_message_attributes_event(dr_ulid):
    def get_attributes(action, tag_value):
        return {
            "tags": {"stringValue": tag_value, "DataType": "String"},
            "content_type": {"stringValue": "json", "DataType": "String"},
            "action": {"stringValue": action, "DataType": "String"},
            "deal_ref_id": {"stringValue": dr_ulid, "DataType": "String"},
            "dealer_id": {"stringValue": DR_DLR_ID, "DataType": "String"},
            "context_id": {"stringValue": dr_ulid, "DataType": "String"},
            "feature": {"stringValue": "CA", "DataType": "String"},
            "api_version": {"stringValue": "v1", "DataType": "String"},
        }

    return get_attributes


@pytest.fixture()
def get_sqs_event_snapshots(decimal_encoder, get_sqs_message_attributes_event):
    def sqs_event(body, action, tag_value):
        event = {
            "Records": [
                {
                    "body": json.dumps(body, cls=decimal_encoder),
                    "messageAttributes": get_sqs_message_attributes_event(
                        action, tag_value
                    ),
                }
            ]
        }

        return event

    return sqs_event


@pytest.fixture()
def generate_s3_bucket_key(dr_ulid):
    def get_key(feature):
        return S3_OBJECT_KEY_TEMPLATE.format(
            dealerId=DR_DLR_ID,
            dealRefId=dr_ulid,
            feature=feature,
            context_id=dr_ulid,
            content_type="json",
        )

    return get_key
