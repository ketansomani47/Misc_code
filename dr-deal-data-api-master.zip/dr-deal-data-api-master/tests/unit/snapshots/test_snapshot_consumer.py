# -*- coding: utf-8 -*-
import json
from http import HTTPStatus

import pytest
from common.settings import SnapshotAction
from snapshots import consumer
from utils import exceptions


class TestSnapshotCreate:
    def test_snapshot_create_successful(
        self,
        s3,
        get_sqs_event_snapshots,
        credit_app_full_payload,
        get_s3_object_tags_value,
        expected_s3_object_tags,
        generate_s3_bucket_key,
        lambda_context,
        boto3_s3_client,
        monkeypatch,
    ):
        """
        Test to verify snapshot create with tags
        """
        event = get_sqs_event_snapshots(
            credit_app_full_payload,
            SnapshotAction.SNAPSHOT_CREATE,
            get_s3_object_tags_value,
        )
        monkeypatch.setattr(consumer.boto3, "client", boto3_s3_client)
        response = consumer.handler(event, lambda_context)

        assert response["statusCode"] == HTTPStatus.CREATED

        s3_object = s3.get_object(
            Bucket=consumer.Env.SNAPSHOT_BUCKET, Key=f"{generate_s3_bucket_key('CA')}"
        )
        s3_object_tags = s3.get_object_tagging(
            Bucket=consumer.Env.SNAPSHOT_BUCKET, Key=f"{generate_s3_bucket_key('CA')}"
        )

        s3_object_body = json.loads(s3_object.get("Body").read().decode("utf-8"))
        s3_object_tags = s3_object_tags.get("TagSet")

        assert s3_object.get("ContentType") == "application/json"
        assert s3_object_body == credit_app_full_payload
        assert s3_object_tags == expected_s3_object_tags

    def test_snapshot_raises_json_decoder_exception(
        self,
        lambda_context,
        get_sqs_event_snapshots,
        credit_app_full_payload,
        get_s3_object_tags_bad_value,
    ):
        """
        Test verifies with some string as payload should raise Json decoder error
        """
        event = get_sqs_event_snapshots(
            credit_app_full_payload,
            SnapshotAction.SNAPSHOT_CREATE,
            get_s3_object_tags_bad_value,
        )

        with pytest.raises(json.JSONDecodeError):
            consumer.handler(event, lambda_context)

    def test_snapshot_raises_snapshot_save_error(
        self,
        lambda_context,
        get_sqs_event_snapshots,
        get_s3_object_tags_value,
        monkeypatch,
        boto3_s3_client,
    ):
        """
        Test to verify snapshot create error handles on client put_object method
        """
        event = get_sqs_event_snapshots(
            "raise_snapshot_error",
            SnapshotAction.SNAPSHOT_CREATE,
            get_s3_object_tags_value,
        )
        monkeypatch.setattr(consumer.boto3, "client", boto3_s3_client)

        with pytest.raises(exceptions.SnapshotSaveError) as snapshot_create_error:
            consumer.handler(event, lambda_context)
        assert "Snapshot Create Failed" in str(snapshot_create_error)

    def test_snapshot_raises_exception(
        self,
        lambda_context,
        get_sqs_event_snapshots,
        get_s3_object_tags_value,
        monkeypatch,
        return_exception,
        credit_app_full_payload,
    ):
        """
        Test to verify snapshot create generic exception handles on any exception
        """
        event = get_sqs_event_snapshots(
            "raise_exception", SnapshotAction.SNAPSHOT_CREATE, get_s3_object_tags_value
        )
        monkeypatch.setattr(consumer.SnapShotConsumerLambda, "create", return_exception)

        with pytest.raises(Exception) as exception:
            consumer.handler(event, lambda_context)

        assert "error" in str(exception)

    def test_snapshot_no_tags(
        self,
        s3,
        get_sqs_event_snapshots,
        credit_app_full_payload,
        get_s3_object_tags_value,
        expected_s3_object_single_tag,
        generate_s3_bucket_key,
        lambda_context,
        boto3_s3_client,
        monkeypatch,
    ):
        """
        Test to verify snapshot create without tags
        """
        event = get_sqs_event_snapshots(
            credit_app_full_payload,
            SnapshotAction.SNAPSHOT_CREATE,
            get_s3_object_tags_value,
        )
        event["Records"][0]["messageAttributes"].pop("tags")
        monkeypatch.setattr(consumer.boto3, "client", boto3_s3_client)
        response = consumer.handler(event, lambda_context)

        assert response["statusCode"] == HTTPStatus.CREATED

        s3_object = s3.get_object(
            Bucket=consumer.Env.SNAPSHOT_BUCKET, Key=f"{generate_s3_bucket_key('CA')}"
        )
        s3_object_tags = s3.get_object_tagging(
            Bucket=consumer.Env.SNAPSHOT_BUCKET, Key=f"{generate_s3_bucket_key('CA')}"
        )

        s3_object_body = json.loads(s3_object.get("Body").read().decode("utf-8"))
        s3_object_tags = s3_object_tags.get("TagSet")

        assert s3_object.get("ContentType") == "application/json"
        assert s3_object_body == credit_app_full_payload
        assert s3_object_tags == expected_s3_object_single_tag
