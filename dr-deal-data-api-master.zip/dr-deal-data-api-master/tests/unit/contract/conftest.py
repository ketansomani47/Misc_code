# -*- coding: utf-8 -*-
import pytest
from common import settings
from utils.db_helper import DynamoDbHelper


@pytest.fixture(autouse=True)
def mock_dynamodb_helper(monkeypatch, mock_query_pk_filter):
    monkeypatch.setattr(DynamoDbHelper, "query_pk_filter", mock_query_pk_filter)


@pytest.fixture()
def get_api_gateway_event_con_new_app(get_api_gateway_event, dr_ulid_new):
    def api_gateway_event(body):
        event = get_api_gateway_event(body)
        event[
            "path"
        ] = "/v1/deals/dealRefId/credit-apps/creditAppId/lender/lenderId/contract"
        event["pathParameters"] = {
            "dealRefId": dr_ulid_new,
            "creditAppId": dr_ulid_new,
            "lenderId": "BOA",
        }
        return event

    return api_gateway_event


@pytest.fixture()
def get_api_gateway_event_con(get_api_gateway_event, dr_ulid_new):
    def api_gateway_event(body):
        event = get_api_gateway_event(body)
        event["path"] = "/v1/deals/dealRefId/contract"
        event["pathParameters"] = {"dealRefId": dr_ulid_new, "creditAppId": dr_ulid_new}
        event["headers"]["lenderId"] = "BOA"
        return event

    return api_gateway_event


@pytest.fixture()
def get_api_gateway_event_con_healthcheck(get_api_gateway_event):
    event = get_api_gateway_event("")
    event["headers"] = {
        settings.HEALTHCHECK_HEADER_FIELD: settings.HEALTHCHECK_HEADER_VALUE
    }
    event[
        "path"
    ] = "/v1/deals/dealRefId/credit-apps/creditAppId/lender/lenderId/contract"
    return event


@pytest.fixture()
def get_api_gateway_event_con_verify_app(get_api_gateway_event, dr_ulid_new):
    def api_gateway_event(body):
        event = get_api_gateway_event(body)
        event[
            "path"
        ] = "/v1/deals/dealRefId/credit-apps/creditAppId/lender/lenderId/contract/contractRefId/verify"
        event["pathParameters"] = {
            "dealRefId": dr_ulid_new,
            "creditAppId": dr_ulid_new,
            "lenderId": "BOA",
            "contractRefId": dr_ulid_new,
        }
        return event

    return api_gateway_event


@pytest.fixture()
def get_api_gateway_event_con_update_app_without_ca(get_api_gateway_event, dr_ulid_new):
    def api_gateway_event(body):
        event = get_api_gateway_event(body)
        event["path"] = "/v1/deals/dealRefId/contract/contractRefId"
        event["pathParameters"] = {
            "dealRefId": dr_ulid_new,
            "contractRefId": dr_ulid_new,
        }
        event["headers"]["lenderId"] = "BOA"
        return event

    return api_gateway_event


@pytest.fixture()
def get_api_gateway_event_con_verify_app_without_ca(get_api_gateway_event, dr_ulid_new):
    def api_gateway_event(body):
        event = get_api_gateway_event(body)
        event["path"] = "/v1/deals/dealRefId/contract/contractRefId/verify"
        event["pathParameters"] = {
            "dealRefId": dr_ulid_new,
            "contractRefId": dr_ulid_new,
        }
        event["headers"]["lenderId"] = "BOA"
        return event

    return api_gateway_event


@pytest.fixture()
def get_api_gateway_event_con_sign(get_api_gateway_event, dr_ulid_new):
    def api_gateway_event(body):
        event = get_api_gateway_event(body)
        event[
            "path"
        ] = "/v1/deals/dealRefId/credit-apps/creditAppId/lender/lenderId/contract/contractRefId/sign"
        event["pathParameters"] = {
            "dealRefId": dr_ulid_new,
            "creditAppId": dr_ulid_new,
            "lenderId": "BOA",
            "contractRefId": dr_ulid_new,
        }
        return event

    return api_gateway_event


@pytest.fixture()
def get_api_gateway_event_con_sign_without_ca(get_api_gateway_event, dr_ulid_new):
    def api_gateway_event(body):
        event = get_api_gateway_event(body)
        event["path"] = "/v1/deals/dealRefId/contract/contractRefId/sign"
        event["pathParameters"] = {
            "dealRefId": dr_ulid_new,
            "contractRefId": dr_ulid_new,
        }
        event["headers"]["lenderId"] = "BOA"
        return event

    return api_gateway_event


@pytest.fixture()
def get_api_gateway_event_standalone_con_sign(get_api_gateway_event, dr_ulid_new):
    def api_gateway_event(body):
        event = get_api_gateway_event(body)
        event["path"] = "/v1/deals/dealRefId/contract/sign"
        event["pathParameters"] = {
            "dealRefId": dr_ulid_new,
        }
        return event

    return api_gateway_event


@pytest.fixture()
def get_api_gateway_event_con_deal_status(get_api_gateway_event, dr_ulid_new):
    def api_gateway_event(body):
        event = get_api_gateway_event(body)
        event["path"] = "/v1/deals/{dealRefId}/contract/{contractRefId}/status"
        event["pathParameters"] = {
            "dealRefId": dr_ulid_new,
            "contractRefId": dr_ulid_new,
        }
        return event

    return api_gateway_event


@pytest.fixture()
def get_api_gateway_event_con_cancel(get_api_gateway_event, dr_ulid_new):
    def api_gateway_event(body):
        event = get_api_gateway_event(body)
        event["path"] = "/v1/deals/{dealRefId}/contract/{contractRefId}/cancel"
        event["pathParameters"] = {
            "dealRefId": dr_ulid_new,
            "contractRefId": dr_ulid_new,
        }
        return event

    return api_gateway_event


@pytest.fixture()
def mock_query_pk_filter_verify_or_sign_contract(dynamodb, **kwargs):
    def query_pk_filter(*args, **kwargs):
        return []

    return query_pk_filter


@pytest.fixture()
def expected_missing_deal_ref_id():
    return [
        {
            "code": "deal.missingRequiredProperty",
            "properties": [
                {
                    "property": "dealRefId",
                    "message": "dealRefId is missing in provided path parameters",
                }
            ],
        }
    ]


@pytest.fixture()
def expected_con_verify_app_missing_lender_id():
    return [
        {
            "code": "deal.missingRequiredProperty",
            "properties": [
                {
                    "property": "lenderId",
                    "message": "lenderId is missing in provided path parameters",
                }
            ],
        }
    ]


@pytest.fixture()
def expected_update_deal_status_missing_contract_ref_id():
    return [
        {
            "code": "deal.missingRequiredProperty",
            "properties": [
                {
                    "property": "contractRefId",
                    "message": "contractRefId is missing in provided path parameters",
                }
            ],
        }
    ]


@pytest.fixture()
def expected_con_verify_app_missing_lender_id_in_headers():
    return [
        {
            "code": "deal.missingRequiredProperty",
            "properties": [
                {
                    "property": "lenderId",
                    "message": "Missing header: 'lenderId' is needed to process request",
                }
            ],
        }
    ]


@pytest.fixture()
def expected_con_verify_or_sign_app_missing_deal_ref_id_and_credit_app_id():
    return [
        {
            "code": "deal.missingRequiredProperty",
            "properties": [
                {
                    "property": "dealRefId",
                    "message": "dealRefId is missing in provided path parameters",
                },
                {
                    "property": "creditAppId",
                    "message": "creditAppId is missing in provided path parameters",
                },
            ],
        }
    ]


@pytest.fixture()
def expected_invalid_deal_ref_id():
    return [
        {
            "code": "deal.invalidRefId",
            "properties": [
                {"property": "dealRefId", "message": "Invalid dealRefId hhh78w5"}
            ],
        }
    ]


@pytest.fixture()
def expected_con_verify_or_sign_app_invalid_credit_app_id():
    return [
        {
            "code": "deal.invalidRefId",
            "properties": [
                {
                    "property": "creditAppId",
                    "message": "Provided creditAppId nnnn is not associated to dealRefId 01E3AK55DC17CPZ02VXMH62HEQ",
                },
                {
                    "property": "contractRefId",
                    "message": "Provided contractRefId 1111111111AAABBBCCDDEEFFGG is not associated to dealRefId 01E3AK55DC17CPZ02VXMH62HEQ",
                },
            ],
        }
    ]


@pytest.fixture()
def expected_invalid_contract_ref_id():
    return [
        {
            "code": "deal.invalidRefId",
            "properties": [
                {
                    "property": "contractRefId",
                    "message": "Provided contractRefId nnnn is not associated to dealRefId 01E3AK55DC17CPZ02VXMH62HEQ",
                }
            ],
        }
    ]


@pytest.fixture()
def expected_con_verify_or_sign_app_invalid_credit_app_id_and_contract_ref_id():
    return [
        {
            "code": "deal.invalidRefId",
            "properties": [
                {
                    "property": "creditAppId",
                    "message": "Provided creditAppId mmm is not associated to dealRefId 01E3AK55DC17CPZ02VXMH62HEQ",
                },
                {
                    "property": "contractRefId",
                    "message": "Provided contractRefId nnnn is not associated to dealRefId 01E3AK55DC17CPZ02VXMH62HEQ",
                },
            ],
        }
    ]


@pytest.fixture()
def expected_missing_body():
    return [
        {
            "code": "deal.missingRequiredProperty",
            "properties": [
                {
                    "property": "eventBody",
                    "message": "No record or body found in AWS event payload",
                }
            ],
        }
    ]
