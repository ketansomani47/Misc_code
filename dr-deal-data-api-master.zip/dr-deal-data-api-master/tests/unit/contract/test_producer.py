# -*- coding: utf-8 -*-
import json
from http import HTTPStatus

from common.settings import CORRELATION_ID_HEADER_KEY, ErrorMsgs
from contract import producer
from utils.db_helper import DynamoDbHelper


def test_con_full_app_successful(
    contract_full_payload,
    sqs,
    get_api_gateway_event_con,
    uuid_provided,
    response_header,
    lambda_context,
    dr_ulid_new,
    dr_ulid,
    monkeypatch,
    mock_validate_reference_ids,
):
    monkeypatch.setattr(
        producer.ExistingDealValidator,
        "validate_reference_ids",
        mock_validate_reference_ids,
    )
    event = get_api_gateway_event_con(contract_full_payload)
    response = producer.contract_new_app(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps(
        {"dealRefId": dr_ulid_new, "contractRefId": dr_ulid}
    )
    assert response["headers"] == response_header(uuid_provided)


def test_con_full_app_successful_no_correlation_id(
    contract_full_payload,
    sqs,
    get_api_gateway_event_con,
    uuid_newly_generated,
    response_header,
    lambda_context,
    dr_ulid_new,
    dr_ulid,
    monkeypatch,
    mock_validate_reference_ids,
):
    monkeypatch.setattr(
        producer.ExistingDealValidator,
        "validate_reference_ids",
        mock_validate_reference_ids,
    )
    event = get_api_gateway_event_con(contract_full_payload)
    event["headers"].pop(CORRELATION_ID_HEADER_KEY)

    response = producer.contract_new_app(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps(
        {"dealRefId": dr_ulid_new, "contractRefId": dr_ulid}
    )
    assert response["headers"] == response_header(uuid_newly_generated)


def test_con_full_app_successful_cash_no_lender_id(
    contract_full_payload,
    sqs,
    get_api_gateway_event_con,
    uuid_provided,
    response_header,
    lambda_context,
    dr_ulid_new,
    dr_ulid,
    monkeypatch,
    mock_validate_reference_ids,
):
    monkeypatch.setattr(
        producer.ExistingDealValidator,
        "validate_reference_ids",
        mock_validate_reference_ids,
    )
    contract_full_payload["financeMethod"] = "Cash"
    event = get_api_gateway_event_con(contract_full_payload)
    event["headers"].pop("lenderId")

    response = producer.contract_new_app(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps(
        {"dealRefId": dr_ulid_new, "contractRefId": dr_ulid}
    )
    assert response["headers"] == response_header(uuid_provided)


def test_con_full_fail_no_body(
    get_api_gateway_event_con,
    uuid_provided,
    response_header,
    lambda_context,
):
    event = get_api_gateway_event_con("")
    response = producer.contract_new_app(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps({"message": ErrorMsgs.missing_body_aws_event})
    assert response["headers"] == response_header(uuid_provided)


def test_con_full_fail_json_decoder(
    get_api_gateway_invalid_event, uuid_provided, response_header, lambda_context
):
    event = get_api_gateway_invalid_event
    response = producer.contract_new_app(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["headers"] == response_header(uuid_provided)


def test_con_app_missing_lender_id(
    contract_full_payload,
    get_api_gateway_event_con,
    lambda_context,
    response_header,
    uuid_provided,
    mock_validate_reference_ids,
    monkeypatch,
    dr_ulid_new,
    dr_ulid,
):
    monkeypatch.setattr(
        producer.ExistingDealValidator,
        "validate_reference_ids",
        mock_validate_reference_ids,
    )
    contract_full_payload["financeMethod"] = "Finance"
    event = get_api_gateway_event_con(contract_full_payload)
    event["headers"].pop("lenderId")
    response = producer.contract_new_app(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps(
        {"dealRefId": dr_ulid_new, "contractRefId": dr_ulid}
    )
    assert response["headers"] == response_header(uuid_provided)


def test_con_new_app_health_check(
    get_api_gateway_event_con_healthcheck, lambda_context
):
    event = get_api_gateway_event_con_healthcheck
    response = producer.contract_new_app(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps("Operational")


def test_con_new_app_invalid_ulid(
    contract_full_payload, get_api_gateway_event_con, lambda_context
):
    event = get_api_gateway_event_con(contract_full_payload)
    event["pathParameters"]["dealRefId"] = "bad_ulid"
    response = producer.contract_new_app(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert "Invalid ulid provided." in json.dumps(response["body"])


def test_con_update_app_successful(
    contract_full_payload,
    get_api_gateway_event_con_update_app_without_ca,
    uuid_provided,
    response_header,
    lambda_context,
    monkeypatch,
    mock_validate_reference_ids,
):
    monkeypatch.setattr(
        producer.ExistingDealValidator,
        "validate_reference_ids",
        mock_validate_reference_ids,
    )
    event = get_api_gateway_event_con_update_app_without_ca(contract_full_payload)
    response = producer.update_contract(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.ACCEPTED
    assert response["body"] == json.dumps({"message": "Accepted"})
    assert response["headers"] == response_header(uuid_provided)


def test_con_update_app_successful_cash_with_no_lender_id(
    contract_full_payload,
    get_api_gateway_event_con_update_app_without_ca,
    uuid_provided,
    response_header,
    lambda_context,
    monkeypatch,
    mock_validate_reference_ids,
):
    monkeypatch.setattr(
        producer.ExistingDealValidator,
        "validate_reference_ids",
        mock_validate_reference_ids,
    )
    contract_full_payload["financeMethod"] = "Cash"
    event = get_api_gateway_event_con_update_app_without_ca(contract_full_payload)
    event["headers"].pop("lenderId")

    response = producer.update_contract(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.ACCEPTED
    assert response["body"] == json.dumps({"message": "Accepted"})
    assert response["headers"] == response_header(uuid_provided)


def test_con_update_app_fail_no_body(
    get_api_gateway_event_con_update_app_without_ca,
    uuid_provided,
    response_header,
    lambda_context,
    expected_missing_body,
):
    event = get_api_gateway_event_con_update_app_without_ca("")
    response = producer.update_contract(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(expected_missing_body)
    assert response["headers"] == response_header(uuid_provided)


def test_con_update_app_fail_json_decoder(
    get_api_gateway_invalid_event, uuid_provided, response_header, lambda_context
):
    event = get_api_gateway_invalid_event
    response = producer.update_contract(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["headers"] == response_header(uuid_provided)


def test_con_update_app_health_check(
    get_api_gateway_event_con_healthcheck, lambda_context
):
    get_api_gateway_event_con_healthcheck[
        "path"
    ] = "/v1/deals/dealRefId/contract/contractRefId"
    event = get_api_gateway_event_con_healthcheck
    response = producer.update_contract(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps("Operational")


def test_con_update_app_missing_deal_ref_id(
    contract_full_payload,
    get_api_gateway_event_con_update_app_without_ca,
    expected_missing_deal_ref_id,
    lambda_context,
    response_header,
    uuid_provided,
):
    event = get_api_gateway_event_con_update_app_without_ca(contract_full_payload)
    del event["pathParameters"]["dealRefId"]
    response = producer.update_contract(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(expected_missing_deal_ref_id)

    assert response["headers"] == response_header(uuid_provided)


def test_con_update_app_missing_lender_id(
    contract_full_payload,
    get_api_gateway_event_con_update_app_without_ca,
    lambda_context,
    response_header,
    uuid_provided,
    mock_validate_reference_ids,
    monkeypatch,
):
    monkeypatch.setattr(
        producer.ExistingDealValidator,
        "validate_reference_ids",
        mock_validate_reference_ids,
    )
    contract_full_payload["financeMethod"] = "Finance"
    event = get_api_gateway_event_con_update_app_without_ca(contract_full_payload)
    event["headers"].pop("lenderId")
    response = producer.update_contract(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.ACCEPTED
    assert response["body"] == json.dumps({"message": "Accepted"})
    assert response["headers"] == response_header(uuid_provided)


def test_con_update_app_invalid_deal_ref_id(
    contract_full_payload,
    get_api_gateway_event_con_update_app_without_ca,
    expected_invalid_deal_ref_id,
    mock_query_pk_filter_verify_or_sign_contract,
    lambda_context,
    response_header,
    uuid_provided,
    monkeypatch,
):
    monkeypatch.setattr(
        DynamoDbHelper,
        "query_pk_filter",
        mock_query_pk_filter_verify_or_sign_contract,
    )
    event = get_api_gateway_event_con_update_app_without_ca(contract_full_payload)
    event["pathParameters"]["dealRefId"] = "hhh78w5"
    response = producer.update_contract(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(expected_invalid_deal_ref_id)

    assert response["headers"] == response_header(uuid_provided)


def test_con_update_app_invalid_contract_ref_id(
    contract_full_payload,
    get_api_gateway_event_con_update_app_without_ca,
    expected_invalid_contract_ref_id,
    lambda_context,
    response_header,
    uuid_provided,
):
    event = get_api_gateway_event_con_update_app_without_ca(contract_full_payload)
    event["pathParameters"]["contractRefId"] = "nnnn"
    event["pathParameters"]["dealRefId"] = "01E3AK55DC17CPZ02VXMH62HEQ"
    response = producer.update_contract(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(expected_invalid_contract_ref_id)

    assert response["headers"] == response_header(uuid_provided)


def test_con_verify_app_successful(
    contract_verify_payload,
    get_api_gateway_event_con_verify_app_without_ca,
    uuid_provided,
    response_header,
    lambda_context,
    monkeypatch,
    mock_validate_reference_ids,
):
    monkeypatch.setattr(
        producer.ExistingDealValidator,
        "validate_reference_ids",
        mock_validate_reference_ids,
    )
    event = get_api_gateway_event_con_verify_app_without_ca(contract_verify_payload)
    response = producer.verify_contract(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.ACCEPTED
    assert response["body"] == json.dumps({"message": "Accepted"})
    assert response["headers"] == response_header(uuid_provided)


def test_con_verify_app_successful_cash_with_no_lender_id(
    contract_verify_payload,
    get_api_gateway_event_con_verify_app_without_ca,
    uuid_provided,
    response_header,
    lambda_context,
    monkeypatch,
    mock_validate_reference_ids,
):
    monkeypatch.setattr(
        producer.ExistingDealValidator,
        "validate_reference_ids",
        mock_validate_reference_ids,
    )
    contract_verify_payload["financeMethod"] = "Cash"
    event = get_api_gateway_event_con_verify_app_without_ca(contract_verify_payload)
    event["headers"].pop("lenderId")

    response = producer.verify_contract(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.ACCEPTED
    assert response["body"] == json.dumps({"message": "Accepted"})
    assert response["headers"] == response_header(uuid_provided)


def test_con_verify_app_fail_no_body(
    get_api_gateway_event_con_verify_app_without_ca,
    uuid_provided,
    response_header,
    lambda_context,
    expected_missing_body,
):
    event = get_api_gateway_event_con_verify_app_without_ca("")
    response = producer.verify_contract(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(expected_missing_body)
    assert response["headers"] == response_header(uuid_provided)


def test_con_verify_app_fail_json_decoder(
    get_api_gateway_invalid_event, uuid_provided, response_header, lambda_context
):
    event = get_api_gateway_invalid_event
    response = producer.verify_contract(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["headers"] == response_header(uuid_provided)


def test_con_verify_app_health_check(
    get_api_gateway_event_con_healthcheck, lambda_context
):
    get_api_gateway_event_con_healthcheck[
        "path"
    ] = "/v1/deals/dealRefId/contract/contractRefId/verify"
    event = get_api_gateway_event_con_healthcheck
    response = producer.verify_contract(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps("Operational")


def test_con_verify_app_missing_deal_ref_id(
    contract_verify_payload,
    get_api_gateway_event_con_verify_app_without_ca,
    expected_missing_deal_ref_id,
    lambda_context,
    response_header,
    uuid_provided,
):
    event = get_api_gateway_event_con_verify_app_without_ca(contract_verify_payload)
    del event["pathParameters"]["dealRefId"]
    response = producer.verify_contract(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(expected_missing_deal_ref_id)

    assert response["headers"] == response_header(uuid_provided)


def test_con_verify_app_missing_lender_id(
    contract_verify_payload,
    get_api_gateway_event_con_verify_app_without_ca,
    lambda_context,
    response_header,
    uuid_provided,
    mock_validate_reference_ids,
    monkeypatch,
):
    monkeypatch.setattr(
        producer.ExistingDealValidator,
        "validate_reference_ids",
        mock_validate_reference_ids,
    )
    contract_verify_payload["financeMethod"] = "Finance"
    event = get_api_gateway_event_con_verify_app_without_ca(contract_verify_payload)
    event["headers"].pop("lenderId")
    response = producer.verify_contract(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.ACCEPTED
    assert response["body"] == json.dumps({"message": "Accepted"})
    assert response["headers"] == response_header(uuid_provided)


def test_con_verify_app_invalid_deal_ref_id(
    contract_verify_payload,
    get_api_gateway_event_con_verify_app_without_ca,
    expected_invalid_deal_ref_id,
    mock_query_pk_filter_verify_or_sign_contract,
    lambda_context,
    response_header,
    uuid_provided,
    monkeypatch,
):
    monkeypatch.setattr(
        DynamoDbHelper,
        "query_pk_filter",
        mock_query_pk_filter_verify_or_sign_contract,
    )
    event = get_api_gateway_event_con_verify_app_without_ca(contract_verify_payload)
    event["pathParameters"]["dealRefId"] = "hhh78w5"
    response = producer.verify_contract(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(expected_invalid_deal_ref_id)

    assert response["headers"] == response_header(uuid_provided)


def test_con_verify_app_invalid_contract_ref_id(
    contract_verify_payload,
    get_api_gateway_event_con_verify_app_without_ca,
    expected_invalid_contract_ref_id,
    lambda_context,
    response_header,
    uuid_provided,
):
    event = get_api_gateway_event_con_verify_app_without_ca(contract_verify_payload)
    event["pathParameters"]["contractRefId"] = "nnnn"
    event["pathParameters"]["dealRefId"] = "01E3AK55DC17CPZ02VXMH62HEQ"
    response = producer.verify_contract(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(expected_invalid_contract_ref_id)

    assert response["headers"] == response_header(uuid_provided)


def test_con_sign_app_successful(
    contract_sign_payload,
    get_api_gateway_event_con_sign_without_ca,
    uuid_provided,
    response_header,
    lambda_context,
    dr_ulid_new,
    dr_ulid,
    monkeypatch,
    mock_validate_reference_ids,
):
    monkeypatch.setattr(
        producer.ExistingDealValidator,
        "validate_reference_ids",
        mock_validate_reference_ids,
    )
    event = get_api_gateway_event_con_sign_without_ca(contract_sign_payload)
    response = producer.sign_contract(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.ACCEPTED
    assert response["body"] == json.dumps({"message": "Accepted"})
    assert response["headers"] == response_header(uuid_provided)


def test_con_sign_app_fail_no_body(
    get_api_gateway_event_con_sign_without_ca,
    uuid_provided,
    response_header,
    lambda_context,
):
    event = get_api_gateway_event_con_sign_without_ca("")
    response = producer.sign_contract(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["headers"] == response_header(uuid_provided)


def test_con_sign_app_missing_deal_ref_id(
    contract_sign_payload,
    get_api_gateway_event_con_sign_without_ca,
    expected_missing_deal_ref_id,
    lambda_context,
    response_header,
    uuid_provided,
):
    event = get_api_gateway_event_con_sign_without_ca(contract_sign_payload)
    del event["pathParameters"]["dealRefId"]
    response = producer.sign_contract(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(expected_missing_deal_ref_id)

    assert response["headers"] == response_header(uuid_provided)


def test_con_sign_app_invalid_deal_ref_id(
    contract_sign_payload,
    get_api_gateway_event_con_sign_without_ca,
    expected_invalid_deal_ref_id,
    mock_query_pk_filter_verify_or_sign_contract,
    lambda_context,
    response_header,
    uuid_provided,
    monkeypatch,
):
    monkeypatch.setattr(
        DynamoDbHelper,
        "query_pk_filter",
        mock_query_pk_filter_verify_or_sign_contract,
    )
    event = get_api_gateway_event_con_sign_without_ca(contract_sign_payload)
    event["pathParameters"]["dealRefId"] = "hhh78w5"
    response = producer.sign_contract(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(expected_invalid_deal_ref_id)

    assert response["headers"] == response_header(uuid_provided)


def test_con_sign_app_invalid_contract_ref_id(
    contract_sign_payload,
    get_api_gateway_event_con_sign_without_ca,
    expected_invalid_contract_ref_id,
    lambda_context,
    response_header,
    uuid_provided,
):
    event = get_api_gateway_event_con_sign_without_ca(contract_sign_payload)
    event["pathParameters"]["contractRefId"] = "nnnn"
    event["pathParameters"]["dealRefId"] = "01E3AK55DC17CPZ02VXMH62HEQ"
    response = producer.sign_contract(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(expected_invalid_contract_ref_id)

    assert response["headers"] == response_header(uuid_provided)


def test_con_sign_app_fail_json_decoder(
    get_api_gateway_invalid_event, uuid_provided, response_header, lambda_context
):
    event = get_api_gateway_invalid_event
    response = producer.sign_contract(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["headers"] == response_header(uuid_provided)


def test_con_sign_app_health_check(
    get_api_gateway_event_con_healthcheck, lambda_context
):
    get_api_gateway_event_con_healthcheck[
        "path"
    ] = "/v1/deals/dealRefId/contract/contractRefId/sign"
    event = get_api_gateway_event_con_healthcheck
    response = producer.sign_contract(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps("Operational")


def test_contract_deal_status_successful(
    contract_deal_status_payload,
    get_api_gateway_event_con_deal_status,
    uuid_provided,
    response_header,
    lambda_context,
    dr_ulid_new,
    dr_ulid,
    monkeypatch,
    mock_validate_reference_ids,
):
    monkeypatch.setattr(
        producer.ExistingDealValidator,
        "validate_reference_ids",
        mock_validate_reference_ids,
    )
    event = get_api_gateway_event_con_deal_status(contract_deal_status_payload)
    response = producer.contract_deal_status(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.ACCEPTED
    assert response["body"] == json.dumps({"message": "Accepted"})
    assert response["headers"] == response_header(uuid_provided)


def test_contract_deal_status_fail_no_body(
    get_api_gateway_event_con_deal_status,
    uuid_provided,
    response_header,
    lambda_context,
):
    event = get_api_gateway_event_con_deal_status("")
    response = producer.contract_deal_status(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["headers"] == response_header(uuid_provided)


def test_contract_deal_status_missing_deal_ref_id(
    contract_deal_status_payload,
    get_api_gateway_event_con_deal_status,
    expected_missing_deal_ref_id,
    lambda_context,
    response_header,
    uuid_provided,
):
    event = get_api_gateway_event_con_deal_status(contract_deal_status_payload)
    del event["pathParameters"]["dealRefId"]
    response = producer.contract_deal_status(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(expected_missing_deal_ref_id)

    assert response["headers"] == response_header(uuid_provided)


def test_contract_deal_status_missing_contract_ref_id(
    contract_deal_status_payload,
    get_api_gateway_event_con_deal_status,
    expected_update_deal_status_missing_contract_ref_id,
    lambda_context,
    response_header,
    uuid_provided,
):
    event = get_api_gateway_event_con_deal_status(contract_deal_status_payload)
    del event["pathParameters"]["contractRefId"]
    response = producer.contract_deal_status(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(
        expected_update_deal_status_missing_contract_ref_id
    )

    assert response["headers"] == response_header(uuid_provided)


def test_contract_deal_status_invalid_deal_ref_id(
    contract_deal_status_payload,
    get_api_gateway_event_con_deal_status,
    expected_invalid_deal_ref_id,
    mock_query_pk_filter_verify_or_sign_contract,
    lambda_context,
    response_header,
    uuid_provided,
    monkeypatch,
):
    monkeypatch.setattr(
        DynamoDbHelper,
        "query_pk_filter",
        mock_query_pk_filter_verify_or_sign_contract,
    )
    event = get_api_gateway_event_con_deal_status(contract_deal_status_payload)
    event["pathParameters"]["dealRefId"] = "hhh78w5"
    response = producer.contract_deal_status(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(expected_invalid_deal_ref_id)

    assert response["headers"] == response_header(uuid_provided)


def test_contract_deal_status_fail_json_decoder(
    get_api_gateway_invalid_event, uuid_provided, response_header, lambda_context
):
    event = get_api_gateway_invalid_event
    response = producer.contract_deal_status(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["headers"] == response_header(uuid_provided)


def test_contract_deal_status_health_check(
    get_api_gateway_event_con_healthcheck, lambda_context
):
    get_api_gateway_event_con_healthcheck[
        "path"
    ] = "/v1/deals/{dealRefId}/contract/{contractRefId}/status"
    event = get_api_gateway_event_con_healthcheck
    response = producer.contract_deal_status(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps("Operational")


def test_contract_cancel_successful(
    contract_cancel_payload,
    get_api_gateway_event_con_cancel,
    uuid_provided,
    response_header,
    lambda_context,
    dr_ulid_new,
    dr_ulid,
    monkeypatch,
    mock_validate_reference_ids,
):
    monkeypatch.setattr(
        producer.ExistingDealValidator,
        "validate_reference_ids",
        mock_validate_reference_ids,
    )
    event = get_api_gateway_event_con_cancel(contract_cancel_payload)
    response = producer.contract_cancel(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.ACCEPTED
    assert response["body"] == json.dumps({"message": "Accepted"})
    assert response["headers"] == response_header(uuid_provided)


def test_contract_cancel_fail_no_body(
    get_api_gateway_event_con_cancel,
    uuid_provided,
    response_header,
    lambda_context,
):
    event = get_api_gateway_event_con_cancel("")
    response = producer.contract_cancel(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["headers"] == response_header(uuid_provided)


def test_contract_cancel_missing_deal_ref_id(
    contract_cancel_payload,
    get_api_gateway_event_con_cancel,
    expected_missing_deal_ref_id,
    lambda_context,
    response_header,
    uuid_provided,
):
    event = get_api_gateway_event_con_cancel(contract_cancel_payload)
    del event["pathParameters"]["dealRefId"]
    response = producer.contract_cancel(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(expected_missing_deal_ref_id)

    assert response["headers"] == response_header(uuid_provided)


def test_contract_cancel_missing_contract_ref_id(
    contract_cancel_payload,
    get_api_gateway_event_con_cancel,
    expected_update_deal_status_missing_contract_ref_id,
    lambda_context,
    response_header,
    uuid_provided,
):
    event = get_api_gateway_event_con_cancel(contract_cancel_payload)
    del event["pathParameters"]["contractRefId"]
    response = producer.contract_cancel(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(
        expected_update_deal_status_missing_contract_ref_id
    )

    assert response["headers"] == response_header(uuid_provided)


def test_contract_cancel_invalid_deal_ref_id(
    contract_cancel_payload,
    get_api_gateway_event_con_cancel,
    expected_invalid_deal_ref_id,
    mock_query_pk_filter_verify_or_sign_contract,
    lambda_context,
    response_header,
    uuid_provided,
    monkeypatch,
):
    monkeypatch.setattr(
        DynamoDbHelper,
        "query_pk_filter",
        mock_query_pk_filter_verify_or_sign_contract,
    )
    event = get_api_gateway_event_con_cancel(contract_cancel_payload)
    event["pathParameters"]["dealRefId"] = "hhh78w5"
    response = producer.contract_cancel(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(expected_invalid_deal_ref_id)

    assert response["headers"] == response_header(uuid_provided)


def test_contract_cancel_fail_json_decoder(
    get_api_gateway_invalid_event, uuid_provided, response_header, lambda_context
):
    event = get_api_gateway_invalid_event
    response = producer.contract_cancel(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["headers"] == response_header(uuid_provided)


def test_contract_cancel_health_check(
    get_api_gateway_event_con_healthcheck, lambda_context
):
    get_api_gateway_event_con_healthcheck[
        "path"
    ] = "/v1/deals/{dealRefId}/contract/{contractRefId}/cancel"
    event = get_api_gateway_event_con_healthcheck
    response = producer.contract_cancel(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps("Operational")
