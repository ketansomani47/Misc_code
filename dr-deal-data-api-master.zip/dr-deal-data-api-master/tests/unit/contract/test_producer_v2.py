# -*- coding: utf-8 -*-
import json
from http import HTTPStatus

from common.settings import CORRELATION_ID_HEADER_KEY, ErrorMsgs
from contract import producer_v2
from utils.db_helper import DynamoDbHelper


def test_con_create_successful(
    contract_v2_payload,
    sqs,
    get_api_gateway_event_con,
    uuid_provided,
    response_header,
    lambda_context,
    dr_ulid_new,
    dr_ulid,
    monkeypatch,
    mock_validate_reference_ids,
):
    event = get_api_gateway_event_con(contract_v2_payload)
    response = producer_v2.create_contract(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.ACCEPTED
    assert response["body"] == json.dumps({"message": "Accepted"})
    assert response["headers"] == response_header(uuid_provided)


def test_con_create_successful_no_correlation_id(
    contract_v2_payload,
    sqs,
    get_api_gateway_event_con,
    uuid_newly_generated,
    response_header,
    lambda_context,
    dr_ulid_new,
    dr_ulid,
    monkeypatch,
    mock_validate_reference_ids,
):
    event = get_api_gateway_event_con(contract_v2_payload)
    event["headers"].pop(CORRELATION_ID_HEADER_KEY)

    response = producer_v2.create_contract(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.ACCEPTED
    assert response["body"] == json.dumps({"message": "Accepted"})
    assert response["headers"] == response_header(uuid_newly_generated)


def test_con_create_successful_cash_no_lender_id(
    contract_v2_payload,
    sqs,
    get_api_gateway_event_con,
    uuid_provided,
    response_header,
    lambda_context,
    dr_ulid_new,
    dr_ulid,
    monkeypatch,
    mock_validate_reference_ids,
):
    contract_v2_payload["financeMethod"] = "Cash"
    event = get_api_gateway_event_con(contract_v2_payload)
    event["headers"].pop("lenderId")

    response = producer_v2.create_contract(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.ACCEPTED
    assert response["body"] == json.dumps({"message": "Accepted"})
    assert response["headers"] == response_header(uuid_provided)


def test_con_create_missing_lender_id(
    contract_v2_payload,
    get_api_gateway_event_con,
    lambda_context,
    response_header,
    uuid_provided,
    mock_validate_reference_ids,
    monkeypatch,
    dr_ulid_new,
    dr_ulid,
):
    contract_v2_payload["financeMethod"] = "Finance"
    event = get_api_gateway_event_con(contract_v2_payload)
    event["headers"].pop("lenderId")
    response = producer_v2.create_contract(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.ACCEPTED
    assert response["body"] == json.dumps({"message": "Accepted"})
    assert response["headers"] == response_header(uuid_provided)


def test_con_create_fail_no_body(
    get_api_gateway_event_con,
    uuid_provided,
    response_header,
    lambda_context,
):
    event = get_api_gateway_event_con("")
    response = producer_v2.create_contract(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps({"message": ErrorMsgs.missing_body_aws_event})
    assert response["headers"] == response_header(uuid_provided)


def test_con_create_fail_json_decoder(
    get_api_gateway_invalid_event, uuid_provided, response_header, lambda_context
):
    event = get_api_gateway_invalid_event
    response = producer_v2.create_contract(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["headers"] == response_header(uuid_provided)


def test_con_new_app_health_check(
    get_api_gateway_event_con_healthcheck, lambda_context
):
    event = get_api_gateway_event_con_healthcheck
    response = producer_v2.create_contract(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps("Operational")


def test_con_verify_app_successful(
    contract_verify_payload,
    get_api_gateway_event_con_verify_app_without_ca,
    uuid_provided,
    response_header,
    lambda_context,
    monkeypatch,
    mock_validate_reference_ids,
):
    event = get_api_gateway_event_con_verify_app_without_ca(contract_verify_payload)
    response = producer_v2.verify_contract(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.ACCEPTED
    assert response["body"] == json.dumps({"message": "Accepted"})
    assert response["headers"] == response_header(uuid_provided)


def test_con_verify_app_successful_cash_with_no_lender_id(
    contract_verify_payload,
    get_api_gateway_event_con_verify_app_without_ca,
    uuid_provided,
    response_header,
    lambda_context,
    monkeypatch,
    mock_validate_reference_ids,
):
    contract_verify_payload["financeMethod"] = "Cash"
    event = get_api_gateway_event_con_verify_app_without_ca(contract_verify_payload)
    event["headers"].pop("lenderId")

    response = producer_v2.verify_contract(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.ACCEPTED
    assert response["body"] == json.dumps({"message": "Accepted"})
    assert response["headers"] == response_header(uuid_provided)


def test_con_verify_app_fail_no_body(
    get_api_gateway_event_con_verify_app_without_ca,
    uuid_provided,
    response_header,
    lambda_context,
    expected_missing_body,
):
    event = get_api_gateway_event_con_verify_app_without_ca("")
    response = producer_v2.verify_contract(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(expected_missing_body)
    assert response["headers"] == response_header(uuid_provided)


def test_con_verify_app_fail_json_decoder(
    get_api_gateway_invalid_event, uuid_provided, response_header, lambda_context
):
    event = get_api_gateway_invalid_event
    response = producer_v2.verify_contract(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["headers"] == response_header(uuid_provided)


def test_con_verify_app_health_check(
    get_api_gateway_event_con_healthcheck, lambda_context
):
    get_api_gateway_event_con_healthcheck[
        "path"
    ] = "/v2/deals/dealRefId/contract/verify"
    event = get_api_gateway_event_con_healthcheck
    response = producer_v2.verify_contract(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps("Operational")


def test_con_verify_app_missing_deal_ref_id(
    contract_verify_payload,
    get_api_gateway_event_con_verify_app_without_ca,
    expected_missing_deal_ref_id,
    lambda_context,
    response_header,
    uuid_provided,
):
    event = get_api_gateway_event_con_verify_app_without_ca(contract_verify_payload)
    del event["pathParameters"]["dealRefId"]
    response = producer_v2.verify_contract(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(expected_missing_deal_ref_id)

    assert response["headers"] == response_header(uuid_provided)


def test_con_verify_app_missing_lender_id(
    contract_verify_payload,
    get_api_gateway_event_con_verify_app_without_ca,
    lambda_context,
    response_header,
    uuid_provided,
    mock_validate_reference_ids,
    monkeypatch,
):
    contract_verify_payload["financeMethod"] = "Finance"
    event = get_api_gateway_event_con_verify_app_without_ca(contract_verify_payload)
    event["headers"].pop("lenderId")
    response = producer_v2.verify_contract(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.ACCEPTED
    assert response["body"] == json.dumps({"message": "Accepted"})
    assert response["headers"] == response_header(uuid_provided)


def test_con_verify_app_invalid_deal_ref_id(
    contract_verify_payload,
    get_api_gateway_event_con_verify_app_without_ca,
    expected_invalid_deal_ref_id,
    mock_query_pk_filter_verify_or_sign_contract,
    lambda_context,
    response_header,
    uuid_provided,
    monkeypatch,
):
    monkeypatch.setattr(
        DynamoDbHelper,
        "query_pk_filter",
        mock_query_pk_filter_verify_or_sign_contract,
    )
    event = get_api_gateway_event_con_verify_app_without_ca(contract_verify_payload)
    event["pathParameters"]["dealRefId"] = "hhh78w5"
    response = producer_v2.verify_contract(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(expected_invalid_deal_ref_id)
    assert response["headers"] == response_header(uuid_provided)


def test_standalone_con_sign_app_successful(
    contract_sign_payload,
    get_api_gateway_event_standalone_con_sign,
    uuid_provided,
    response_header,
    lambda_context,
    dr_ulid_new,
    dr_ulid,
    monkeypatch,
    mock_validate_reference_ids,
):
    monkeypatch.setattr(
        producer_v2.ExistingDealValidator,
        "validate_reference_ids",
        mock_validate_reference_ids,
    )
    event = get_api_gateway_event_standalone_con_sign(contract_sign_payload)
    response = producer_v2.standalone_sign_contract(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.ACCEPTED
    assert response["body"] == json.dumps({"message": "Accepted"})
    assert response["headers"] == response_header(uuid_provided)


def test_standalone_con_sign_app_fail_no_body(
    get_api_gateway_event_standalone_con_sign,
    uuid_provided,
    response_header,
    lambda_context,
):
    event = get_api_gateway_event_standalone_con_sign("")
    response = producer_v2.standalone_sign_contract(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["headers"] == response_header(uuid_provided)


def test_standalone_con_sign_app_missing_deal_ref_id(
    contract_sign_payload,
    get_api_gateway_event_standalone_con_sign,
    expected_missing_deal_ref_id,
    lambda_context,
    response_header,
    uuid_provided,
):
    event = get_api_gateway_event_standalone_con_sign(contract_sign_payload)
    del event["pathParameters"]["dealRefId"]
    response = producer_v2.standalone_sign_contract(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(expected_missing_deal_ref_id)

    assert response["headers"] == response_header(uuid_provided)


def test_standalone_con_sign_app_fail_json_decoder(
    get_api_gateway_invalid_event, uuid_provided, response_header, lambda_context
):
    event = get_api_gateway_invalid_event
    response = producer_v2.standalone_sign_contract(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["headers"] == response_header(uuid_provided)


def test_standalone_con_sign_app_health_check(
    get_api_gateway_event_con_healthcheck, lambda_context
):
    get_api_gateway_event_con_healthcheck["path"] = "/v2/deals/dealRefId/contract/sign"
    event = get_api_gateway_event_con_healthcheck
    response = producer_v2.standalone_sign_contract(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps("Operational")


def test_standalone_con_sign_app_invalid_deal_ref_id(
    contract_sign_payload,
    get_api_gateway_event_standalone_con_sign,
    expected_invalid_deal_ref_id,
    mock_query_pk_filter_verify_or_sign_contract,
    lambda_context,
    response_header,
    uuid_provided,
    monkeypatch,
):
    monkeypatch.setattr(
        DynamoDbHelper,
        "query_pk_filter",
        mock_query_pk_filter_verify_or_sign_contract,
    )
    event = get_api_gateway_event_standalone_con_sign(contract_sign_payload)
    event["pathParameters"]["dealRefId"] = "hhh78w5"
    response = producer_v2.standalone_sign_contract(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(expected_invalid_deal_ref_id)

    assert response["headers"] == response_header(uuid_provided)


def test_contract_cancel_successful(
    contract_cancel_payload,
    get_api_gateway_event_con_cancel,
    uuid_provided,
    response_header,
    lambda_context,
    dr_ulid_new,
    dr_ulid,
    monkeypatch,
    mock_validate_reference_ids,
):
    monkeypatch.setattr(
        producer_v2.ExistingDealValidator,
        "validate_reference_ids",
        mock_validate_reference_ids,
    )
    event = get_api_gateway_event_con_cancel(contract_cancel_payload)
    response = producer_v2.cancel_contract(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.ACCEPTED
    assert response["body"] == json.dumps({"message": "Accepted"})
    assert response["headers"] == response_header(uuid_provided)


def test_contract_cancel_fail_no_body(
    get_api_gateway_event_con_cancel,
    uuid_provided,
    response_header,
    lambda_context,
):
    event = get_api_gateway_event_con_cancel("")
    response = producer_v2.cancel_contract(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["headers"] == response_header(uuid_provided)


def test_contract_cancel_missing_deal_ref_id(
    contract_cancel_payload,
    get_api_gateway_event_con_cancel,
    expected_missing_deal_ref_id,
    lambda_context,
    response_header,
    uuid_provided,
):
    event = get_api_gateway_event_con_cancel(contract_cancel_payload)
    del event["pathParameters"]["dealRefId"]
    response = producer_v2.cancel_contract(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(expected_missing_deal_ref_id)

    assert response["headers"] == response_header(uuid_provided)


def test_contract_cancel_invalid_deal_ref_id(
    contract_cancel_payload,
    get_api_gateway_event_con_cancel,
    expected_invalid_deal_ref_id,
    mock_query_pk_filter_verify_or_sign_contract,
    lambda_context,
    response_header,
    uuid_provided,
    monkeypatch,
):
    monkeypatch.setattr(
        DynamoDbHelper,
        "query_pk_filter",
        mock_query_pk_filter_verify_or_sign_contract,
    )
    event = get_api_gateway_event_con_cancel(contract_cancel_payload)
    event["pathParameters"]["dealRefId"] = "hhh78w5"
    response = producer_v2.cancel_contract(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(expected_invalid_deal_ref_id)

    assert response["headers"] == response_header(uuid_provided)


def test_contract_cancel_fail_json_decoder(
    get_api_gateway_invalid_event, uuid_provided, response_header, lambda_context
):
    event = get_api_gateway_invalid_event
    response = producer_v2.cancel_contract(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["headers"] == response_header(uuid_provided)


def test_contract_cancel_health_check(
    get_api_gateway_event_con_healthcheck, lambda_context
):
    get_api_gateway_event_con_healthcheck[
        "path"
    ] = "/v2/deals/{dealRefId}/contract/cancel"
    event = get_api_gateway_event_con_healthcheck
    response = producer_v2.cancel_contract(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps("Operational")
