# -*- coding: utf-8 -*-
import copy
import json
from http import HTTPStatus

from common import settings
from common.settings import ErrorMsgs
from common.validators import BaseValidator
from credit_bureau import producer
from utils.db_helper import DynamoDbHelper


def test_cb_generic_error_cb_pull(
    monkeypatch,
    lambda_context,
    credit_bureau_full_payload,
    get_api_gateway_cb_event_new_deal,
    uuid_provided,
    response_header,
):
    def raise_error(self, *args, **kwargs):
        raise Exception("test exception")

    event = get_api_gateway_cb_event_new_deal(credit_bureau_full_payload)
    monkeypatch.setattr(BaseValidator, "__init__", raise_error)

    test_subjects = [producer.cb_new_deal, producer.cb_existing_deal]

    for test_subject in test_subjects:
        print(repr(test_subject))
        response = test_subject(event, lambda_context)
        assert response["statusCode"] == HTTPStatus.INTERNAL_SERVER_ERROR
        assert response["body"] == json.dumps({"message": "test exception"})
        assert response["headers"] == response_header(uuid_provided)


def test_cb_generic_error_cb_response(
    monkeypatch,
    lambda_context,
    credit_bureau_event_payload,
    get_api_gateway_credit_bureau_event,
    uuid_provided,
    response_header,
):
    def raise_error(self, *args, **kwargs):
        raise Exception("test exception")

    event = get_api_gateway_credit_bureau_event(credit_bureau_event_payload)
    monkeypatch.setattr(BaseValidator, "__init__", raise_error)
    response = producer.cb_response(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.INTERNAL_SERVER_ERROR
    assert response["body"] == json.dumps({"message": "test exception"})
    assert response["headers"] == response_header(uuid_provided)


def test_cb_new_deal_successful(
    credit_bureau_full_payload,
    sqs,
    get_api_gateway_cb_event_new_deal,
    uuid_provided,
    response_header,
    lambda_context,
):
    event = get_api_gateway_cb_event_new_deal(credit_bureau_full_payload)

    response = producer.cb_new_deal(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps(
        {
            "dealRefId": "0000000000AAABBBCCDDEEFFGG",
            "creditBureauRefId": "1111111111AAABBBCCDDEEFFGG",
        }
    )
    assert response["headers"] == response_header(uuid_provided)


def test_cb_new_deal_no_header(
    sqs,
    uuid_newly_generated,
    response_header,
    get_api_gateway_cb_event_new_deal,
    lambda_context,
):
    event = get_api_gateway_cb_event_new_deal("")
    event.pop("headers")
    response = producer.cb_new_deal(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(
        {"message": "No Credit-Bureau-Reference-Id header provided"}
    )
    assert response["headers"] == response_header(uuid_newly_generated)


def test_cb_new_deal_no_body(
    sqs,
    uuid_provided,
    response_header,
    get_api_gateway_cb_event_new_deal,
    lambda_context,
):
    event = get_api_gateway_cb_event_new_deal("")
    response = producer.cb_new_deal(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps({"message": ErrorMsgs.missing_body_aws_event})
    assert response["headers"] == response_header(uuid_provided)


def test_cb_new_deal_json_decoder_error(
    sqs,
    get_credit_bureau_api_gateway_invalid_event,
    uuid_provided,
    response_header,
    lambda_context,
):
    event = get_credit_bureau_api_gateway_invalid_event("credit_bureau_full_payload")
    event["path"] = "/v1/deals/credit-bureaus"
    response = producer.cb_new_deal(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["headers"] == response_header(uuid_provided)


def test_cb_new_deal_health_check(lambda_context):
    event = {
        "headers": {
            settings.HEALTHCHECK_HEADER_FIELD: settings.HEALTHCHECK_HEADER_VALUE
        },
        "path": "/v1/deals/credit-bureaus",
    }
    response = producer.cb_new_deal(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps("Operational")


def test_cb_new_deal_exception(
    credit_bureau_event_payload,
    get_api_gateway_credit_bureau_event,
    response_header,
    monkeypatch,
    db_query_items,
    return_exception,
    lambda_context,
):
    event = get_api_gateway_credit_bureau_event(credit_bureau_event_payload)
    event["path"] = "/v1/deals/credit-bureaus"
    monkeypatch.setattr(DynamoDbHelper, "query_items", db_query_items)
    monkeypatch.setattr(producer, "BodyValidator", return_exception)

    response = producer.cb_new_deal(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.INTERNAL_SERVER_ERROR
    assert response["body"] == json.dumps({"message": "error"})


def test_cb_existing_deal_successful(
    credit_bureau_full_payload,
    sqs,
    get_api_gateway_credit_bureau_event,
    uuid_newly_generated,
    response_header,
    monkeypatch,
    db_query_dtc_deal,
    lambda_context,
):

    event = get_api_gateway_credit_bureau_event(credit_bureau_full_payload)
    event["path"] = "/v1/deals/dealRefId/credit-bureaus"
    event["pathParameters"] = {"dealRefId": "0000000000AAABBBCCDDEEFFGG"}

    monkeypatch.setattr(DynamoDbHelper, "query_items", db_query_dtc_deal)
    response = producer.cb_existing_deal(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps(
        {
            "dealRefId": "0000000000AAABBBCCDDEEFFGG",
            "creditBureauRefId": "1111111111AAABBBCCDDEEFFGG",
        }
    )


def test_cb_existing_deal_duplicate_cb_pull_id(
    credit_bureau_full_payload,
    sqs,
    get_api_gateway_cb_event_existing_deal,
    uuid_newly_generated,
    response_header,
    monkeypatch,
    db_query_items,
    lambda_context,
):

    event = get_api_gateway_cb_event_existing_deal(credit_bureau_full_payload)

    monkeypatch.setattr(DynamoDbHelper, "query_items", db_query_items)
    response = producer.cb_existing_deal(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(
        {
            "message": "You have tired to post to an endpoint for which the resource already exists."
        }
    )


def test_cb_existing_deal_no_header(
    sqs,
    uuid_newly_generated,
    response_header,
    monkeypatch,
    db_query_items,
    lambda_context,
):

    event = {
        "path": "/v1/deals/dealRefId/credit-bureaus",
        "pathParameters": {"dealRefId": "0000000000AAABBBCCDDEEFFGG"},
    }

    monkeypatch.setattr(DynamoDbHelper, "query_items", db_query_items)

    response = producer.cb_existing_deal(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(
        {"message": "No Credit-Bureau-Reference-Id header provided"}
    )
    assert response["headers"] == response_header(uuid_newly_generated)


def test_cb_existing_deal_no_body(sqs, uuid_provided, response_header, lambda_context):
    event = {
        "headers": {
            settings.CORRELATION_ID_HEADER_KEY: "12345abc-abc1-2def-56ef-000000000000",
            settings.CB_PULL_HEADER_KEY: "0000000000AAABBBCCDDEEFFGG",
        },
        "path": "/v1/deals/dealRefId/credit-bureaus",
    }
    response = producer.cb_existing_deal(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps({"message": "dealRefId not provided"})
    assert response["headers"] == response_header(uuid_provided)


def test_cb_existing_deal_json_decoder_error(
    sqs,
    get_credit_bureau_api_gateway_invalid_event,
    uuid_provided,
    response_header,
    lambda_context,
):
    event = get_credit_bureau_api_gateway_invalid_event("credit_bureau_full_payload")
    event["path"] = "/v1/deals/dealRefId/credit-bureaus"
    response = producer.cb_existing_deal(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["headers"] == response_header(uuid_provided)


def test_cb_existing_deal_health_check(lambda_context):
    event = {
        "headers": {
            settings.HEALTHCHECK_HEADER_FIELD: settings.HEALTHCHECK_HEADER_VALUE
        },
        "path": "/v1/deals/dealRefId/credit-bureaus",
    }
    response = producer.cb_existing_deal(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps("Operational")


def test_cb_existing_deal_bad_json_decoder_error(
    lambda_context, get_api_gateway_cb_event_existing_deal_with_bad_json
):
    """
    Test verifies with some string as payload should raise Json decoder error
    """
    event = get_api_gateway_cb_event_existing_deal_with_bad_json

    response = producer.cb_existing_deal(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(
        {"message": "Expecting value: line 1 column 1 (char 0)"}
    )


def test_cb_response_post_successful(
    credit_bureau_event_payload,
    sqs,
    get_api_gateway_credit_bureau_event,
    uuid_provided,
    response_header,
    monkeypatch,
    db_query_items,
    lambda_context,
    get_mock_existing_deal_validator,
):
    event = get_api_gateway_credit_bureau_event(credit_bureau_event_payload)

    monkeypatch.setattr(DynamoDbHelper, "query_items", db_query_items)
    MockExistingDealValidator = get_mock_existing_deal_validator(
        credit_bureau_event_payload
    )
    monkeypatch.setattr(producer, "ExistingDealValidator", MockExistingDealValidator)

    response = producer.cb_response(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps(
        {
            "dealRefId": "0000000000AAABBBCCDDEEFFGG",
            "creditBureauRefId": "1111111111AAABBBCCDDEEFF22",
        }
    )
    assert response["headers"] == response_header(uuid_provided)


def test_cb_response_post_validation_fail(
    credit_bureau_event_bad_payload,
    get_api_gateway_credit_bureau_event,
    response_header,
    monkeypatch,
    db_query_items,
    lambda_context,
):
    """
    Test to verifies cb response payload fails verification for existing cb_pull_id
    """
    event = get_api_gateway_credit_bureau_event(credit_bureau_event_bad_payload)

    monkeypatch.setattr(DynamoDbHelper, "query_items", db_query_items)

    response = producer.cb_response(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(
        {
            "message": "You have tired to post to an endpoint for which the resource doesn't exists."
        }
    )


def test_cb_response_post_no_event_body(
    sqs,
    uuid_provided,
    response_header,
    credit_bureau_empty_event_payload,
    get_api_gateway_credit_bureau_event,
    lambda_context,
    get_mock_existing_deal_validator,
    monkeypatch,
):
    event = get_api_gateway_credit_bureau_event(credit_bureau_empty_event_payload)
    event["path"] = "/v1/deals/dealRefID/credit-bureau-response"
    MockExistingDealValidator = get_mock_existing_deal_validator(
        credit_bureau_empty_event_payload
    )
    monkeypatch.setattr(producer, "ExistingDealValidator", MockExistingDealValidator)

    response = producer.cb_response(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps({"message": ErrorMsgs.missing_event_payload})


def test_cb_response_post_json_decoder_error(
    sqs,
    get_credit_bureau_api_gateway_invalid_event,
    uuid_provided,
    response_header,
    lambda_context,
):
    event = get_credit_bureau_api_gateway_invalid_event("credit_bureau_full_payload")
    event["path"] = "/v1/deals/dealRefID/credit-bureau-response"
    response = producer.cb_response(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST


def test_cb_response_post_health_check(lambda_context):
    event = {
        "headers": {
            settings.HEALTHCHECK_HEADER_FIELD: settings.HEALTHCHECK_HEADER_VALUE
        },
        "path": "/v1/deals/dealRefID/credit-bureau-response",
    }
    response = producer.cb_response(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.CREATED
    assert response["body"] == json.dumps("Operational")


def test_cb_response_post_exception(
    credit_bureau_event_payload,
    sqs,
    get_api_gateway_credit_bureau_event,
    uuid_provided,
    response_header,
    monkeypatch,
    db_query_items,
    return_exception,
    lambda_context,
):
    event = get_api_gateway_credit_bureau_event(credit_bureau_event_payload)
    event["path"] = "/v1/deals/dealRefID/credit-bureau-response"
    monkeypatch.setattr(DynamoDbHelper, "query_items", db_query_items)
    monkeypatch.setattr(producer, "ExistingDealValidator", return_exception)

    response = producer.cb_response(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.INTERNAL_SERVER_ERROR
    assert response["body"] == json.dumps({"message": "error"})


def test_cb_response_post_no_cb_pull_id(
    sqs,
    uuid_provided,
    response_header,
    credit_bureau_event_payload,
    get_api_gateway_credit_bureau_event,
    monkeypatch,
    db_query_items,
    lambda_context,
):
    payload = copy.deepcopy(credit_bureau_event_payload)
    payload.pop("eventTransactionId")
    event = get_api_gateway_credit_bureau_event(payload)
    event["path"] = "/v1/deals/dealRefID/credit-bureau-response"
    monkeypatch.setattr(DynamoDbHelper, "query_items", db_query_items)

    response = producer.cb_response(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps({"message": ErrorMsgs.missing_transaction_id})


def test_cb_response_post_no_deal_ref_id(
    sqs,
    uuid_provided,
    response_header,
    credit_bureau_event_payload,
    get_api_gateway_credit_bureau_event,
    monkeypatch,
    db_query_items,
    lambda_context,
):
    payload = copy.deepcopy(credit_bureau_event_payload)
    payload["eventKeyData"].pop("dealRefId")
    event = get_api_gateway_credit_bureau_event(payload)
    event["path"] = "/v1/deals/dealRefID/credit-bureau-response"
    monkeypatch.setattr(DynamoDbHelper, "query_items", db_query_items)

    response = producer.cb_response(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps(
        {"message": ErrorMsgs.deal_ref_id_not_provided}
    )


def test_cb_response_post_no_body(
    sqs,
    uuid_provided,
    response_header,
    credit_bureau_event_payload,
    get_api_gateway_credit_bureau_event,
    monkeypatch,
    db_query_items,
    lambda_context,
):
    payload = copy.deepcopy(credit_bureau_event_payload)
    event = get_api_gateway_credit_bureau_event(payload)
    event["path"] = "/v1/deals/dealRefID/credit-bureau-response"
    event.pop("body")
    monkeypatch.setattr(DynamoDbHelper, "query_items", db_query_items)

    response = producer.cb_response(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.BAD_REQUEST
    assert response["body"] == json.dumps({"message": ErrorMsgs.missing_body_aws_event})
