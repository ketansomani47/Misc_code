# -*- coding: utf-8 -*-
import copy
import json
from decimal import Decimal

import pytest
from common import settings as se
from utils.db_helper import DynamoDbHelper


CREDIT_BUREAU_ID = "1111111111AAABBBCCDDEEFFGG"


@pytest.fixture(autouse=True)
def mock_dynamodb_helper(monkeypatch, mock_query_pk_filter):
    monkeypatch.setattr(DynamoDbHelper, "query_pk_filter", mock_query_pk_filter)


@pytest.fixture()
def extra_dynamodb_fields_credit_bureau(extra_dynamodb_fields, constant_time):
    fields = copy.copy(extra_dynamodb_fields)
    fields.update({"ttl": Decimal(constant_time + se.RetentionPeriod.credit_bureau)})
    return fields


@pytest.fixture()
def get_api_gateway_credit_bureau_event(
    uuid_provided, credit_app_partial_payload, decimal_encoder
):
    def api_gateway_event(body):
        return {
            "body": json.dumps(body, cls=decimal_encoder),
            "headers": {
                se.CORRELATION_ID_HEADER_KEY: uuid_provided,
                se.CB_PULL_HEADER_KEY: CREDIT_BUREAU_ID,
            },
            "path": "/v1/deals/dealRefId/credit-bureaus",
            "pathParameters": {"dealRefId": "0000000000AAABBBCCDDEEFFGG"},
        }

    return api_gateway_event


@pytest.fixture()
def get_api_gateway_cb_event_new_deal(get_api_gateway_event):
    def api_gateway_event(body):
        event = get_api_gateway_event(body)
        event["path"] = "/v1/deals/credit-bureaus"
        event["headers"].update({se.CB_PULL_HEADER_KEY: CREDIT_BUREAU_ID})
        event["pathParameters"] = {"dealRefId": "0000000000AAABBBCCDDEEFFGG"}
        return event

    return api_gateway_event


@pytest.fixture()
def get_api_gateway_cb_event_existing_deal(get_api_gateway_event):
    def api_gateway_event(body):
        event = get_api_gateway_event(body)
        event["path"] = "/v1/deals/dealRefId/credit-bureaus"
        event["headers"].update({se.CB_PULL_HEADER_KEY: CREDIT_BUREAU_ID})
        event["pathParameters"] = {"dealRefId": "0000000000AAABBBCCDDEEFFGG"}
        return event

    return api_gateway_event


@pytest.fixture()
def get_api_gateway_cb_event_existing_deal_with_bad_json(
    get_api_gateway_invalid_event, get_api_gateway_cb_event_existing_deal
):
    event = get_api_gateway_invalid_event
    event["path"] = "/v1/deals/dealRefId/credit-bureaus"
    event["headers"].update({se.CB_PULL_HEADER_KEY: CREDIT_BUREAU_ID})
    event["pathParameters"] = {"dealRefId": "0000000000AAABBBCCDDEEFFGG"}
    return event


@pytest.fixture()
def get_api_gateway_cb_event_response(get_api_gateway_event):
    def api_gateway_event(body):
        event = get_api_gateway_event(body)
        event["headers"] = {}
        event["path"] = "/v1/deals/dealRefID/credit-bureau-response"
        return event

    return api_gateway_event


@pytest.fixture()
def get_credit_bureau_api_gateway_invalid_event(
    uuid_provided, credit_app_partial_payload
):
    def api_gateway_event(body):
        return {
            "body": body,
            "headers": {
                se.CORRELATION_ID_HEADER_KEY: uuid_provided,
                se.CB_PULL_HEADER_KEY: CREDIT_BUREAU_ID,
            },
        }

    return api_gateway_event


@pytest.fixture()
def expected_applicant_reports(extra_dynamodb_fields_credit_bureau):
    reports = {}
    reports.update(extra_dynamodb_fields_credit_bureau)
    reports.update(
        {
            "dealComponent": f"CB.PULL.EQUIFAX.CREDITBUREAU.APPLICANT.{CREDIT_BUREAU_ID}",
            "provider": "Equifax",
            "type": "CreditBureau",
            "creditBureauRefId": CREDIT_BUREAU_ID,
        }
    )

    return reports


@pytest.fixture()
def expected_applicant_redflag_reports(extra_dynamodb_fields_credit_bureau):
    reports = {}
    reports.update(extra_dynamodb_fields_credit_bureau)
    reports.update(
        {
            "dealComponent": f"CB.PULL.EQUIFAX.REDFLAG.APPLICANT.{CREDIT_BUREAU_ID}",
            "provider": "Equifax",
            "type": "Redflag",
            "creditBureauRefId": CREDIT_BUREAU_ID,
        }
    )

    return reports


@pytest.fixture()
def expected_applicant_ofac_reports(extra_dynamodb_fields_credit_bureau):
    reports = {}
    reports.update(extra_dynamodb_fields_credit_bureau)
    reports.update(
        {
            "dealComponent": f"CB.PULL.EQUIFAX.OFAC.APPLICANT.{CREDIT_BUREAU_ID}",
            "provider": "Equifax",
            "type": "OFAC",
            "creditBureauRefId": CREDIT_BUREAU_ID,
        }
    )

    return reports


@pytest.fixture()
def expected_coapplicant_reports(extra_dynamodb_fields_credit_bureau):
    reports = {}
    reports.update(extra_dynamodb_fields_credit_bureau)
    reports.update(
        {
            "dealComponent": f"CB.PULL.EQUIFAX.SOFTPULL.COAPPLICANT.{CREDIT_BUREAU_ID}",
            "provider": "Equifax",
            "type": "SoftPull",
            "creditBureauRefId": CREDIT_BUREAU_ID,
        }
    )

    return reports


@pytest.fixture()
def expected_coapplicant_redflag_reports(extra_dynamodb_fields_credit_bureau):
    reports = {}
    reports.update(extra_dynamodb_fields_credit_bureau)
    reports.update(
        {
            "dealComponent": f"CB.PULL.EXPERIAN.REDFLAG.COAPPLICANT.{CREDIT_BUREAU_ID}",
            "provider": "Experian",
            "type": "Redflag",
            "creditBureauRefId": CREDIT_BUREAU_ID,
        }
    )

    return reports


@pytest.fixture()
def credit_bureau_full_payload(dr_ulid, cb_applicant, cb_coapplicant):
    return {
        "headers": {se.CB_PULL_HEADER_KEY: CREDIT_BUREAU_ID},
        "body": {
            "dealRefId": dr_ulid,
            "sourcePartnerId": "VIN",
            "targetPlatforms": [{"id": "RT1", "partyId": "123987"}],
            "financeMethod": "Lease",
            "applicant": cb_applicant,
            "coApplicant": cb_coapplicant,
        },
    }


@pytest.fixture()
def credit_bureau_event_payload(dr_ulid, cb_applicant, cb_coapplicant):
    return {
        "eventId": "12345abc-abc1-2def-56ef-000000000000",
        "eventTransactionId": "1111111111AAABBBCCDDEEFF22",
        "eventKeyData": {
            "dealRefId": "0000000000AAABBBCCDDEEFFGG",
            "creditBureauRefIdFD": "1111111111AAABBBCCDDEEFF22",
            "creditBureauRefIdUnifi": "12345abc-abc1-2def-56ef-000000000000",
        },
        "payload": {
            "dealRefId": dr_ulid,
            "sourcePartnerId": "VIN",
            "targetPlatforms": [{"id": "R1J", "partyId": "123987"}],
            "financeMethod": "Lease",
            "applicant": cb_applicant,
            "coApplicant": cb_coapplicant,
        },
    }


@pytest.fixture()
def credit_bureau_event_bad_payload(credit_bureau_event_payload):
    payload = copy.deepcopy(credit_bureau_event_payload)
    payload["eventTransactionId"] = "222222222AAABBBCCDDEEFF11"

    return payload


@pytest.fixture()
def credit_bureau_empty_event_payload(dr_ulid, cb_applicant, cb_coapplicant):
    return {
        "eventId": "12345abc-abc1-2def-56ef-000000000000",
        "eventTransactionId": "1111111111AAABBBCCDDEEFFGG",
        "eventKeyData": {
            "dealRefId": "0000000000AAABBBCCDDEEFFGG",
            "creditBureauRefIdFD": "1111111111AAABBBCCDDEEFFGG",
            "creditBureauRefIdUnifi": "12345abc-abc1-2def-56ef-000000000000",
        },
    }


@pytest.fixture()
def credit_bureau_partial_payload(dr_ulid, cb_applicant):
    return {
        "headers": {se.CB_PULL_HEADER_KEY: CREDIT_BUREAU_ID},
        "body": {
            "dealRefId": dr_ulid,
            "sourcePartnerId": "VIN",
            "targetPlatforms": [{"id": "RT1", "partyId": "123987"}],
            "financeMethod": "Lease",
            "customerType": "Individual",
            "applicant": cb_applicant,
        },
    }


@pytest.fixture()
def expected_updated_applicant_data(expected_applicant):
    expected_applicant.update(
        {
            "firstName": "Test",
            "lastName": "Updated",
            "middleName": "J",
            "suffix": "SR",
            "phone": "6463475555",
            "dateOfBirthMonth": "1",
            "dateOfBirthDay": "21",
        }
    )

    return expected_applicant
