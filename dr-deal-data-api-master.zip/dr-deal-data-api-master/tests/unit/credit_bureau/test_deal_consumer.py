# -*- coding: utf-8 -*-
from http import HTTPStatus

from boto3.dynamodb.conditions import Key
from common import deal_consumer
from common.settings import PayloadType as pt
from dynamodb_json import json_util


def test_credit_bureau_post_full_payload(
    dynamodb,
    credit_bureau_full_payload,
    expected_applicant,
    expected_applicant_reports,
    expected_applicant_redflag_reports,
    expected_applicant_ofac_reports,
    expected_coapplicant_reports,
    expected_coapplicant_redflag_reports,
    get_sqs_event_credit_bureau,
    update_body_with_key_data,
    lambda_context,
    expected_key_data,
):
    """
    Test to verifies full payload with applicant and reports is persisted
    """
    body = credit_bureau_full_payload.get("body")
    body = update_body_with_key_data(body)
    deal_ref_id = body.get("dealRefId")
    event = get_sqs_event_credit_bureau(body, pt.CREDIT_BUREAU_PULL)
    response = deal_consumer.handler(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.CREATED

    deals_table = dynamodb.Table(deal_consumer.DealDataParameters().db_name)

    key_expression = Key("dealRefId").eq(deal_ref_id)
    query_results = deals_table.query(KeyConditionExpression=key_expression).get(
        "Items", []
    )

    assert len(query_results) == 13

    key_expression = Key("dealRefId").eq(deal_ref_id) & Key("dealComponent").eq(
        "DTC.APPLICANT"
    )
    query_results = deals_table.query(KeyConditionExpression=key_expression).get(
        "Items", []
    )

    applicant_data = query_results[0]
    assert applicant_data == expected_applicant

    key_expression = Key("dealRefId").eq(deal_ref_id) & Key("dealComponent").eq(
        "DTC.DEAL"
    )
    query_results = deals_table.query(KeyConditionExpression=key_expression).get(
        "Items", []
    )
    assert len(query_results) == 1
    assert query_results[0].items() >= expected_key_data.items()

    key_expression = Key("dealRefId").eq(deal_ref_id) & Key(
        "dealComponent"
    ).begins_with("CB.PULL")
    query_results = deals_table.query(KeyConditionExpression=key_expression).get(
        "Items", []
    )
    applicant_reports = query_results[0]
    assert expected_applicant_reports == applicant_reports

    coapplicant_reports = query_results[3]
    assert expected_coapplicant_reports == coapplicant_reports

    key_expression = Key("dealRefId").eq(deal_ref_id) & Key(
        "dealComponent"
    ).begins_with("CB.PULL.EQUIFAX.REDFLAG")
    query_results = deals_table.query(KeyConditionExpression=key_expression).get(
        "Items", []
    )
    applicant_redflag_reports = query_results[0]

    key_expression = Key("dealRefId").eq(deal_ref_id) & Key(
        "dealComponent"
    ).begins_with("CB.PULL.EXPERIAN.REDFLAG")
    query_results = deals_table.query(KeyConditionExpression=key_expression).get(
        "Items", []
    )
    assert expected_applicant_redflag_reports == applicant_redflag_reports
    coapplicant_redflag_reports = query_results[0]

    assert expected_coapplicant_redflag_reports == coapplicant_redflag_reports

    key_expression = Key("dealRefId").eq(deal_ref_id) & Key(
        "dealComponent"
    ).begins_with("CB.PULL.EQUIFAX.OFAC")
    query_results = deals_table.query(KeyConditionExpression=key_expression).get(
        "Items", []
    )
    applicant_ofac_reports = query_results[0]
    assert expected_applicant_ofac_reports == applicant_ofac_reports


def test_credit_bureau_post_partial_payload(
    credit_bureau_partial_payload,
    expected_applicant,
    expected_applicant_reports,
    dynamodb,
    decimal_encoder,
    get_sqs_event_credit_bureau,
    lambda_context,
):
    """
    To verify partial payload only with applicant is persisted
    """
    body = credit_bureau_partial_payload.get("body")
    deal_ref_id = body.get("dealRefId")
    event = get_sqs_event_credit_bureau(body, pt.CREDIT_BUREAU_PULL)

    response = deal_consumer.handler(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.CREATED

    deals_table = dynamodb.Table(deal_consumer.DealDataParameters().db_name)
    key_expression = Key("dealRefId").eq(deal_ref_id)
    query_results = deals_table.query(KeyConditionExpression=key_expression).get(
        "Items", []
    )
    assert len(query_results) == 9

    key_expression = Key("dealRefId").eq(deal_ref_id) & Key("dealComponent").eq(
        "DTC.APPLICANT"
    )
    query_results = deals_table.query(KeyConditionExpression=key_expression).get(
        "Items", []
    )

    applicant_data = query_results[0]
    assert applicant_data == expected_applicant

    key_expression = Key("dealRefId").eq(deal_ref_id) & Key(
        "dealComponent"
    ).begins_with("CB")
    query_results = deals_table.query(KeyConditionExpression=key_expression).get(
        "Items", []
    )

    applicant_reports = query_results[0]

    assert expected_applicant_reports == applicant_reports


def test_credit_bureau_post_response_full_payload(
    dynamodb, credit_bureau_full_payload, get_sqs_event_credit_bureau, lambda_context
):
    """
    Test to verifies full payload with applicant and reports is persisted
    """
    body = credit_bureau_full_payload.get("body")
    deal_ref_id = body.get("dealRefId")
    event = get_sqs_event_credit_bureau(body, pt.CREDIT_BUREAU_RESPONSE)

    response = deal_consumer.handler(event, lambda_context)
    assert response["statusCode"] == HTTPStatus.CREATED

    deals_table = dynamodb.Table(deal_consumer.DealDataParameters().db_name)

    key_expression = Key("dealRefId").eq(deal_ref_id)
    query_results = deals_table.query(KeyConditionExpression=key_expression).get(
        "Items", []
    )

    assert len(query_results) == 7


def test_credit_bureau_update_full_payload(
    dynamodb,
    credit_bureau_full_payload,
    expected_updated_applicant_data,
    get_sqs_event_credit_bureau,
    update_deal_data,
    boto3_client,
    monkeypatch,
    lambda_context,
    update_body_with_key_data,
    expected_key_data,
):
    """
    Test to verify update on credit bureau full payload with applicant
    """
    deal_ref_id = credit_bureau_full_payload.get("body", {}).get("dealRefId")
    event = get_sqs_event_credit_bureau(
        credit_bureau_full_payload.get("body"), pt.CREDIT_BUREAU_PULL
    )

    response = deal_consumer.handler(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.CREATED

    credit_bureau_full_payload = update_deal_data(
        credit_bureau_full_payload.get("body")
    )
    credit_bureau_full_payload = update_body_with_key_data(credit_bureau_full_payload)
    monkeypatch.setattr(deal_consumer.boto3, "client", boto3_client)
    update_event = get_sqs_event_credit_bureau(
        credit_bureau_full_payload, pt.CREDIT_BUREAU_PULL_DEAL_UPDATE
    )

    response = deal_consumer.handler(update_event, lambda_context)

    assert response["statusCode"] == HTTPStatus.CREATED

    deals_table = dynamodb.Table(deal_consumer.DealDataParameters().db_name)

    key_expression = Key("dealRefId").eq(deal_ref_id)
    query_results = deals_table.query(KeyConditionExpression=key_expression).get(
        "Items", []
    )
    assert len(query_results) == 13

    key_expression = Key("dealRefId").eq(deal_ref_id) & Key("dealComponent").eq(
        "DTC.DEAL"
    )
    query_results = json_util.loads(
        deals_table.query(KeyConditionExpression=key_expression).get("Items", [])
    )
    assert len(query_results) == 1
    assert query_results[0].items() >= expected_key_data.items()

    key_expression = Key("dealRefId").eq(deal_ref_id) & Key("dealComponent").eq(
        "DTC.APPLICANT"
    )

    query_results = deals_table.query(KeyConditionExpression=key_expression).get(
        "Items", []
    )
    applicant_data = json_util.loads(query_results[0])
    assert applicant_data == json_util.loads(expected_updated_applicant_data)


def test_credit_bureau_ttl_no_greater_than_deal(
    dynamodb,
    credit_bureau_full_payload,
    expected_updated_applicant_data,
    get_sqs_event_credit_bureau,
    update_deal_data,
    boto3_client,
    monkeypatch,
    lambda_context,
    frozen_time,
):
    """
    Test that CB ttl is set to the deal's ttl if the deal's ttl is lower than (current time + 30 days)
    This scenario happens if bureaus are pulled more than 30 days after the deal is created.
    """
    deal_ref_id = credit_bureau_full_payload.get("body", {}).get("dealRefId")
    event = get_sqs_event_credit_bureau(
        credit_bureau_full_payload.get("body"), pt.CREDIT_BUREAU_PULL
    )

    event["Records"][0]["messageAttributes"]["dealTTL"]["stringValue"] = frozen_time
    response = deal_consumer.handler(event, lambda_context)

    assert response["statusCode"] == HTTPStatus.CREATED

    deals_table = dynamodb.Table(deal_consumer.DealDataParameters().db_name)
    key_expression = Key("dealRefId").eq(deal_ref_id)
    query_results = deals_table.query(KeyConditionExpression=key_expression).get(
        "Items", []
    )

    count = 0
    for record in query_results:
        if record["dealComponent"].startswith("CB."):
            count = count + 1
            assert int(record["ttl"]) == frozen_time

    assert count == 7
