#!/bin/bash

set -e

ACTION=$1
REGION=$2
DEPLOY_ENV=$3
DIR_NAME=$4

function get_terraform_state_bucket() {
    local bucket_name
    bucket_name="$AWS_ACCT_ALIAS"-terraform-state-"$REGION"
    echo "$bucket_name"
}

function get_workspace_name() {
    local workspace_name
    workspace_name="$DEPLOY_ENV"-"$REGION"
    echo "$workspace_name"

}

function get_account_alias() {
    local account_alias
    account_alias=$(aws iam list-account-aliases --output json | jq -r '.AccountAliases[0]')
    echo "$account_alias"
}

function run_tfenv_init() {
  tfenv init
  tfenv install
}

function initialize_terraform() {
    local aws_s3_bucket_name=$1
    echo "[INFO] [manage.sh] aws_s3_bucket_name=${aws_s3_bucket_name}"
    echo "[INFO] [manage.sh] Running terraform init..."
    terraform init -no-color -get=true -input=false -backend-config="bucket=$aws_s3_bucket_name" -backend-config="region=$REGION"
}

function create_or_select_terraform_workspace() {
    echo "[INFO] [manage.sh] Creating/selecting terraform workspace..."
    terraform_state_bucket=$(get_terraform_state_bucket)
    workspace_name=$(get_workspace_name)

    echo "[INFO] [manage.sh] terraform_state_bucket=${terraform_state_bucket}"
    echo "[INFO] [manage.sh] workspace_name=${workspace_name}"

    initialize_terraform "$terraform_state_bucket"
    terraform workspace new "$workspace_name" || terraform workspace select "$workspace_name"
}

function terraform_plan() {
    echo "[INFO] [manage.sh] Running terraform plan..."
    terraform plan -no-color -input=false -var region="$REGION" -var deploy_env="$DEPLOY_ENV"
}

function terraform_apply() {
    echo "[INFO] [manage.sh] Running terraform apply..."
    terraform apply -no-color -auto-approve -var region="$REGION" -var deploy_env="$DEPLOY_ENV"
}

function terraform_destroy() {
    echo "[INFO] [manage.sh] Running terraform destroy..."
    terraform destroy -no-color -var region="$REGION" -var deploy_env="$DEPLOY_ENV"
}

function terraform_state_replace() {
    echo "[INFO] [manage.sh] Running terraform state replace..."
    terraform state replace-provider -auto-approve registry.terraform.io/-/aws registry.terraform.io/hashicorp/aws
    terraform state replace-provider -auto-approve registry.terraform.io/-/alks registry.terraform.io/cox-automotive/alks
}

AWS_ACCT_ALIAS=$(get_account_alias)

cd "$DIR_NAME"
echo "[INFO] Variable REGION in manage.sh is $REGION"
if [ "$ACTION" = "init" ]; then
    create_or_select_terraform_workspace
    run_tfenv_init
elif [ "$ACTION" = "plan" ]; then
    terraform_plan
elif [ "$ACTION" = "apply" ]; then
    terraform_apply
elif [ "$ACTION" = "deploy" ]; then
    create_or_select_terraform_workspace
    run_tfenv_init
    terraform_state_replace
    terraform_plan
    terraform_apply
elif [ "$ACTION" = "destroy" ]; then
      terraform_destroy
fi
cd ..
