## Usage

1. Update variables file with all fields corresponding to the project

```bash
./manage.sh ACTION REGION DEPLOY_ENV DIR_NAME
```

`ACTION`:

 One of the following:

 * **`init`**: To initialize terraform workspace.
 * **`plan`**: To verify what terraform is trying to create/update/delete existing resource in current workspace
 * **`apply`**: Applies all changes to current workspace, create/update/delete existing resource and update terraform state in S3
 * **`destroy`**: To destroy all resources which are created using current workspace

`REGION`:

 One of the following:
 * `us-east-1`
 * `us-east-2`
 * `us-west-1`
 * `us-west-2`

`DEPLOY_ENV`:

 One of the following:
 * `lab`
 * `dvt`
 * `qa`
 * `uat`
 * `prod`

 An environment identifier used create a terraform workspace. Terraform state (and workspace) data is preserved in an S3 bucket named
 in the form `<aws_account_alias>-terraform-state-<region>`, where `aws_account_alias` corresponds to the account the active AWS credentials
 belong to and region is aws region. Required when `ACTION` for all actions.

`DIR_NAME`:

 One of the following:
 * `serverless`

#### Examples:

```bash
./manage.sh init us-east-1 qa serverless

./manage.sh plan us-east-1 qa serverless

./manage.sh apply us-east-1 qa serverless

./manage.sh destroy us-east-1 qa serverless
```

## Dependencies

##### ALKS Terraform Provider:
https://github.com/Cox-Automotive/terraform-provider-alks

##### AWS CLI
https://aws.amazon.com/cli/
