# -*- coding: utf-8 -*-
import json
from http import HTTPStatus

from boto3.dynamodb.conditions import Attr, Key
from common.lambda_base import GetLambda
from common.settings import TARGET_PLATFORM_FIELD, Env, ErrorMsgs, InfoMsgs
from schemas.v1.KEY_DATA_V2 import SUPPORTED_QUERY_STRINGS
from utils import common
from utils.common import DealDataParameters
from utils.db_helper import DynamoDbHelper
from utils.exceptions import BadRequestError


class KeyDataLambda(GetLambda):
    def __init__(self, operation, **kwargs):
        super().__init__(operation=operation, **kwargs)
        self.db_records = []
        self.target_platform_id = None

    @GetLambda.catch_exceptions
    @GetLambda.is_handler
    def get(self, event, context):
        """
        This method takes key data in query string parameter and uses it to do a scan on db to do reverse lookup. These
        keys are stored in deal data with dealComponent as `REF_IDS.<TargetPlatform>`.
        :param dict event: An API Gateway event object
        :param dict context: AWS Lambda Context Object
        :return: JSON with status code and body
        """
        include_inactive_refs = self.request_headers.get(
            "includeInactiveRefs", "false"
        ).lower()

        if include_inactive_refs not in ["true", "false"]:
            raise BadRequestError(
                f"Provided includeInactiveRefs '{include_inactive_refs}' is not supported. "
                f"Please provide one of the enum ['true', 'false']"
            )

        self.log.info(
            InfoMsgs.received_get_request,
            queryStringParameters=self.query_string_params,
            includeInactiveRefs=include_inactive_refs,
        )
        query_string = self.validate_query_string_params()

        self.log.bind(targetPlatformId=self.target_platform_id)

        field = query_string
        value = self.query_string_params[query_string]

        # Lookup for dealRefId need to be done first if query string is not dealRefId
        if query_string != "dealRefId":
            data = self.get_db_records(field=field, value=value)
            if not data:
                return {
                    "statusCode": HTTPStatus.NO_CONTENT,
                    "headers": self.response_headers,
                }
            field = "dealRefId"
            value = data[0]["dealRefId"]

        data = self.get_db_records(field=field, value=value)
        data = self.generate_response_body(
            data=data, include_inactive_refs=include_inactive_refs
        )
        return {
            "statusCode": HTTPStatus.OK if data else HTTPStatus.NO_CONTENT,
            "body": json.dumps(data, cls=common.decimal_decoder()),
            "headers": self.response_headers,
        }

    def get_db_records(self, field, value):
        """
        Get the data from DynamoDB
        """
        db = DynamoDbHelper(
            region=Env.AWS_REGION, table_name=DealDataParameters().db_name
        )
        key_expression = Key(field).eq(value)
        index_name = f"{field}-index"

        # Retrieve all refs if targetPlatform is DTA or
        # if targetPlatform is not DTA retrieve DTA and provided targetPlatform reference data from DB
        if self.target_platform_id == "DTA":
            filter_expression = Attr("dealComponent").begins_with("REF_IDS")
        else:
            filter_expression = Attr("dealComponent").begins_with("REF_IDS.DTA") | Attr(
                "dealComponent"
            ).begins_with(f"REF_IDS.{self.target_platform_id}")

        self.log.info("DB query info", field=field, value=value)

        self.db_records = db.query_items(
            key_expression=key_expression,
            filter_expression=filter_expression,
            index=index_name,
        )

        data = self.db_records if self.db_records else []
        self.log.info(
            InfoMsgs.received_data_from_db.format(operation=self.operation),
            dbData=data,
        )
        return data

    def validate_query_string_params(self):
        """
        Validate only one querystring parameter was provided and that it is one of the supported parameters.
        targetPlatformId is the additional querystring parameter which can be passed additional to the actual
        querystring parameter.
        :return: query string parameter or raise validation error
        """
        self.target_platform_id = self.query_string_params.pop(
            TARGET_PLATFORM_FIELD, "DTA"
        ).upper()
        number_of_query_string = len(self.query_string_params)

        # Verify if query string parameter is present
        if not self.query_string_params:
            raise BadRequestError(ErrorMsgs.missing_query_string_parameters)

        # Verify if the number of query string is not more than 2 including targetPlatformId
        elif number_of_query_string > 1:
            raise BadRequestError(ErrorMsgs.error_multiple_key_data_query_param)

        # Verify targetPlatformId is supported
        elif self.target_platform_id not in SUPPORTED_QUERY_STRINGS.keys():
            raise BadRequestError(
                ErrorMsgs.error_unsupported_target_platform_key_data.format(
                    field=self.target_platform_id
                )
            )

        # Verify if the provided query string is in the supported list
        field = list(self.query_string_params.keys())[0]
        if field not in SUPPORTED_QUERY_STRINGS.get(self.target_platform_id):
            raise BadRequestError(
                ErrorMsgs.unsupported_key_data_query_field.format(
                    field=field, target_platform_id=self.target_platform_id
                )
            )

        # Verify if provided query string value is not empty string
        if not self.query_string_params.get(field):
            raise BadRequestError(ErrorMsgs.error_empty_query_string_value)

        return field

    def generate_response_body(self, data, include_inactive_refs):
        """
        Generate response body from DB record structure to Key-Data GET structure.
        Example:

        DB Records
            [
                {
                    "updatedTimestamp": "2024-02-14T15:09:30.201136",
                    "dealRefId": "01HPM2MRQV3BBM5MJ9BW8NNMVC",
                    "creditAppId": "01HPM2MRQV9J1TZFMCCGWH2WRZ",
                    "sourcePartnerId": "DXR",
                    "dealComponent": "REF_IDS.DTA",
                    "dealRefIdFD": "40892980R55632109T94555126",
                    "ttl": 1713107370,
                    "createdTimestamp": "2024-02-14T15:09:30.201136",
                    "financeMethod": "Retail"
                },
                {
                    "updatedTimestamp": "2024-02-14T15:09:30.201136",
                    "dealRefId": "01HPM2MRQV3BBM5MJ9BW8NNMVC",
                    "creditAppId": "01HPM2MRQV9J1TZFMCCGWH2WRZ",
                    "dealComponent": "REF_IDS.DTA.01HPM2MRQV9J1TZFMCCGWH2WRZ",
                    "appRefIdFD": "14070672R35644561T00336281",
                    "ttl": 1713107370,
                    "createdTimestamp": "2024-02-14T15:09:30.201136",
                    "appRefIdFDInt": "3740988768350614"
                },
                {
                    "dealerCode": "3630525967086895",
                    "sourcePartnerDealerId": "DXR",
                    "updatedTimestamp": "2024-02-14T15:12:27.357240",
                    "dealRefId": "01HPM2MRQV3BBM5MJ9BW8NNMVC",
                    "dealComponent": "REF_IDS.DTC",
                    "documentMasterIndexId": "2030136927049466",
                    "ttl": 1713107370,
                    "createdTimestamp": "2024-02-14T15:09:30.201136",
                    "dealJacketId": "5842474322261442"
                }
            ]

        Transformed record:
            [
                {
                    "targetPlatformId: "DTA",
                    "dealRefId": "01HPM2MRQV3BBM5MJ9BW8NNMVC",
                    "creditAppId": "01HPM2MRQV9J1TZFMCCGWH2WRZ",
                    "sourcePartnerId": "DXR",
                    "dealRefIdFD": "40892980R55632109T94555126",
                    "financeMethod": "Retail",
                    "appRefIdFD": "14070672R35644561T00336281",
                    "appRefIdFDInt": "3740988768350614"
                },
                {   "targetPlatformId: "DTC",
                    "dealerCode": "3769099458031863",
                    "sourcePartnerDealerId": "DXR",
                    "dealRefId": "01HPM2MRQV3BBM5MJ9BW8NNMVC",
                    "documentMasterIndexId": "0525406473318388",
                    "dealJacketId": "6486769205765269"
                }
            ]

        :param data: list of records received from dynamoDB
        :param include_inactive_refs: to return all or active refs
        :return: list of json with all fields
        """
        data = sorted(data, key=lambda i: i["dealComponent"])
        response = []
        deal_record = {}
        deal_record_appended = False
        credit_app_id = None

        for record in data:

            # Process dealComponent "REF_IDS.<target>" record
            if record["dealComponent"] in [
                "REF_IDS.DTA",
                "REF_IDS.DTC",
                "REF_IDS.IDL",
                "REF_IDS.R1J",
            ]:
                deal_component = record["dealComponent"]
                record["targetPlatformId"] = deal_component.split(".")[1]
                response.append(self.remove_fields_from_record(record, deal_component))
                deal_record_appended = True

                if "DTA" in deal_component:
                    credit_app_id = record.get("creditAppId")

            # Process dealComponent "REF_IDS.<target>.<dealId/creditAppId>" record
            # Below checks for following
            # * If includeInactiveRefs is false(which means return only active deals) verify if the creditAppId
            #       is matching with target platform record (REF_IDS.<target>.<dealId/creditAppId>), if
            #       matches append to the response
            # * If includeInactiveRefs is true, append to the response list
            elif (
                include_inactive_refs == "false"
                and credit_app_id
                and credit_app_id == record.get("creditAppId")
            ) or include_inactive_refs == "true":

                if deal_record_appended:
                    deal_record = response.pop()
                    deal_record_appended = False

                response.append(
                    {
                        **deal_record,
                        **self.remove_fields_from_record(
                            record, record["dealComponent"]
                        ),
                    }
                )
        return response

    @staticmethod
    def remove_fields_from_record(record, deal_component):
        """
        Drop all unwanted fields from the DB records
        :param record: DB record
        :param deal_component: dealComponent of that record
        :return: JSON after dropping all not required fields from the data
        """
        if "REF_IDS.DTA" not in deal_component:
            record.pop("dealRefId", None)
        for field in ["createdTimestamp", "updatedTimestamp", "dealComponent", "ttl"]:
            record.pop(field, None)
        return record


key_data_get = KeyDataLambda.get_handler(handler_func="get", operation="KeyData")
