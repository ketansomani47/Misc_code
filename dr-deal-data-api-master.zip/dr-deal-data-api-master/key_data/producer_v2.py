# -*- coding: utf-8 -*-
from http import HTTPStatus

import dr_utils
from common.lambda_base import ProducerLambda
from common.settings import (
    TARGET_PLATFORM_FIELD,
    Env,
    ErrorMsgs,
    PayloadType,
    TargetPlatformIds,
)
from common.validators import ExistingDealValidator
from key_data.mapper import transform_key_data_records_v2
from schemas.v1.KEY_DATA_V2 import CONDITIONAL_VALIDATIONS, KEY_DATA_SCHEMA
from utils import common
from utils.exceptions import BadRequestError


class KeyDataProducerLambda(ProducerLambda):
    def __init__(self, **kwargs):

        super().__init__(**kwargs)
        self.deal_ref_id = None
        self.target_platform_id = None

    @ProducerLambda.catch_exceptions
    @ProducerLambda.is_handler
    def existing_deal_key_data_handler(self, event, context):
        """
        Handles the Deal PATCH with Key Data for existing Deal endpoint.

        Endpoint: /v2/deals/{dealRefId}/key-data

        This asynchronous API submits a message to DealDataQueue and returns dealRefId to the client with
        HTTP status No Content (204).

        :param dict event: An API Gateway event object
        :param dict context: AWS Lambda Context Object
        :return: JSON with status code and body
        """

        self.deal_ref_id = common.get_path_parameter(event, "dealRefId")

        self.log.bind(dealRefId=self.deal_ref_id)
        self.log.info("Key Data creation request received for exiting deal")

        validator = ExistingDealValidator(event, self.deal_ref_id)
        if not validator.deal_exists():
            raise BadRequestError(
                ErrorMsgs.missing_deal_from_db.format(deal_ref_id=self.deal_ref_id)
            )
        data = validator.validate_body(add_deal_ref_id_to_payload=False)

        self.validate_target_platform(data)
        self.validate_body_by_target_platform(data)
        self.conditional_validation_by_target_platform(data)

        # Verify if provided creditAppId is attached to the deal
        if "creditAppId" in data:
            self.validate_credit_app_id(data, validator)

        self.log.bind(requestPayload=data)

        transformed_data = transform_key_data_records_v2(
            data, self.target_platform_id, self.payload_type
        )
        transformed_data["baggage"] = self.baggage
        self.log.bind(transformedPayload=transformed_data)

        dr_utils.send_payload_to_queue(
            queue=Env.DEAL_DATA_QUEUE,
            payload=transformed_data,
            region=Env.AWS_REGION,
            msg_group_id=self.deal_ref_id,
            payloadType=self.payload_type,
            correlationId=self.correlation_id,
            dealRefId=self.deal_ref_id,
        )

        self.log.info(
            f"Key Data creation request for existing deal sent to queue: {Env.DEAL_DATA_QUEUE}"
        )

        return {"statusCode": HTTPStatus.NO_CONTENT, "headers": self.response_headers}

    def validate_target_platform(self, data):
        """
        Validate provided target platform is supported or not
        :param data: Request payload
        :return: None or raise BadRequest
        """
        self.target_platform_id = data.pop(TARGET_PLATFORM_FIELD, None)
        if not self.target_platform_id:
            raise BadRequestError(
                f"Missing '{TARGET_PLATFORM_FIELD}' in request payload"
            )
        elif self.target_platform_id and self.target_platform_id not in dir(
            TargetPlatformIds
        ):
            raise BadRequestError(
                ErrorMsgs.error_unsupported_target_platform_key_data.format(
                    field=self.target_platform_id
                )
            )

    def validate_body_by_target_platform(self, data):
        """
        Validate fields provided in the payload are supported by target platform
        :param data: Request payload
        :return: None or raise BadRequest
        """
        self.log.info(f"Validating body for targetPlatform: {self.target_platform_id}")
        target_platform_mapping = KEY_DATA_SCHEMA.get(self.target_platform_id)
        not_supported_fields = []
        for field in data:
            if field not in target_platform_mapping.keys():
                not_supported_fields.append(field)

        if not_supported_fields:
            fields = ", ".join(not_supported_fields)
            raise BadRequestError(
                ErrorMsgs.unsupported_key_data_post_fields.format(
                    field=fields, target_platform_id=self.target_platform_id
                )
            )

    def conditional_validation_by_target_platform(self, data):
        """
        Validate fields dependent on other fields for given target platform
        :param data: Request payload
        :return: None or raise BadRequest
        """
        self.log.info(
            f"Conditional validation for targetPlatform: {self.target_platform_id}"
        )
        conditional_validations = CONDITIONAL_VALIDATIONS.get(self.target_platform_id)
        for field, dependent_field in conditional_validations.items():
            if field in data and dependent_field not in data:
                if field in ["creditAppIdR1"]:
                    raise BadRequestError(
                        ErrorMsgs.key_data_conditional_validation_fields_2.format(
                            dependent_field=dependent_field,
                            field=field,
                        )
                    )
                else:
                    raise BadRequestError(
                        ErrorMsgs.key_data_conditional_validation_fields.format(
                            dependent_field=dependent_field,
                            field=field,
                        )
                    )

    def validate_credit_app_id(self, data, validator):
        """
        Validate creditAppId is attached to dealRefId and is active
        :param data: Request payload
        :param validator: existing validator object
        :return: None or raise BadRequest
        """
        db_records = validator.db_records
        found_ca = False

        for record in db_records:
            if "REF_IDS.DTA" in record["dealComponent"] and data[
                "creditAppId"
            ] == record.get("creditAppId"):
                found_ca = True

        if not found_ca:
            raise BadRequestError(
                ErrorMsgs.reference_id_mismatch_new_format.format(
                    reference_id_type="creditAppId",
                    reference_id=data["creditAppId"],
                    deal_ref_id=self.deal_ref_id,
                )
            )


def handler(event, content):
    return KeyDataProducerLambda().get_handler(
        handler_func="existing_deal_key_data_handler",
        payload_type=PayloadType.KEY_DATA_UPDATE_V2,
    )(event, content)
