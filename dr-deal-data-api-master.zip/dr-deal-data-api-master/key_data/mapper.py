# -*- coding: utf-8 -*-
from common.settings import TARGET_PLATFORM_FIELD, PayloadType
from schemas.v1.KEY_DATA import (
    TARGET_PLATFORM_RECORD,
    TARGET_PLATFORM_STANDARD_REF,
    TARGET_PLATFORM_STANDARD_REF_RECORD,
)
from schemas.v1.KEY_DATA_V2 import (
    DB_FIELD_MAPPING_V2,
    TARGET_PLATFORM_STANDARD_REF_V2,
)


def get_source_partner_dealer_id(data: dict, target_platform: str, payload_type: str):
    """
    Return source partner dealer id from the data provided based on payload type
    :param data: payload which is received to the deal consumer
    :param target_platform: target_platform id that need to be created for
    :param payload_type: type of payload we are transforming from
    :return: sourcePartnerDealerId as key and its value
    """
    record = {}
    if target_platform != "DTA" and payload_type not in [
        PayloadType.KEY_DATA_POST,
        PayloadType.KEY_DATA_UPDATE,
        PayloadType.KEY_DATA_UPDATE_V2,
    ]:
        for tp in data.get("targetPlatforms") or []:
            if tp["id"] == target_platform:
                record["sourcePartnerDealerId"] = tp["partyId"]
    elif target_platform != "DTA" and "sourcePartnerDealerId" in data:
        record["sourcePartnerDealerId"] = data["sourcePartnerDealerId"]
    return record


def map_target_platform_record(data: dict, target_platform: str, payload_type: str):
    """
    generate deal specific record
    partition key - dealRefId
    SortKey - REF_IDS.<target_platform_id>.<standard_ref_id>
    :param data: payload which is received to the deal consumer
    :param target_platform: target_platform id that need to be created for
    :param payload_type: type of payload we are transforming from
    :return: List of DB records
    """
    record = {}
    target_platform_fields = TARGET_PLATFORM_RECORD.get(target_platform) or {}
    for payload_field, db_field in target_platform_fields.items():
        # For V2 Key-data payload field with be consistent with db field name will not have any Suffix like V1
        if payload_type in [PayloadType.KEY_DATA_UPDATE_V2]:
            payload_field = db_field

        if data.get(payload_field):
            record[db_field] = data[payload_field]

    record.update(get_source_partner_dealer_id(data, target_platform, payload_type))

    if record:
        deal_component = f"REF_IDS.{target_platform}"
        return {deal_component: record}
    return record


def map_target_platform_standard_ref_record(
    data: dict, target_platform: str, payload_type: str
):
    """
    generate standard ref id specific record
    partition key - dealRefId
    SortKey - REF_IDS.<target_platform_id>.<standard_ref_id>
    :param data: payload which is received to the deal consumer
    :param target_platform: target_platform id that need to be created for
    :param payload_type: type of payload we are transforming from
    :return: List of DB records
    """
    record = {}
    if payload_type in [PayloadType.KEY_DATA_UPDATE_V2]:
        target_platform_standard_ref = TARGET_PLATFORM_STANDARD_REF_V2.get(
            target_platform
        )
    else:
        target_platform_standard_ref = TARGET_PLATFORM_STANDARD_REF.get(target_platform)
    target_platform_standard_record = TARGET_PLATFORM_STANDARD_REF_RECORD.get(
        target_platform
    )
    if target_platform_standard_ref in data:
        for payload_field, db_field in target_platform_standard_record.items():
            # For V2 Key-data payload field with be consistent with db field name will not have any Suffix like V1
            if payload_type in [PayloadType.KEY_DATA_UPDATE_V2]:
                payload_field = db_field

            if data.get(payload_field):
                record[db_field] = data[payload_field]
        deal_component = (
            f"REF_IDS.{target_platform}.{data[target_platform_standard_ref]}"
        )
        return {deal_component: record}
    return record


def transform_key_data_records(data: dict, payload_type: str):
    """
    Transforms refIds to specific db record with
    partition key - dealRefId
    SortKey - REF_IDS.<target_platform_id> and REF_IDS.<target_platform_id>.<standard_ref_id>
    :param data: payload which is received to the deal consumer
    :param payload_type: type of payload we are transforming from
    :return: List of DB records
    """
    if payload_type in [PayloadType.KEY_DATA_POST, PayloadType.KEY_DATA_UPDATE]:
        target_platforms = [data.pop(TARGET_PLATFORM_FIELD, "DTC")]
    else:
        target_platforms = [tp["id"] for tp in data.get("targetPlatforms") or []]

    for target_platform in target_platforms:
        # Adding check to remove random targetPlatforms getting in CA, Leads APIs
        if target_platform in TARGET_PLATFORM_RECORD:
            data.update(
                **map_target_platform_record(data, target_platform, payload_type),
                **map_target_platform_standard_ref_record(
                    data, target_platform, payload_type
                ),
            )

    if "DTA" not in target_platforms:
        data.update(
            **map_target_platform_record(data, "DTA", payload_type),
            **map_target_platform_standard_ref_record(data, "DTA", payload_type),
        )
    return data


def transform_key_data_records_v2(data: dict, target_platform: str, payload_type: str):
    """
    Transforms refIds to specific db record with
    partition key - dealRefId
    SortKey - REF_IDS.<target_platform_id> and REF_IDS.<target_platform_id>.<standard_ref_id>
    :param data: payload which is received to the deal consumer
    :param target_platform: target_platform id that need to be created for
    :param payload_type: type of payload we are transforming from
    :return: List of DB records
    """
    return {
        **map_target_platform_record(data, target_platform, payload_type),
        **map_target_platform_standard_ref_record(data, target_platform, payload_type),
        **create_backward_compatible_to_v1_from_v2(data, target_platform),
    }


def create_backward_compatible_to_v1_from_v2(data: dict, target_platform: str):
    """
    Transforms the v2 data fields to v1 field standards so that it can be saved in DTC.DEAL record for
    backward compatible for a given target platform
    :param data: payload which is received to the deal consumer
    :param target_platform: target_platform id that need to be created for
    """
    record = {}
    deal_record_mapping = DB_FIELD_MAPPING_V2.get(target_platform)

    for payload_field, db_field in deal_record_mapping.items():
        if payload_field in data:
            record[db_field] = data[payload_field]

    return record
