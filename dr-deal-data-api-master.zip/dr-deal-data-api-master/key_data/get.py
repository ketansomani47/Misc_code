# -*- coding: utf-8 -*-
import json
from abc import ABC
from http import HTTPStatus

from boto3.dynamodb.conditions import Attr, Key
from common.lambda_base import GetLambda
from common.settings import (
    TARGET_PLATFORM_FIELD,
    DealComponent,
    Env,
    ErrorMsgs,
    InfoMsgs,
    KeyDataFetchMethod,
    TargetPlatformIds,
)
from schemas.v1.KEY_DATA import DB_FIELD_MAPPING, SUPPORTED_QUERY_STRINGS
from utils import common
from utils.common import DealDataParameters
from utils.db_helper import DynamoDbHelper
from utils.exceptions import BadRequestError


class KeyDataLambda(GetLambda, ABC):
    def __init__(self, operation, **kwargs):
        super().__init__(operation=operation, **kwargs)
        self.db_records = []
        self.data_source = KeyDataFetchMethod.DYNAMO_DB
        self.target_platform_provided = None

    @property
    def target_platform_id(self):
        """
        targetPlatformId from query string parameter or default it to DTC
        """
        if not self.target_platform_provided:
            self.target_platform_provided = TargetPlatformIds.DTC
        return self.target_platform_provided

    @GetLambda.catch_exceptions
    @GetLambda.is_handler
    def get(self, event, context):
        """
        This method takes key data in query string parameter and uses it to do a scan on db to do reverse lookup. These
        keys are stored in deal data with dealComponent as `DTC.DEAL`.
        :param dict event: An API Gateway event object
        :param dict context: AWS Lambda Context Object
        :return: JSON with status code and body
        """
        self.log.info(
            InfoMsgs.received_get_request,
            queryStringParameters=self.query_string_params,
        )
        self.validate_query_string_params()

        self.log.bind(targetPlatformId=self.target_platform_id)

        field, value = self.get_db_field_name_and_value()

        db = DynamoDbHelper(
            region=Env.AWS_REGION, table_name=DealDataParameters().db_name
        )
        filter_expression = Attr("dealComponent").eq(DealComponent.DTC_DEAL)
        key_expression = Key(field).eq(value)
        index_name = f"{field}-index"

        self.log.info(
            "DB query info",
            index=index_name,
            field=field,
            value=value,
            keyExpression=key_expression,
            filterExpression=filter_expression,
        )

        self.db_records = db.query_items(
            key_expression=key_expression,
            filter_expression=filter_expression,
            index=index_name,
        )

        data = self.db_records if self.db_records else []
        self.log.info(
            InfoMsgs.received_data_from_db.format(operation=self.operation),
            dbData=data,
        )
        resp_data = self.generate_response_body(data=data)

        # Updating response headers for data source
        response_headers = self.response_headers
        response_headers.update({"X-Data-Source": self.data_source})
        return {
            "statusCode": HTTPStatus.OK,
            "body": json.dumps(resp_data, cls=common.decimal_decoder()),
            "headers": response_headers,
        }

    def validate_query_string_params(self):
        """
        Validate only one querystring parameter was provided and that it is one of the supported parameters.
        targetPlatformId is the additional querystring parameter which can be passed additional to the actual
        querystring parameter.
        :return: query string parameter or raise validation error
        """
        number_of_query_string = len(self.query_string_params)
        self.target_platform_provided = self.query_string_params.pop(
            TARGET_PLATFORM_FIELD, None
        )

        # Verify if query string parameter is present
        if not self.query_string_params:
            raise BadRequestError(ErrorMsgs.missing_query_string_parameters)

        # Verify if the number of query string is not more than 2 including targetPlatformId
        elif number_of_query_string > 2:
            raise BadRequestError(ErrorMsgs.error_multiple_key_data_query_param)

        # Verify if number of query strings are 2, one of them is targetPlatformId
        elif number_of_query_string == 2 and not self.target_platform_provided:
            raise BadRequestError(ErrorMsgs.error_multiple_key_data_query_param)

        # Verify if number of query strings are 2, one of them is targetPlatformId and targetPlatformId is supported
        elif (
            number_of_query_string == 2
            and self.target_platform_provided
            and self.target_platform_id not in DB_FIELD_MAPPING.keys()
        ):
            raise BadRequestError(
                ErrorMsgs.error_unsupported_target_platform_key_data.format(
                    field=self.target_platform_id
                )
            )

        # Verify if the provided query string is in the supported list
        field = list(self.query_string_params.keys())[0]
        if field not in SUPPORTED_QUERY_STRINGS:
            raise BadRequestError(
                ErrorMsgs.error_unsupported_key_data.format(field=field)
            )

        # Verify if provided query string value is not empty string
        if not self.query_string_params.get(field):
            raise BadRequestError(ErrorMsgs.error_empty_query_string_value)

    def get_db_field_name_and_value(self):
        """
        Get field name and value to query on dynamoDB from the provided query string
        :return: The query string field
        """
        field = list(self.query_string_params.keys())[0]
        target_platform_mapping = DB_FIELD_MAPPING.get(self.target_platform_id)
        dta_mapping = DB_FIELD_MAPPING.get(TargetPlatformIds.DTA)
        key = target_platform_mapping.get(field) or dta_mapping.get(field)
        if not key:
            raise BadRequestError(
                ErrorMsgs.unsupported_key_data_query_field.format(
                    field=field, target_platform_id=self.target_platform_id
                )
            )
        return key, self.query_string_params[field]

    def generate_response_body(self, data):
        """
        Generate response body with the fields which are related to that particular target platform
        :param data: list of records received from dynamoDB
        :return: list of json with all fields
        """
        response = []
        for record in data:
            response_record = {}
            target_platform_mapping = DB_FIELD_MAPPING.get(self.target_platform_id)
            dta_mapping = DB_FIELD_MAPPING.get(TargetPlatformIds.DTA)
            for key, value in target_platform_mapping.items():
                if value in record:
                    response_record[key] = record[value]
            for key, value in dta_mapping.items():
                if value in record:
                    response_record[key] = record[value]
            response.append(response_record)
        return response


key_data_get = KeyDataLambda.get_handler(handler_func="get", operation="KeyData")
