# -*- coding: utf-8 -*-
import json
from http import HTTPStatus

import dr_utils
import ulid
from common.lambda_base import ProducerLambda
from common.settings import (
    TARGET_PLATFORM_FIELD,
    Env,
    ErrorMsgs,
    PayloadType,
    TargetPlatformIds,
)
from common.validators import BodyValidator, ExistingDealValidator
from schemas.v1.KEY_DATA import DB_FIELD_MAPPING
from utils import common
from utils.exceptions import BadRequestError


class KeyDataProducerLambda(ProducerLambda):
    def __init__(self, **kwargs):

        super().__init__(**kwargs)
        self.deal_ref_id = None
        self.credit_app_id = None
        self._target_platform_id = None

    @property
    def target_platform_id(self):
        """
        targetPlatformId from query string parameter or default it to DTC
        """
        if not self._target_platform_id:
            self._target_platform_id = TargetPlatformIds.DTC
        return self._target_platform_id

    @ProducerLambda.catch_exceptions
    @ProducerLambda.is_handler
    def new_deal_key_data_handler(self, event, context):
        """
        Handles the Key Data Post for new Deal endpoint. Creates a new a new Deal.
        Endpoint: /deals/key-data
        This asynchronous API submits a message to DealDataQueue and returns dealRefId to the client with
        HTTP status CREATED (201).
        :param dict event: An API Gateway event object
        :param dict context: AWS Lambda Context Object
        :return: JSON with status code and body
        """

        self.deal_ref_id = ulid.new().str

        self.log.bind(dealRefId=self.deal_ref_id)
        self.log.info("Key Data creation request received for new deal")

        validator = BodyValidator(event, self.deal_ref_id)
        data = validator.validate_body()

        # add key_data dict to data with keys extracted from headers
        data.update(self.key_data)

        self.validate_target_platform(data)
        self.validate_body_by_target_platform(data)

        self.log.bind(requestPayload=data)

        transformed_data = self.transform_body_by_target_platform(data)
        transformed_data["baggage"] = self.baggage

        self.log.bind(transformedPayload=transformed_data)

        dr_utils.send_payload_to_queue(
            queue=Env.DEAL_DATA_QUEUE,
            payload=transformed_data,
            region=Env.AWS_REGION,
            msg_group_id=self.deal_ref_id,
            payloadType=self.payload_type,
            correlationId=self.correlation_id,
            dealRefId=self.deal_ref_id,
        )

        self.log.info(
            f"Key Data creation request for new deal sent to queue: {Env.DEAL_DATA_QUEUE}"
        )

        return_body = {"dealRefId": self.deal_ref_id}

        return {
            "statusCode": HTTPStatus.CREATED,
            "body": json.dumps(return_body),
            "headers": self.response_headers,
        }

    @ProducerLambda.catch_exceptions
    @ProducerLambda.is_handler
    def existing_deal_key_data_handler(self, event, context):
        """
        Handles the Deal PATCH with Key Data for existing Deal endpoint.

        Endpoint: /deals/{dealRefId}/key-data

        This asynchronous API submits a message to DealDataQueue and returns dealRefId to the client with
        HTTP status No Content (204).

        :param dict event: An API Gateway event object
        :param dict context: AWS Lambda Context Object
        :return: JSON with status code and body
        """

        self.deal_ref_id = common.get_path_parameter(event, "dealRefId")

        self.log.bind(dealRefId=self.deal_ref_id)
        self.log.info("Key Data creation request received for exiting deal")

        validator = ExistingDealValidator(event, self.deal_ref_id)
        validator.validate_body()
        validator.validate_api_version(self.request_api_version)

        data = validator.data

        # add key_data dict to data with keys extracted from headers
        data.update(self.key_data)

        self.validate_target_platform(data)
        self.validate_body_by_target_platform(data)

        self.log.bind(requestPayload=data)

        transformed_data = self.transform_body_by_target_platform(data)
        transformed_data["baggage"] = self.baggage

        self.log.bind(transformedPayload=transformed_data)

        if Env.CHECK_LEAD_REFERENCE_ID.lower() == "true" and data.get("dealRefIdFD"):
            validator.validate_reference_ids(
                reference_ids={"dealRefIdFD": data["dealRefIdFD"]}, should_exist=False
            )

        dr_utils.send_payload_to_queue(
            queue=Env.DEAL_DATA_QUEUE,
            payload=transformed_data,
            region=Env.AWS_REGION,
            msg_group_id=self.deal_ref_id,
            payloadType=self.payload_type,
            correlationId=self.correlation_id,
            dealTTL=validator.stored_ttl,
            dealRefId=self.deal_ref_id,
        )

        self.log.info(
            f"Key Data creation request for existing deal sent to queue: {Env.DEAL_DATA_QUEUE}"
        )

        return {"statusCode": HTTPStatus.NO_CONTENT, "headers": self.response_headers}

    def validate_target_platform(self, data):
        """
        Validate provided target platform is supported or not
        :param data: Request payload
        :return: None or raise BadRequest
        """
        self._target_platform_id = data.pop(TARGET_PLATFORM_FIELD, None)
        if (
            self._target_platform_id
            and self._target_platform_id not in DB_FIELD_MAPPING.keys()
        ):
            raise BadRequestError(
                ErrorMsgs.error_unsupported_target_platform_key_data.format(
                    field=self._target_platform_id
                )
            )

    def validate_body_by_target_platform(self, data):
        """
        Validate fields provided in the payload are supported by target platform
        :param data: Request payload
        :return: None or raise BadRequest
        """
        self.log.info(f"Validating body for targetPlatform: {self.target_platform_id}")
        target_platform_mapping = DB_FIELD_MAPPING.get(self.target_platform_id)
        dta_mapping = DB_FIELD_MAPPING.get(TargetPlatformIds.DTA)
        not_supported_fields = []
        for field in data:
            if (
                field not in target_platform_mapping.keys()
                and field not in dta_mapping.keys()
            ):
                not_supported_fields.append(field)

        if not_supported_fields:
            fields = ", ".join(not_supported_fields)
            raise BadRequestError(
                ErrorMsgs.unsupported_key_data_post_fields.format(
                    field=fields, target_platform_id=self.target_platform_id
                )
            )

    def transform_body_by_target_platform(self, data):
        """
        Transform fields provided in the payload by target platform
        :param data: Request payload
        :return: Transformed JSON
        """
        self.log.info(f"Transform body for targetPlatform: {self.target_platform_id}")
        target_platform_mapping = DB_FIELD_MAPPING.get(self.target_platform_id)
        dta_mapping = DB_FIELD_MAPPING.get(TargetPlatformIds.DTA)
        transformed_data = {}
        for field, value in data.items():
            if field in target_platform_mapping.keys():
                transformed_data[target_platform_mapping.get(field)] = value

            if field in dta_mapping.keys():
                transformed_data[dta_mapping.get(field)] = value
        transformed_data[TARGET_PLATFORM_FIELD] = self.target_platform_id
        return transformed_data


def key_data_handlers(event, content):
    handler_function = None
    if event.get("requestContext").get("operationName") == "key_data_patch":
        handler_function = KeyDataProducerLambda().get_handler(
            handler_func="existing_deal_key_data_handler",
            payload_type=PayloadType.KEY_DATA_UPDATE,
        )(event, content)

    if event.get("requestContext").get("operationName") == "key_data_post":
        handler_function = KeyDataProducerLambda().get_handler(
            handler_func="new_deal_key_data_handler",
            payload_type=PayloadType.KEY_DATA_POST,
        )(event, content)
    return handler_function
