# -*- coding: utf-8 -*-
import json
from http import HTTPStatus

import boto3
from boto3.dynamodb.conditions import Key
from common.lambda_base import GetLambda
from common.settings import Env, InfoMsgs
from common.validators import ExistingDealValidator
from utils.common import DealDataParameters
from utils.db_helper import DynamoDbHelper


class LenderIdLambda(GetLambda):
    def __init__(self, operation=None, **kwargs):
        super().__init__(operation=operation, **kwargs)
        self.dynamodb_client = boto3.resource("dynamodb", region_name=Env.AWS_REGION)
        self.db_records = []
        self.lender_ids = set()

    @GetLambda.catch_exceptions
    @GetLambda.is_handler
    def get_lender_ids(self, event, context):
        """
        Returns all the lender ids stored inside eventKeyData for a given event where dealComponent begins with
        (DTC.EVENTS). dealRefId is required to extract all lender ids
        :param dict event: An API Gateway event object
        :param dict context: AWS Lambda Context Object
        :return: JSON with status code and body
        """
        deal_ref_id = self.path_params.get("dealRefId")
        target_platform_id = self.query_string_params.pop("targetPlatformId", "DTC")
        validator = ExistingDealValidator(event, deal_ref_id)
        validator.validate_api_version(self.request_api_version)

        db = DynamoDbHelper(
            region=Env.AWS_REGION, table_name=DealDataParameters().db_name
        )
        key_expression = Key("dealRefId").eq(deal_ref_id) & Key(
            "dealComponent"
        ).begins_with(f"{target_platform_id}.EVENTS")
        self.db_records = db.query_with_selected_attributes(
            key_expr=key_expression, attributes="eventKeyData"
        )

        for item in self.db_records:
            lender_id = (item.get("eventKeyData") or {}).get("lenderId")
            if lender_id:
                self.lender_ids.add(lender_id)

        self.log.info(
            InfoMsgs.received_data_from_db.format(operation=self.operation),
            keyExpression=key_expression,
        )

        return {
            "statusCode": HTTPStatus.OK,
            "body": json.dumps({"lenderIds": list(self.lender_ids)}),
            "headers": self.response_headers,
        }


get_lender_ids = LenderIdLambda.get_handler(
    handler_func="get_lender_ids", operation="LenderIdGet"
)
