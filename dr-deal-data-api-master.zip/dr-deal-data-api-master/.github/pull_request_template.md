### PROBLEM

#### [US123456](https://rally1.rallydev.com/#/search?keywords=US1234): As a rebel, I want to use The Force as a powersource for spaceship propulsion ####

### SOLUTION

For this story, we implemented The Force-powered spaceship drive for the rebels. It allows them to utilize the power of The Force around us to travel unseen through space so that they can attack the Evil Empire.

```
Code Block if applicable.
```

### TESTING
- [ ] Local
- [ ] Unit Testing
- [ ] Functional Testing


#### Code Review checklist:

##### General
- [ ] Pull Request title appropriate
- [ ] Pull Request description captures ample information
- [ ] Feature toggle names added in the description
- [ ] Valuable unit/ integrations tests added
- [ ] Dependencies specified (*DB, Pull Request, etc*)

##### Coding practices
- [ ] Code is easy to understand
- [ ] Function and Variable names state the purpose correctly
- [ ] Functions are small in size
- [ ] Required logs and log events are added
- [ ] There is no code repeated
- [ ] There are no commented out code, print/ debug statements
- [ ] All exceptions are handled or bubbled up

##### Security
- [ ] No sensitive information is logged or visible in a stacktrace
