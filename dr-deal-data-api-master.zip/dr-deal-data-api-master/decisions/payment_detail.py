# -*- coding: utf-8 -*-
import json
from http import HTTPStatus

from common import settings as se
from common.lambda_base import GetLambda, ProducerLambda
from common.settings import Env, ErrorMsgs, InfoMsgs, S3Config
from common.validators import ExistingDealValidator
from decisions import lender_decision
from utils import common


class PaymentDetailLambda(GetLambda, ProducerLambda):
    """
    Class to Post and Get payment details from s3
    """

    def __init__(self, operation, **kwargs):
        super().__init__(operation=operation, **kwargs)
        self.deal_ref_id = None
        self.partner_dealer_id = None
        self.credit_app_id = None
        self.lender_id = None
        self.event_id = None
        self.partner_id = None

    @ProducerLambda.catch_exceptions
    @ProducerLambda.is_handler
    def post(self, event: dict, context: dict):
        """
        Store event to S3 with event_id.json and latest.json
        :param dict event: An API Gateway event object
        :param dict context: AWS Lambda Context Object
        :return: JSON with status code and body
        """

        self.deal_ref_id = common.get_path_parameter(event, "dealRefId")
        self.partner_dealer_id = common.get_path_parameter(event, "partnerDealerId")
        self.credit_app_id = common.get_path_parameter(event, "creditAppId")
        self.lender_id = common.get_path_parameter(event, "lenderId")
        self.event_id = self.request_headers.get("eventId")
        self.partner_id = self.request_headers.get(se.CD_SOURCE_PARTNER)

        self.log.bind(
            dealRefId=self.deal_ref_id,
            partnerDealerId=self.partner_dealer_id,
            creditAppId=self.credit_app_id,
            lenderId=self.lender_id,
            eventId=self.event_id,
            partnerId=self.partner_id,
        )

        self.log.info(
            "Request received to post payment details to S3", operation=self.operation
        )

        validator = ExistingDealValidator(
            event, self.deal_ref_id, new_error_message=True, validate_deal_exist=True
        )
        data = validator.validate_body(add_deal_ref_id_to_payload=False)

        validator.validate_header(
            self.request_headers, ["eventId", se.CD_SOURCE_PARTNER]
        )
        common.verify_uuid(self.event_id, validator=validator)

        ref_ids = {
            "sourcePartnerDealerId": self.partner_dealer_id,
            "creditAppId": self.credit_app_id,
            "sourcePartnerId": self.partner_id,
        }
        validator.validate_reference_ids(ref_ids)

        s3_key_event = common.generate_s3_key(
            S3Config.S3_PAYMENT_DETAILS_KEY,
            dealRefId=self.deal_ref_id,
            partnerDealerId=self.partner_dealer_id,
            creditAppId=self.credit_app_id,
            lenderId=self.lender_id,
            partnerId=self.partner_id,
            eventId=self.event_id,
        )

        s3_tag_keys = {
            "dealRefId": self.deal_ref_id,
            "partnerDealerId": self.partner_dealer_id,
            "creditAppId": self.credit_app_id,
            "lenderId": self.lender_id,
            "partnerId": self.partner_id,
            "feature": "PAYMENTDETAILS",
        }

        # Store to S3 with eventId key
        s3_tags = common.generate_s3_file_tags(s3_tag_keys)
        common.store_to_s3(
            data=data, s3_key=s3_key_event, s3_tags=s3_tags, file_type="json"
        )
        self.log.info(
            InfoMsgs.stored_payment_detail.format(
                file_name=f"eventId : {self.event_id}"
            ),
            operation=self.operation,
        )

        s3_key_latest = common.generate_s3_key(
            S3Config.S3_PAYMENT_DETAILS_KEY,
            dealRefId=self.deal_ref_id,
            partnerDealerId=self.partner_dealer_id,
            creditAppId=self.credit_app_id,
            lenderId=self.lender_id,
            partnerId=self.partner_id,
            eventId="LATEST",
        )

        # Store to S3 with latest key
        common.store_to_s3(
            data=data, s3_key=s3_key_latest, s3_tags=s3_tags, file_type="json"
        )
        self.log.info(
            InfoMsgs.stored_payment_detail.format(file_name="latest json"),
            operation=self.operation,
        )

        return {
            "statusCode": HTTPStatus.CREATED,
            "headers": self.response_headers,
        }

    @GetLambda.catch_exceptions
    @GetLambda.is_handler
    def get(self, event: dict, context: dict):
        """
        Fetches the latest payment details from S3.
        :param dict event: An API Gateway event object
        :param dict context: AWS Lambda Context Object
        :return: JSON with status code and body
        """

        self.deal_ref_id = common.get_path_parameter(event, "dealRefId")
        self.partner_dealer_id = common.get_path_parameter(event, "partnerDealerId")
        self.lender_id = common.get_path_parameter(event, "lenderId")
        self.credit_app_id = common.get_path_parameter(event, "creditAppId")
        self.partner_id = self.request_headers.get(se.CD_SOURCE_PARTNER)

        self.log.bind(
            partnerDealerId=self.partner_dealer_id,
            dealRefId=self.deal_ref_id,
            lenderId=self.lender_id,
            creditAppId=self.credit_app_id,
            partnerId=self.partner_id,
        )

        self.log.info(
            "Request received to get payment details from S3", operation=self.operation
        )

        ExistingDealValidator.validate_header(
            self.request_headers, [se.CD_SOURCE_PARTNER]
        )

        file_path = common.generate_s3_key(
            S3Config.S3_PAYMENT_DETAILS_KEY,
            dealRefId=self.deal_ref_id,
            partnerDealerId=self.partner_dealer_id,
            creditAppId=self.credit_app_id,
            lenderId=self.lender_id,
            partnerId=self.partner_id,
            eventId="LATEST",
        )

        status_code, data = lender_decision.get_latest_decision_from_s3(
            Env.DEAL_BUCKET, file_path
        )
        if status_code == HTTPStatus.NOT_FOUND:
            self.log.error(ErrorMsgs.payment_detail_not_found, operation=self.operation)
        elif status_code == HTTPStatus.OK:
            self.log.info(InfoMsgs.retrieved_payment_detail, operation=self.operation)

        return {
            "statusCode": status_code,
            "body": json.dumps(data, cls=common.decimal_decoder()),
            "headers": self.response_headers,
        }


def payment_detail_handler(event, context):
    if (
        event.get("headers", {}).get(se.HEALTHCHECK_HEADER_FIELD)
        == se.HEALTHCHECK_HEADER_VALUE
    ):
        return {"statusCode": HTTPStatus.CREATED, "body": json.dumps("Operational")}
    operation = event.get("requestContext").get("operationName")
    routes = {
        "payment_detail_post": PaymentDetailLambda.get_handler(
            handler_func="post", operation="Post Payment Detail"
        ),
        "payment_detail_get": PaymentDetailLambda.get_handler(
            handler_func="get", operation="Get Payment Detail"
        ),
    }
    handler_function = routes.get(operation)
    return handler_function(event, context)
