# -*- coding: utf-8 -*-
import json
import re
from http import HTTPStatus

import boto3
from common import settings as se
from common.lambda_base import GetLambda
from common.settings import PII_DATA_KEYS, Env, ErrorMsgs, InfoMsgs, S3Config
from common.validators import ExistingDealValidator
from utils import EventsEnum, common, logger
from utils.exceptions import BadRequestError


def get_latest(event, context):
    """
    Fetches the json file and sends it to the response. The json file is expected to be saved by events framework.
    Deal data api does not have a means to save the API.
    :param dict event: An API Gateway event object
    :param dict context: AWS Lambda Context Object
    :return: JSON with status code and body
    """
    operation = se.LENDER_DECISION_OPERATION
    (
        body,
        corr_id,
        response_header,
        request_version,
        headers,
    ) = common.get_common_attributes(event, Env.AWS_REGION, Env.VERSION)

    if headers.get(se.HEALTHCHECK_HEADER_FIELD) == se.HEALTHCHECK_HEADER_VALUE:
        return {"statusCode": HTTPStatus.CREATED, "body": json.dumps("Operational")}

    deal_ref_id = common.get_path_parameter(event, "dealRefId")
    partner_dealer_id = common.get_path_parameter(event, "partnerDealerId")
    lender_id = common.get_path_parameter(event, "lenderId")
    source_partner = headers.get(se.CD_SOURCE_PARTNER)

    log = logger.new(
        functionArn=context.invoked_function_arn,
        correlationId=corr_id,
        partnerDealerId=partner_dealer_id,
        dealRefId=deal_ref_id,
        lenderId=lender_id,
        requestHeaders=headers,
    )
    try:
        ExistingDealValidator.validate_header(headers, [se.CD_SOURCE_PARTNER])

        file_prefix = (
            f"{source_partner}/{partner_dealer_id}/{deal_ref_id}/CA/{lender_id}/latest"
        ).upper()

        status_code, data = get_latest_decision_from_s3(Env.DEAL_BUCKET, file_prefix)
        log.info(InfoMsgs.processing_lender_decision.format(operation=operation))

        return {
            "statusCode": status_code,
            "body": json.dumps(data, cls=common.decimal_decoder()),
            "headers": response_header,
        }
    except BadRequestError as error:
        message = (
            f"{ErrorMsgs.error_processing_get.format(operation=operation)} {error}"
        )
        log.warning(message, exc_info=error, aws_event=EventsEnum.decision_get_failed)
        return_body = {"message": str(error)}
        return {
            "statusCode": HTTPStatus.BAD_REQUEST,
            "body": json.dumps(return_body),
            "headers": response_header,
        }
    except Exception:
        message = ErrorMsgs.error_processing_get.format(operation=operation)
        log.exception(message, _event=EventsEnum.decision_get_failed)
        return_body = {"message": "Unable to process request"}
        return {
            "statusCode": HTTPStatus.INTERNAL_SERVER_ERROR,
            "body": json.dumps(return_body),
            "headers": response_header,
        }


def get_latest_decision_from_s3(bucket_name, file, include_pii=False):
    """

    :param bucket_name: bucket name where the function will search for the file.
    :param file: The name of the file used to search. A .json will be suffixed.
    :return: status_code, 200 if found and 404 if not found.
    :param include_pii: bool field to scrub pii or not
    :return: data, the contents of the file or a not found message.
    """
    s3_object = boto3.client("s3")

    data = '{"message": "Not Found"}'

    status_code = HTTPStatus.NOT_FOUND
    list_files = s3_object.list_objects_v2(Bucket=bucket_name, Prefix=file)

    if list_files["KeyCount"] > 0:
        s3_file_obj = s3_object.get_object(Bucket=bucket_name, Key=f"{file}.json")
        data = s3_file_obj["Body"].read().decode("utf-8")
        status_code = HTTPStatus.OK

    if not include_pii:
        data = scrub_pii_data(data)

    return status_code, json.loads(data)


def scrub_pii_data(data: str):
    """
    This method will scrub PII/ Protected data keys from payload
    :param data: original payload fetched from S3
    :return: scrubbed data
    """
    for key in PII_DATA_KEYS:
        string = re.compile(rf'"{key}": "(.*?)(?<!\\)"', re.DOTALL)
        data = string.sub(f'"{key}": "XXXX"', data)

    return data


class FLDWithCreditAppLambda(GetLambda):
    """
    Class to Get full lender decision with creditAppId from s3
    """

    def __init__(self, operation, **kwargs):
        super().__init__(operation=operation, **kwargs)
        self.deal_ref_id = None
        self.partner_dealer_id = None
        self.credit_app_id = None
        self.lender_id = None
        self.partner_id = None

    @GetLambda.catch_exceptions
    @GetLambda.is_handler
    def get(self, event: dict, context: dict):
        """
        Fetches the latest full lender decision with creditAppId from S3
        :param dict event: An API Gateway event object
        :param dict context: AWS Lambda Context Object
        :return: JSON with status code and body
        """

        self.deal_ref_id = common.get_path_parameter(event, "dealRefId")
        self.partner_dealer_id = common.get_path_parameter(event, "partnerDealerId")
        self.lender_id = common.get_path_parameter(event, "lenderId")
        self.credit_app_id = common.get_path_parameter(event, "creditAppId")
        self.partner_id = self.request_headers.get(se.CD_SOURCE_PARTNER)

        self.log.bind(
            partnerDealerId=self.partner_dealer_id,
            dealRefId=self.deal_ref_id,
            lenderId=self.lender_id,
            creditAppId=self.credit_app_id,
            partnerId=self.partner_id,
        )

        self.log.info(
            "Request received to get full lender decision with creditAppId from S3",
            operation=self.operation,
        )

        ExistingDealValidator.validate_header(
            self.request_headers, [se.CD_SOURCE_PARTNER]
        )

        file_path = common.generate_s3_key(
            S3Config.S3_FLD_WITH_CREDIT_APP_KEY,
            dealRefId=self.deal_ref_id,
            partnerDealerId=self.partner_dealer_id,
            creditAppId=self.credit_app_id,
            lenderId=self.lender_id,
            partnerId=self.partner_id,
            eventId="LATEST",
        )

        status_code, data = get_latest_decision_from_s3(Env.DEAL_BUCKET, file_path)
        if status_code == HTTPStatus.NOT_FOUND:
            self.log.error(
                ErrorMsgs.fld_with_credit_app_not_found, operation=self.operation
            )
        elif status_code == HTTPStatus.OK:
            self.log.info(
                InfoMsgs.retrieved_fld_with_credit_app_id, operation=self.operation
            )

        return {
            "statusCode": status_code,
            "body": json.dumps(data, cls=common.decimal_decoder()),
            "headers": self.response_headers,
        }


def fld_with_credit_app_handler(event, context):
    if (
        event.get("headers", {}).get(se.HEALTHCHECK_HEADER_FIELD)
        == se.HEALTHCHECK_HEADER_VALUE
    ):
        return {"statusCode": HTTPStatus.CREATED, "body": json.dumps("Operational")}
    operation = event.get("requestContext", {}).get("operationName")
    routes = {
        "fld_with_credit_app_get": FLDWithCreditAppLambda.get_handler(
            handler_func="get", operation="Get FLD with creditAppId"
        ),
    }
    handler_function = routes.get(operation)
    return handler_function(event, context)
