#!/bin/bash

set -e

function parse_arguments() {
  while [ $# -gt 0 ]; do
    case "$1" in
    --action=*)
      ACTION="${1#*=}"
      ;;
    --artifactory_creds=*)
      ARTIFACTORY_CREDS="${1#*=}"
      ;;
    --deploy_env=*)
      DEPLOY_ENV="${1#*=}"
      ;;
    --stage=*)
      STAGE="${1#*=}"
      ;;
    --aws_region=*)
      AWS_REGION="${1#*=}"
      ;;
    --version=*)
      VERSION="${1#*=}"
      ;;
    --run_function=*)
      RUN_FUNCTION="${1#*=}"
      ;;
    --run_test=*)
      RUN_TEST="${1#*=}"
      ;;
    *)
      echo "[Error] Invalid argument $1"
      exit 1
      ;;
    esac
    shift
  done
}

function run_docker() {
  echo "[INFO] Running Docker"
  docker-compose run --rm api
}

function install_prerequisites() {
  echo "[INFO] Install requirements"
  pip3 install -r requirements_pr.txt --index-url=https://"$ARTIFACTORY_CREDS"@artifactory.coxautoinc.com/artifactory/api/pypi/dtfni-pypi/simple/
  echo "[INFO] Install node modules"
  npm install
}

function run_terraform() {
  echo "[INFO] Deploying terraform infrastructure..."
  pushd terraform
  bash manage.sh deploy "$AWS_REGION" "$DEPLOY_ENV" serverless
  popd
}

function deploy_serverless() {
  pushd serverless
  echo "[INFO] Deal data serverless deploy STARTED..."
  serverless deploy --force --verbose --stage="$STAGE" --region="$AWS_REGION" --param="deploy_env=$DEPLOY_ENV" --param="aws_version=$VERSION" --param="artifactory_creds=$ARTIFACTORY_CREDS"
  popd
}

function remove_serverless() {
  pushd serverless
  echo "[INFO] Deal data serverless remove STARTED..."
  serverless remove --stage="$STAGE" --param="deploy_env=$DEPLOY_ENV" --param="region=$AWS_REGION" --param="aws_version=$VERSION" --param="artifactory_creds=$ARTIFACTORY_CREDS"
  serverless remove logs --stage="$STAGE" --param="deploy_env=$DEPLOY_ENV" --param="region=$AWS_REGION" --param="aws_version=$VERSION" --param="artifactory_creds=$ARTIFACTORY_CREDS"
  aws logs delete-log-group --log-group-name /aws/api-gateway/dr-deal-data-api-"$STAGE"
  echo "[INFO] Deal data serverless remove COMPLETE..."
  popd
}

function run_functional_tests() {
  echo "[INFO] Running function test for $RUN_TEST"
  pytest -vv tests/functional/"$RUN_TEST" --stage="$STAGE" --env="$DEPLOY_ENV" --api_version="$VERSION" --region="$AWS_REGION"
}

function cleanup() {
  rm -rf artifact
  rm -rdf serverless/.serverless
  rm -rdf serverless/schemas
  rm -rf serverless/deploy.out
  rm -rdf terraform/serverless/.terraform*
  rm -rdf .pytest_cache
  rm -rdf .coverage
  rm -rdf htmlcov
  echo "[INFO] Cleanup Completed"
}

parse_arguments "$@"

CURRENT_PATH=$(pwd)
echo "[INFO] CURRENT_PATH = ${CURRENT_PATH}"

if [ "$ACTION" = "deploy" ]; then
  deploy_serverless
elif [ "$ACTION" = "remove" ] && [[ "$DEPLOY_ENV" == "np_pr" || "$DEPLOY_ENV" == "lab" ]]; then
  remove_serverless
elif [ "$RUN_FUNCTION" ]; then
  echo "[INFO] Running function $RUN_FUNCTION"
  $RUN_FUNCTION
fi
