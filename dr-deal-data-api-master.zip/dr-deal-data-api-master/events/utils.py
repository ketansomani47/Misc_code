# -*- coding: utf-8 -*-
import os


class Env:
    """Environment variables. Wrapped in a class to simplify testing."""

    DEPLOY_ENV = os.environ.get("DEPLOY_ENV")
    AWS_REGION = os.environ.get("REGION")
    EVENT_QUEUE = os.environ.get("EVENT_QUEUE")
    EVENT_ROUTE_QUEUE = os.environ.get("EVENT_ROUTE_QUEUE")
    DEAL_DATA_DLQ = os.environ.get("DEAL_DATA_DLQ")
    VERSION = os.environ.get("VERSION")
    EVENTS_ENDPOINT = os.environ.get("EVENTS_ENDPOINT")
    SETTINGS_ENDPOINT = os.environ.get("SETTINGS_ENDPOINT")
    SETTINGS_API_KEY = os.environ.get("SETTINGS_API_KEY")
