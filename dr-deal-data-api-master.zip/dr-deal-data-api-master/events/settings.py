# -*- coding: utf-8 -*-

DEAL_DATA_ENV_MAPPING = {
    "np_pr": {
        "url": "https://deal-data-dvi1.drsvcnp.aws.dealertrack.com",
        "key": "VmjmjZpH5wcLd6VcSKUNxC301dT41YbzYME1EbIyn",
    },
    "lab": {
        "url": "https://deal-data-dvi1.drsvcnp.aws.dealertrack.com",
        "key": "VmjmjZpH5wcLd6VcSKUNxC301dT41YbzYME1EbIyn",
    },
    "dev": {
        "url": "https://deal-data-dvi1.drsvcnp.aws.dealertrack.com",
        "key": "VmjmjZpH5wcLd6VcSKUNxC301dT41YbzYME1EbIyn",
    },
    "qa": {
        "url": "https://deal-data-qa.drsvcnp.aws.dealertrack.com",
        "key": "ZNzY6z2yzJ3BDAOc3aQX03Pm6cqmk1ZR84VntVaOo",
    },
    "pa": {
        "url": "https://deal-data-pa.drapi-pp.aws.dealertrack.com",
        "key": "8bcm9vUZhL15Eci2yRP7h79HtaEbq3ceOeQcf8zgx",
    },
    "uat": {
        "url": "https://deal-data.drsvcpp.aws.dealertrack.com",
        "key": "jjQ1VYlZim9ZNHhR4LrYQ5Pf9jUIgUqF5Q6hqZwG",
    },
    "prod": {
        "url": "https://deal-data.drsvc.aws.dealertrack.com",
        "key": "8bcm9vUVhL15Eci2yRR7h79HtmEbq3ceOeQcf8zgx",
    },
}

EVENT_SOURCE = "ideal:Deals"

EVENT_NAME_MAPPING = {
    "Approved": "CreditDecisions:Approved",
    "Declined": "CreditDecisions:Declined",
    "AppSubmitted": "CreditApplications:Submitted",
}

EVENT_TYPE_MAPPING = {
    "Approved": "ideal:CreditDecisions",
    "Declined": "ideal:CreditDecisions",
    "AppSubmitted": "ideal:CreditApplications",
}


class EventSource:
    """
    This class is registration for all event source
    """

    DECISIONS = "AHC:DECISIONS"
    CREDITBUREAUS = "DR:CREDITBUREAURESPONSE"
