# -*- coding: utf-8 -*-
import copy
import json
from datetime import datetime, timezone
from decimal import Decimal
from http import HTTPStatus
from uuid import uuid4 as uuid

import boto3
import dr_utils
from common.settings import ErrorMsgs
from events.settings import EventSource
from events.utils import Env
from utils import EventsEnum, common, logger
from utils.common import DealDataParameters


def handler(event, context):
    """
    Get payload as an event from EVENT_QUEUE and process it based on type of event
    :param dict event: help to get api body and headers.
    :param context: context received with event
    :return: ACK will be based on body receive
    """
    message = next(iter(event.get("Records")), {})
    body = message.get("body")
    corr_id = dr_utils.get_sqs_msg_attr("correlationId", message) or str(uuid())
    payload_type = dr_utils.get_sqs_msg_attr("payloadType", message)
    log = logger.new(
        functionArn=context.invoked_function_arn,
        correlationId=corr_id,
        payloadType=payload_type,
    )
    try:
        data = json.loads(body, parse_float=Decimal)
        resp = {}
        if not data:
            raise Exception(ErrorMsgs.missing_body_aws_event)

        deal_ref_id = data.get("eventTransactionId")
        log.bind(dealRefId=deal_ref_id)

        if payload_type == EventSource.DECISIONS:
            resp = process_decision_event(data=data, deal_ref_id=deal_ref_id)

        # send credit app decision to event route queue to process it further
        dr_utils.send_payload_to_queue(
            queue=Env.EVENT_ROUTE_QUEUE,
            payload=data,
            region=Env.AWS_REGION,
            msg_group_id=deal_ref_id,
            payloadType=payload_type,
            correlationId=corr_id,
        )

        return {
            "statusCode": HTTPStatus.OK,
            "body": json.dumps({"description": resp, "dealRefId": deal_ref_id}),
        }

    except json.JSONDecodeError as e:
        log.exception(
            "Invalid JSON received",
            requestPayload=body,
            _event=EventsEnum.event_parsing_failed,
        )
        raise e

    except Exception as error:
        message = ErrorMsgs.sending_msg_dlq.format(
            payload_type=payload_type, queue=Env.DEAL_DATA_DLQ, error=error
        )
        log.exception(
            message,
            requestPayload=body,
            _event=EventsEnum.event_processing_failed,
        )
        raise error


def process_decision_event(data: dict, deal_ref_id: str):
    """
    Persists decision event in dynamodb and send data to event route queue
    :param data: event payload
    :param deal_ref_id: unique id for given deal
    :return: response with description and dealRefId
    """
    data = copy.deepcopy(data)
    data = common.convert_empty_strings_to_none(data)
    records = [
        add_deal_info(data, deal_ref_id),
        add_deal_info(data, deal_ref_id, include_timestamp=True),
    ]

    persist_deal_records(records=records, table_name=DealDataParameters().db_name)
    logger.info("event response saved successfully")
    return "Decision stored successfully."


def get_event_timestamp(time=None):
    """
    Convert time string to timestamp till millisecond
    :param time: date time string in this format: "%Y-%m-%dT%H:%M:%S.%fZ". For ex: 2020-01-11T12:34:45.034Z
    :return: timestamp till millisecond. For ex: 1569852310233
    """
    if not time:
        time = datetime.isoformat(datetime.utcnow()) + "Z"
    dt = datetime.strptime(time, "%Y-%m-%dT%H:%M:%S.%fZ").replace(tzinfo=timezone.utc)
    time_stamp = datetime.timestamp(dt)
    # time_stamp will be like this 1578109955.147632, to convert it for millisecond do int(1578109955.147632*1000)
    return int(time_stamp * 1000)


def add_deal_info(
    event_data, deal_ref_id, event_str="DECISION", include_timestamp=False
):
    """
    Add dealComponent and dealRefId to given event
    :param event_data: event json having decision or ack information
    :param deal_ref_id: unique id for given deal
    :param event_str: event string like DECISION
    :param include_timestamp: includes time stamp if required in deal component
    :return: event object with dealRefId and dealComponent
    """
    resp = {}
    timestamp = get_event_timestamp(event_data.get("eventTime"))
    lender_id = event_data["payload"].get("lenderId")
    deal_component = f"{lender_id}.{event_str}"
    deal_component = (
        f"{deal_component}.{timestamp}" if include_timestamp else deal_component
    )
    deal_ref_id = f"{deal_ref_id}.{event_str}" if include_timestamp else deal_ref_id
    resp.update(event_data)
    resp.update({"dealRefId": deal_ref_id, "dealComponent": deal_component})
    return resp


def persist_deal_records(records: list, table_name: str):
    """
    Update record with dealRefId, createdTimestamp and updatedTimestamp and insert data into dynamodb.
    :param records: list of records that need to be inserted
    :param table_name: dynamo db table name
    :return: dealComponent
    """
    current_time = datetime.isoformat(datetime.utcnow())
    dynamodb = boto3.resource("dynamodb", region_name=Env.AWS_REGION)
    table = dynamodb.Table(table_name)
    with table.batch_writer() as batch:
        for record in records:
            record.update(
                {"createdTimestamp": current_time, "updatedTimestamp": current_time}
            )
            batch.put_item(record)
