# -*- coding: utf-8 -*-
import json
from http import HTTPStatus
from uuid import uuid4 as uuid

import dr_utils
import ulid
from boto3.dynamodb.conditions import Key
from common import settings as se
from common.mixins import process_exception
from common.settings import ErrorMsgs
from events.settings import EventSource
from events.utils import Env
from stringcase import camelcase
from utils import EventsEnum, common, logger
from utils.common import DealDataParameters
from utils.db_helper import DynamoDbHelper
from utils.exceptions import BadRequestError


def post(event, context):
    """Decision Event post endpoint.
    Accept decision summary as event and process it to EVENT_QUEUE.
    :param event: help to get api body and headers.
    :param context:
    :return: Currently no validation, so ACK will be based on body receive
    """
    body = event.get("body", "{}")
    headers = event.get("headers", {}) or {}
    corr_id = headers.get(se.CORRELATION_ID_HEADER_KEY) or str(uuid())
    payload_type = "EVENT"

    # The current design has a flaw, if no deal_ref_id is present or invalid JSON is provided we won't be able to
    # extract the deal_ref_id which will not send messages to the DLQ as all DLQs are fifo now. FIFO queues require a
    # message group id, if not present they won't take the payload
    deal_ref_id = ulid.new().str

    log = logger.new(functionArn=context.invoked_function_arn, correlationId=corr_id)
    response_header = common.get_response_header(corr_id, Env.AWS_REGION, Env.VERSION)

    if headers.get(se.HEALTHCHECK_HEADER_FIELD) == se.HEALTHCHECK_HEADER_VALUE:
        return {"statusCode": HTTPStatus.CREATED, "body": json.dumps("Operational")}
    try:
        data = json.loads(body)
        if not data:
            raise Exception(ErrorMsgs.missing_body_aws_event)

        data = common.change_dict_naming(data, camelcase)
        deal_ref_id = data.get("eventTransactionId")

        log.bind(dealRefId=deal_ref_id)

        payload_type = data.get("eventSource", "").upper()

        if not data.get("eventId"):
            data["eventId"] = str(uuid())

        log.info("Event Received", data=data)
        dr_utils.send_payload_to_queue(
            queue=Env.EVENT_QUEUE,
            payload=data,
            region=Env.AWS_REGION,
            msg_group_id=deal_ref_id,
            payloadType=data.get("eventSource", "").upper(),
            correlationId=corr_id,
        )
        log.info(f"Event successfully sent to {Env.EVENT_QUEUE}")
        return_body = {"status": "SUCCESS"}
        return {
            "statusCode": HTTPStatus.OK,
            "body": json.dumps(return_body),
            "headers": response_header,
        }
    except json.JSONDecodeError as error:
        log.exception(
            "Invalid event payload received",
            requestPayload=body,
            _event=EventsEnum.event_parsing_failed,
        )
        return process_exception(
            error=error,
            event=event,
            status_code=HTTPStatus.BAD_REQUEST,
            headers=response_header,
            queue_name=Env.DEAL_DATA_DLQ,
            region=Env.AWS_REGION,
            correlation_id=corr_id,
            msg_group_id=deal_ref_id,
        )
    except Exception as error:
        message = ErrorMsgs.sending_msg_dlq.format(
            payload_type=payload_type, queue=Env.DEAL_DATA_DLQ, error=error
        )
        log.exception(
            message,
            requestPayload=body,
            _event=EventsEnum.event_processing_failed,
        )
        return process_exception(
            error=error,
            event=event,
            headers=response_header,
            queue_name=Env.DEAL_DATA_DLQ,
            region=Env.AWS_REGION,
            correlation_id=corr_id,
            msg_group_id=deal_ref_id,
        )


def reprocess_handler(event, context):
    deal_ref_id = common.get_path_parameter(event, "eventTransactionId")
    deal_component = common.get_path_parameter(event, "dealComponent")
    try:
        (
            body,
            corr_id,
            response_header,
            request_version,
            headers,
        ) = common.get_common_attributes(event, Env.AWS_REGION, Env.VERSION)

        log = logger.new(
            functionArn=context.invoked_function_arn,
            dealRefId=deal_ref_id,
            correlationId=corr_id,
            dealComponent=deal_component,
        )
        log.info("Event reprocess request received")

        if headers.get(se.HEALTHCHECK_HEADER_FIELD) == se.HEALTHCHECK_HEADER_VALUE:
            return {"statusCode": HTTPStatus.CREATED, "body": json.dumps("Operational")}

        event_deal_payload = get_event_deal(deal_ref_id, deal_component)

        # send credit app decision to event route queue to process it further
        dr_utils.send_payload_to_queue(
            queue=Env.EVENT_ROUTE_QUEUE,
            payload=event_deal_payload,
            region=Env.AWS_REGION,
            msg_group_id=deal_ref_id,
            correlationId=corr_id,
            payloadType=EventSource.DECISIONS,
        )
        log.info(f"Event reprocessing request sent to queue: {Env.EVENT_ROUTE_QUEUE}")

        return {"statusCode": HTTPStatus.NO_CONTENT}
    except BadRequestError as error:
        message = f"{ErrorMsgs.error_processing_get.format(operation='Event Reprocess')} {error}"
        log.warning(message, _event=EventsEnum.deal_get_failed)
        return_body = {"dealRefId": deal_ref_id, "message": str(error)}
        return {"statusCode": HTTPStatus.BAD_REQUEST, "body": json.dumps(return_body)}
    except Exception as error:
        message = ErrorMsgs.error_processing_get.format(operation="Event Reprocess")
        log.exception(message, _event=EventsEnum.deal_get_failed)
        return_body = {"dealRefId": deal_ref_id, "message": str(error)}
        return {
            "statusCode": HTTPStatus.INTERNAL_SERVER_ERROR,
            "body": json.dumps(return_body),
        }


def get_event_deal(deal_ref_id, deal_component):
    """
    Fetches event details based on deal_component.
    :param str deal_ref_id: as failed event transaction id.
    :param str deal_component: dynamodb deal_component. e.g. AHC.DECISION.
    :return: Event details for given deal_ref_id and deal_component.
    """
    key_expression = Key("dealRefId").eq(deal_ref_id) & Key("dealComponent").eq(
        deal_component
    )
    db = DynamoDbHelper(region=Env.AWS_REGION, table_name=DealDataParameters().db_name)
    db_records = db.query_items(key_expression=key_expression)

    if not db_records:
        raise BadRequestError("No event data found or invalid transaction id passed.")

    return db_records[0]
