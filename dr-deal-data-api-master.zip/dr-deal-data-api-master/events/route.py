# -*- coding: utf-8 -*-
import json
from http import HTTPStatus
from uuid import uuid4 as uuid

import dr_utils
import requests
from common import settings
from common.settings import ErrorMsgs
from events.settings import (
    DEAL_DATA_ENV_MAPPING,
    EVENT_NAME_MAPPING,
    EVENT_SOURCE,
    EVENT_TYPE_MAPPING,
    EventSource,
)
from events.utils import Env
from key_data import get
from requests.exceptions import ConnectTimeout
from utils import EventsEnum, logger


def handler(event, context):
    """Decision Event post endpoint.
    Accept decision summary as event and post it to FD.
    :param dict event: An API Gateway event object
    :param dict context: AWS Lambda Context Object
    :return: Currently no validation, so ACK will be based on body receive
    """
    message = next(iter(event.get("Records")), {})
    body = message.get("body")
    corr_id = dr_utils.get_sqs_msg_attr("correlationId", message) or str(uuid())
    payload_type = dr_utils.get_sqs_msg_attr("payloadType", message)
    log = logger.new(
        functionArn=context.invoked_function_arn,
        correlationId=corr_id,
        payloadType=payload_type,
    )
    log.info(f"Processing event response from queue {Env.EVENT_ROUTE_QUEUE}")

    try:
        data = json.loads(body)
        if not data:
            raise Exception(ErrorMsgs.missing_body_aws_event)

        event_trans_id = data.get("eventTransactionId")
        log.bind(dealRefId=event_trans_id)

        if payload_type == EventSource.DECISIONS:
            log.info("Processing credit app decision")
            resp_text = process_honda_decision(
                context, event_trans_id, body, data, corr_id, log, payload_type
            )
        elif payload_type == EventSource.CREDITBUREAUS:
            log.info("Processing credit bureau event")
            resp_text = route_cb_response(
                body=body, correlation_id=corr_id, cb_pull_id=event_trans_id
            )
        else:
            resp_text = (
                f"Unregistered event source:{payload_type}, message cannot be routed"
            )
            log.warning(resp_text)

    except json.JSONDecodeError as e:
        log.exception(
            "Invalid JSON received",
            requestPayload=body,
            _event=EventsEnum.app_parsing_failed,
        )
        raise e

    except (ConnectTimeout, TimeoutError):
        status_code, resp_text = dr_utils.retry_or_fail(
            data=data,
            retry_delay_mapper=settings.RETRY_DELAY_TIME,
            retry_queue=Env.EVENT_ROUTE_QUEUE,
            failure_queue=Env.DEAL_DATA_DLQ,
            region=Env.AWS_REGION,
            deal_ref_id=data.get("eventTransactionId"),
            correlation_id=corr_id,
            payload_type=payload_type,
        )
        """
        For Connection or Timeout errors we send application to Event Route Queue for a retry logic, and return
        status code 504 for every retry or else return 200 and dump the message in DealDataDLQ.
        """
        log.exception(
            resp_text, requestPayload=data, _event=EventsEnum.fd_timeout_error
        )
        return {"statusCode": status_code, "body": json.dumps(resp_text)}

    except Exception as error:
        resp_text = str(error)
        log.exception(resp_text, _event=EventsEnum.event_processing_failed)
        raise error

    return {"statusCode": HTTPStatus.OK, "body": json.dumps(resp_text)}


def process_honda_decision(
    context,
    event_trans_id: str,
    body: str,
    data: dict,
    corr_id: str,
    log: logger,
    payload_type: str,
) -> str:
    """Function to process honda decision by performing:
       - a look up in key-data for sourcePartnerId;
       - get a subscription of sourcePartnerId to iDeal.
    :param context: event transaction id
    :param event_trans_id: event transaction id
    :param body: event payload
    :param data: deserialized event payload
    :param corr_id: correlation_id
    :param log: log entity
    :param payload_type: Type of payload
    :return: string response text
    """
    event_key_data = _proceed_source_partner_condition(
        context, event_trans_id, corr_id, log
    )

    source_partner_id = event_key_data.get("sourcePartnerId")

    log.bind(
        dealRefId=event_trans_id,
        payloadType=payload_type,
        sourcePartnerId=source_partner_id,
    )

    log.info("Routing event to Events Framework")
    resp_text = route_to_events(
        data=data,
        event_key_data=event_key_data,
        deal_ref_id=event_trans_id,
        correlation_id=corr_id,
        log=log,
    )
    return resp_text


def route_to_events(
    data: dict, event_key_data: dict, deal_ref_id: str, correlation_id: str, log: logger
) -> str:
    """
    Event is routed to the Events Framework
    :param data: event payload
    :param event_key_data: event_key_data
    :param deal_ref_id: eventTransactionId
    :param correlation_id: correlation id
    :param log: event logger
    :return: success message

    """
    endpoint = (
        settings.SIMULATOR_POST
        if correlation_id.endswith("_TEST")
        else f"https://{Env.EVENTS_ENDPOINT}"
    )

    log.info("Processing and transforming event and sent it to Events Framework")

    stipulations = None
    if (
        data["payload"].get("stipulations") != []
        and data["payload"].get("stipulations") is not None
    ):
        stipulations = data["payload"].pop("stipulations")
        stipulations = [
            {"text": i} if not isinstance(i, dict) else i for i in stipulations
        ]

    event = {
        "eventVersion": "1.2",
        "eventId": data.get("eventId"),
        "eventIdentityId": str(uuid()),
        "eventEntityId": data.get("eventEntityId"),
        "eventTransactionId": data.get("eventTransactionId"),
        "eventName": EVENT_NAME_MAPPING[data.get("payload").get("approvalStatus")],
        "eventType": EVENT_TYPE_MAPPING[data.get("payload").get("approvalStatus")],
        "eventSource": EVENT_SOURCE,
        "eventTime": data.get("eventTime"),
        "eventDetailHref": data.get("eventDetailHref"),
        "payload": {
            "status": data.get("payload").get("approvalStatus"),
            "approvedAmount": data.get("payload").get("approvedAmount"),
            "approvedRate": data.get("payload").get("approvedRate"),
            "approvedTerm": data.get("payload").get("approvedTerm"),
            "lenderId": data.get("payload").get("lenderId"),
            "lenderName": data.get("payload").get("lenderName"),
            "tier": data.get("payload").get("tier"),
            "stipulations": stipulations,
            "monthlyPayment": data.get("payload").get("monthlyPayment"),
            "lenderMoneyFactor": data.get("payload").get("lenderMoneyFactor"),
            "customerMoneyFactor": data.get("payload").get("customerMoneyFactor"),
            "downPayment": data.get("payload").get("downPayment"),
            "financeMethod": data.get("payload").get("financeMethod"),
            "lenderApplicationId": data.get("payload").get("lenderApplicationId"),
            "rateVariance": data.get("payload").get("rateVariance"),
        },
        "eventKeyData": {
            "appRefIdFD": event_key_data.get("appRefIdFD"),
            "dealRefIdDR": event_key_data.get("dealRefId"),
            "lenderId": data.get("payload").get("lenderId"),
            "partnerCode": event_key_data.get("partnerCode"),
            "sourcePartnerDealerId": event_key_data.get("sourcePartnerDealerId"),
            "sourcePartnerId": event_key_data.get("sourcePartnerId"),
            "dealerCode": event_key_data.get("dealerCode"),
            "dealJacketId": event_key_data.get("dealJacketId"),
            "dealerId": data.get("eventIdentityId"),
        },
    }

    json_body = json.dumps(event)

    log.bind(eventsUrl=endpoint)
    headers = {"X-CoxAuto-Correlation-Id": correlation_id}
    resp = requests.post(endpoint, data=json_body, headers=headers)
    log.info(
        "Response from Events Framework",
        responseBody=resp.text,
        statusCode=resp.status_code,
        dealRefId=deal_ref_id,
    )

    if resp.status_code != HTTPStatus.CREATED:
        raise Exception("Failed to submit event to EventsFramework")

    log.info("Event was successfully sent to EventsFramework")

    return "Successfully Sent"


def route_cb_response(body: str, correlation_id: str, cb_pull_id: str):
    """
    Routes the event to deal data api
    :param body: event payload
    :param correlation_id:
    :param cb_pull_id: unique id for the cb pull id
    :return: success message

    """
    if cb_pull_id.endswith("_TEST"):
        endpoint = settings.SIMULATOR_POST
    else:
        endpoint = get_cb_response_endpoint(Env.DEPLOY_ENV)

    dd_headers = get_deal_data_headers(correlation_id=correlation_id)

    resp = requests.post(endpoint, data=body, headers=dd_headers, timeout=5)
    logger.bind(dealdataUrl=endpoint)

    if resp.status_code != HTTPStatus.CREATED:
        raise Exception(f"Failed to submit {EventSource.CREDITBUREAUS} to DealData API")

    logger.info(
        "Response from Deal Data API",
        responseBody=resp.text,
        statusCode=resp.status_code,
    )

    return "Successfully sent to deal data api"


def get_deal_data_api_key(env: str):
    return DEAL_DATA_ENV_MAPPING[env]["key"]


def get_cb_response_endpoint(env: str):
    """
    Constructs credit bureau response endpoint based on environment
    :param env: environment name
    :return: string environment specific url

    """
    url = DEAL_DATA_ENV_MAPPING[env]["url"]
    version = Env.VERSION

    return f"{url}/v{version[0]}/credit-bureau-response"


def get_deal_data_headers(correlation_id: str):
    """
    Constructs deal data headers based on environment
    :param api_key: apikey
    :param correlation_id: correlation_id
    :return: string url
    """
    headers = {"X-CoxAuto-Correlation-Id": correlation_id}
    return headers


def _proceed_source_partner_condition(context, event_trans_id, correlation_id, log):
    event = {
        "path": "/v1/deals/key-data/",
        "queryStringParameters": {
            "dealRefId": event_trans_id,
            "targetPlatformId": "IDL",
        },
        "headers": {settings.CORRELATION_ID_HEADER_KEY: correlation_id},
    }
    key_data_response = get.key_data_get(event, context)
    event_key_data = json.loads(key_data_response["body"])
    log.info(
        "Response from key data",
        statusCode=key_data_response["statusCode"],
        responseBody=event_key_data,
    )
    if not event_key_data:
        raise Exception("Failed to get key data record")

    return event_key_data[0]
