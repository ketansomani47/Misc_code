# -*- coding: utf-8 -*-
import json
import uuid
from datetime import datetime
from decimal import Decimal
from functools import reduce
from http import HTTPStatus

import utils.schema
from boto3.dynamodb.conditions import And, Attr, Key
from botocore.exceptions import ClientError
from common import settings
from common.lambda_base import GetLambda, ProducerLambda
from common.settings import (
    GET_EVENTS_FILTER_PARAMS,
    Env,
    ErrorMsgs,
    InfoMsgs,
    SchemaType,
)
from common.validators import ExistingDealValidator
from utils import common
from utils.common import DealDataParameters
from utils.db_helper import DynamoDbHelper
from utils.exceptions import BadRequestError


class EventsLambda(GetLambda, ProducerLambda):
    def __init__(self, operation=None, **kwargs):
        super().__init__(operation=operation, **kwargs)

    @GetLambda.catch_exceptions
    @GetLambda.is_handler
    def get_event(self, event, context):
        """
        This method will query on '{targetPlatformId}.EVENTS.{EVENT_ID}'. This will return one record or emtpy list.
        :param dict event: An API Gateway event object
        :param dict context: AWS Lambda Context Object
        :return: JSON with status code and body
        """
        deal_ref_id = self.path_params.get("dealRefId")
        event_id = self.path_params.get("eventId")
        target_platform_id = self.query_string_params.pop("targetPlatformId", "DTC")

        self.log.bind(
            dealRefId=deal_ref_id,
            eventId=event_id,
        )

        # TODO Remove this when all error messages will be in same format
        event["new_error_message"] = True
        invalid_path_params = [
            path for path in ["dealRefId", "eventId"] if not self.path_params.get(path)
        ]

        validator = ExistingDealValidator(
            event,
            deal_ref_id,
            new_error_message=True,
            path_parameters=invalid_path_params,
        )
        validator.validate_api_version(self.request_api_version)

        self.validate_query_string_params(validator)

        db = DynamoDbHelper(
            region=Env.AWS_REGION, table_name=DealDataParameters().db_name
        )

        deal_component = f"{target_platform_id}.EVENTS.{event_id}"
        db_record = db.query_db_pk_sk(deal_ref_id, deal_component)
        if not db_record:
            validator.generate_error_message(
                "dealComponent",
                ErrorMsgs.invalid_event_id.format(
                    event_id=event_id, deal_ref_id=deal_ref_id
                ),
                indicator="invalid_data",
            )
            validator.generate_data_property_errors_message()
            error = validator.validation_errors
            raise BadRequestError(error)

        db_record = self.generate_schema_filtered_response(db_record)
        self.log.info(InfoMsgs.received_data_from_db.format(operation=self.operation))

        return {
            "statusCode": HTTPStatus.OK,
            "body": json.dumps(db_record, cls=common.decimal_decoder()),
            "headers": self.response_headers,
        }

    @GetLambda.catch_exceptions
    @GetLambda.is_handler
    def get_events(self, event, context):
        """
        This method will query on '{targetPlatformId}.EVENTS.{EVENT_ID}' and can take filters as query string parameters and use it on
        this queried dealComponent key. If the parameters are provided they are used to filter dict items based on all
        the filters provided, else if no query parameters are provided it returns all the events for that dealRefId.
        :param dict event: An API Gateway event object
        :param dict context: AWS Lambda Context Object
        :return: JSON with status code and body
        """
        deal_ref_id = self.path_params.get("dealRefId")
        target_platform_id = self.query_string_params.pop("targetPlatformId", "DTC")

        self.log.bind(
            dealRefId=deal_ref_id,
            queryStringParameters=self.query_string_params,
        )

        # TODO Remove this when all error messages will be in same format
        event["new_error_message"] = True
        path_params = ["dealRefId"] if not deal_ref_id else []

        validator = ExistingDealValidator(
            event, deal_ref_id, new_error_message=True, path_parameters=path_params
        )
        validator.validate_api_version(self.request_api_version)

        self.validate_query_string_params(validator)

        db = DynamoDbHelper(
            region=Env.AWS_REGION, table_name=DealDataParameters().db_name
        )
        key_expression = Key("dealRefId").eq(deal_ref_id) & Key(
            "dealComponent"
        ).begins_with(f"{target_platform_id}.EVENTS")
        filter_expression = (
            reduce(And, ([Attr(k).eq(v) for k, v in self.query_string_params.items()]))
            if self.query_string_params
            else None
        )

        db_records = db.query_items(
            key_expression=key_expression, filter_expression=filter_expression
        )
        db_records = self.generate_schema_filtered_response(db_records)
        status_code = HTTPStatus.OK if db_records else HTTPStatus.NOT_FOUND

        self.log.info(InfoMsgs.received_data_from_db.format(operation=self.operation))

        return {
            "statusCode": status_code,
            "body": json.dumps(db_records, cls=common.decimal_decoder()),
            "headers": self.response_headers,
        }

    @ProducerLambda.catch_exceptions
    @ProducerLambda.is_handler
    def post_events(self, event, context):
        """
        This method will post on 'DTC.EVENTS.{EVENT_ID} use it on this posted dealComponent key.
        :param dict event: An API Gateway event object
        :param dict context: AWS Lambda Context Object
        :return: JSON with status code and body
        """
        deal_ref_id = self.path_params.get("dealRefId")

        self.log.bind(
            dealRefId=deal_ref_id,
        )

        event["new_error_message"] = True
        path_params = ["dealRefId"] if not deal_ref_id else []

        validator = ExistingDealValidator(
            event, deal_ref_id, new_error_message=True, path_parameters=path_params
        )

        validator.validate_body()
        validator.validate_api_version(self.request_api_version)

        body = json.loads(event.get("body") or "{}", parse_float=Decimal)
        self.log.info(InfoMsgs.body_received.format(body=body))

        body = self.generate_schema_filtered_payload(data=body)

        event_id = body.get("eventId", str(uuid.uuid4()))
        target_platform = body.get("eventKeyData").get("targetPlatform", "DTC")
        deal_component = f"{target_platform}.EVENTS.{event_id}"

        current_time = datetime.isoformat(datetime.utcnow())

        body.pop("payload", None)
        if not body.get("eventDetailHref"):
            body.pop("eventDetailHref", None)
        body.pop("payloadSchemaHref", None)
        body["eventIdInbound"] = body.pop("eventId")
        body.update(
            {
                "dealRefId": deal_ref_id,
                "dealComponent": deal_component,
                "ttl": validator.stored_ttl or common.SingleTTL().general_ttl(),
                "createdTimestamp": current_time,
                "updatedTimestamp": current_time,
            }
        )
        self.log.info(InfoMsgs.body_to_be_sent.format(body=body))
        db = DynamoDbHelper(
            region=Env.AWS_REGION, table_name=DealDataParameters().db_name
        )
        try:
            db.update_item(
                partition_key="dealRefId",
                sort_key="dealComponent",
                update_record=body,
                condition_expression=Attr("dealComponent").not_exists(),
            )
        except ClientError as error:
            if error.response["Error"]["Code"] == "ConditionalCheckFailedException":
                validator.generate_error_message(
                    "dealComponent",
                    ErrorMsgs.duplicate_event_record,
                    indicator="invalid_data",
                )
                validator.generate_data_property_errors_message()
                error = validator.validation_errors
                return_body = eval(str(error))
                return {
                    "statusCode": HTTPStatus.BAD_REQUEST,
                    "body": json.dumps(return_body),
                    "headers": self.response_headers,
                }
            raise Exception(error)
        self.log.info(InfoMsgs.post_event)
        return {
            "statusCode": HTTPStatus.CREATED,
            "body": json.dumps({"dealRefId": deal_ref_id, "eventId": event_id}),
            "headers": self.response_headers,
        }

    @ProducerLambda.catch_exceptions
    @ProducerLambda.is_handler
    def patch_events(self, event, context):
        """
        Handles the Event PATCH on 'DTC.EVENTS.{EVENT_ID}
        :param dict event: An API Gateway event object
        :param dict context: AWS Lambda Context Object
        :return: JSON with status code and body
        """

        deal_ref_id = self.path_params.get("dealRefId")
        event_id = self.path_params.get("eventId")
        self.log.bind(
            dealRefId=deal_ref_id,
            eventId=event_id,
        )

        event["new_error_message"] = True
        invalid_path_params = [
            path for path in ["dealRefId", "eventId"] if not self.path_params.get(path)
        ]

        validator = ExistingDealValidator(
            event,
            deal_ref_id,
            new_error_message=True,
            path_parameters=invalid_path_params,
        )

        validator.validate_body()
        validator.validate_api_version(self.request_api_version)
        body = json.loads(event.get("body") or "{}", parse_float=Decimal)
        target_platform = body.pop("targetPlatform", "DTC")
        deal_component = f"{target_platform}.EVENTS.{event_id}"

        self.log.info(InfoMsgs.body_received.format(body=body))

        body = self.generate_schema_filtered_payload(data=body)

        current_time = datetime.isoformat(datetime.utcnow())

        body.update(
            {
                "dealComponent": deal_component,
                "dealRefId": deal_ref_id,
                "ttl": validator.stored_ttl or common.SingleTTL().general_ttl(),
                "updatedTimestamp": current_time,
            }
        )

        self.log.info(InfoMsgs.body_to_be_sent.format(body=body))

        db = DynamoDbHelper(
            region=Env.AWS_REGION, table_name=DealDataParameters().db_name
        )
        try:
            db.update_item(
                partition_key="dealRefId",
                sort_key="dealComponent",
                update_record=body,
            )
        except ClientError as error:
            if error.response["Error"]["Code"] == "ConditionalCheckFailedException":
                validator.generate_error_message(
                    "dealComponent",
                    ErrorMsgs.invalid_event_id.format(
                        event_id=event_id, deal_ref_id=deal_ref_id
                    ),
                    indicator="invalid_data",
                )
                validator.generate_data_property_errors_message()
                error = validator.validation_errors
                return {
                    "statusCode": HTTPStatus.BAD_REQUEST,
                    "body": json.dumps(error),
                    "headers": self.response_headers,
                }

        self.log.info(InfoMsgs.patch_event_on_db)

        return {
            "statusCode": HTTPStatus.NO_CONTENT,
            "body": None,
            "headers": self.response_headers,
        }

    @ProducerLambda.catch_exceptions
    @ProducerLambda.is_handler
    def post_lender_decision(self, event, context):
        """
        Handles the Event Post for lender decision on 'CD.{LENDER_ID}.{CREDIT_APP_ID}
        :param dict event: An API Gateway event object
        :param dict context: AWS Lambda Context Object
        :return: JSON with status code and body
        """
        deal_ref_id = self.path_params.get("dealRefId")
        credit_app_id = self.path_params.get("creditAppId")

        self.log.bind(
            dealRefId=deal_ref_id,
            creditAppId=credit_app_id,
        )

        event["new_error_message"] = True
        invalid_path_params = [
            path
            for path in ["dealRefId", "creditAppId"]
            if not self.path_params.get(path)
        ]
        validator = ExistingDealValidator(
            event,
            deal_ref_id,
            new_error_message=True,
            path_parameters=invalid_path_params,
        )
        common.verify_ulid(credit_app_id, "creditAppId", validator)
        validator.validate_body()
        validator.validate_api_version(self.request_api_version)
        validator.validate_reference_ids({"creditAppId": credit_app_id})

        lender_decision_payload = json.loads(event["body"], parse_float=Decimal)
        self.log.info(InfoMsgs.body_received.format(body=lender_decision_payload))

        # validating lenderId is in body so we can use for dealComponent
        lender_id = lender_decision_payload.get("lenderId")
        if not lender_id:
            validator.generate_error_message(
                "lenderId",
                ErrorMsgs.missing_lender_id,
                "missing_data",
            )
            validator.generate_missing_property_errors_message()
            raise BadRequestError(validator.validation_errors)

        deal_component = f"CD.{lender_id}.{credit_app_id}"
        current_time = datetime.isoformat(datetime.utcnow())
        lender_decision_payload.update(
            {
                "dealRefId": deal_ref_id,
                "dealComponent": deal_component,
                "ttl": validator.stored_ttl or common.SingleTTL().general_ttl(),
                "createdTimestamp": current_time,
                "updatedTimestamp": current_time,
            }
        )

        self.log.info(InfoMsgs.body_to_be_sent.format(body=lender_decision_payload))

        db = DynamoDbHelper(
            region=Env.AWS_REGION, table_name=DealDataParameters().db_name
        )
        db.table.put_item(Item=lender_decision_payload)

        self.log.info(InfoMsgs.post_lender_decision)

        return {
            "statusCode": HTTPStatus.CREATED,
            "body": json.dumps({"message": "Lender decision posted"}),
            "headers": self.response_headers,
        }

    def validate_query_string_params(self, validator):
        """
        :param validator: validator class instance
        raises error if any of the filter key doesn't exist in allowed list
        """
        try:
            if self.query_string_params:
                assert all(
                    key in GET_EVENTS_FILTER_PARAMS for key in self.query_string_params
                ), validator.generate_error_message(
                    "queryParameters",
                    ErrorMsgs.error_unsupported_events_filter.format(
                        filters=GET_EVENTS_FILTER_PARAMS
                    ),
                    "invalid_query_params",
                )
        except AssertionError:
            validator.generate_invalid_query_param_errors_message()
            raise BadRequestError(validator.validation_errors)

    def generate_schema_filtered_response(self, records: list):
        """
        Extract schema for corresponding schema type and filters all the keys not present in the schema.
        :param records: data in the list
        :return: list of filtered data
        """
        schema_type = SchemaType.get_schema_name("EVENT")
        schema = utils.schema.get_schema(self.request_api_version, schema_type)
        response_data = [
            {field: record[field] for field in schema if field in record}
            for record in records
        ]
        return response_data

    def generate_schema_filtered_payload(self, data):
        """
        Function to drop additional fields from payload which are not part of schema
        :param data: payload that is received
        :return: json object with fields which are part of schema
        """
        schema_type = SchemaType.get_schema_name("EVENT")
        schema = utils.schema.get_schema(self.request_api_version, schema_type)
        data = {field: data[field] for field in schema if field in data}

        self.log.info(f"Payload after removing additional fields if present: {data}")
        return data


def events_handlers(event, content):
    if (
        event.get("headers", {}).get(settings.HEALTHCHECK_HEADER_FIELD)
        == settings.HEALTHCHECK_HEADER_VALUE
    ):
        return {"statusCode": HTTPStatus.OK, "body": json.dumps("Operational")}

    operation = event.get("requestContext").get("operationName")
    events_lambda = EventsLambda(operation=operation)

    routes = {
        "post_event": events_lambda.get_handler(handler_func="post_events"),
        "get_event": events_lambda.get_handler(handler_func="get_event"),
        "get_events": events_lambda.get_handler(handler_func="get_events"),
        "patch_event": events_lambda.get_handler(handler_func="patch_events"),
        "post_lender_decision": events_lambda.get_handler(
            handler_func="post_lender_decision"
        ),
    }

    handler_function = routes.get(operation)

    return handler_function(event, content)
