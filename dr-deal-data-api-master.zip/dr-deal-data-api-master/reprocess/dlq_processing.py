# -*- coding: utf-8 -*-
from datetime import datetime
from http import HTTPStatus

import boto3
from common.deal_consumer import ConsumerLambda
from common.settings import S3_DLQ_OBJECT_KEY_TEMPLATE, Env
from pytz import timezone


class DlqProcessingLambda(ConsumerLambda):
    def __init__(self):
        super().__init__()
        self.s3_client = boto3.client("s3", region_name=Env.AWS_REGION)
        self.time_stamp = datetime.isoformat(datetime.now(timezone("EST")))

    @ConsumerLambda.is_handler
    def handle(self, event: dict, context: dict):
        """
        Handles messages from DealDataDLQ to save into s3 bucket reprocessing_garage

        :param event: An SQS event object
        :param context: AWS Lambda Context Object
        :return: JSON with status code
        """
        try:
            self.log.info(
                f"Beginning process to move message from {Env.DEAL_DATA_DLQ} to s3 bucket {Env.REPROCESSING_GARAGE}"
            )
            msg_key = self.generate_reprocessing_garage_bucket_key()
            msg_tags = self.generate_reprocessing_garage_bucket_tags()

            # Adding msg_group_id as a tag so that it will be reprocessing API independent and controlled by Application
            msg_tags = f"{msg_tags}&msg_group_id={self.sqs_msg['attributes']['MessageGroupId']}"

            self.log.bind(
                payloadType=self.payload_type,
                correlationId=self.correlation_id,
                dealRefId=self.deal_ref_id,
                body=self.body,
                bucketKey=msg_key,
                bucketTags=msg_tags,
            )

            self.s3_client.put_object(
                Body=self.body,
                Bucket=Env.REPROCESSING_GARAGE,
                Key=msg_key,
                Tagging=msg_tags,
                ContentType="txt",
            )
            self.log.info(
                f"DLQ message stored successfully to s3 bucket: {Env.REPROCESSING_GARAGE}"
            )
            return {"statusCode": HTTPStatus.CREATED}

        except Exception as error:
            self.log.exception(
                f"Saving dlq message to reprocessing garage failed: {str(error)}"
            )
            raise error

    def generate_reprocessing_garage_bucket_key(self):
        """
        This method generates s3 object key for dlq messages
        :return: s3 object key
        """

        return S3_DLQ_OBJECT_KEY_TEMPLATE.format(
            dlqName=Env.DEAL_DATA_DLQ,
            dealRefId=self.deal_ref_id,
            timestamp=self.time_stamp,
            content_type="txt",
        )

    def generate_reprocessing_garage_bucket_tags(self):
        """
        This method extract s3 object tags for dlq messages from msg_attrs and appends the storage region to it
        :return: string of key value pair in querystring format
        """
        tags = []
        msg_attrs = vars(self.msg_attrs)
        msg_attrs["x-aws-region"] = Env.AWS_REGION
        for key, value in msg_attrs.items():
            tags.append(f"&{key}={value}") if tags else tags.append(f"{key}={value}")

        return "".join(tags)


handler = DlqProcessingLambda.get_handler()
